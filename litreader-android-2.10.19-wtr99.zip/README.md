# YueDu

A dark-themed reader for web novels, light novels, manga, manhua and manhwa
(library, reader + comic reader, per-source browse/search, history, updates feed, comments, TTS,
music, save-data export/import). Ships as a Perchance generator, and is also
packaged into a WebView app.

Start here if you're a new agent picking this project up.

## Current version — 2.20.0 (build wtr99)

**Four new comic sources: Nyx Scans, MangaKIO, MangaOwl and MangaDotNet.** All four bring latest feeds, search, full book details with chapter lists, and chapters — MangaKIO's guarded pictures route through the image loader (or the Android app) like the other Referer-guarded sources. MangaDotNet books get their synopsis, author and tags from the site's own data feed, its adult titles stay out of this normal source, and its health check asks the site's API instead of the bot-walled homepage. MangaOwl chapters only count real chapter pictures, so a stub page fails honestly instead of showing a cover as a one-page chapter.

## Previous — 2.20.0 (build wtr98)

**YueDu everywhere, and voices you can tell apart.** Every trace of the old LitReader name is gone: UI strings, changelogs, saved-data keys (your library, settings and downloads migrate over on their own), the Android package and bridge, and the docs. The old app and the new one install side by side, so export a backup in the old app first and import it in the new one. Read-aloud voices are now grouped — Women, Men, Other — with clean names instead of engine gibberish, in both the reader panel and Reading settings. Also: the image-loader worker was renamed to match, so redeploy `src/image-proxy/worker.js`.

## Previous — 2.20.0 (build wtr97)

**Sources open at the very top, and the Library stops counting sources.** Tapping a source pins the feed to the top — including a beat later, when late-arriving genre chips used to drag it down — so it can never land scrolled down. The Library's Normal and 18+ rows drop the source counts they copied from Browse (Browse keeps them — that's where sources live); the Library keeps its book counts.

## Previous — 2.20.0 (build wtr96)

**Slow-connection notices get specific, and the update log catches up.**
The connection popup now names what is actually struggling (failing hosts,
longest waits, requests still trying) instead of blaming your signal for
everything, gains a Details button that opens the Error console directly,
and pops up far less often while merely slow — the top pill keeps watch
instead. The in-app update log was also missing everything since October, so
it now covers all of it: per-medium scroll settings, four more comic
sources, the remembered save folder, tap shields and delete confirms, the
real updater with its banner, the Kotatsu-plain Updates screen, the
library search switch, smooth comic strips with settings-housed debug, and
the rewritten global search.

## Previous — 2.20.0 (build wtr95)

**Global search actually finishes now — and shows its work.** It used to
ask two sources at a time, wait for every one of the 90+ ticked sources, and
show nothing until the slowest answered (a single hanging source meant a dead
spinner for minutes, then quitting). Now it searches six sources at once,
caps each source at 30 seconds so a dead one can't hold the rest hostage,
and paints each source's section the moment it answers under a live
"Searching 12/94… 40 results so far" header, ending with a per-source count
and the total time. Retrying or clearing mid-search cleanly drops the old
run. Your ticked sources are remembered across restarts, and the 18+ vault's
source chips are tickable too.

## Previous — 2.20.0 (build wtr94)

**Library search grows a mode switch, comics read smoother, and page debug
moves into Reading settings.** The search bar's magnifier is now a button:
tap it to choose Normal (the quick box) or Advanced (the full criteria sheet
— now offered for novels too, not just comics). While advanced filters are
active the button wears a dot next to the result count; the old standalone
Advanced button is gone. Comic pages now size their placeholders to the
shimmer height, so strips no longer jump as pictures land, and the "Still
loading N/M pages" strip plus the per-page Debug buttons are gone from the
page flow — page debug now lives at the bottom of the comics card in Reading
settings, visible and copyable with its own Copy debug button.

## Previous — 2.20.0 (build wtr93)

**Updates screen goes Kotatsu-plain.** The changelog box is gone: the
Updates screen is now a plain page like Kotatsu Redo's AppUpdate screen —
centered icon, version title, size line, free-flowing notes, and a docked
bottom bar with text-style Later on the left and the accent Update button on
the right. The thin progress bar sits above the buttons while downloading,
then the button flips to Install. Long notes scroll inside their own area so
the buttons never scroll away; the up-to-date and error states use the same
plain layout.

## Previous — 2.20.0 (build wtr92)

**In-app updates, Kotatsu-style.** The Updates tab is now a real updater:
version title, download size, the FULL changelog in a scrollable list,
Later + Update buttons, and a progress bar while the new version downloads.
On Android the download runs through the system DownloadManager and the
installer opens itself when it finishes (the button becomes Install if you
miss it); other builds download the APK in-page with progress and open the
file to install. A `New update` banner now appears on every screen at
launch, with Later (snoozes 7 days) and Update (opens the Updates tab).
Manifest gains an optional `apkSize` (bytes) — see
`scratch/yuedu-console-update-spec.md` for the console AI. Native bridge
grows `apkProgress` (pollable download state) and `apkInstall` (re-open the
installer).

## Previous — 2.20.0 (build wtr91)

**Taps land where you tap, and deletes ask first.** Buttons use a fast
tap handler, so the delayed click that follows a tap used to fall through a
just-closed dialog onto whatever was behind it (opening a book behind Later,
etc.). Closing the folder or confirm dialog now raises a brief invisible
shield that absorbs that ghost tap. Deletes are no longer one-tap: removing
a downloaded chapter/episode, deleting a title's downloads, clearing all
downloads, and the row-arrow remove toggle all ask in a centered Keep/Delete
dialog first. Your library entries are never touched — only downloaded files.

## Previous — 2.20.0 (build wtr90)

**The save folder remembers you, and finds itself after a reinstall.** The
fixed on-device `YueDu` folder (backups, save-data exports) asked every
session in the browser build and forgot everything on a data wipe. Now the
picked folder's handle is kept in IndexedDB and silently re-granted, so
exports go straight there with no dialog; if the handle goes stale, the
export still downloads via the browser and the dialog reopens once with a
"one tap to reconnect" message. On Android the bridge grew `folderProbe`:
after an uninstall/reinstall or a data erase, the app checks
`Download/YueDu/` and, finding your old files, switches itself back to folder
mode without asking. (w89, unshipped: the dialog itself, the `saveFile`
bridge call, per-mode export routing and the save-screen status line.)

## Previous — 2.20.0 (build wtr88)

**Downloads for everything, and a Downloads screen.** Comic chapters and anime
episodes can now be kept on the device, just like novel chapters: every comic
row and every episode row has a download arrow, the book page has a hero
Download button (whole novel / whole series / whole anime, with Next-100/500
batch buttons in the sheet), and single episodes refuse honestly when the
episode only plays on its site. Comics store page pictures, mp4 episodes store
the file, HLS episodes store every segment plus the playlist (highest-bandwidth
variant; encrypted streams and >800 MB episodes are refused with a message
instead of hanging). Reopening a downloaded chapter/episode reads and plays
from the device with no connection — HLS plays through a rewritten local
playlist. **More → Downloads** lists every downloaded title under kind tabs
(All / Novels / Comics / Anime with counts), with progress, size and a storage
meter. Tapping a title shows its downloaded chapters or episodes — tap one to
read or watch it straight from the device, or remove single entries. Per-title
delete or wipe-everything buttons free the space. Backup
v2: export/import now sweeps every `yuedu_*` setting (deny-listed secrets
excluded) under the `YueDu` marker, so new settings survive restores; old
backups still import. YouTube-embed (video) books keep no download UI.

## Previous — 2.20.0 (build wtr87)

Rebrand: the app is now **YueDu** (joyful reading — the Play Store
lookalike shares the old YueDu name and the old black-cat art, so both
are gone). The cover everywhere (intro, about, launcher icon, store art) is
now a single white **悦** character on black, drawn as crisp text rather than
a picture. Same app, same library, same saved data (storage keys, backup
format and the update channel are untouched, so updates install over the old
version with nothing lost).

## Previous — 2.20.0 (build wtr86)

Advanced library search. The library's new **Advanced** button opens a search
sheet with a field per criterion — title (also matches alternative titles),
author, genre, tags (comma-separated, every tag must match), source (auto-built
from your shelves), shelf, last update and chapter count (min/max) — and every
filled field must match. The quick search box now matches alternative titles
too. Active advanced filters show as an "Advanced · N" chip next to the result
count, and Clear search & filters resets them. Note: "last update" filters by
last library activity (when the title was added or last read) — per-source
update timestamps are not stored, so true upstream update dates can't be
filtered yet.

## Previous — 2.20.0 (build wtr85)

Two comic sources join. **DivaScans** (Comics 18+ shelf, `divascans.org`):
manhwa in English on its JSON API — latest feed, search, full chapter lists
and direct chapter pictures (about 40% of its latest feed is flagged mature
upstream, so the whole source sits behind the 18+ gate). **Webtoons English**
(Comics tab, `webtoons.com`): official WEBTOON Originals with popular,
trending and originals feeds, search, full episode lists and chapter pictures
(Naver's image CDN refuses every proxy and datacenter egress, so pictures
need the Android app's image bridge and covers show as title art until they
load — both flagged for the phone check). **MangaCloud** skipped: its whole
JSON API answers 409 Conflict to every automated route (Cloudflare Turnstile
on `mangacloud.org`, upstream Kotatsu parser unchanged at HEAD) — it needs an
in-app site-check flow before it can be wired.

## Previous — 2.20.0 (build wtr84)

Two comic sources join. **Arc-Relight** (Comics tab, `arc-relight.com`): sci-fi
doujinshi in English on its JSON API — latest feed, search, full chapter lists
and direct chapter pictures. **HotComics** (Comics 18+ shelf): latest feed,
search, full chapter lists and direct chapter pictures (adult-only catalogue).
Also fixed: opening Appearance now paints its swatch rows (the screen used to
open empty, so themes looked unchangeable), and the app background defaults
back to Pure black with Kotatsu gray still one tap away in Appearance.

## Previous — 2.20.0 (build wtr83)

Browse keeps your place now: opening a source remembers the list position and
puts you back there on exit, instead of the top. Novels and comics glide
separately — auto-scroll, scroll speed and swipe speed are per-medium settings
(the comic reader also always uses its own touch rules), while anime keeps its
own Episode settings as before. The app background defaults to Kotatsu gray,
with the old blacks still one tap away in Appearance.

## Previous — 2.20.0 (build wtr82)

Repair build. **OmegaScans** chapter pictures now fall back to the in-app
bridge with the site referrer when a direct load fails (one picture in Sex
Stopwatch ch1 kept dying with no recovery path — same fix class as
StoneScape/Project Suki). **AllManga** leaves the Comics tab again: its
reader gate kept blocking chapters on every route the app owns.

## Previous — 2.20.0 (build wtr81)

Three comic sources join in this build. **MangaGo** (Comics tab,
`mangago.me`): latest feed, search, full chapter lists and chapter pictures
decrypted in-app — AES + batch pages, scrambled pictures rebuilt too.
**OmegaScans** (Comics 18+ shelf, adult-only catalogue): latest feed, search,
full chapter lists and direct chapter pictures on its own JSON API.
**AllManga** rejoins the Comics tab per user request (removed in wtr80):
same GraphQL catalogue + reader-check token flow as before. The wtr80 batch
is also in this build: AllManga removal undone by the rejoin, app-exit lock
fix, 520→510 layout, browse totals, reader Copy-debug row, in-app Updates
tab with download, white-outline cat art everywhere (intro, About, launcher,
cover), blue accent theme, plain-text up-to-date state, and per-kind
Normal/18+ rows visible in Library All.

## Previous — 2.20.0 (build wtr79)

No new sources in this build — one repair continued. The **AllManga**
reader check now opens inside the app: when chapter pages hit the
clearance gate, the reader offers the check screen (the same one captcha
sources use); passing it earns the cookie the token needs, and the
chapter loads on the automatic retry. **Project Suki** (fixed in wtr78)
is confirmed working on-device.

No new sources in this build — two repairs. **Project Suki** chapter
pictures now ride the native bridge with the site Referer (the 10–25 MB
gallery pages kept dying on the plain in-page routes, same fix class as
StoneScape). **AllManga** chapter pages now carry the site's reader-check
token: the app computes the AES-GCM envelope in-app, so chapters that
failed with `AA_CRYPTO_MISSING` open wherever the check clears — and say
so honestly where it doesn't.

One more comic source joins in this build, ported from Kotatsu-Redo:
**MANGA Plus** (Comics tab, official Shueisha simulpub manga in
English: hottest feed, search, full chapter lists, and chapter
pictures decrypted in-app from its protobuf API). **Lunar Manga**
could not join: its domain now serves gambling spam and no successor
domain answers with manga — send a working domain and it can be
wired.

Two more comic sources join in this build: **18PornComic** (Comics 18+
shelf, its own manga-club engine on `18porncomic.com`: latest hentai
feed, search, books with authors, artists, statuses and genres,
ascending chapter lists, base64-packed chapter pictures decoded
in-app) and **S2Read** (Comics tab, plain generic-Madara config,
`manga/` series, inline chapter lists, direct `cdn-1.s2read.com`
chapter pictures). **Hentai13** could not join: no Kotatsu-Redo parser
exists for it at the pinned commit or upstream HEAD, and no hentai13
domain resolves — send a working domain and it can be wired.

Two more comic sources join in this build, both ported from
Kotatsu-Redo: **Project Suki** (its own HTML+JSON engine on
`projectsuki.com`: homepage/browse feeds, search, books with
authors, genres and status, `callpage` chapter pictures) and
**AllManga** (the Mkissa catalogue on its GraphQL API:
latest feed, search, books with authors and statuses —
chapter pages ride the same `chapterPages` API the site's own
reader uses, with the native bridge as fallback; where the
site demands its own check first, chapters say so honestly
instead of opening empty). **GenzToon** could not join: no
Kotatsu-Redo parser exists for it and its domains don't
resolve — send a working domain and it can be wired.

Three more comic sources join in this build, all ported from
Kotatsu-Redo: **MangaEclipse** (plain generic-Madara config,
`manga/` series, inline chapter lists, same-host direct chapter
pictures), **ManhwaDen** (18+ shelf, generic-Madara config,
`manga/` series, holder-AJAX chapter lists, direct chapter
pictures from its own `remanhwa.me` image host), and
**Mangataro** (its own signed JSON API engine in the RoliaScan
family: `wp-json` latest plus search, MD5-token ascending
chapter lists, direct chapter pictures).

Manga18x is gone (its upstream picture CDN 404s everything, so the source was
deleted outright — code, cards, wiring, fallbacks and log bullets, no
user-visible trace) and three English comic sources join the Comics tab, all
ported from Kotatsu-Redo: **MangaFire** (signed JSON API: latest list, search,
full chapter lists, direct `mfcdn` pages), **EnThunderScans** (`/comics/`
mangareader catalogue; coin-locked chapters are skipped) and **GourmetScans**
(shared Madara engine; its encrypted chapter pictures are decrypted in-app,
and login-walled chapters say so instead of opening empty). MangaFire's
server-side bot wall is flaky (`keyword` search and a few titles/chapters 403
from any client, then succeed later) — retry, or check on the phone.

Three more English comic sources join in this build, all ported from
Kotatsu-Redo: **MangaFreak** (custom non-Madara engine: `h1` title,
label-read status/author, the full ascending `manga_series_list` table for
chapters, no trailing slash on `/Manga/` URLs, bridge-fetched pictures with a
`mangafreak.me` Referer), **MangaDass** (Madara flavor, 18+ shelf: `li.a-h`
chapters, plain `read-content` pictures on `img11`, card ratings from
`.my-rating`), and **MangaSushi** (plain generic-Madara config, Bh
holder-AJAX chapters, qh chapter pages).

Three more English comic sources join in this build, all ported from
Kotatsu-Redo: **ManhuaHot** (plain generic-Madara config, `manga/` series,
inline chapters, `cdn.manhuahot.com` pictures), **HiveComic** (its own JSON
API engine: `/api/query` latest + search, `/api/chapters` chapter lists,
`/api/chapter` ordered pictures on `storage.hivetoon.com`; coin-locked
chapters throw an honest unlock message instead of opening empty), and
**MangaDistrict** (generic-Madara config, 18+ shelf, `series/` series path,
`cdn.mangadistrict.com` pictures).

Two more English comic sources join in this build, both ported from
Kotatsu-Redo: **Thrive** (its own NEXT_DATA engine on `thrive.moe`:
homepage/genre/search feeds, `/title/` books, `/read/` chapters with
`cdn.thrive.moe` pictures; Indonesian) and **VortexScans** (same iken JSON
backend as HiveComic: `/api/query`, `/api/chapters`, `/api/chapter` with
ordered `storage.vortexscans.org` pictures; locked chapters stay honest).
**MangaRead** needed nothing: it has been in the app since v2.10.3 on the
generic Madara path (`mr-`, `www.mangaread.org`) and still verifies
feed → book → chapter.

Three more comic sources join in this build, all ported from
Kotatsu-Redo: **KsGroupScans** (plain generic-Madara config, `manga/`
series, holder-AJAX chapter lists, direct same-host chapter pictures),
**QiScans** (its own JSON API engine on `api.qimanhwa.com`: `/series`
latest plus `/series/search`, paged chapter lists reversed to ascending,
ordered pictures on `media.qimanga.com`; a number-0 prologue chapter is
handled, and paid chapters say they need unlocking instead of opening
empty), and **DecadenceScans** (generic-Madara config, 18+ shelf; its
chapter pages are AJAX-paginated, so chapters open with `?style=list`
and read every `page-break` picture).

One more comic source joins in this build, ported from Kotatsu-Redo:
**CloneManga** (Dan Kim's single-page comic viewer on
`manga.clone-army.org`: one catalogue, per-series chapters with one
direct picture each). **FlameComics** and **DemonicScans** needed
nothing: both were already in the app and still verify feed → book →
chapter with real pages.

Five more comic sources join in this build, all ported from
Kotatsu-Redo: **AllPornComic** and **MangaManiacs** (18+ shelf, shared
Madara engine: `porncomic/` and `manga/` series, inline and AJAX
chapter lists, direct chapter pictures) and **GdScans** (same
machinery, Comics tab) — plus **YuriBase** (18+ shelf, Indonesian
site: Firestore-backed lists with slug-prefix search, flight-JSON
chapter lists, direct chapter pictures; its old `yuribase.id` domain
now only serves a move notice, so the app uses `yuribase.top`) and
**StoneScape** (Comics tab, JSON API: latest, search, chapter lists
and direct pictures).

Two fixes ride in this build. **YuriBase cards showed text only, no
covers**: its cover URLs live under an `/banner/` path and the app's
placeholder filter drops any URL containing `banner`, so every card
was wiped to text — the filter is now skipped for YuriBase art (those
banners run ~2 MB each, so the first screen still takes a moment on a
slow pipe). **StoneScape chapters failed on-device**: its 4–5 MB
chapter pictures kept dying on the plain in-page routes, so they now
ride the native bridge with the site Referer (the same headers
Kotatsu sends).

Three more comic sources join in this build, all ported from
Kotatsu-Redo: **HentaiXYuri** (18+ shelf, plain generic-Madara config:
`manga/` series, archive cards, `admin-ajax.php` chapters with the
`/ajax/chapters/` fallback, same-host direct chapter pictures) and
**GeassComics** (Comics tab, its own JSON API engine on
`api.geasscomics.xyz`: latest feed plus search, chapter lists
reversed to ascending, ordered pictures on `cdn.geasscomics.xyz`;
Portuguese — the CDN answers 403 to datacenter egress, so chapters
ride the proxy in preview and go direct-or-proxy on the phone).
**EzManga** needed nothing: it has been in the app since v2.9.68 on
its own reader API and still verifies feed → book → chapter
(free chapters read directly; coin chapters say so honestly).

Four more comic sources join in this build, all ported from
Kotatsu-Redo: **RoliaScan** (its own signed JSON API engine:
`wp-json` latest plus search, MD5-token chapter lists, direct
chapter pictures), **DankeFursLesen** (its own Guya API engine:
full 656-title catalogue with client-side search, direct chapter
pictures), **Tritinia** (plain generic-Madara config, `manga/`
series; chapters open with `?style=list`), and **GedeComix**
(18+ shelf, generic-Madara config, `porncomic/` series).
**KewnScans** could not join: its domain is dead upstream (nginx
404 on every route), so there is nothing to wire — same call as
Manga18x. **GeassComics** leaves the app: Portuguese-only, so all
of its wiring, engine and log lines are removed with no
user-visible trace.

The app reports **v2.19.9**, matching the newest update-log entry (the old 2.10.19 label pin is lifted). Version numbers now follow a cap-10 scheme (patch 0–10, then minor+1): all 215 existing update-log entries were renumbered chronologically oldest→newest into 2.0.0–2.19.5, and all 71 source version pills were remapped to match, so every pill still links to a real entry and newer stays higher. The 2.19.9 entry below adds Hanime (18+ hentai catalogue with direct HLS streams, the Nekoyomi extension way) and removes HiAnimeTV (its episode pages only ever showed the site itself instead of the anime). The 2.19.8 entry below had fixed HiAnimeTV playback by embedding the episode page; 2.19.7 had added HiAnimeTV as a normal subbed-anime source; 2.19.6 covers the HentaiHaven retry hardening. Code = 2.10.23 function set (ten-row chapter window, page scroll, sticky header, nav clearance, scoped checks, pills+favorites). wtr45: book pages open at the top (no more auto-jump to the current chapter), the Continue strip is gone, and the title you are reading pins itself to the very top of the Library list. wtr46: the Because-you-read suggestion row is gone too — the Library just shows the books, most-read first.
Also in this build (wtr37): Hanime handshake signature fix — the signature was missing a comma (server answered 422). wtr36 had: handshake reply binary flag (was "native status ?"). wtr35 had: Hanime added + HiAnimeTV removed (page wiring plus native bridge returning response headers). wtr34 had: HiAnimeTV episode-embed fix. wtr33 had: HiAnimeTV source added. wtr32 had: native bridge reports declared body length so truncated reads retry instead of poisoning the player. Page-side: fragment retries with backoff, error-page sniffing.
(Note: history below was written under the old un-capped numbers; the in-app log holds the renumbered record.)

## Previously — 2.19.5 (was 2.10.23; 2026-10-24, code only — label reverted to 2.10.19 before shipping)

The app is on **v2.10.23** — *ten-row chapter window*. The chapter list is a fixed ten-row window again with its own scroll and no chapter cap: the book page scrolls down to it and stops there, and everything past chapter 10 lives inside the list's own scroll — however many chapters the novel, comic or anime has. The list auto-loads as you scroll inside it, and the header stays pinned while the page moves.
Also in this version (build wtr30): page-side only, no native changes — the tag only proves the new page bundle is installed.

## Previously — 2.10.22 (2026-10-24)

The app is on **v2.10.22** — *bounded book page*. The book/hero page no longer extends itself as you scroll: it opens with the first batch of chapters, and further batches load only when you tap Show more — so even very long novels stay a manageable page length instead of growing without end. The reader's chapter picker still auto-loads as before.
Also in this version (build wtr29): page-side only, no native changes — the tag only proves the new page bundle is installed.

## Previously — 2.10.21 (2026-10-24)

The app is on **v2.10.21** — *book page scrolls as one*. The book/hero page no longer traps the chapter list in its own small scrolling box: hero, synopsis, Related and chapters scroll together as one page under a sticky header, so a long synopsis or a tall Related row cannot squeeze the list down to a few rows. The auto-load on scroll and the bottom-bar clearance carry over — the auto-load observer now watches the page scroll instead of the old inner box, and list rebuilds (filter, sort, new arrivals) keep your place on the page.
Also in this version (build wtr28): page-side only, no native changes — the tag only proves the new page bundle is installed.

## Previously — 2.10.20 (2026-10-24)

The app is on **v2.10.20** — *scoped checks + chapter list room*. Browse now checks only the tab you open: opening Anime checks the anime sources instead of all 60+ at once, so Novels and Comics no longer slow it down (verified live: 35 novel checks, 0 comic, 0 anime with the Novels tab open). Pull-to-refresh still checks everything. Also, the chapter list on book pages now always keeps its own scrolling space with a limit and ends above the bottom bar instead of sliding under it — synopsis and Related no longer squeeze it out.
Also in this version (build wtr27): page-side only, no native changes — the tag only proves the new page bundle is installed.

## Previously — 2.10.19 (2026-10-23)

The app is on **v2.10.19** — *source versions + favorites*. Every source card in Browse now wears a small version pill naming the last app version that added or fixed that source — freshly-touched sources read high (like v2.10.18), long-untouched ones read low. The versions were read off the update log, so they stay honest. Also new: tap the star on any source card to pin it under a ★ Favorites row at the top of Browse. Favorites survive restarts and follow the same Show-tabs, language and search filters as the rest of the list.
Also in this version (build wtr26): page-side only, no native changes — the tag only proves the new page bundle is installed.

## Previously — 2.10.18 (2026-10-22)

The app is on **v2.10.18** — *anime loading header removed*. The episode screen no longer shows the duplicate black-box header (Episode N / title / Loading…) under the Episode N + Sub/Dub row — that row stays the single header, with the loading spinner and stream status directly under the video. Follow-up, same version: after the episode loads, that same header stays above the player instead of vanishing, and tapping outside the video brings the reader header and footer back like the loading screen does. Player overlay (play, seek, settings, double-tap) untouched. Also in this version: the inline player chrome goes compact — smaller buttons and slimmer bars so the episode stays visible under the overlay, while fullscreen keeps the full-size controls. Also in this version: the stuck “Loading video…” veil is fixed — episodes try to play at once, and the loading cover lifts the moment the video is actually ready (with an honest Ready status if autoplay was blocked) instead of spinning until tapped; dead streams still report unreachable. Landscape video can no longer sit off-center: the watching reader body clips horizontal overflow, so a sideways page shift can never make the left gap smaller than the right. Also in this version: the watching screen pins itself centered — any sideways shift is reset at once and on open, so the video can't sit off-center. Also in this version: full-screen landscape controls grow up — play, previous/next, top-bar buttons, episode title and seek bar are all bigger, YouTube-style for phones held sideways; the inline portrait player is unchanged. Also in this version: the big controls are pinned to the full-screen state itself (and the compact sizes to upright portrait only), so sideways playback is always big. Also in this version: the center play trio sits dead-center on the screen (88px play, 60px sides) instead of following the video box, the lock screen returns upright with an open episode re-pinned to landscape on Unlock, and the slow-connection pill sits below the status bar. Also in this version: the top-right Episodes/settings buttons answer again (the list button called the wrong handler, and both sheets ride into the fullscreen layer while open), and the pink seek slider sits flush at the bottom with the fullscreen button above it. Also in this version: the bottom block floats well clear of the screen edge so the slider stays readable, and all bottom sheets slide up as floating rounded boxes instead of edge-to-edge panels. Also in this version: leaving fullscreen drops straight to portrait, and vertical swipes on the video show volume/brightness bars (hardware volume keys mirror into the same bar). Also in this version: the volume/brightness bar moved off the center play button to the screen sides (volume left, brightness right), AnimeGG lists its own score-first order as Top rated anime instead of mirroring Anikage, watched progress syncs across both anime tabs, and the lock blanks the recents card the moment focus leaves with every return re-locking. Also in this version: the volume bar moved to the left edge and brightness to the right, AnimeGG shows its real site icon, every failure screen carries a Copy debug button with route logging, and AI wording left the update log. Also in this version: AnimeGG episodes open faster (title lookups fan out in parallel with no half-second gaps, the series page and episode links are remembered so repeat visits skip fetches, the next episode starts resolving in the background) and Copy debug always pastes the real debug text instead of unavailable. Also in this version: WTR Lab reader requests show up in Copy debug too (including bot-check answers instead of a misleading zero length), and Try again asks the server for a fresh attempt instead of replaying the identical request. Also in this version: WTR Lab chapters read the reply whatever key it arrives under (some novels answer under a chapter node instead of data), and Copy debug names the reply keys and pending-task count. Also in this version: Copy debug opens the reply one level deeper (fields inside the data and chapter nodes), so a present-but-bodiless answer can finally be told apart from a real body. Also in this version: WTR Lab chapters hunt the paragraphs anywhere in the reply (deep scan past odd keys, genre/task lists skipped, sealed bodies still decrypted, raw Chinese still called raw). Also in this version: bare-string bodies under a data key are picked up too, and Copy debug spells out what the nested data field is. Also in this version: Copy debug stamps the build tag and the exact on-screen error line, so a paste alone tells which build failed and what it said. Also in this version: a failed chapter's automatic retry only fires while that chapter is still open — opening a different chapter mid-countdown no longer drags the reader back to the failed one. Also in this version: WTR Lab AI-tab translations load in the reader — when the reply carries no text but points at its content file, the app follows that pointer and decrypts the AI English exactly like the site does. Also in this version: WTR Lab chapters try every translation service automatically — when the AI tab has no English the reader asks the Web+ tab too before reporting no translation. Also in this version: exiting a chapter or episode always lands on that title's hero page first (title, cover, chapter/episode list) instead of dropping to the feed or library. Also in this version: loading states are alive — covers shimmer while the image loads (the dead "No cover" label only shows when the image truly failed), comic pages show a shimmering placeholder with a spinner instead of dark blanks, and opening a chapter shows skeleton text lines under the spinner. Applied identically to the three shipped files. Also in this version (build wtr15): HentaiHaven joins as an 18+ anime source behind a new Anime 18+ gate — Popular/Trending/Latest feeds, ranked-list search, hero with episodes, direct-HLS playback. Also in this version (build wtr16): refused episode streams show their reason with Try again + Copy debug instead of a stuck play box, a Site player button opens the HentaiHaven watch page in-app as a fallback, and Episode 1: Episode 1 style titles collapse to just Episode 1.
Also in this version (build wtr17): HentaiHaven video fragments carry the site as Referer/Origin on every host, and Copy debug on a failed stream names the exact fragment plus the loader's reason.
Also in this version (build wtr18): the native bridge decides binary-vs-text by file extension too, fixing media files served under a playlist content-type (HentaiHaven's audio init).
Also in this version (build wtr19): the native bridge silently retries a truncated download once on a fresh connection instead of failing the chapter or episode.
Also in this version (build wtr20): subtitle files pass the bridge loader (only playlists need the playlist marker) and the player prefers English subs.
Also in this version (build wtr21): HentaiHaven Episode settings lists the embedded subtitle languages (English pre-selected) and the player keeps that choice, the text bridge decodes subtitle files that arrive as bytes, and the native bridge treats disguised .html segments as binary and subtitle files as text — second opens no longer die with fragLoadError native-empty-body.
Also in this version (build wtr22): HentaiHaven subtitles actually render (hls.js fetches direct .vtt tracks as playlists and fails, so the player now fetches the chosen language itself and attaches it as a sidecar track; subtitle errors can no longer kill playback) and stalls heal themselves (media pieces the old native bridge mangles now fall back to a direct fetch). Page-side: works even before the app rebuild.
Also in this version (build wtr23): Browse keeps its own Show-tabs pick and its own scroll position — tapping Novels/Comics/Anime in Browse no longer flips the Library tabs (or vice versa), switching screens restores each screen's scroll, and unlocking after backgrounding a fullscreen anime always settles back to portrait (sideways viewing is one fullscreen tap away; the portrait return needs the rebuilt APK).
Also in this version (build wtr24): HentaiHaven subtitles work the Nekoyomi way — episodes play the site's VP9 playlist (1080p, the variant the HentaiHaven extension hands its player) and English subs come from the s/en.vtt file next to the playlist. A plain remote track element cannot load that file in Chromium (proven: track ERROR, 0 cues while the same bytes load fine), so the app attaches it natively and immediately swaps in a fetched copy (bridge with Referer, direct fallback) — verified 246 cues showing on the VP9 stream. Other languages stay pickable in episode settings.
Also in this version (build wtr25): HentaiHaven subtitles stack long lines — the site's cues are each one straight line, so the player splits long ones into two balanced lines (word boundary, preferring breaks after punctuation) when it builds the track. Words and punctuation are the site's own file, byte for byte what Nekoyomi shows.

## Previously — 2.10.17 (2026-10-17)

Same version, several rounds — one clear list of everything in it:

- MangaTown + ZinManga removed (engines, Browse rows, search, feeds, covers, health checks); shelved titles answer that the source is gone with Find-on-another-source. Feed back-to-top no longer floats over the reader.
- Reaper Trans + ShojoScans join the comics (MangaStream theme / VioletScans engine, verified with real pixels); VioletScans moves to violetmanga.com, old addresses as mirrors.
- Auto-scroll stutter fixed (progress pipeline 4x/s), then smoothed further (velocity easing, guarded progress writes). Update notice = bottom sheet; developer message = thread. Portrait-only.
- Literotica joins novels (own 18+ shelf, Normal/18+ modes); labeled source-list dividers; stalled chapter lists tap-to-retry with live counts; second (usually Japanese) title on feed cards; shelf switching steps feeds back; novel screen shelf button restored; hero blurred cover photo; optional 18+ 4-digit PIN (offered, skippable, once per session, in More) with the first-offer and parking-door holes closed.
- Intro Continue hardened, then generalized: every back/close/nav/reader control answers through tapOrClick (pointerup + click, drag guard, dedup) — no more two-tap buttons.
- History renewed (cards, chip day headers, pill toolbar). HentaiForce banner syntax crash fixed.
- WTR Lab: queued translations say "still being translated", raw-only chapters say so — raw Chinese never shown as a chapter (wtrCjkRatio guard).
- Nova: "…and N more" unfolds on tap (nova.notesExpanded + toggle). Synopsis 14px / author 13.5px for the 530 layout.
- Chapter progress restored (per-row % mini-bar, Reading mark, ✓, unread count, book bar under Start Reading). Reader footer/header/nav flush via native system-inset bridge (--lit-inset-top/bottom through the 530 scale).
- This log itself rewritten: the in-app Update log lists one change per bullet.
- Follow-ups, same version: leaving a book/chapter no longer bounces back in (closing taps ignore the next half second on cards, chapters and feeds); header/footer/search/music paddings take the larger of the app inset and the browser safe-area instead of stacking both; the 18+ PIN pad answers first-tap and rapid digits each count; WTR Lab chapters decrypt without WebCrypto (built-in AES-256-GCM) and fullwidth punctuation no longer reads as raw Chinese; auto-scroll glides Kotatsu-style (constant step, short fade-in, no per-frame layout); continuous novel chapters default on; the book screen grows a Related row (same source, author/genre); the update notice and developer message ignore outside taps and close only on their own buttons; untranslated WTR Lab chapters say so without the retry loop, and the offline decryptor runs where WebCrypto is missing; the 18+ PIN now guards adult books and chapters wherever they are opened from, hides adult rows in history and updates while 18+ is off, and a fresh PIN locks at once; About re-shows the developer message on demand, and hurried double-taps stay on the hero catalog instead of falling through into a chapter; WTR Lab falls back to its older chapter route when the current one meets the bot check; WTR Lab reads QuickNovel-style now — phone-first chapter requests, a silent invisible chapter-page fallback when the API stays gated, and the dead captcha puzzle is gone; Scribble Hub follows its redesign (new card markup matched, honest "isn't answering" feed message), and the PIN Cancel plus source double-tap ghost taps are guarded; anime is back — HiAnime and AnimePahe return behind the Anime chip and AnimeGG joins them (shared AniList catalogue for search and feeds on all three, sub & dub on HiAnime/AnimeGG, sub-only on AnimePahe; episodes resolve fresh at watch time with resume and history, and streams need a home connection so the preview reports honestly while the app plays them).

- History and Updates grow up: search bar, All/Novels/Comics/Anime tabs and a genre dropdown on both screens, plus a privacy gate — opening them asks for your PIN if set, otherwise recommends one (Set a PIN / Later). Settings gains a Security and privacy tab holding the 18+ PIN (the error console has since moved out to its own Settings row — see below). Intro source count fixed at 67 (no more 50→67 flash). Applied identically to the three shipped files.
- Intro Continue no longer taps through: the click trailing the Continue tap used to land on the library card underneath (e.g. an anime cover) and walk straight into its hero catalog. A 600ms guard now swallows clicks belonging to the dismiss tap itself while letting fresh taps through. Applied identically to the three shipped files.
- Cover viewer fixed + cover download: the centered cover no longer vanishes a millisecond after opening (tap-through ghost click swallowed), and a Download pill saves the cover to the device. Applied identically to the three shipped files.
- Connection awareness for slow/no data: a centered popup ("No internet connection" / "Slow connection") with OK appears when the device goes offline or taps fail for signal reasons, plus a small status pill (Offline / Slow / Back online) that opens the popup on tap. Purely passive (no extra requests), and single-site failures never trigger it. Applied identically to the three shipped files.
- Error console for every source kind (Settings → Error console): novel, comic and anime failures land here with the exact message plus source, title and address tried — error popups, failed requests, anime player errors, chapter/episode error cards and script crashes, newest first, filterable by kind, with Copy report / per-entry copy for pasting back in chat.
- Layout is fixed at 520 CSS px (page viewport + native enforcer + inset scale all match); anime player top/bottom controls sit inside solid dark bars like the reader chrome instead of floating; the error console leaves Security and privacy for its own top-level Settings row (offline/slow-data help points there now); anime site-player episodes stay a bare iframe with no chrome (a tap-to-show top+bottom bar was tried and removed at the user's request). Anikage's chain re-verified live end to end (browse → episodes → servers → sources with subtitles; the extension's own `?lang=` stands — the site accepts `subType` too). Playback root-caused: the page fetched HLS playlists/segments with plain hls.js and no Referer (browsers forbid setting it) so bakayaro refused every file — Nekoyomi works because its extension proxies every byte with the headers attached. Fix mirrors that through our native bridge: hls now loads playlists/segments/keys with the site Referer intact (mp4s already rode the native intercept), no pre-validation burn of short-lived stream tokens, fresh resolve each watch with avoid-list failover. Applied identically to the three shipped files. Follow-up fix (same version): the first bridge loader handed hls the bridge's {status,text} wrapper object as playlist data instead of the text, so every playlist failed to parse and both Sub/Dub cycled contacting/loading into "host refused" — unwrapped now, with HTTP-status rejection, Origin sent alongside Referer, hls preferred even where the WebView claims native HLS (native playback sends no Referer), and a debug line with Copy-debug on the error card. Second follow-up: bakayaro HLS URLs look like `/m3u8/<token>` with no `.m3u8` extension, which the old `.m3u8`-only test misread as progressive mp4 (direct play, no Referer) — detection is now path-aware, and hls fatal details feed into the debug line. Third follow-up: two playback bugs — full segments were requested with `Range: bytes=0-0` (1 byte each, hence `fragParsingError`; now mirrors hls.js Range rules) and every subtitle track was set showing at once (now only the first shows). Fourth: captions had the browser's default black-box cue style — now clean white text with outline, like AnimeGG.

Applied identically to the three shipped files.

- Player round (same version): no more double subtitles — sidecar tracks are deduped by URL and exactly one shows (re-asserted when late tracks arrive; HLS manifest subs yield to sidecars and only play when there are none); landscape bars drop to 45% black with a smaller control set (34px buttons, 54px center, 12px titles); portrait no longer doubles the episode title above the video; tapping ‹ › / episode list / settings / Sub-Dub in fullscreen stays in landscape fullscreen (fullscreen now covers the app so sheets open over the video, and episode changes keep it instead of exiting); the settings sheet header can no longer squash over its rows. Applied identically to the three shipped files.

- Player motion: the episode overlay bars slide in/out with a fading pop on the center button, and the Episode settings / episode-list sheets glide up on open and down on close with the backdrop fading. Applied identically to the three shipped files.

## Previously — 2.10.16 (2026-10-17)

The app is on **v2.10.16** — *ZinManga ungated, MangaTown honest, no more shake*. Three reader reports, three fixes, measured live before shipping. (1) ZinManga chapters would not open: the source sat behind the image-loader gate, but its chapter pictures (img-1.mangazin.org) answer the browser build's own proxy routes with real bytes (200 + image/jpeg through both server routes, verified), so it reads ungated now through the plain fallback chain — no loader, no app. (2) MangaTown chapters failed with "did not answer": the chapter fetch now states its marker (`require: MT_wantChapter`, so a mirror's mangled copy loses the race instead of winning it and failing the chapter), page pictures gain data-src/srcset fallbacks, the page-option pattern accepts hyphenated paths, and pages arrive four at a time so the burst stops tripping the site's bot protection (zjcdn pictures still 403 server-side, so the loader/app gate stays). (3) Continuous comic reading shook: chapters trimmed off the top of the strip never moved the scroll (everything under the eye jumped up by what left) — `mgContTrim` now measures the leaving height and writes the scroll back as one absolute position, prepend-style, so anchoring cannot double-count it; and off-screen pages estimate the same tall 800x1500 size as the placeholder instead of 550x800, so they no longer snap as they come near. Applied identically to the three shipped files.

## Previously — 2.10.15 (2026-10-17)

The app is on **v2.10.15** — *smooth pages*. Comic pages arrived as a pop: flat-black boxes that jumped the scroll when a tall picture landed in a 2:3 guess. Now placeholders wear a slow shimmer and pictures fade in (one `mgshimmer` keyframe + an opacity transition, honored `prefers-reduced-motion`, off-screen pages cost nothing via `content-visibility`); strip boxes guess tall (800x1500 — the strip only exists in vertical mode) so landings shift far less; every retry, fallback and page turn drops back to the shimmer via `mgConceal` until the arrival re-reveals it in `mgStampRatio`, the one funnel every page load already passes through. Applied identically to the three shipped files.

## Previously — 2.10.14 (2026-10-17)

The app is on **v2.10.14** — *512 kept, referrer-proofed*. Per the user's call ("retain that 500+ cover and find another way"), cards are back on the full 512-wide cover — but they no longer depend on what the phone's image loader sends: `mdCoverLoad` tries the pixels first and, the moment that misbehaves (error, ten seconds of silence, or the 300x321 placeholder arriving as a good picture), fetches the cover as bytes through the proxy (`mdCoverBytes`: superFetch, else the app's own fetch route) and shows it from a local blob URL, which no Referer can attach to and which keeps the canvas clean so real covers cache properly. A blob that still decodes 300x321 is refused; then the drawn cover, as ever. Stored MangaDex snapshots purge once more (flag "4"). Applied identically to the three shipped files.

## Previously — 2.10.13 (2026-10-17)

The app is on **v2.10.13** — *the size that worked*. The user reported covers still broken on their phone but fine in the lower version, and sent the 2.10.3 APK: diffed line by line, the native side is identical and the only cover difference is the size — 2.10.3's feed cards wore the 256-wide thumb, the 2.10.6 rewrite switched them to the 512-wide variant, and that variant is what comes back as the hotlink placeholder on the phone. Cards wear the 256 again (lighter per card too); the book screen keeps the 512 (as 2.10.3 did); stored MangaDex snapshots purge once more (flag "3") so they refetch in the working size; all 2.10.12 guards stay on. Applied identically to the three shipped files.

## Previously — 2.10.12 (2026-10-17)

The app is on **v2.10.12** — *covers finished*. 2.10.11 stopped the Referer on grid + hero and purged the cache, but the cover viewer set src with no policy at all and the library/history/updates thumbs carried none — every MangaDex cover opened there came back as the placeholder and re-poisoned the just-purged cache. Worse, the placeholder loads as a perfectly good picture (HTTP 200), so no error ever fired and nothing retried it. Now the page declares no-referrer itself (injected meta, before any cover loads), every cover img carries it, a 300x321 picture arriving down a MangaDex route is failed by hand so the proxy answers the real cover instead, placeholders are never cached, and the stored MangaDex snapshots are purged again (flag "2") so they refetch. Applied identically to the three shipped files.

## Previously — 2.10.11 (2026-10-17)

The app is on **v2.10.11** — *covers back, no drag-back*. Two fixes: (1) MangaDex covers showed its hotlink placeholder ("You can read this at…") because cover requests sent a Referer — all cover `<img>`s now carry `referrerpolicy="no-referrer"` (grid + hero, every source), and a one-time purge drops the poisoned placeholder snapshots (45 of 60 stored covers!) from the persisted cache so they refetch. (2) Leaving a book/chapter/source cancels its late finish — `renderBookScreen` no longer re-adds `.open` on background refreshes (navigating callers pass `_openNow`), `closeReader` invalidates the in-flight open + stops retry timers, and `exitSourceMode` drops pending recovery hops. Applied identically to the three shipped files.

## Previously — 2.10.10 (2026-10-17)

The app is on **v2.10.10** — *feed loads toward you*. The discover pump fetched shelves nonstop whether the reader scrolled or not (hundreds of ~459KB MangaDex shelves parsed + rendered + rated in the background, forever). Now `pumpDiscover` parks while the tail sits more than a screen past the viewport (`discoverTailNear`), a tail observer (`discoverWatchTail`, 1200px margin, run-guarded) resumes on scroll, and re-entering a feed already on screen skips the full rebuild (DOM-vs-books first/last/count check). Applied identically to the three shipped files.

## Previously — 2.10.9 (2026-10-17)

The app is on **v2.10.9** — *feed scroll stays smooth*. Two per-shelf/per-scroll costs grew with feed length and blocked the main thread: `coverFallbackScan` read every pending cover's rect (thousands of forced layouts on scroll, per shelf, every 2.5s tick) and `appendFeedBooks` re-walked the whole container via `loadCovers`. The scan is now time-budgeted (~6ms/turn, rotating cursor), scroll/resize/interval checks are gated on a `coverAnyPending` flag (zero DOM cost when nothing waits), and new shelves watch only their own cards (`loadCovers(wrap)` before insert). Applied identically to the three shipped files.

## Previously — 2.10.8 (2026-10-17)

The app is on **v2.10.8** — *MangaDex feed does nothing per card*. MangaDex left `CHAPTER_ENRICHABLE`: feed/search cards fire zero per-title requests (ratings stay — one batched statistics call per shelf). Reason: six shelves × 32 cards each fired its own `/aggregate` at a 5-req/s API, and the `MD_chaptersFor` fallback downloaded up to 2000 chapter rows per card when rate-limited — that was the feed lag/freeze. `MD_countChapters` is now aggregate-only (miss → `{n:0}`); the count still shows on the book screen via the full chapter list in `MD_getBook`. Applied identically to `index.html`, `src/standalone/index.html`, `src/android-app/app/src/main/assets/www/index.html`.

## Previously — 2.10.7 (2026-10-17)

The app is on **v2.10.7** — *MangaDex reads ahead*. The strip observer starts pages much earlier (2600px lookahead) and pages within ~1.25 screens of the eye cut to the front of the queue; a new landing-zone sweep (`mgEnsureNear`, ±2/＋4 pages around the visible index, every scroll frame) guarantees a scrub lands loaded; chapter preloads ride their own single-item lane (`mgWarmQ`, `MG_MAXWARM=1`, deduped per chapter in `mgWarmSeen`) behind real pages instead of clogging the 4 image slots; the queue holds one wait per picture (`_queuedWant`, so repeat asks can't restart a download mid-flight — the loaded→black→loading-again flash); and the stall watchdog drops 15s → 10s so a silent MangaDex at-home node reroutes to the proxy sooner. Applied identically to `index.html`, `src/standalone/index.html`, `src/android-app/app/src/main/assets/www/index.html`.

## Previously — 2.10.6 (2026-10-17)

The app is on **v2.10.6** — *MangaDex returns*. The full MD engine is back (`MD_search/feed/getBook/getChapter/countChapters` via api.mangadex.org, ratings queue, `MD_COVERS`, `mdfeed` jobs): `SRC["MangaDex"]` reads live again, with SOURCES entry, MG_LOGOS key, cover-host pairs (uploads + mangadex.network nodes), aliases, base-URL/health rows, rating + chapter-count branches (counts via the small aggregate endpoint), discover/feed/extend branches, covers + at-home pages through the normal queue + stall watchdog, data-saver pictures unless the HD pages switch is on, `titleAlt` second title, and the mangadex.org /title/ open-on-site URL.

## Previously — 2.10.5 (2026-10-17)

The app was on **v2.10.5** — *MangaDex removed*. The whole MD engine
(`MD_search/feed/getBook/getChapter/countChapters`, ratings queue, `MD_COVERS`,
`mdfeed` jobs, `MD_ALT` spare-tire) is deleted; `SRC["MangaDex"]` is now
`retiredSrc("MangaDex")` so shelved titles answer with the reason + Find on
another source. SOURCES entry, MG_LOGOS key, cover-host pair, aliases,
base-URL/health rows, rating + chapter-count branches, discover/feed/extend
branches, and the reader's MD fallback steps + `mgStallMsFor` are all gone.
Kept deliberately: `mx-` id prefix (old books still resolve to the retired
message), the `MangaDex:` cover-cache purge, and the mangadex.org "open on
site" URL.

## Previously — 2.10.4 (2026-10-17)

The app is on **v2.10.4** — *steady comic pages*. One image queue (`mgLoadQ`,
4 slots) paces every plain picture on every source, strip + pager; slots free
on load/error/stall, fallbacks + retries + the paged current page cut to the
front, warms (`mgWarmOne`, incl. one page back) wait at the back. `.mgPage`
gets `content-visibility: auto` + `contain-intrinsic-size`; loaded pictures
stamp their true ratio (`mgStampRatio` + `loaded` flag) so revisits repaint in
place. MangaDex remembers the at-home node twin of every page (`MD_ALT`) as a
second route, the image loader is tried for MD too, and the MD stall fuse is
10s (`mgStallMsFor`).

## Previously — 2.10.3 (2026-10-17)

The app is on **v2.10.3** — *MangaDex stall watchdog*. 2.9.76 diffed
function-by-function (cover fix exonerated — header-only). Every direct comic
page load arms `mgArmStall` (`mgStallMs` 15s): still blank → `mgImgFailed`
reroutes via loader/proxy; `mgClearStall` on load/failure/retry. Verified
against 2.9.76: `mgSetPageImg`, `loadCoverImg`, `mangaProgress`,
`mgVisibleIndex`, `mangaBuildStrip`, MD chapter code all same-or-lighter.

## Previously — 2.10.2 (2026-10-17)

The app is on **v2.10.2** — *MangaDex data-saver + step back + history › +
recent source*. `MD_getChapter` takes `/data-saver/` pictures via `MD_pageURLs`
(full size only when the new `mangaHD` switch is on); `nativeFetchBytes`
decodes base64 in 256KB slices yielding to the loop. `__litBackPressed`
walks overlays → reader → book → feed → list → library → 0, and
`MainActivity.onBackPressed` asks it first (press-again-to-exit at root).
History swipe mirrored to swipe-right revealing a red › (`hSwipeDelR`).
`noteRecentSource` (set in `openChapter`, persisted) renders one
recent card above the alphabet in `renderSources`.

## Previously — 2.10.1 (2026-10-17)

The app is on **v2.10.1** — *chapter-hop fix + auto-scroll + swipe speed*.
`openChapter` locks Prev/Next the moment a chapter starts opening (stale
double-taps used to re-open the same chapter) and unlocks them on the chapter
that lands, with the header naming it while it loads; continuous jumps hold
the same lock via `readerNavBusy`/`readerNavIdle`. New in Reading settings:
Auto-scroll (rAF glide for novels + Webtoon strips, timed page turns for paged
comics, 1–10 speed, touch parks it with a ▶ pill to resume, stops at end of
chapter) and Swipe speed (1–3× touch/wheel boost for long comic pages).

## Previously — 2.9.100 (2026-10-17)

The app is on **v2.9.100** — *compact reading settings*. The three long
`.rsHint` essays (continuous scroll, comics Read-as, TTS) become one-liners;
`.rsRow` padding 13px → 10px; `.chapterModalHeader` 14px → 12px (shared with
the chapter picker). Sheet sizes to content under its 75% cap.

## Previously — 2.9.99 (2026-10-17)

The app is on **v2.9.99** — *smooth + chapter rows fixed*. `.cName` gets
`flex:1` (dl/lock icons pinned right); `chapterItemHTML` falls back to
`This chapter…` when number and name are both missing. `exitSourceMode`
restores `main` scrollTop (the hide-feed-first clamp sent users to the top).
Perf: rAF-throttled `readerBody` scroll → `updateReaderProgress`;
`mgVisibleIndex` caches page els + binary search (~9 rects vs ~500);
`mangaProgress` reuses idx for the group; `coverFallbackScan` deferred to rAF;
feed covers gain `loading=lazy decoding=async`; `.badge`/`.statusBadge`/
`.feedPct` drop `backdrop-filter` for solid pills. `MG.pageEls` cleared in
`mangaClose`.

## Previously — 2.9.98 (2026-10-17)

The app is on **v2.9.98** — *white titles everywhere*. `.novelTitle`,
`.itemTitle`, `.bookSynopsis`, `.gSrcLabel`, `.headerMenu button`,
`.cardMenu button`, `.settingRow`, `#selBar button`, `.emptyState b`,
`.csReviewTitle` all → `#fff`, matching the hero catalog name.

## Previously — 2.9.97 (2026-10-17)

The app is on **v2.9.97** — *global chips collapse + 550 width*. Global search
source chips show the first 6 with a `Show more (+N)` pill (`#globalSrcMore`,
notes hidden selected count; `Show less` collapses; choice survives
re-renders). Fixed layout width 520 → 550: viewport meta, `MainActivity`
comments + `enforceFixedViewport` regex/replacement, 2.9.96 grid comment.
Historical 520 mentions (changelogs, older README sections) left as-is.

## Previously — 2.9.96 (2026-10-17)

The app is on **v2.9.96** — *grid spreads edge to edge*. `.grid` tracks go
`repeat(auto-fill, 135px)` → `repeat(auto-fill, minmax(150px, 1fr))`: at the
fixed 520 layout the 3 columns stretch to the edges instead of piling centered;
wide screens still gain columns via auto-fill. Shared by library, global
results and browse grids. Covers stretch via `.coverWrap` aspect-ratio (no
change needed).

## Previously — 2.9.95 (2026-10-17)

The app is on **v2.9.95** — *520 lock repaired*. Viewport meta drops `maximum-scale=1` (it clamped fit-scale on >520dp screens; `user-scalable=no` stays so no pinch zoom). `MainActivity.enforceFixedViewport` (called from `onPageFinished`) creates/corrects the `width=520` viewport meta at runtime, so the fixed layout holds even if a stale page is ever bundled. Native change → needs a full fresh APK build.

## Previously — 2.9.94 (2026-10-17)

The app is on **v2.9.94** — *whiter serif text*. `.bookSynopsis` → `#e8e8f2`, chapter `.cName` → `#ffffff`, alt title + author → `#c9c9d6`, hero meta → `#9a9aa8`. Read chapters keep `#757587` dim as the read signal; empty-synopsis placeholder untouched.

## Previously — 2.9.93 (2026-10-17)

The app is on **v2.9.93** — *double title, synopsis toggle, serif everywhere*. MangaDex alt titles ride along (`MD_altTitle` prefers the original language, then ja/ja-ro/ko/zh/en; stored as `book.titleAlt` via `MD_card`/`MD_getBook`, copied through all three enrich paths + `addToLibrary` + library assign) and the hero shows them under the main title (`#bookHeroAltTitle`, hidden when absent/identical). Synopsis clamps to 3 lines again (2.9.92 force-open override removed) with a `Show more / Show less` toggle (`#bookSynToggle`, rAF overflow check). Whole-app font is now `"Playfair Display", Georgia, serif` on `body`; reader page content keeps its `--r-font` setting, System Sans stays a reader option.

## Previously — 2.9.92 (2026-10-17)

The app is on **v2.9.92** — *the old book screen is back*. Deleted the 2.9.38 marquee/refresh, 2.9.40 reference-hero and 2.9.41/2.9.49 override blocks; the surviving base + old rules are the Sept-21 design again (112px cover, italic serif title/rows, ✓ meta via `bookMetaText`, pink rating, full synopsis, plain catalog). `chapterItemHTML` back to name + dl/lock/ext/bmk marks with `cread` dim / `inprog` accent. Removed: header bookmark + ⋮ menu (status/shelf stay on the library card menu), hero blur/status chips, progress bar, bulk Download button (sheet code dormant), synopsis collapse, unread count. Mark-all-read/clear moved to `chapterFilterMenu` (`data-act`). First genre chip filled pink (EASTERN), rest hue outlines.

## Previously — 2.9.91 (2026-10-17)

The app is on **v2.9.91** — *history buttons spread*. `#historyScreen .histToolBtn` back to `flex: 1` centered: same left/center/right positions as the boxed bar, still boxless.

## Previously — 2.9.90 (2026-10-17)

The app is on **v2.9.90** — *history toolbar, unboxed*. `#historyScreen .histTools` drops the container box for plain left-aligned text actions; Updates keeps its bar. Note from user report: select-mode boxes were verified gone in the preview (26px circle checkbox, no row outline, no `#selBar`) — if they still show on the phone, that phone is running an older APK, which only a rebuild + reinstall fixes.

## Previously — 2.9.89 (2026-10-17)

The app is on **v2.9.89** — *history select, cleaned up*. History select mode no longer shows the shared `#selBar` (that stays the library's): toolbar swaps to Done + `Delete (n)` (`#selHistDeleteBtn`, Fix/Clear hidden meanwhile). Swipe Delete is a floating trash circle (`#historyList .hSwipeDel span`) instead of a full-height bar; per-row `✓` boxes become real circle checkboxes with a soft selected tint. Row-tap selection now also stamps the checkbox glyph (it only flipped the row class before).

## Previously — 2.9.88 (2026-10-17)

The app is on **v2.9.88** — *history, unboxed*. `#historyList .listItem` drops the card (background/border/radius/margin) for plain divider rows; the shared card rule is overridden later in the file so `#updatesList` keeps its cards. Sticky day headers gain a per-day `.histDayN` count via a `dayCounts` pass in `renderHistory`.

## Previously — 2.9.87 (2026-10-17)

The app is on **v2.9.87** — *history, renewed + no Clear pill*. Sticky day headers (`position: sticky` on `.histDateGroup`), chapter line with "N left", source · time on its own `.histMeta` line, continue chevron per row (hidden in select mode); swipe/select/open paths untouched. `#libClearFilters` deleted (markup, CSS, `syncLibFilters` line, listener) — the ⋮ menu's Clear search & filters stays.

## Previously — 2.9.86 (2026-10-17)

The app is on **v2.9.86** — *calmer library filters*. All / Novels / Comics lose the segmented box and return to plain underline tabs; `#libBar` (count + Filters + Clear) moves above Shelf / Status so expanding Filters grows downward and the tapped button never jumps.

## Previously — 2.9.85 (2026-10-17)

The app is on **v2.9.85** — *compact library filters*. The 2.9.84 card ate ~32% of the screen, so it is gone: `#libFilters` is a plain tight wrapper, the Show switch is slim, and Shelf/Status collapse behind a remembered Filters toggle (`libFiltersOpen` + `yuedu_libfilters`), auto-opening while a shelf/status filter is active. Count + toggle + Clear share one small `#libBar` line.

## Previously — 2.9.84 (2026-10-17)

The app is on **v2.9.84** — *library, arranged*. The Show / Shelf / Status rows move into one labeled filter card with a title count and a Clear pill (`#libFilters`, `#libCountRow`, `syncLibFilters` at the end of `renderGrid` — the funnel every filter change passes through); All / Novels / Comics become a joined segmented switch at the top of the card; Shelf / Status rows borrow their labels from CSS (`::before`) so no render function changes shape. Scoped to `#libraryScreen` — Browse rows untouched.

## Previously — 2.9.83 (2026-10-17)

The app is on **v2.9.83** — *520 layout holds on any smallest width*. The packaged app's WebView never enabled the wide viewport, so it ignored the page's `width=520` rule and laid out at the device width instead — changing the smallest width to 400dp reshaped the whole app. `MainActivity` now sets wide viewport + overview mode, so the layout stays fixed at 520 CSS px and scales to fit the screen.

## Previously — 2.9.82 (2026-10-17)

The app is on **v2.9.82** — *updates leave GitHub*. Update notices and developer messages now come from the `yuedu-console` generator (editable file `yuedu-manifest`) instead of the GitHub `latest.json` — create that generator from `scratch/yuedu-console-main.pjs` + `scratch/yuedu-console-index.html`, save it with exactly that name, and Publish.

## Previously — 2.9.81 (2026-10-17)

The app is on **v2.9.81** — *videos paused*. YouTube goes inactive like anime before it: no Videos chip, no videos in Browse/counts/health/global search — shelved videos still open.

## Previously — 2.9.80 (2026-10-17)

The app is on **v2.9.80** — *anime paused, 18+ moves inside Comics*. HiAnime and AnimePahe go inactive (no Anime chip, no anime in Browse/counts/health/global search — shelved anime still opens). The After Dark screen and all standalone 18+ chips are gone: Comics carries a Normal / 18+ switch, 18+ behind the same age gate, adult sources listed, searched and counted only while it is on.

## Previously — 2.9.79 (2026-10-17)

The app is on **v2.9.79** — *smooth MangaDex feeds + 520 layout width*. Card chapter counts came from downloading whole chapter lists (up to 2,000 rows over 4 requests per card); now one small aggregate request (verified identical counts), plus lazy/async cover decoding and skipped off-screen rendering. Layout width changed 600 to 520 as requested.

## Previously — 2.9.78 (2026-10-17)

The app is on **v2.9.78** — *MangaDex covers really fixed*. v2.9.77 sent no Referer but the placeholder persisted: measured side by side, MangaDex also serves the white placeholder when the request carries an `Origin` header, and the app marked every MangaDex cover for anonymous (CORS) loading, which sends exactly that. Covers now load plainly with neither header (verified live: four different real covers on four cards).

## Previously — 2.9.77 (2026-10-16)

The app is on **v2.9.77** — *MangaDex covers show again*. The site answers cover requests carrying another site's address with a white placeholder instead of the real picture; the reader always sent its own address along, so every card wore the placeholder while the health check (which sends none) kept reporting healthy. Covers and chapter pages now load with no Referer, and saved placeholders are purged and reloaded properly. Verified live: real 512x809 covers rendering on cards.

## Previously — 2.9.76 (2026-09-29)

The app is on **v2.9.76** — *MangaFox chapters open again*. The site moved its page pictures behind a loader that answers in packed code; the reader asked it but never unpacked the answer, so every chapter came back empty ("did not answer with this chapter's pages"). Chapters now decode the loader's reply into real page pictures (verified live: full JPEG pages at 684x1100), and the loader gets three tries with a longer wait instead of one quick attempt.

## Previously — 2.9.75 (2026-09-28)

The app is on **v2.9.75** — *YouTube joins YueDu (67 sources)*. Search the whole of YouTube, open trending/music/gaming/news/movies/sports/live shelves from the feed, and play videos in a built-in watch screen with an Open-in-YouTube fallback for uploads that refuse embedding. Videos shelve like everything else — one library, one history, resume where you left off — and a new **Videos** chip joins Novels, Comics and Anime on Browse. Read through YouTube's own internal API (search + continuations + player), verified live before shipping.

## Previously — 2.9.74 (2026-09-28)

The app is on **v2.9.74** — *five comic sources repaired*. **MangaFox** books open again (chapter links moved under volume folders — lists, counts and chapters read the volume-style links now, saved chapters keep working). **MangaReader** feeds carry the full popular/latest rows instead of 8 slider titles. **ToonGod**, **ZinManga**, **Manhwa68**, **MangaGG** and **MangaFox** picture hosts joined the guarded Referer list (covers + pages via image loader or app). **Comizy** search/book/chapters/feed re-checked live end to end.

## Previously — 2.9.73 (2026-09-28)

The app is on **v2.9.73** — *Nova really opens chapter pictures now*. The health sweep used to pass a comic source when its chapter API returned page URLs; those URLs can still refuse at load time (hotlink guards, dead CDNs), which is exactly the "feed and chapter list fine, chapter won't open" failure. A manga chapter now passes only if its first page pictures actually load through the same routes the reader uses (direct, image loader, proxy, native bridge in the app) — otherwise the source reports **down** with how many pictures loaded. Also new: the newest chapter is probed alongside the first ones, sources whose chapters need an image loader say so instead of failing silently, partial page loads are flagged on the health screen, and the probe budget is 60s. Same sweep also caught a real listings bug: MangaHere, MangaFox and MangaTown books were mixing other comics' chapters into their lists (foreign slugs, instant 404s) — lists now keep only the book's own chapters. MangaFox additionally moved its chapter pictures to a session-checked `chapterfun.ashx` loader (chapterid + page key off the chapter page); chapters read through it where the site allows, with the ashx call capped so a walled endpoint can't stall the probe. Verified live: MangaReader healthy with 3/3 page pictures loaded, MangaHere honestly loader-blocked in preview, MangaFox honestly chapter-down, Royal Road novel probe unchanged.

## Previously — 2.9.72 (2026-09-28)

The app is on **v2.9.72** — *two more novel sources (30 novels, 66 sources total)*. **Fenrir Realm** (fenrirealm.com, original English web novels, entirely its own JSON: `/api/series/filter` title search + paged feed, `/api/new/v2/series/<slug>` records with author/genres/status plus whole chapter lists off `/chapters`, chapters off `/api/new/v2/chapters/<id>` as TipTap-or-HTML with the site's per-chapter watermark classes, aria-hidden decoys, attribution bits and zero-width filler stripped — locked chapters answer honestly instead of blank). **WNTL** (wntl.net, translated Korean web novels, entirely its own JSON: the whole 18-novel catalogue in one `/api/novels` call behind search and latest/catalogue feeds, full published-only chapter lists off `/api/chapters/<id>`, markdown chapters off `/api/chapter-content/<id>/<file>` read into paragraphs). Endpoints mapped from LNReader's plugin sources. Verified live: Fenrir ch1 = 273 clean paragraphs, WNTL erk = 535 chapters with ch1 = 252 paragraphs.

## Previously — 2.9.71 (2026-09-28)

The app is on **v2.9.71** — *seven more comic sources (30 comics, 64 sources total)*. Four more Madara sites ride the shared engine — **ToonGod** (manhwa/webtoons, ajax search 18 hits, Ragnarok 68 chapters/28 pages), **ZinManga** (mangazin.org: ?s= search 12 hits, Solo Leveling: Arise 26 chapters, ch26 = 148 pages), **Manhwa68** (Ragnarok 47 chapters/20 pages) and **MangaGG** (Arise 18 chapters/15 pages) — all four picture hosts demand the site as Referer, so they ride `gatedComic` (search/books/feeds/covers everywhere, chapters via image loader or app). Three plain readers join with custom engines: **MangaFox** (MH-family clone on the same manga-list-4/chapterlist/packed-chapter markup — search, 4 directory feeds, Naruto-scale lists, ch1 = 21 pages plain at 728x1294), **MangaReader** (mangareader.site: /search?q= cards with background-image covers, /popular + /updates feeds, /chapter/ pages with plain imgx images at up to 4480px) and **RavenScans** (ravenscans.org: ?s= search, 136-page /manga/ archive feed, `<slug>-chapter-N` pages with plain cdn4 webp at 1080x1500). Also fixed: Madara ?s= fallback sends `+` for spaces (ZinManga answered `%20` with nothing), MangaFox directory covers (manga-list-1-cover class), MangaReader h1 Hot-badge strip + card covers + Start-Reading chapter names, RavenScans Color/Chapter/date title tails. ManhuaUS (captcha wall) and SleepyTranslations (unusable search) Madara configs removed. Verified live: all 7 search/book/chapter/feed with real pixels on the plain three.

## Previously — 2.9.70 (2026-09-28)

The app is on **v2.9.70** — *NatoManga + MangaTown join (57 sources)*. NatoManga (natomanga.com, manga/manhwa/manhua) is the MangaNato engine alive under a new name: search (18 results live, newest-chapter counts ride along), homepage latest-releases feed (56 cards), series pages (author, status, genres, ld+json rating, synopsis) with whole chapter lists off its own JSON chapters API (Naruto = all 787 chapters, ch0–ch700.6 — the default page holds 50, `?limit=2000` holds them all), and one-request chapter pages (ch1 = 53 pages). MangaTown (mangatown.com, MangaHere's sister site on the same guarded fmcdn/zjcdn hosts): search (20 results live), /latest/ feed (334 pages deep, 30 cards a page), series pages (author, Completed status, 4.56-style rating, genres, synopsis, whole chapter list — Naruto = all 752 listed chapters, c000–c700.6; most links carry an empty `name=""`, so numbers come from the URLs), and one-page-per-request chapters fetched six at a time (ch1 = 53 pages). Both ride `gatedComic` + the referer lists — honest loader gate in browser, full reads in app.

## Previously — 2.9.69 (2026-09-27)

The app is on **v2.9.69** — *MangaHere joins (55 sources)*. MangaHere (mangahere.cc, manga/manhwa/manhua) reads from plain server-rendered pages: search (12 results live, cards with covers/status), /latest/ feed (477 pages, newest-chapter counts ride along), series pages (author, 4.98-style rating, status, genres, synopsis, whole chapter list — Solo Leveling = all 201 listed chapters, Ch.001–Ch.202; the site's own tab count 212 is stale, the link count wins). Chapter pages carry a standard packed block decoded with the existing AP_unpack (ch1 = 14 pages in one request). Pictures are Referer-guarded, so it rides `gatedComic` + the mgImgNeedsReferer/mgImgRefererFor lists — honest loader gate in browser, full reads in app.

## Previously — 2.9.68 (2026-09-27)

The app is on **v2.9.68** — *two more comic sources: Comizy + EzManga*. Comizy (comizy.io, the reader MangaBuddy became) reads through its JSON API: search (26 results live), by-slug→hsid→detail + full chapter list (Naruto = 748 chapters), trending-chapters feed with offset paging; its cmzcdn.org pages refuse every browser route (plain/anon img, loader-less proxy, weserv, fetch all fail), so it rides `gatedComic` — search/book/feed everywhere, chapters need the image loader or app. Covers on rx.comizy.io load as plain `<img>` (no CORS → crossOrigin exclusion). EzManga (ezmanga.org, manhwa/manga) reads through its Keyoapp JSON API (route map lifted from its own SSR pages + JS bundle: `/api/v1/series/search?q=`, `/api/v1/series?page=`, `/api/v1/series/<slug>` with stats.chapterCount, `/api/v2/series/<slug>/chapters?limit=100` + cursor, `/api/v1/series/<slug>/chapters/<ch>`): search/book (Spring Fever = 66 chapters, author/rating/votes/status/genre)/feed all live, free chapters read page by page (ch1 = 11 pages at 800px real, media.ezmanga.org plain-loads so it skips crossOrigin too), coin-locked chapters answer honestly instead of blank. 54 sources total (28 novels, 20 comics, 4 18+, 2 anime).

## Previously — 2.9.67 (2026-09-27)

The app is on **v2.9.67** — *anime uses the native device route*. The pass-on-screen-but-blocked-in-app loop was the clearance cookie: a file:// page fetching a site is cross-site, so WebView fetch omits it, while top-level page loads carry it. Anime requests in the app now go through `LitNative.fetch` (whole cookie jar attached as a header, ajax headers kept) — the same model as Aniyomi's OkHttp client on its WebView jar — with WebView fetch as fallback. Verified live: native path resolves text/status through a stub bridge, fallback path unchanged, challenge-URL routing intact.

## Previously — 2.9.66 (2026-09-27)

The app is on **v2.9.66** — *check screen stops closing on you*. Two fixes: it auto-closed on any clearance cookie, including a stale one, so it slammed shut before anything was solved; it now waits for a page load + 8s + a genuinely new clearance and says "Check passed — returning…" first. And it could open an ajax URL (JSON, nothing to solve) — catalogue ajax/api refusals now open the site page, video-host ajax refusals open the embed page. Verified live: ajax URLs route to solvable pages, real pages still open directly.

## Previously — 2.9.65 (2026-09-27)

The app is on **v2.9.65** — *anime captcha loop fixed at both ends*. Two causes: the pass screen opened the catalogue site while the refusal came from the video host (megacloud/kwik are different addresses — passing hianime.to never clears them), and the check passed as desktop Chrome while the retry went out as a `; wv` WebView, so the clearance never counted. Blocked errors now carry the refusing URL (`haUrl`), the check screen opens that exact address (video-host blocks get their own Pass button and name the host), and both WebViews share one marker-free UA (MainActivity strips `; wv`; Challenge copies the host UA). Verified live: challenge-URL routing (site vs video host), error names the video host, desktop preview still errors honestly.

## Previously — 2.9.64 (2026-09-27)

The app is on **v2.9.64** — *anime goes Aniyomi-style: one device client, auto-passing checks*. Read Aniyomi's CloudflareInterceptor/WebViewInterceptor + consumet's hianime/kwik extractors and matched them. In the packaged app every anime request is now ONE call from the phone (device fetch, WebView cookies, `X-Requested-With` + `Referer` ajax headers the working providers send) with no proxy hedge beside it — parallel datacenter requests were bot-wall bait and could never carry the earned clearance, and each refusal now lands on Pass-check in seconds instead of after minutes of sf retries. The challenge screen uses a desktop Chrome UA (the `; wv` marker looped Cloudflare forever), auto-closes the moment a fresh `cf_clearance` cookie appears (no more guessing when to tap Done), and surfaces real load errors instead of a stuck `Loading… 10%`. Browser behavior unchanged. Needs one APK run: open an episode, pass the check once, confirm playback.

## Previously — 2.9.63 (2026-09-27)

The app is on **v2.9.63** — *MangaGeko + MangaKatana books open again*. Both crashed on a copy-pasted `madScoreToRating(scoreText)` line where `scoreText` was never defined (the same crash fixed on AsuraScans in 2.9.52) — every book died before its chapter list. Both now read rating 0/votes 0; neither site carries a parseable score. Verified live: Geko book = 62 chapters, ch1 = 25 pages; Katana Naruto = 700 chapters, ch1 = 60 pages. NovelHi verified healthy on this network (1548-chapter novel: search/book/chapter all read) — Nova's chapter failure is its per-novel daily metering on that network, which shows the honest rate-limit message and clears by itself.

## Previously — 2.9.62 (2026-09-27)

The app is on **v2.9.62** — *second anime source: AnimePahe*. Source #52, sub-only, on the same shared AniList catalogue as HiAnime (`ap-<anilistId>-e<N>` episodes, so library/history/progress/book screen work untouched). Watch chain: title match to an AnimePahe session (`/api?m=search`, token+episode-count scoring, cached per AniList id), episode sessions off `/api?m=release`, kwik links off the `/play` page, kwik embed unpacked statically (ported `safeUnpack`, no eval) to an m3u8. Dub falls back to sub and the watch screen + status line say sub. Verified live: search "naruto" → 24 ap- books, trending feed 24, Naruto book = 220 eps, session + ep-1 session + 2 kwik links resolve, unpacker unit-checked, SRC/prefix/feed/jobs/View dispatch all resolve to animepahe.com. Kwik embeds are bot-walled from datacenter IPs (honest blocked error → Pass-check/WebView path), same standard as HiAnime streams — needs one APK run to confirm playback.

## Previously — 2.9.61 (2026-09-27)

The app is on **v2.9.61** — *anime plays past the bot check*. HiAnime's Cloudflare wall was the whole failure: the app read the check page as "no such title"/"unreachable" instead of naming it. `HA_text` now spots check pages (every stage tagged: search/episodes/servers/sources/video) and throws a proper blocked error, and the watch error card offers **Pass check in WebView** (Android app — real browser, shared cookies, auto-retry on Done) plus **Open in app** with a retry button. Also added: HiAnime in `sourceBaseURL`. Could not verify streams end-to-end here (hosts block datacenter IPs); needs one APK run: open an episode, tap Pass check, confirm playback.

## Previously — 2.9.60 (2026-09-27)

The app is on **v2.9.60** — *anime joins the library*. HiAnime (`type: "anime"`, the third kind beside novels and comics) is source #51: catalogue from AniList's CORS-open GraphQL API (search, trending/popular/top feeds, details with episode counts), streams from HiAnime's ajax chain (endpoint map from consumet 1.8.8's hianime provider — vendored in scratch/anime-research/tar/p-hianime.js — plus the aniyomi extensions survey in scratch/anime-research/aniyomi-en.json). Episodes ride the chapter machinery (`ha-<anilistId>-e<N>`) so library/history/progress/book screen work untouched; a dedicated watch screen (`AN_*`, hls.js + `<video>`, sub/dub switch, subtitle tracks, resume, watched marking) opens from `openChapter`'s anime branch. Health probe treats catalogue + episodes as the verdict (streams can't be verified from datacenter IPs — hianime/megacloud block them there; the APK on a residential IP is where they play). Verified live: search "naruto" → 24 results, Naruto = 220 episodes with real ep-1 title, feed 24, probe ok in 1.3s, source card Connected, Anime chip + counts, book screen 200 rows, watch error card honest in preview.

## Previously — 2.9.59 (2026-09-27)

The app is on **v2.9.59** — *third-tap heart death fixed*. Reproduced live on a DynastyScans comic (add, remove, dead). Verified 6 alternating taps with the feed pill syncing both ways. Test book removed from the library afterwards.

## Previously — 2.9.58 (2026-09-27)

The app is on **v2.9.58** — *centered comic actions*. Comics hide Download (no offline for manga), which left 4 buttons in a 5-column grid sliding left — the row now drops to 4 columns via data-cols. Verified live: DynastyScans → 4 cols centered, Webnovel → 5 cols.

## Previously — 2.9.57 (2026-09-27)

The app is on **v2.9.57** — *countless genres + honest feed ends*. Genre chips/sheet carry no counts; the background tag enricher is deleted (genres come only from listing cards). Feed tail is a Load more button on all feeds incl. 18+; error-deaths show tap-to-retry via discover.errored instead of “seen everything”. Verified live on MangaKatana: 80 cards, plain-name chips, button sentinel, no tagging.

## Previously — 2.9.56 (2026-09-27)

The app is on **v2.9.56** — *the 3-source mystery + parallel Nova*. Typing “hi” in Browse's source search matches exactly Archive of Our Own, Chikari and NovelHi — that leftover query was the whole bug. The box has an ✕ now and the subtitle counts matches (“3 of 46 match”). Nova checks 6 sources at once (3-wide retries) with reader traffic metered separately; a full 50-source sweep measured ~72s live with feed lines like “✓ Chikari · 2.5s”. Note: stubbing page functions from eval doesn't propagate — verify with real runs, not stubs.

## Previously — 2.9.55 (2026-09-27)

The app is on **v2.9.55** — *stale counts → N/A*. While a fresh sweep runs, Healthy/Slow/Down read N/A (grey, smaller) instead of last run's numbers; retries keep counting live since they only touch failures. Verified live: 38/4/4 → N/A ×3 mid-sweep → 38/4/4 after.

## Previously — 2.9.54 (2026-09-27)

The app is on **v2.9.54** — *Nova leveled up*. Bigger robot (arms, glowing core, cheeks, brighter busy glow) with drifting particles, typewriter speech, percent in the progress title, and a mono activity feed that logs each source live while she works (auto-hidden when idle). Feed hooks via a healthRecord wrapper; old paint fns stay renamed as *Old shims.

## Previously — 2.9.53 (2026-09-27)

The app is on **v2.9.53** — *Nova, the source-health robot*. The More → Source health list (fifty rows, filter chips, per-row retry buttons) is gone: a central robot with a progress ring, Healthy/Slow/Down counts, one Check-all button (tapping Nova works too), and plain-word notes on failures. She narrates each check, then auto-retries whatever stumbled (failed-first, max 6, quiet gaps, never while the reader is loading). Probe engine untouched; old paint functions renamed to *Old shims (the preview parser rejects duplicate declarations).

## Previously — 2.9.52 (2026-09-27)

The app is on **v2.9.52** — *six fixes*. AsuraScans detail crash fixed live (scoreText never existed on the new Astro site; rating now from ld+json/props ÷2, votes from ratingCount; cards read the star badge). Action row is a 5-col grid (zero shift measured). Remove path wrapped so the screen always repaints. Counts include adult (intro+about = 50); health has a gated 18+ chip via healthVisibleSources/vaultAllowed (sweep already covered adult). History swipe-to-delete with tap-to-close. All verified live except the exact toggle-death, which never reproduced — most likely fallout from the Asura crash blocking the UI.

## Previously — 2.9.41 (2026-09-26)

The app is on **v2.9.41** — *reference-identical book screen*. Plain pink author (no pill), hero status/shelf pills removed (live in ⋮ menu as Set status / Add to shelf, labels echo current values), chapter rows back as separate cards with single-line titles + brighter dl circles, 15px header title, white rating number, chunkier genre chips, read chevron pinned right, chapter search uses the reference dash. Scoped to #bookChapters so the chapter picker modal keeps its list rows. Fixed: opening Set status from ⋮ no longer instantly closed by the statusMenu document closer (#bookMenuStatus exempt).

## Previously — 2.9.40 (2026-09-26)

The app is on **v2.9.40** — *reference hero rebuild*. Header bookmark + ⋮ menu (mark-all-read/clear via PROGRESS+saveProgress), icon meta row, gradient read button with icons, action card, synopsis collapse head, chapters card with cNum/goChev/inprog rows.

## Previously — 2.9.39 (2026-09-26)

The app is on **v2.9.39** — *book progress + action scroll*. Progress bar under the read button (chapter/read/percent), unread count in chapterListHead, icon row scrolls (flex-shrink 0).

## Previously — 2.9.38 (2026-09-26)

The app is on **v2.9.38** — *vault filters + hero refresh*. Vault filter row (vaultLangBtn/vaultLangFilter/vaultLangSheet, vaultHideBad, keys yuedu_vaultlang/yuedu_vaulthide); hero restyle (marquee blur, 128px cover, heroPill meta, gradient read button, synopsis card, sticky chapter head, chapter cards).

## Previously — 2.9.37 (2026-09-26)

The app is on **v2.9.37** — *After Dark Browse, faster genres, deeper 18+ feeds*. Vault gains source search, All/Novels/Comics chips (state.vaultKind) and its own global search (vaultGlobalSel); tag enrichment 60-card batches × 8 workers with pending-chain so counts grow past 1; adult feeds start at 4 pages with caps 200/200/100/100 (HentaiFox page-3 skip fixed).

## Previously — 2.9.36 (2026-09-26)

The app is on **v2.9.36** — *After Dark tab removed, feed exit button, big genre screen*. Bottom After Dark tab deleted (18+ chip only, plain style, no emoji); floating ↑ back-to-top in feeds; genre sheet rebuilt as a big centered list with its own search; tag enrichment 6-wide with live chip updates.

## Previously — 2.9.35 (2026-09-26)

The app is on **v2.9.35** — *18+ chip, feed genre lists, red 18+ flags*. 🌙 18+ chip beside All/Novels/Comics on Browse (opens the vault, gate kept); every non-Webnovel feed gets tappable genre chips with counts + an All-N full-list sheet (feeds without tags enrich up to 30 cards in the background, 4 at a time); adult feeds tint BAD_GENRES red (token match, so "lolicon (female)" flags — verified 240 genres on HentaiForce with lolicon/shotacon red, 0 red on MangaKatana). Cards carry data-tags; Webnovel keeps its server genre search.

## Previously — 2.9.34 (2026-09-26)

The app was on **v2.9.34** — *Hentai20 + HentaiEra + HentaiFox join After Dark*. Hentai20 (adult manhwa) via theme pages + reader JSON (25-page chapter at 720x5000 verified); HentaiEra and HentaiFox (adult galleries) via the HentaiForce one-request page-list pattern (55 and 37 pages verified). Vault holds 4 sources; all new hosts ride the cover loader from day one.

## Previously — 2.9.33 (2026-09-26)

The app is on **v2.9.33** — *After Dark tab + HentaiForce*. 18+ sources live behind a moonlit nav tab with a one-time age gate; HentaiForce (adult galleries) via plain pages + one-request page lists (55-page gallery at 1280x1800 verified). Adult sources stay out of Browse, global search, health, counts and move-book lists unless the book itself is adult. Entering one from the vault returns to the vault on back.

## Previously — 2.9.32 (2026-09-26)

The app is on **v2.9.32** — *Komiku + VioletScans join (46 sources)*. Komiku (Indonesian manga/manhwa/manhua) via its live API host (the parser's one is dead), htmx list endpoint, series pages and plain chapter pictures with the promo banner skipped (70 chapters, 720x2500 verified). VioletScans (English romance) via plain pages + reader JSON (64 chapters, 37-page chapter at 800x8240 verified). RoliaScan parked (redesigned into a JS shell). Both new hosts ride the cover loader's plain-load list from day one.

## Previously — 2.9.31 (2026-09-26)

The app is on **v2.9.31** — *feed-cover fix for the two new sources*. DynastyScans and ManhuaPlusOrg covers were blank: the cover loader asked the two new picture hosts in CORS mode (refused, no proxy behind them). Both hosts join the plain-load list with the image proxy behind them, like every other manga host. Verified in the live Browse screen (160x228, 360x518 real pixels).

## Previously — 2.9.30 (2026-09-26)

The app is on **v2.9.30** — *DynastyScans + ManhuaPlusOrg join (44 sources)*. DynastyScans (yuri scanlations) via plain reader pages (search, cover directory feeds, series, var-pages chapters — 1114x1600 verified); ManhuaPlusOrg via liliana pages + /ajax/image/list/chap image-list call (search, latest feed, full chapter lists, long strips — 800x10584 verified, plain browser-readable). 13 more Kotatsu-Redo-tree candidates probed and skipped (closed/CF-walled/unreachable/parked/hijacked/adult/bot-thumbs).

## Previously — 2.9.29 (2026-09-26)

The app is on **v2.9.29** — *Tapas + DemonicScans join (42 sources)*. Tapas via m.tapas.io mobile pages (letter-search feeds, series info, tokenized content__img pages, Ink-locked episodes named); DemonicScans via its readermc pages (search.php, lastupdates feeds, full inline chapter lists, cdn.demoniclibs.com pages, ad skipped). Both verified with real decoded pixels (940x1372, 1204x1650). 15 candidates probed and skipped (parked/bot-walled/dead/pictureless).

## Previously — 2.9.28 (2026-09-26)

The app is on **v2.9.28** — *feeds pause off-screen, Enter closes the keyboard, whiter chapter text, TTS touch always on, History toolbar, launcher mark in intro/about*. `showScreen` pauses `discover` off Browse, scroll pump gated on Browse active, sourceFilter Enter blurs, READER_THEMES dark colors bumped (~7%), touch handlers unconditional beside pointer ones, History segmented toolbar + roomier rows, intro/about SVGs = launcher book with spine. Verified live.

## Previously — 2.9.27 (2026-09-26)

The app is on **v2.9.27** — *genre filter everywhere, Madara stars, quieter notices, launcher tile, pink announcements*. Genre filter box on every source screen (Webnovel keeps chips; others filter cards by genre text), Madara `_score` parses to star ratings, chapter date-tails stripped in `cleanChName`/`chapterTitleFor`, toast gate (warn/err/update only), `addToLibrary` CSS.escape, native image concurrency 4, blob revoke in `mgDropPages`, intro/about dark-tile pink-book logos, announce pink recolor, History card rows, titles wording, hide-unavailable default ON, mangaCont default on, 40 sources. Verified: boots clean, no syntax errors.

## Previously — 2.9.26 (2026-09-26)

The app is on **v2.9.26** — *ZinManga's second Referer, no more double captcha, no connection pill, one book mark*. (2.9.22–2.9.25 shipped without a log entry: guarded sources return, LikeManga rejoins as the 5th gated source, guarded covers go native-first in the app.)

- **ZinManga chapter pictures** are asked for with the chapter page as Referer first, site root second (`mgPageReferer` + `data-page` stamped on every strip page at build/append/prepend, `MG.chapterId` behind the pager). The other guarded hosts accept both, so they just gain a spare try.
- **Captcha stops asking twice**: `captchaProbe` verifies the blocked page (not the front page), a Done counts for 90s (`captchaLastDoneAt` — a refusal inside that window stays off-screen with "keeps trying on its own" while auto-retry runs), and a 3s double-tap guard on Solve plus `singleTop` on the Challenge activity stops stacked screens.
- **Captcha screen + Challenge activity restyled** (app-theme card, accent Solve, title/sub/progress/Cancel), **toasts refined** (plain fallbacks before every `color-mix`/gradient so old WebViews draw the icon tile), **connection pill deleted** (markup, CSS, machinery → no-op stubs; transports still call the same names), **intro logo = launcher open-book mark** (also drops the dot; plain fallbacks added).
- 41 sources; versionCode 4. Verified live: 2.9.26 boots clean, toast kinds, captcha card layout + grace branch, strip `data-page` 3/3, ZinManga ch26 parses 148 pages off `img-1.mangazin.org`.

## Previously — 2.9.21 (2026-09-26)

The app is on **v2.9.21** — *ZinManga replaces LikeManga*. LikeManga leaves: its pictures are hotlink-guarded (`Referer: https://likemanga.ink/` required) and stay blank on every route a browser build has, so it is retired (`RETIRED_SOURCES`, shelved books answer with the reason). ZinManga (mangazin.org, manga/manhwa/manhua) joins as the 5th MADARA_HOSTS site instead — measured 2026-09-26, search/series/chapters/pages all plain HTML and its `img-1.mangazin.org` pages + covers load with a plain `<img>` — so it reads through the shared Madara engine end to end. 40 sources total.

## Previously — 2.9.19 (2026-09-26)

The app was on **v2.9.19** — *endless novel feeds*. All 28 novel sources extend page-by-page via discoverExtend (NoBadNovel already covers its whole catalogue); 3 consecutive empty or 6 failed shelves end the feed. 39 sources total.

## Previously — 2.9.18 (2026-09-26)

The app was on **v2.9.18** — *library search that can't miss over spaces*. Query trimmed/collapsed/NFKC-normalized before matching, null-safe titles, empty state quotes the query.

## Previously — 2.9.17 (2026-09-25)

The app was on **v2.9.17** — *Toonily covers, endless comic feeds*. Toonily/MangaKatana picture hosts requested plainly with fetch-proxy fallback; all 11 comic feeds extend page-by-page via discoverExtend until the catalogue runs dry.

## Previously — 2.9.16 (2026-09-25)

The app was on **v2.9.16** — *two more comic sources*. Toonily (manhwa, fourth Madara site) and MangaKatana (own reader) join the source list with logos, search covers and webtoon reading.

## Previously — 2.9.15 (2026-09-25)

The app was on **v2.9.15** — *quieter updates, steady comic sheet, webtoon default*. Empty-library update checks note inline instead of a popup; mode picks no longer flip the sheet to novel settings; Auto is gone, Webtoon is the default.

## Previously — 2.9.14 (2026-09-25)

The app is on **v2.9.14** — *the insides match the new look*. Sub-screen rows grouped into cards with icon tiles, Reading in five labeled groups, glowing toggles, Save data hero card.

## Previously — 2.9.13 (2026-09-25)

The app is on **v2.9.13** — *progress on the cover*. Started library titles wear a thin accent progress bar along the cover bottom; the empty-state button keeps its label on one line.

## Previously — 2.9.12 (2026-09-25)

The app is on **v2.9.12** — *a More tab that reads at a glance*. Three labeled card groups (Sources, App, Info), tinted icon tiles, matching icons, a live source count on Sources & extensions, no two-line wraps.

## Previously — 2.9.11 (2026-09-25)

The app is on **v2.9.11** — *notices name the right source*. The reconnect watch could announce the wrong source (a ManhwaTop notice while browsing ManhuaPlus) because it re-derived its source from a globally remembered address that background requests overwrite; it now pins its own source and stays silent with nothing pending.

## Previously — 2.9.10 (2026-09-25)

The app is on **v2.9.10** — *comic logos, true comic kinds, YueDu everywhere*. The nine comic sources wear their site logos in the source list; their badges read Manhwa, Manhua or Manga depending on what the source carries, on the source list and on every card; the name is YueDu in every string and storage key (existing saves migrate from pocketnovel_* to yuedu_* on first load); the welcome screen covers novels and comics together.

## Previously — 2.9.9 (2026-09-25)

The app is on **v2.9.9** — *all 28 novel sources search-checked*. Every novel source answers with its own matching titles and covers (two queries each). Fixes: NoBadNovel empty answers fall back to catalogue title-filter; CG cover window 500 to 3000 chars (dragon 5/5 covers); NovGo/NovelFull coverless cards backfill from the title page. Genuine site answers kept: Wuxiaworld has no magic, Inkitt matching is the site own, RR nocover rows stay coverless.

## Previously — 2.9.8 (2026-09-25)

The app is on **v2.9.8** — *tight cards, black comic chrome, centred language sheet, health kind tabs, comic search covers*. Card titles fit their text (no dead band under short names); the comic reader's header/footer/search are solid black; the Browse language filter is a centred sheet; Source health has the Novels/Manga switch; Madara comic searches return covers via the site search page, and coverless MangaPill/Madara cards backfill from the title's own page. ManhuaPlus 'solo'/'lookism' emptiness is genuine (the site itself has nothing), not a search bug.

## Previously — 2.9.7 (2026-10-01)

The app is on **v2.9.7** — *Browse outside the source list, redesigned*. The
request was: keep the source list exactly, redesign global search and the rest
of Browse, with an undo ready.

- CSS-only, scoped to `#browseScreen`: global card (gradient, accent light-bar,
  icon tile, focus glow), source chips re-tinted to the Manga-pill pink,
  filter row as a card, bolder result headers, pill back button, micro-caps
  genre/rating labels, `color-mix` fallbacks on `.gchip.on`.
- Undo: full pre-change copies at `src/undobackup-browse-redesign-296/`
  (durable) plus `scratch/undo-browse-redesign/` (session). Delete the src
  backup once the user approves the redesign.
- Mirrored to `src/standalone/index.html`.

## Previously — 2.9.6 (2026-10-01)

The app is on **v2.9.6** — *the Manga pill stays on the card, and keeps its
colour*. The request was: *"Fix Manga pill, its feed novel color doesn't show"*.

- `applyChapterCount` rewrote a feed card's whole `.novelMeta` line with the
  chapter count alone, wiping the `Manga` kindChip the moment the lazy length
  landed — which is every MangaPill/FlameComics/MangaGeko card. It rebuilds the
  line with the pill plus the count now, and a title with no count keeps the
  pill on its own instead of losing the line. Verified live: all staged
  MangaPill cards wear `Manga` + count after enrichment.
- `.kindChip` (and `.sourceKind`, the same pill on the source card) declared
  background/border only via `color-mix`, which older Android WebViews drop —
  bare text, no pill. Plain `#462235`/`#772948` fallbacks first, `color-mix`
  over them where supported.
- Mirrored to `src/standalone/index.html`.

## Previously — 2.9.5 (2026-10-01)

The app is on **v2.9.5** — *its own feed per source, read counts on cards, shelves
that file themselves*. The request described three pains: manga sources wearing
each other's feeds, no read-vs-total counts on library/feed cards, and no
want-to-read/reading/don't-want measures.

- The shared feed was the feed cache keyed by shelf name alone: `madfeed:popular:1`
  names a different shelf on all three Madara sites, so the first-opened lent its
  feed to the other two (same cards, same bookIds — hence the "already saved"
  déjà vu). Keyed by source+shelf now; verified ManhuaPlus vs ManhwaTop return
  different shelves.
- `readDoneCount` counts finished chapters from `PROGRESS[].__done__`;
  `chapterChipLabel/total` renders `read/total ch` once started, plain total before.
  Used by feed cards (render + enrichment path), library cards (`libChaptersHTML`),
  novels and comics alike.
- Feed cards for library titles carry the shelf tag (`shelfTagHTML` on the lib
  entry in `gridResult`); adding to the library auto-files *Want to read* when
  unshelved (`autoShelf(book, "interested")` — first chapter → *Reading* and last
  → *Finished* already existed and are untouched).
- Mirrored to `src/standalone/index.html`.

## Previously — 2.9.4 (2026-10-01)

The app is on **v2.9.4** — *one more comic source, and MangaFire's verdict*. The
request was: *"Add more popular sources on Manga source. What I mean Manga is
with the combined manhua and ect. And also try doing mangafire English sources"*.

- **MangaGeko** (`gk-`, vertical) is source nine for comics: manga, manhua and
  manhwa in English, read from its own server-rendered pages. Search
  `/search/?search=`, series `/manga/<slug>/` (og:image cover, `.categories`
  genres, `.description` blurb, Ongoing/Completed status), the whole chapter list
  at `<series>all-chapters/` (newest first, reversed to reading order), chapter
  pages as `center img` pictures. Covers lazy-load from `data-src`. The catalogue
  pages (`/browse-comics/`) render their rows in script, so the feed is
  single-letter searches (`gkfeed:a/e/i/o/s/t`, ~30 cards a shelf). An `.author`
  box reading "Updating" means unknown and is stored as "". Measured: "solo"
  search finds Emperor of Solo Play, 85 chapters Ch 1–85, ch. 85 = 22 pages.
- **MangaFire** stays out. Probed hard: every page returns the same 3.4 KB script
  shell, the content API is Laravel routes that are all "could not be found"
  except through undocumented paths, POSTs to `/api/*` are refused, the app
  bundle host 404s every transport, and no public parser source exists to copy
  the route map from. Nothing the app owns gets a readable answer, so there is
  nothing to build on.
- Also probed and skipped: VyManga (JS shell now, Kotatsu parser stale),
  ManhwaClan + KunManga (bot checks), TopManhua (dead).
- Mirrored to `src/standalone/index.html`; main.pjs + DESCRIPTION.md 36→37.

## Previously — 2.9.3 (2026-10-01)

The app is on **v2.9.3** — *three more comic sources*. The request was: *"Add new
Manga sources, manhwa, Manga manhua and ect. Sources."*

- **AsuraScans** (`as-`, vertical): server-rendered browse/series/chapter pages.
  Cards (`.series-card`) already state the chapter count, so it shows straight
  away. Series at `/comics/<public-id>`, chapters at `.../chapter/<n>`, pages are
  `img[data-page-index]` on cdn.asurascans.com. Chapter numbers come from the URL
  because the row text glues the date onto them ("Chapter 201 day ago" for ch. 20);
  the two "First Chapter" buttons are skipped in favour of the list's own ch. 1 row.
- **FlameComics** (`fc-`, vertical): Next.js JSON behind `/_next/data/<buildId>/`
  (buildId read off `/browse`, cached — redeploys change it). `browse.json` holds
  all ~167 series (also the search: client-side title filter), `series/<id>.json`
  holds chapter tokens, pages parsed off the chapter page's own pictures on
  cdn.flamecomics.xyz (JSON route as fallback, with `edit_time` kept on chapter rows).
- **MangaPill** (`ml-<num>-<slug>`, rtl): manga only — its manhwa catalogue was
  removed. Server-rendered `/search?type=&status=&q=`, `/manga/<num>/<slug>`,
  `#chapters` links, `img.js-page[data-src]` pages on cdn.readdetectiveconan.com.
  Each title is linked twice (cover link + title link), so only the link wearing
  words is read. Feed = homepage + single-letter searches.
- Wiring, same as every source: ID_PREFIX_SOURCES, COVER_HOST_SOURCES,
  SRC_ALIASES, sourceBaseURL, sourceForURL, coverURLs + loadCoverImg exclusion
  (all three picture CDNs load plainly with npcProxy behind), MG_LOGOS, SRC map,
  CHAPTER_ENRICHABLE + chapterCountForBook, buildDiscoverJobs (`asfeed`/`flfeed`/
  `mlfeed:`), fetchBrowsePage, feedLabel, HEALTH_URLS, SOURCES (`type: "manga"`).
  Measured: Asura search "solo" → Solo Farming In The Tower (145 ch stated);
  series 20 chapters Ch 1–20, ch.1 = 22 pages; Flame series 165 = 17 chapters,
  ch.17 = 17 pages; MangaPill Solo Glitch Player = 186 chapters, ch.186 = 58 pages.
- Mirrored to `src/standalone/index.html`; main.pjs + DESCRIPTION.md 33→36.

## Previously — 2.9.0 (2026-09-30)

The app is on **v2.9.0** — *the comic reader keeps its pages, and reads on through
chapters*. The request was: *"fix the tts read aloud icons floating, it floats
even on the Manga one. Make it dissappear, appear only in novel. And also when I
first open a chapter. I got straight into the end. Notification end of chapter.
The pages seems to be compacted like not even an inch tall. But soon it becomes
larges and goes back to normal and I automatically got into the top, fix this
bugs. And add a continues reading options on Manga."*

### The placeholder is the attributes, not `aspect-ratio` — read this first

The v2.8.0 strip's placeholder was `aspect-ratio: 2 / 3` on `.mgPage img`, plus a
`load` handler that reset it to `auto` for the arriving picture. `aspect-ratio`
is Chrome 88 (Jan 2021). On an engine that predates it — cheap Android phones and
older Android System WebView builds, which is exactly what the APK runs in — a
page whose picture has not arrived gets **no height at all** and falls back to
`.mgPage { min-height: 100px }`. That one rule explains three of the four
symptoms in the report:

- *"the pages seems to be compacted like not even an inch tall"* — that is the
  100px floor, exactly;
- *"I got straight into the end. Notification end of chapter"* — with 100px
  pages, the end card (≈350px including its own padding) is a few hundred pixels
  down a strip that should be 56,000px long, so it is on the screen at the moment
  the chapter opens;
- *"soon it becomes larges and goes back to normal and I automatically got into
  the top"* — the pictures land, the pages take their real height, the card drops
  out of sight and the reader is at the top of the chapter again.

Pages now state their shape with their own attributes — `mgPageHTML` renders
`<img … width="800" height="1200">`, and `#mgImg` in `mangaBuildPager` carries
the same pair — and the CSS `aspect-ratio` rule and the `load` handler are gone.
Measured in the live page: an `<img>` with no `src` and no attributes is 0px
tall; with the attributes it is 585px in a 390px column (identical in a browser
that *does* support `aspect-ratio`, so nothing changes for a modern one); a 2:3
attribute hint over a 1:3 picture ends up 1170px, so a real picture always beats
the hint. The **paged** reader had no placeholder at all — a page was 0px tall
until its picture arrived, which is the same complaint in its other shape — and
now measures 586px from the moment a chapter opens.

Trap for a future session: this bug is invisible to a test built on data-URL
pages (they load in the same frame) and visible in every engine to a test that
measures an `<img>` with no `src`. Measure the box, don't eyeball it, and prefer
real network pages (`MD_search` → `MD_getBook` → `openChapter`) when the
placeholder is what is being checked.

### Continuous chapters (`mangaCont`)

A new reader setting, default **off**, in the manga block of the reader settings
sheet (`[data-mgrows]`, a "Continuous chapters" row beside "Page gap", with the
explanation moved into the block's long hint) and wired through `mgSetCont` in
the delegated `change` handler. It is the comic's answer to the novel reader's
`cont`, and the same idea in both of a comic's shapes:

- **Webtoon.** `MG.groups` is one row per chapter the strip holds (`cid`, `num`,
  `name`, `nextId`, `prevId`, `total`, `start`, `count`), while `MG.pages` stays
  the flat list of every picture in the DOM — so everything that counts pages
  (`mgVisibleIndex`, `mangaProgress`, the loader's `data-i`) keeps working
  unchanged. `mgContAppendNext` (`contFetch` → pages appended + a group pushed)
  is driven from `mangaProgress` when the reader is within two pages of the
  tail **or** within 1600px of the foot; `mgContPrependPrev` puts the previous
  chapter back on top and compensates the scroll by exactly what it added
  (reading `beforeH`/`beforeTop` *before* the insert and writing an absolute
  position after, the same pattern as the novel's `contPrependPrev`).
  `mgContTrim` keeps three chapters either side (`CONT_KEEP`) and renumbers every
  page's `data-i` when a chapter arrives or leaves; `mgContTail` draws the
  strip's last child — nothing, a spinner, a retry, or the ordinary end card once
  the last chapter a source has is in the strip.
- **Paged.** `mangaShow(i >= n)` crosses into the next chapter (`mgContCross(1)`)
  instead of showing the end card, and `mangaTurn(-1)` at page 0 opens the
  previous chapter at its last page; `mgFollowChapter` moves the header, the
  footer's count, the bookmark, `state.chapterId/chapterNum/nextId/prevId` and
  the history entry to the chapter under the eye, and `mgUpdateEndCard` rewrites
  the card behind the last page so it names the chapter the reader is in.
- Next/Back in the footer (`mgContJump`) scroll to a neighbouring chapter when it
  is already in the strip, otherwise reopen through `openChapter`; in the paged
  shapes they are one `mgContCross` away. The scrubber is chapter-relative
  (`scrubTo`) because that is what `mangaProgress` puts on it.

Measured: a five-page chapter carried on into the next one on the fifth turn and
back onto the previous chapter's last page on the turn before it; a nine-chapter
walk held fifteen pages in the DOM at every step with `data-i` contiguous
(0..14) and the strip never larger than five chapters; a chapter opened at 50%
resumed at `scrollTop` 27801 of 55682 and a scrub to 20% landed on the chapter in
hand's first page ("1 / 5") rather than at 20% of the whole strip.

**One bug found the hard way:** the trailing half of `mgContTrim` must
`MG.groups.pop()` *before* `mgDropPages` — a row left in the array makes
`length - 1 - vi > CONT_KEEP` true for ever and freezes the page in an infinite
`while`. It froze the live preview during the first trim test.

### A finished chapter opens at its first page

`mangaOpen` reads `chapterPct` and treats `>= 95` as `0`: reaching the end card
writes the chapter down at 100%, and restoring that puts a reader who had only
tapped past a chapter straight back onto its last page — the fourth symptom
("I got straight into the end"). A chapter that is *under way* still resumes
exactly where it was (measured: half-way reopened at `scrollTop` 27801 of
55682; the same chapter at 100% reopened at 0).

### The TTS widget over a comic, and the restore timers

- `ttsRefreshWidget` already refused to show the widget for a manga chapter
  (`MG.on`), but it calls `ttsPanelHide()` when it hides it — and `ttsPanelHide`
  put the widget back up without asking whether a comic was open, so the speaker
  was hidden and re-shown in the same call, every time the reader's furniture was
  drawn. `ttsPanelHide` (and `ttsPanelShow`) now check `!MG.on`; `mangaOpen`
  calls `ttsAbort()` before `ttsRefreshWidget()` so a chapter of pictures also
  stops any speech that was running.
- `mgRestoreScroll`'s four timed jumps (260/700/1400/2400ms) now check
  `MG.seq` **and** `MG.chapterId`, and find their page through the chapter's own
  row in `MG.groups` rather than by an index into the strip — a continuous strip
  can have had a chapter put back on top between one jump and the next, which
  moves every page below it along.

### Traps when testing this

- **This release's own `pendingSrcChanges` trap:** after editing, `page_eval`
  runs the *old* code until `page_refresh`. One scrub test here was measured
  against stale code and produced a nonsense result; the flag in the result is
  what caught it.
- `mgContTrim` relies on the browser's scroll anchoring to hold the reader's
  place when pages *above* them are removed (the novel reader's `contTrim` has
  always relied on it too). Do not add a compensating `scrollTop` write — that
  double-counts, which is the trap 2.8.3 recorded for the chrome jump.
- `mgContAppendNext` is deliberately *not* triggered from the IntersectionObserver:
  the observer fires for every page that comes near the foot, so a reader parked
  at the bottom of a chapter walked straight through the rest of the book before
  the append moved to `mangaProgress`. The observer only *warms* the next chapter
  now (`mgTailNextId`).
- The strip's placeholder ratio (2:3) is a guess; a real MangaDex spread is
  1568x1100, so a page shrinks from 586px to 274px when it lands. That is
  expected and unchanged from 2.8.0.

## Previously — 2.8.3 (2026-09-30)

The app is on **v2.8.3** — *showing the controls no longer moves the page*. The
request was: *"when you tap and those ui shows up there seems to be a shake like
that yi showing somehow pushes the thing down. It happens in the novel thing, but
it was fix."*

### The jump, and the rule that prevents it

Measured before the fix on a 390x844 screen, in a webtoon: showing the controls
moved the strip **down 64px** and hiding them moved it back
(`firstVisible.top` -300 → -236 → -300). Two `.chrome-hidden` rules did it:

```css
#reader:not(.chrome-hidden) .reader-body.manga.mg-vertical { padding-top: calc(72px + env(safe-area-inset-top, 0px)); … }
#reader:not(.chrome-hidden) .reader-body.manga.mg-paged    { padding-top: calc(72px + env(safe-area-inset-top, 0px)); … }
```

The header's height was reserved along the top *only while the controls were up*,
and a top padding that appears moves everything under it. The paged reader looked
innocent only because its bottom padding grew by the same amount — a centred page
is centred in `[72, 772]` exactly as it was in `[0, 844]` — but a **tall**
fit-width page in the stage moved with it.

The chrome-dependence is gone:

- `.reader-body.manga` is `.mg-vertical { padding: 8px 0 0 }` / `.mg-paged
  { padding: 0 }` in **both** states; the controls float over the art.
- the footer's room at the end of a chapter moved into the end card:
  `.mgEnd { padding: 46px 22px calc(96px + env(safe-area-inset-bottom, 0px)) }`
  — measured at the end of a webtoon with the controls up, the last button's
  bottom is 748px and the footer's top 772px, 24px clear, and it cannot move
  anything above it.
- the novel's rule was scoped so it cannot leak onto a comic:
  `#reader:not(.chrome-hidden) .reader-body:not(.manga) { padding-bottom: 110px }`.
- `setReaderChrome` (~19584) is the plain class toggle again, with the invariant
  written beside it: **a `.chrome-hidden` rule may only change space BELOW the
  content, never above it.** A novel has always obeyed it (its top padding is a
  deliberate constant 78px), which is why a tap has never moved a novel's words.

A compensating `scrollTop` write was tried first and abandoned: it **fights the
browser's scroll anchoring**, and the strip flew 300px forward instead of holding
still. Do not reintroduce it; make the layout not move in the first place.

Verified after: webtoon part-way down (`firstVisible.top` -300 through
show/hide/show), paged tall page (`imgTop` -400, `stage.scrollTop` 400), paged
short centred page (`imgTop` 129), novel at `scrollTop` 1200 (`refTop` -1063) —
all unchanged, with the controls still toggling from the top, middle and bottom
of the screen.

### Traps when testing this

- **`mgRestoreScroll` (~11345) jumps on a timer.** It scrolls to the saved
  position and repeats at 260/700/1400/2400 ms after a chapter opens, so a test
  that opens a chapter with saved progress and measures a second later records
  *its* jump and blames the controls. Delete `PROGRESS[bookId]` for the test book
  and wait out 2.4s before measuring — this cost an hour of chasing a phantom.
- The animation is 220ms: wait ~340ms between taps, or a follow-up tap lands on
  whatever is under the finger mid-transition.

## Previously — 2.8.2 (2026-09-30)

The app is on **v2.8.2** — *the reader answers every tap, and the filter rows
dress like the tabs*. The request was: *"Make those in library like show, all
reading, ongoing big and exactly like those default, local button, and the Manga
read, remove the like number 1/14 on the bottom. And improve it. Because theres
like a space that is not occupied on the bottom. And the tapping the ui doesn't
sometimes show up … it doesn't respond when you tap on the top. Only on the
button near that number 1/14 or something."*

### One tap handler for the whole reader (the actual bug)

Tap-to-show-controls used to be split in three: a `#readerBody` click listener
(the novel reader, and whatever of a comic the page did not cover), a
`mangaBuildPager` pointerdown/up/move trio that read a *tap* out of the pointer
events, and `stage.click → stopPropagation` to stop those two double-toggling.
That produced "only the footer button works":

- the pager's tap required `moved` to stay false, and `moved` went true after
  **12px** of finger travel — so a tap that drifted at all was read as a drag and
  thrown away;
- `.reader-header` and `.reader-footer` are *siblings* of `#readerBody`, not
  children, so a tap on either — the top and the bottom of the screen, wherever
  the chrome was sitting — reached no listener at all.

There is now one handler, on `#reader` (~22581): a tap matching
`button, a, input, textarea, select, label, #readerScrubber, #readerSearch` is
left to that control, a tap inside `.mgStage` of a paged comic is split into the
outer thirds (turn the page) and the middle (toggle), and every other tap
anywhere toggles the chrome. `mangaBuildPager` (~11387) keeps only the *swipe* —
a horizontal drag over 45px — because a swipe is the one gesture the browser
sends no click for; it stamps `lastPageTurn` (~11259) so the click some browsers
still send after a swipe cannot turn the page twice. **A new tap action must
therefore be either a real control or sit outside `#reader`** (`#readerSettings`,
`#chapterModal`, `#ttsPanel`, `#ttsWidget`, `#commentsSheet` are all outside it
already).

### The rest of v2.8.2

- **The floating page count is gone in the comic reader.** `mangaProgress`
  (~11535) used to write `1 / 14` into `#readerPctFloat` *and* `#readerFootPct`;
  the pill is now emptied and `hidden` (~11545). The number lives only in the
  footer's chapter-list button (`#readerFootPct`), which is the control that uses
  it. `openChapter` (~18808) hides the pill on every open and
  `updateReaderProgress` un-hides it for novels, so a novel keeps its pill.
- **The comic reader reserves nothing along the bottom.** `.reader-body.manga`
  carried `60px` of bottom padding in *both* shapes, to clear a footer that is
  usually not on screen — a permanent band of empty background under the art, and
  the paged stage 784px tall in an 844px screen. The base padding is `0` now
  (`mg-vertical` keeps its 8px top gap) and space is reserved only while the
  chrome is up: `#reader:not(.chrome-hidden) .reader-body.manga.mg-paged
  { padding-top: calc(72px + safe-area-top); padding-bottom: calc(72px +
  safe-area-bottom) }` (~1321) — 72px being the measured height of the footer.
  Measured after: the paged stage is the full 844px, and a `2:3` page at 390px is
  centred with 404 device px above it and 403 below.
  **v2.8.3 took the chrome-dependence back out of those two rules entirely** —
  reserving that space only while the controls were up was what made a comic jump
  when they appeared; see the v2.8.3 section above for the form they take now.
- **The library and Browse filter rows are styled as tabs.** `.statusChip`
  (~215) is no longer an 11.5px pill but `.tab`'s own treatment — 14px/600 text,
  no box, `::after` accent underline when `.on` — and `.statusRow` wraps
  (`flex-wrap: wrap`, `column-gap: 14px`) instead of scrolling sideways. The
  shelf colours (~2115) moved from always-on to `.shelfChip.on.*`, so an off chip
  is the same neutral an off tab is.
  **The platform's `button:not([disabled]) { color: inherit }` out-specifies a
  bare class** (0,1,1 beats 0,1,0) — which is why an off chip takes its colour
  from the screen behind it, and why an off *tab* is `#e7e7f0` rather than the
  `#8a8a9c` `.tab` asks for. Matching the tabs meant *not* fighting that;
  `.statusChip.on` (0,2,0) and `.statusChip.ongoing.on` (0,3,0) win on their own.
  Measured: a chip is 29px tall in 14px type, identical to `.tab`; the last
  status row was 396px of chips in 363px of screen and clipped *No status* — with
  wrapping, everything is on screen at 390px.

### Carried over from 2.8.1 (which this README never got)

**2.8.1 was the novels-or-manga switch**, and it is live: `KIND_KEY`,
`KIND_META`, `KIND_ORDER`, `kindOfSource`/`kindOfBook`/`kindCounts`/
`kindChipsHTML`/`setKindFilter` (~3814-3850) plus one document-level listener on
`button[data-kind]`. `state.kindFilter` is `""|"novel"|"manga"` and is the only
persisted filter; two chips and no *All* (the shelf and status rows already have
one); the manga chip is pink. `renderKindRow` (library, above `#shelfRow`) and
`renderSrcKindRow` (in `#browseIdle`) draw it; `renderGrid` filters the library by
kind, `applySourceFilter` stacks the kind around the search/language/
hide-unavailable tests and hides the AI cards while *Manga* is on, and
`sourceSubText()` writes the counts into `#browseSub`.

### Verification notes for both versions

- Reproduce a reader without a source: build a fake book (`pages` = a handful of
  `data:image/svg+xml` URLs, `800x1200`) and call `mangaOpen(book, ch, …)` after
  `$("reader").classList.add("open")` — no network, and the data URLs survive
  `snapshot.js` (unlike a real comic host).
- Drive taps from `page_eval` as a full gesture: `pointerdown`, `pointerup`, then
  `click`, on the element `document.elementFromPoint(x, y)` returns. **Wait
  ~340ms between taps** — the header and footer animate over 220ms, so a second
  tap sent immediately lands on whatever is under the finger mid-transition and
  the reading is nonsense.
- Clear the other sheets first: `#commentsSheet` (z-index 70) and `#bookScreen`
  will sit on top of the reader and make `elementFromPoint` report *their*
  children. `closeCommentsSheet()` and `$("bookScreen").classList.remove("open")`
  before measuring.
- Check a capture objectively: decode it in `execute_js` with
  `createImageBitmap` + `OffscreenCanvas` and count rows of a known colour. The
  vision model called a perfectly centred page "lower in the frame" (measured:
  404 device px above, 403 below).

## Previously — 2.8.0 (2026-09-30)

The app is on **v2.8.0** — *YueDu reads comics*. The request was:
*"Let's not limit this YueDu to Novels only, let's do Manga manhua like
Kotatsu. Here's it's github https://github.com/KotatsuApp/Kotatsu"*.

Kotatsu is an Android manga reader, and its per-site parsers live in its sibling
repo **`KotatsuApp/kotatsu-parsers`** (`master`), not in `KotatsuApp/Kotatsu`
(which is app/UI only) — that parsers repo is where the five sources below were
chosen from and where their markup was read, together with live fetches of each
site.

### What was added

**Five sources, 33 in total**, each `type: "manga"` in `SOURCES` (~line 15403;
the manga rows are 15430-15437):

| Source | Engine | Default shape |
| --- | --- | --- |
| MangaDex | its own JSON API (`MD_*`, from ~10613) | paged, right-to-left |
| WeebCentral | its own pages (`WB_*`, from ~10774) | paged, right-to-left |
| ManhuaPlus | the shared **Madara** engine (`MAD_*`, from ~10925) | webtoon |
| MangaRead | Madara | paged, right-to-left |
| ManhwaTop | Madara | webtoon |

ManhuaPlus, MangaRead and ManhwaTop are the same WordPress theme, so **one
parser opens all three**: `MADARA_HOSTS` (~10925) is the table saying how each
differs (host, series path, reading direction, list badge, colour), and another
Madara site is one line there plus one row in `SOURCES`.

`CHAPTER_ENRICHABLE` / `chapterCountForBook` (~16282) gained `mdx`/`wb`/`mad`
branches so a comic card's chapter count is read from the title's own page;
`cardMetaHTML` (~16253) puts a **Manga** chip on grid cards and
`sourceCardHTML` (~16047) a `kindChip`-styled badge on the source-list card.
`passRating` exempts comics from the rating floor (no comic listing states a
score), and a comic's download button and per-row download icons are hidden.

### The comic reader

`MG` (~11183) is the state; `mangaOpen` (~11212) is the entry point reached
from `openChapter` whenever a chapter comes back with `pages` instead of
`html`. Two shapes:

- `mangaBuildStrip` (~11276) — **webtoon**: `.mgStrip` as a column of
  `.mgPage` divs, edge to edge, `gap` from `mangaGap`. A page's `<img>` starts
  with `aspect-ratio: 2 / 3` and no `src`; an IntersectionObserver
  (`rootMargin: "1400px 0px"`, root = `#readerBody`) sets `src` from
  `data-src` as the page comes near, and a `load` handler resets the aspect
  ratio to `auto`. That placeholder ratio is what bounds the loading: measured
  on a 53-page chapter, 5 pages were requested on open and 9 by the time the end
  card was reached.
- `mangaBuildPager` (~11315) — **paged**: `#mgStage` + `#mgImg`,
  `mangaShow(i)`, fit width (page as wide as the stage, tall pages scroll) or
  fit height (whole page, centred). Page turns come from a tap in either third,
  a swipe, or the keyboard; the direction reverses for `rtl`.

`mgUiFor` / `mgSetMode` / `mgSetFit` / `mgSetGap` (~11529-11545) keep the
settings sheet in step: manga rows live in the `[data-mgrows]` block (~3151)
and the novel-only rows carry `data-novelonly`; `mgUiFor(true)` hides one set and
shows the other, hides `readerSearchBtn`, and aborts TTS. `mangaMode: "auto"`,
`mangaFit: "width"`, `mangaGap: true` are in `DEFAULT_READER_SETTINGS` (~19337);
"auto" follows the source's own `mangaMode` (`mangaModeFor`, ~11187). The
novel reader is untouched — `MG.on` is false for it and every branch is guarded
by it.

### Gotchas found while building this (all of them cost time)

- **MangaDex answers a page-image request with a watermark.** A server-side
  `fetch()` of `uploads.mangadex.org/data/...` (i.e. what `snapshot.js` and
  `fetch_url` do) returns a 600x642 JPEG reading *"You can read this at:
  MANGADEX"*; a browser `<img>` load of the very same URL returns the real page.
  So the reader must show pages as `<img>` (it does), and **never verify MangaDex
  rendering through a fetch-based capture** — measure `naturalWidth` or use the
  `npcProxy` trick below.
- **MangaDex images are sent without CORS**, so a canvas that has drawn one is
  tainted: `vision({selector: "#mgImg"})` fails with "tainted canvas" and
  `snapshot.js` cannot inline them. Verification-only workaround that works:
  `img.crossOrigin = "anonymous"; img.src = npcProxy(realUrl)` gives a blob the
  canvas will accept (used for the 2.8.0 screenshots; the app itself must not
  add `crossOrigin` to comic pages).
- **snapDOM renders clones with different font metrics.** The `Read as` /
  `Page fit` segments measured one line each in the live DOM
  (`Range.getClientRects().length === 1`, 30px button / 28px content) while the
  capture showed `Left to right` wrapped inside a 30px button and clipped. Live
  numbers are the truth (see the 2.7.64 note above) — but `white-space: nowrap`
  was added to `.rsSeg .seg` anyway, so a wider fallback font can never clip a
  label.
- **MangaDex hosts nothing for the titles it licenses.** Their chapters carry an
  `externalUrl` and are skipped by `MD_chaptersFor`; `MD_SCANNED` plus the
  `langNote` on the book screen say so ("MangaDex hosts none of this title's
  chapters — it only links out to the release, which this app cannot open")
  rather than showing a bare empty list. Solo Leveling is one such title.
- **Madara's `admin-ajax.php` POST is intermittently refused** (search and the
  chapter endpoint), so both routes must stay: `MAD_search` falls back to
  `/?s=…&post_type=wp-manga`, and `MAD_chapters` to `<series>/ajax/chapters/`.
- **WeebCentral's fact rows are typo'd.** The tags row is spelled `Tags(s)`
  (and `Description` has no colon), so a text search for `Tag(s)` found nothing
  and tags + synopsis came back empty. `WB_facts` (~10798, with
  `WB_FACT_ALIASES` ~10791) reads the label out of each row's `<strong>` and
  looks it up, which works on both the series page (`<li><strong>`) and the
  search page (`<div><strong>`).
- **A chapter named only by its number.** Madara prints `CHapter 3860`;
  `cleanChName` returns its input when there is nothing left after the number,
  so the reader heading read "Chapter 3860: CHapter 3860".
  `chapterTitleFor` (~18629) now strips a leading `Chapter N` off the name and
  builds the heading from what is left, and `openChapter` and the manga end card
  both go through it.
- **A comic source's shelf is not all readable.** MangaDex's popular shelf opens
  with three licensed titles it hosts nothing of, so the health probe judged the
  source "empty". `probeSourceHealthRaw` now walks up to **six** titles (four
  empty ones tolerated) before that verdict, and its wording is kind-aware
  (`Titles, chapters and covers open` for a comic source). Measured after the
  fix: all five comic sources ok with covers, MangaDex included, 1.3-9.1s.

### Verifying the comic reader (what actually works)

- `probeSourceHealth(name)` for a source verdict; `MD_getBook`/`WB_getBook`/
  `MAD_getBook` then `openChapter` to drive the reader from `page_eval`.
- Layout claims were checked with `getBoundingClientRect` on `.mgPage img`,
  `#mgImg`, `#mgStage` (full-bleed = image width === stage width === viewport
  width; fit height = equal margins), not by eye.
- Screenshots that contain artwork: proxy the pages first (see above), then
  `snapshot.js` on `#reader`. `vision` cannot capture a tainted canvas.
- Reusable scripts from the 2.8.0 session (scratch/, ephemeral): `mg-reader.js`
  (paged/webtoon measurements), `mg-health.js` (all five probes), plus the
  `mg-mr.js` / `mg-mad.js` open-a-chapter drivers.

## Previously — 2.7.64 (2026-09-30)

The app is on **v2.7.64** — *the connection pill was rebuilt*. The request was:
*"Improved the Slow Connection UI alert"*.

### The connection pill (v2.7.64)

All of it is in `index.html`: the `/* ---------- connection pill ---------- */`
CSS block (~line 1449), the markup `#netAlert` (~line 3063, next to `#toast`),
and the `NET_ALERT` machinery under `/* ============================= connection
pill ============================= */` (~line 3634). **The detection logic is
untouched** — `netOwnState`, `netState`, `NET_FAIL_WINDOW`, the two-different-
hosts rule, `netNoteFail`/`netNoteSlow`/`netNotePic` and the 5s
`setInterval(netRefresh)` all behave exactly as before. What changed is what the
pill shows and how it is laid out.

- **Two lines.** The markup is now `#netAlertIco` (badge) +
  `#netAlertTxt` (title, bold, 12.5px) + `#netAlertSub` (muted, 11px), with
  `NET_ALERT.ico`/`.sub`/`.kind` added to the state object. `netSetAlert(kind)`
  writes all three; `NET_TITLE` holds the three titles.
- **`netDetail(kind)`** turns the evidence the app already gathered into the
  second line: two stalled/failed hosts → *Pages are taking a while to arrive*;
  two picture hosts → *Cover pictures are taking a while*; `navigator.onLine ===
  false` → *YueDu will pick up where you left off*; offline by its own
  evidence → *Requests aren't getting through*; Network Information API numbers
  → *Your signal is weak — <rtt> ms round trip* or *… — <downlink> Mb/s*.
- **A third state, `ok`.** On recovery the pill turns green, reads *Back online —
  pages and pictures are loading again*, and only then fades (after the existing
  4s of good state). `kind` tracks the current state so the pill is only
  re-rendered when the state really changes; the fade now also clears the `ok`
  and `offline` classes.
- **Badge, not dot.** `.netIco` is a 22px tinted circle carrying a glyph: `…`
  (amber, `netPulse` ring animation), `!` (red, static), `✓` (green, static) —
  so the state does not depend on colour alone.
- **Sized to its words.** `.netAlert` is `width: max-content` with
  `max-width: calc(100% - 28px)` and `border-radius: 16px` (a two-line pill is
  no longer a stadium); `.netSub` **wraps** instead of `nowrap` + ellipsis,
  because the end of the sentence is the part that says what happened.
  Measured live: 390px screen → 230-269 × 54px, detail on one line, badge centre
  exactly on the text block (`badgeCentreDelta` 0), 11px above and below,
  nothing clipped; a 200px-wide window → 172 × 85px with the detail on two
  lines, still nothing clipped. `align-items: center` keeps the badge centred
  when the text does wrap.
- **Reduced motion**: `.netIco { animation: none !important }` under
  `@media (prefers-reduced-motion: reduce)`.
- `role="status" aria-live="polite"` is unchanged, so a screen reader hears
  state changes without interrupting.

**Note on verifying this one**: the pill was checked by measuring the live DOM
(getBoundingClientRect on the real pill and on the exact clones used for the
screenshot). snapDOM renders the clones with different font metrics, which makes
the captured sub-line wrap to two lines and can make the badge *look*
top-aligned — the live measurements (`badgeCentreDelta: 0`, `subLines: 1`) are
the truth. Prefer the numbers over the capture here.

## Previously — 2.7.63 (2026-09-30)

The app was on **v2.7.63** — *feed cards from the three newest sources whose
listings state no chapter count now show it*. The request was: *"I noticed that,
some sources that is brand new added doesn't have the chapter list shown on the
feed. Fix them."*

### Chapter-count enrichment for Chrysanthemum Garden, Novelight and NoBadNovel

`cardChaptersHTML` (`index.html`, ~line 14900) prints the `N ch` chip only when
`res.chapters > 0`, so a card from a source whose listing states no length shows
no chip at all. Measured 2026-09-30 across every active source's first feed job,
**seven** of the 28 state no count anywhere in their listings — Webnovel,
GoodNovel, Wuxiaworld, Ranobes, **Chrysanthemum Garden**, **Novelight** and
**NoBadNovel** — and the last three are exactly the sources added last
(#25/#26/#28). The other four are older and were left as they are (their cards
still carry no chip, and `src/DESCRIPTION.md` says so in plain words).

The fix is a second lazy-enrichment block, `CHAPTER_ENRICHABLE` /
`CHAPTER_CACHE` / `CHAPTER_PENDING` / `CHAPTER_QUEUE`, sitting immediately after
the rating-enrichment block (`/* ---------- lazy chapter-count enrichment for
feed/search cards ----------`, ~line 15090). Per source, one request per novel,
read from the novel's **own page**:

| source | request | number read |
| --- | --- | --- |
| Chrysanthemum Garden | `CG_HOME/novel-tl/<slug>/` (`CG_IS_PAGE`) | `CG_chapterList(html).length` (the site's own chapter list), falling back to its `Total Chapters: N` line |
| Novelight | `NL_HOME/book/<slug>` (`NL_IS_PAGE`) | `NL_infoMap(html)["loaded chapters"]`, floored by `Math.max(...NL_pages(html).map(p => p.high))` — exactly what `NL_cat` computes for the novel's own screen |
| NoBadNovel | `NN_HOME/series/<slug>` (`NN_IS_PAGE`) | `NN_toc(html).length` — the app's own list length for that novel |

**Why CG counts the list and not the printed line**: the novel page prints
`Total Chapters: N` beside the author, and that is the **raw** novel's number —
it goes stale. Measured, `lqpb` states `Total Chapters: 377` while the site has
published **92** rows for it (chapters 1-74 with sub-chapters); `dlwhba` states
138 against 115 listed. `CG_bookDetail` builds the book screen's list from
`CG_chapterList(html)`, so counting the list is what makes the card agree with
the novel's own screen. Verified for `lqpb` 92=92, `dlwhba` 115=115, `dlhcn`
70=70, `profiler` 86=86 (card vs `CG_bookDetail().cat.total`).

**Driven by looking, not by loading.** `loadCoverImg` (`index.html` ~line 5473)
now calls `enqueueChapters(card)` for the card it belongs to, so the **same**
IntersectionObserver (`getCoverIO`, rootMargin 500px) and the **same**
`coverFallbackScan` (getBoundingClientRect, ±700px, wired to scroll/resize +
a 2.5s interval) that get a cover onto a card are what ask for its length. No
new observer, and no dependence on the observer alone. `card.dataset.chAsked`
marks a card as asked; `applyChapterCountEverywhere(bookId, n)` patches **every**
card wearing a novel (a novel can be in the feed and in a global search at once),
and `cardChaptersHTML` consults `CHAPTER_CACHE` so a re-render prints the known
number straight away.

**Budgets and politeness**: `CHAPTER_MAX_WORKERS = 3`, but a burst-sensitive host
(`isBurstSensitive`, which Chrysanthemum Garden is) is never asked for two pages
at once (`CHAPTER_INFLIGHT`). Per visit per source: `CHAPTER_FILL_CAP = 60`
novels / `CHAPTER_FILL_BYTES = 12 MiB` (data-saver: 12 / 2 MiB, via
`coverFillSaver`). `chapterFillReset(discover.src)` sits beside
`coverFillReset(discover.src)` in `startDiscover`. A spent budget removes the
chip (`applyChapterCount(card, 0)`) rather than leaving a "…" for ever.

**The chip holds its place**: for an enrichable source the card renders
`<span class="cardCh pending">…</span>` until the number lands, so cards do not
grow under the reader. `.cardCh.pending { color: #6b6b7d; }` is in the card CSS
(~line 250). A novel the site has no number for carries no chip: Novelight's
`surviving-in-an-rpg-maker-horror-game` states `Loaded Chapters: 0` and lists no
chapters, and its card says nothing.

Measured page sizes (why the byte budget exists): ~195-380 KB per CG novel page,
~85 KB per Novelight page, ~30 KB-1 MB per NoBadNovel page (it carries the whole
chapter list). Live feed checks at a 390×844 viewport: CG 10 cards in view → 10
chips (`86 ch`, `13 ch`, `90 ch`…); NL → `6 ch`, `12 ch`, `16 ch`…; NN → `164 ch`,
`77 ch`, `1,137 ch`…; RR/WuxiaClick/Chikari (listing-stated counts) unchanged.

## Previously — 2.7.62 (2026-09-30)

The app was on **v2.7.62** — new source **#28, NoBadNovel** (`nobadnovel.com`;
the source name is spelled the way **QuickNovel**'s provider file spells it, one
word, though the site's own wordmark reads "No Bad Novel"). The request was:
*"Add the source called, no bad novel"*.

### NoBadNovel (source #28)

Everything lives in one block in `index.html`, immediately before `const SRC = {`
(search `/* ------------------------- NoBadNovel source -------------------------`).
No import. `cover: () => ""` in its `SRC` entry (covers come from the rows).

The internal prefix is **`NN_`**, *not* `NB_` — `NB_`/`nb-` belong to NovelBuddy —
and book ids are `nn-<slug>`.

It is read **from the site's own pages**, because there is nothing else to read:
the site is Astro generated from WordPress, behind Cloudflare, and its whole
client bundle does nothing but send a search to `/series?keyword=…`. There is no
JSON API — `/wp-json/wp/v2/posts`, `/api/series` and `/genres` all 404, and
`api.nobadnovel.com` does not answer. The source was found in **QuickNovel**'s
provider list (refetched from `LagradOst/QuickNovel`), whose
`NoBadNovelProvider.kt` names the host and its selectors (`h4 a`,
`.grid > div`, `.chapter-list a`, `div.text-base.sm:text-lg`) — and **those were
still accurate**, unlike WuxiaClick's.

**Wiring** (same shape as WuxiaClick's): `ID_PREFIX_SOURCES` → `nn: "NoBadNovel"`;
`COVER_HOST_SOURCES` → `["cdn.nobadnovel.com", "NoBadNovel"]`,
`["nobadnovel.com", "NoBadNovel"]`; `SRC_ALIASES` → `nobadnovel`,
`nobadnovelcom`, `nobad`, `nbn`, `nn`; `sourceForURL` → `nobadnovel.com`;
`coverURLs` → `[url, weserv(url)]`; `loadCoverImg` →
`&& !/nobadnovel\.com/.test(url)` added to the crossOrigin-exclusion chain;
`sourceBaseURL`; `openWebnovel` (`/series/<slug>`); `HEALTH_URLS`
(`https://www.nobadnovel.com/series`); `buildDiscoverJobs` (8 jobs);
`fetchBrowsePage` (the `NN_IS_PAGE` branch, plus its
`sf(url, { require: NN_IS_PAGE })` line in the HTML chain); `feedLabel`
("Browse NoBadNovel"); `SRC` entry; `SOURCES` entry (`icon: "NBN"`,
`color: "#1c8abe"` — the blue out of the site's own icon — desc "Translated
Chinese web novels", `logoUrl` = the site's own `/zao/icon.svg` rasterised to a
256×256 transparent PNG and uploaded →
`user.uploads.dev/file/31e0d3b94b1e453d99a8f30faaf342ba.png`).
**No `catPager` entry** (the whole chapter list is one page), **no
`RATING_ENRICHABLE` entry** (the site publishes no rating), **no
`FEED_COVER_NOTE`** (every card carries a picture), **not `BURST_SENSITIVE`**
(measured: six catalogue pages in parallel answered in 785 ms, no challenge).

### How NoBadNovel is read (measured 2026-09-30, all through the app's routes)

- **The whole site is 132 novels** — 41,584 chapters between them, **95 ongoing
  and 37 completed** — in six catalogue pages of 24 cards (~30 KB, ~0.5 s each).
- **Catalogue**: `/series`, paged `/series/page/<n>`, filtered the way its own
  Browse page offers (`?status=OnGoing|Completed`, `?sort=createdAt|updatedAt`,
  `?order=asc|desc`). Measured: 6 pages / 132 novels; `?status=Completed` 2 pages
  (37); `?status=OnGoing` 4 pages (95); `/series/page/7` is empty.
- **Front page**: *Recommend* and *Hot Series* (six cards each — the same card
  markup as the catalogue, and the only cards in the app's feed with no status
  badge) plus a *Recent Updates* list (a different, list-shaped card that nothing
  here reads: it states a date and a blurb, not a chapter).
- **A novel** is `/series/<slug>`: cover, `h1` title, `Author:` row, the
  `div.badge` status, the blurb inside `#intro .content` (`<br>` = paragraph
  break) and its **whole** chapter list — volume after volume, in document order.
  Measured across **all 132** novels: shortest **1 chapter**, longest **1,566**
  (**520 KB, 1.2 s**), average page **127 KB**; **11 of the 132** publish more
  than one `<ol class="chapter-list">` (up to five volumes — the numbering
  verified to run on unbroken across them on a 501-chapter, five-volume novel).
  Every one of the **41,584** row labels is `C<n>. <title>` — no other shape
  exists anywhere on the site — and every one of the 41,584 chapter slugs is plain
  `[a-z0-9-]`, so no chapter address ever needs escaping.
- **A chapter** is `/series/<slug>/chapter-<n>-<title-slug>`: ~34 KB, ~0.8 s.
  The prose is `<p class="mb-4 para">` paragraphs, with the site's in-article
  `<ins class="adsbygoogle">` slots sitting **inside the same block** between
  them; reading the paragraphs is what leaves the adverts out (measured on
  `one-trait-draw-per-year-even-simulations-count/chapter-78-simulator-start`:
  95 paragraphs, 8,412 characters, no ad markup left). **No chapter of the 41,584
  is locked or paid** — this source publishes no paid set at all.
- **A missing address answers 200 with a 426-byte stub** (one Cloudflare beacon
  script and no page at all), which `require` therefore never refuses. `NN_page`
  handles it: it catches the failure, re-fetches the URL *without* the marker and
  reads a body that fails `NN_IS_PAGE` as "the site has nothing at this address"
  — and that is what a gone chapter is reported as. Verified: both
  `/series/no-such-novel-xyz` and a real novel's `chapter-99999` answer 426
  bytes, and `sf(…, {require})` on them throws a **blocked** error (not
  `contentless`), which is why the plain re-fetch exists.
- **Search** is the site's own `/series?keyword=`: measured — `villain` 15,
  `cultivation` 10, `emperor` 3, `poor` 1; `shadow` 0; and `the` / `a` / `my` /
  `and` / `you` all **0**, because the site drops the commonest English words from
  its index. It is *not* a plain title match: `man` answers six novels none of
  whose titles *or* blurbs contain the word, so it indexes something it does not
  display. The app relays whatever it answers.
- **What it does not publish**: no genres, no tags, no rating, no vote count and
  no chapter count anywhere in its listings — so a NoBadNovel card carries its
  cover, its title and its author, with nothing invented for the gaps. The length
  appears where the site itself states it: on the book screen, where its own
  chapter list is the count (verified: "✓ 164 chapters · NoBadNovel").
- **Covers** live on `cdn.nobadnovel.com`, which sends **no ACAO** (measured: a
  plain no-CORS image loads at 225×300, the very same URL in CORS mode is
  refused), so a cover is requested plainly with the image proxy behind it. Each
  URL carries a per-image template (`…~tplv-resize:225:300_<hash>.png`) that is
  the **only** form the host answers — measured: the same picture without the
  template fails, and with the template's size changed to `450:600` or
  `975:1300` fails too. **Never rewrite a cdn.nobadnovel.com URL.**
- **Feed** (8 jobs, ~0.55 s each, 3.9 s for the lot): the front page (its own
  picks, 11-12 novels), then `/series?sort=updatedAt&order=desc`, then `/series`
  pages 1-6 — between them **all 132 novels the site has**, in that order.
- **Health probe**: `ok` at the chapter stage in **1.3 s**, `found: 11`,
  `coverOk: true`, via superfetch.

## Previously — 2.7.61 (2026-09-30)

The app is on **v2.7.61** — new source **#27, WuxiaClick** (`wuxia.click`; the
same site answers on `wuxiaworld.eu`). The request was: *"Add wuxiaclick
source"*.

### WuxiaClick (source #27)

Everything lives in one block in `index.html`, immediately before `const SRC = {`
(search `/* ------------------------- WuxiaClick source -------------------------`).
No import. `cover: () => ""` in its `SRC` entry (covers come from the rows).

It is read **entirely from the site's own JSON API** — nothing is scraped, no
page is challenged, and the site's own reader is built from the very same
endpoints. The site is Next.js + Mantine; its bundle names the base
(`siteDict.apiUrl` = `https://wuxia.click/api`), and its chapter module (module
`8840` in the novel page's chunk `9828`) is `GET <api>/chapters/<slug>/`, which
is how the last endpoint was found.

**Wiring** (same shape as Novelight's): `ID_PREFIX_SOURCES` → `wx: "WuxiaClick"`;
`COVER_HOST_SOURCES` → `["cdn.wuxiaworld.eu", "WuxiaClick"]`; `SRC_ALIASES` →
`wuxiaclick`, `wuxiaclickcom`, `wuxiaclicknet`, `wuxiaworldeu`, `wx`, `wc`,
`click`; `coverURLs` → `[url, weserv(url)]`; `loadCoverImg` →
`&& !/cdn\.wuxiaworld\.eu/.test(url)` added to the crossOrigin-exclusion chain
(**without which every cover fails** — measured: a plain no-CORS image loads at
650×1004, the very same URL in CORS mode is refused); `sourceBaseURL`,
`openWebnovel` (`/novel/<slug>`), `HEALTH_URLS`
(`api/novels/?limit=1&order=-total_views`), `buildDiscoverJobs` (8 shelves),
`fetchBrowsePage` (a JSON branch — `WC_parseList(await WC_api(url))`),
`feedLabel` ("Popular on WuxiaClick") and `FEED_COVER_NOTE` (the drawn-cover
note). **There is no `catPager` entry**: the whole chapter list arrives in one
request, so there is nothing to page.
`SOURCES` entry: `icon: "WCX"` (two letters would read as Wuxiaworld's `WW` or
collide with Novel Cool's `NC`), `color: "#f97316"`, desc "Chinese webnovels,
wuxia & MTL", logo = the site's own 192×192 mask icon uploaded
(`user.uploads.dev/file/a2e6431e930c764fe0bf1d86f3029e14.png`; the site's
manifest serves it as `icons/icon-192x192.png`).

### How WuxiaClick is read (measured 2026-09-30, all through the app's routes)

- **The catalogue** is `/api/novels/` — **29,675** novels, 24 a page (`limit` /
  `offset`), and every row carries all a card needs without opening anything:
  `name`, `image`, `slug`, the whole `description`, `rating` (a string, out of
  five), `ranking`, `views` (formatted — `14.3M`), `chapters` (the translated
  count) and the full `categories` / `tags` arrays.
- **Sorting and filtering are the site's own**: `order=-total_views`, `-rating`,
  `-created_at`, `-num_of_chaps`, `-numOfChaps`, `name`, plus `category_name=`,
  `tag_name=` and `search=`. An unknown `order` (e.g. `-views`) answers **400**
  with `{"order": ["Select a valid choice…"]}`, which is how the names were
  confirmed.
- **A novel's own record** is `/api/novels/<slug>/`: adds `author.name` (a
  comma-joined string on the CJK novels), `status`, `views` / `human_views`,
  `numOfChaps`, `other_names`, `is_mtl`, `first_chapter`, `linked_mtl` (the
  site's MTL twin — not used) and its hundred-odd tags. **`image` and
  `original_image` are both null for a share of the catalogue** — see below.
- **The whole chapter list is one request**: `/api/chapters/<slug>/` → an array
  of `{id, index, title, novSlugChapSlug, timeAdded}`, oldest first. Measured:
  1,434 chapters in **207 KB / 1.2 s** (Lord of the Mysteries) and 9,921 chapters
  in **1.6 MB / 3.7 s** (Heavenly Tyrant Martial Soul). `novSlugChapSlug` is the
  id each chapter's text is addressed by, and `index` gives the list its numbers.
- **A chapter** is `/api/getchapter/<novSlugChapSlug>/` → `{index, title, text,
  nextChap, prevChap, novelParent, novelParentName, id, is_eighteen,
  linked_mtl, mtlwuxia_url}`. `text` is plain, **one `\n` per line and each line
  a paragraph**, with the site's own leading space. Measured: LotM chapter 1 as
  **9,898 characters / 0.7 s**. Every chapter is free — the site publishes no
  locked set — so `locked` is always false and an empty `text` is reported as an
  empty chapter (a `reader-error` block) rather than as a lock.
- **Status codes are the site's own four**, CD / OG / HS / DD — exactly the four
  its advanced-search bundle offers (chunk `pages/advance_search/[[...query]]`:
  Completed `CD`, Ongoing `OG`, Hiatus `HS`, Dropped `DD`). `WC_status`
  translates those and returns `""` for anything else, so a novel marked `tr`
  (Shadow Slave, Supreme Magus) shows no status rather than a guessed one.
  `normStatus` is **not** used for this and cannot be: it returns `""` for all
  four codes (checked).
- **15 of its 100 most-read novels carry no cover anywhere on the site.**
  Measured: Lord of the Mysteries, Martial World, Reverend Insanity, Shadow
  Slave, Supreme Magus and ten more have `image: null` *and* no picture on their
  own novel page (the HTML of `novel/lord-of-the-mysteries` contains no
  `cdn.wuxiaworld.eu` string at all). Those cards get YueDu's drawn cover and
  `FEED_COVER_NOTE` says so above the shelf. The covers it does publish come from
  `cdn.wuxiaworld.eu`; the site's own transform
  (`imaginary.wuxiaworld.eu/resize?url=…&type=webp&width=300`) is not used.

### Which shelves the feed uses, and which three it does not

Measured across the site's sorts, three of them lead with machine-translated
raws:

| sort | top of the shelf | verdict |
|---|---|---|
| `-total_views` | Lord of the Mysteries ★4.76 · Alchemy Emperor ★3.23 · Omniscient Reader's Viewpoint ★4.59 | **used**, three pages deep (offset 120 is Battle Through the Heavens ★3.21) |
| `category_name=<g>&-total_views` | real novels in every genre checked — fantasy, action, romance, xuanhuan, mystery, sci-fi, adult | **used**, five of them |
| `-rating` | "100,000 Reasons to Spend" ★5.00 with **0 chapters** | left out |
| `-created_at` | "When Our Class Was Transported to Another World…" ★3.40, then a wall of bulk-imported MTL | left out |
| `-num_of_chaps` | Heavenly Tyrant Martial Soul ★2.00 (9,921 chapters) | left out |
| `-numOfChaps` | "Legend of the Ghost Controller" ★5.00 with 0 chapters | left out |

The feed is therefore `-total_views` at offsets 0 / 24 / 48, then fantasy,
action, romance, xuanhuan and mystery. That this site's *newest* shelf is one of
its worst is a fact about the site, not the app.

### Measured

- `SRC["WuxiaClick"].search("coiling")` → 2 books; Coiling Dragon (★4.3, 806ch)
  first, with its cover.
- Feed job 1 → 24 books in **1.2 s** (19 of them with covers); a fantasy shelf →
  24 in **3.0 s**.
- `getBook("wx-lord-of-the-mysteries")` → **1.4 s**: 1,434 chapters, author
  Cuttlefish That Loves Diving, genre Comedy, 6 tags, ★4.8, status completed, no
  cover. A book screen renders "1434 chapters", "Completed", and rows reading
  "Chapter 1 – Crimson", "Chapter 2 – Situation".
- `getBook("wx-heavenly-tyrant-martial-soul")` → **2.8 s**: 9,921 chapters, and
  the book screen still renders (200 rows at a time, "Show more · 200/9921").
- `getChapter` on LotM 1 → **0.8 s**, 9,685 characters in 74 paragraphs; the
  reader's heading is "Chapter 1: Crimson" and its body opens with the site's own
  "Translator: AtlasStudios" / "Editor: AtlasStudios" lines, kept.
- Covers on real feed cards: `naturalWidth` **388** and **180** through the
  plain, non-CORS route.
- `probeSourceHealth("WuxiaClick")` → `ok`, stage `chapter`, 24 found, via
  superfetch, **2.2 s**.
- Chapter titles have their number taken off (`WC_chName`), so a row is not
  "Chapter 1 – Chapter 1 - Crimson"; a title that is *only* a number ("CH 3")
  leaves the row reading just "Chapter 3".

## Previously — 2.7.60 (2026-09-30)

The app is on **v2.7.60** — new source **#26, Novelight** (`novelight.net`), plus
the About screen widened. The request was: *"Fix the about, it's ui is small. It
doesn't fill up the space between its left and right. And also add another source
Named Novel Light"*. The source is the site's own spelling, **Novelight**.

### Novelight (source #26)

Everything lives in one block in `index.html`, immediately before `const SRC = {`
(search `/* ------------------------- Novelight -------------------------`). No
import. `cover: () => ""` in its `SRC` entry (covers come from the cards).

**Wiring** (same shape as Chrysanthemum Garden's):
`ID_PREFIX_SOURCES` → `nl: "Novelight"` (a 2-letter prefix, so `nlh-…`
NovelHall ids still fall through to the cover-host lookup as before);
`COVER_HOST_SOURCES` → `["novelight.net", "Novelight"]`; `SRC_ALIASES` →
`novelight`, `novelightnet`, `novellight`, `nlight`, `nl`; `coverURLs` → CG-style
`[url, weserv(url)]`; `loadCoverImg` → `&& !/novelight\.net/.test(url)` added to
the crossOrigin-exclusion chain (**without which every cover fails** — measured:
a plain no-CORS image loads at 650×942, the same URL in CORS mode is refused);
`sourceBaseURL`, `openWebnovel` (`/book/<slug>`), `HEALTH_URLS`
(`novelight.net/catalog/`), `buildDiscoverJobs` (7 catalogue shelves),
`fetchBrowsePage` (`NL_parseBooks`, with `{ require: NL_IS_PAGE }`),
`feedLabel` ("Popular on Novelight"), `catPager` → `_nl` → `NL_catMore`, and
`chapterInnerHTML`'s locked-chapter wording (Novelight coins).
`SOURCES` entry: `icon: "NVL"` (NovelFull already owns `NL`), `color: "#d1603d"`,
logo = the site's own 32×32 mark upscaled and uploaded
(`user.uploads.dev/file/e632555b5ee3e1b0daa06d160976e47e.png`). The site has no
larger icon than 32×32 anywhere (its `.ico` holds one 32×32 frame; LNReader's copy
is the same artwork), so that is the best honest asset; it is only ever drawn at
24px in the source list, where it reads fine.

### How Novelight is read (measured 2026-09-30, all through the app's routes)

- **Catalogue**: `/catalog/` with the site's own sorts
  (`?ordering=popularity|-time_updated|-time_created|-year_of_release`), filters
  (`?genres=<n>`, `?country=<n>`, `?type=<n>`, `?status=`, `?translation=`) and
  search (`?search=<q>`). 30 cards of ~170 KB a page; each card is only a poster
  and a title, so **Novelight cards carry no chapter count** (the site states it
  only on a novel's page) — the DESCRIPTION "Twenty of the twenty-six" line.
- **A novel**: `/book/<slug>`. The page carries the cover (`.poster img`, a
  `/media/…` path), `.block.appreciate` (e.g. `4.4/5` and `(1988)`), the synopsis
  and tags inside `#information`, and a `.mini-info` block whose labelled rows are
  Status, Translation, Type, Country, Year of Realese, Author, Illustrator,
  Genres and **Loaded Chapters** (the honest count). `OBJECT_BY_COMMENT` is the
  numeric id the reader API is addressed by.
- **The chapter list is paged newest-first, 50 to a page.** The page's own
  `<select id="select-pagination-chapter">` counts from the newest — option 1 is
  labelled `853 - 902`, the last option is the start of the novel (`1 - 2` on
  that novel). The rest comes from
  `/book/ajax/chapter-pagination?book_id=<id>&page=<n>` → `{html}` with the same
  `.chapter` cards. **The select's labels are the numbering** (`low..high` per
  page), which is where each chapter's `num` comes from; `NL_pages` reads them.
- **The chapter text is not in the chapter page** — the page ships
  `[[ content ]]` where the story goes — it comes from
  `/book/ajax/read-chapter/<chapterId>` → `{class, content}`, ~13,300 characters
  for a ~1.5 s read on the 902-chapter novel.
- **Both reader endpoints are header-gated**, exactly like NovelHi's: a plain
  request gets the site's own 403 error page (measured: superFetch with no
  headers → 403, 26 KB of error HTML; with the `X-Requested-With` +
  `x-cors-headers` pair → 200 and the JSON). So `NL_xhr` sweeps the NovelHi route
  functions (`NH_routeNative`/`NH_routeSuperfetch`/`NH_routeDirect`/
  `NH_routeBridge`/`NH_routeWorker`/`NH_routeProxy`) — the one place in the app
  that can carry a header over every transport — twice, and re-tells their errors
  in Novelight's words. `NL_HEADERS` is built locally so the block does not depend
  on where NovelHi's is defined.
- **Its newest chapters are a paid set.** The site marks them with
  `<span class="cost">` in the list and answers `read-chapter` for them with an
  **empty body** (measured: the newest 50 of a 902-chapter novel all locked,
  everything older free). `NL_getChapter` returns `locked:true` for those, and for
  anything whose body comes back empty — the reader is told the truth instead of
  being shown a blank chapter. Locked rows keep the site's own padlock in the list
  (`c.locked`, so `chapterItemHTML` draws the lock and no download arrow).
- **The list is built from the oldest end.** Because the site pages
  newest-first and YueDu's list is read in reading order, `NL_cat` fetches the
  **oldest three pages in parallel** (`NL_FIRST_PAGES`) and stitches them in
  order, then `NL_catMore` walks the page numbers down (`next--`) two pages
  (`NL_TOC_STEP`) per tap, appending — so the list grows *towards* the newest
  chapters and is always ascending. A novel's own first page is often short
  (measured `1 - 2`), which is why three are taken at once.

### Measured

- `SRC["Novelight"].search("dragon")` → 7 books with covers.
- Feed job 1 → 30 books in **1.8 s**; a genre shelf → 30 in **2.2 s**.
- `getBook("nl-the-regressed-mercenarys-machinations")` → **3.3 s**: 102 chapters
  loaded (1→102) of 902, author 골드행, genre Fantasy, 6 tags, rating 4.5 with 1,803
  votes, status completed, cover, multi-paragraph synopsis.
- `NL_catMore` → 102 → **202 chapters in 4 s**, monotonic.
- `getChapter` on chapter 1 → **1.5 s**, 13,302 chars of clean prose.
- Newest page → 50 rows, all locked; reading one → `locked:true`, no body.
- `probeSourceHealth("Novelight")` → `ok`, stage `chapter`, 30 found,
  `coverOk: true`, via superfetch, **4.9 s**.

### About screen — widened (same version)

The page was a 460px column centred in whatever it was given, which left wide
empty margins on anything wider than a phone. Now:

- `.aboutInner { width: 100% }` — the page runs edge to edge, 16px side padding,
  the same padding the other screens use.
- Type scaled up throughout (name 27px, tagline 14.5px, stat numbers 23px, card
  titles 12px, `who made it` 16.5px, body 14.5px, feature rows 14px, buttons 15px,
  footnote 12px).
- `@media (min-width: 760px)`: `.aboutInner` becomes a 2-column grid — hero,
  `.aboutStats`, `.aboutActions` and `.aboutFoot` span both columns, and the two
  reading cards sit side by side (measured at 1080px: hero/stats/actions/foot
  1048px wide, each card 517px). The two buttons now live inside
  `.aboutActions` so that row can span the grid.
- Verified at 390 / 320 / 1080: no horizontal overflow at any width, chips on one
  row at 390 and a clean centred second row at 320, and a pixel scan of a
  snapshot at 1080 shows content from x=19 to x=1295 of 1296 (i.e. it does fill
  the width — `vision` misread this as centred, the pixels disagree).
- `Sources` on the page reads **26** with no code change, because it is read from
  `SOURCES` — the whole point of that row.

## Previously — 2.7.59 (2026-09-30)

The app is on **v2.7.59** — the **About** screen (More → About) rebuilt as a
real page. The request was: *"Improve the ui and ect of the About. Like the one
in more, and you can find about, and who made it ect."*

All of it is in `index.html`: the CSS block under `/* ---------- about / update
log ---------- */` (lines ~705–800) and the `#aboutScreen` markup (~line 2500),
plus `fillAboutScreen()` / `checkForUpdateFromAbout()` next to
`openAboutScreen()`.

### What the page is now

1. **Hero** (`.aboutHero`) — the app's mark in a 74px gradient tile with a
   `::after` ring, name at 25px/850, version, tagline, and three `.aboutChip`
   pills (*no ads / no account / no tracking*). Accent-lit card: a 15%-accent
   linear gradient, a `.aboutHero::before` radial wash that fades out well inside
   the card (paste the same guard as `.latestCard` — a glow whose box ends
   mid-panel leaves a visible band), and a `1px` accent border.
2. **`.aboutStats`** — a 3-up grid: **Sources / Themes / Fonts**. All three are
   filled at open time by `fillAboutScreen()` from `SOURCES.filter(s => s.active
   !== false).length`, `READER_THEMES.length` and `FONTS.length`. **Never
   hardcode these numbers** — that is the whole point of the row.
3. **Who made it** (`.aboutCard`) — avatar tile with the initial, name, subtitle,
   then the author's own paragraph, kept **verbatim** from the old screen. Do not
   rewrite it; those are the author's words.
4. **What's inside** (`.aboutCard` + `.aboutFeat`) — seven rows, each with a
   `.fi` icon tile and `<b>label</b> — text`. The reader row's counts
   (`#aboutFeatReader`) are also filled from `READER_THEMES`/`FONTS`.
5. **Actions** — `#aboutUpdatelogBtn` (primary, opens the log as before) and
   `#aboutCheckBtn` (secondary). `checkForUpdateFromAbout()` reuses the app's own
   manifest path: `latestManifest` if already fetched, else the same
   `UPDATE_MANIFEST_URL?t=` fetch with an 8s `AbortController` and the
   `fetch` → `sf` fallback. It writes one line into `#aboutUpdLine`
   (`.ok` green / `.new` accent / `.bad` amber) and, when
   `updateEnabled(m) && semverGt(m.version, APP_VERSION)`, calls
   `showUpdateModal(m)` — the same card the Update log shows.
6. **Footnote** — author/version line plus the "novels belong to their writers
   and to the sites that publish them / YueDu is not affiliated" note.

### Layout rules worth keeping

- `.aboutBody` is a plain scrolling page, **not** a centred flex block.
  The old `margin: auto` centring made the top of the page unreachable once the
  copy was taller than the display (the classic auto-margin-in-a-scroller bug).
- `.aboutInner` is `max-width: 460px; margin: 0 auto`.
- `.aboutChip` is 10px/700 with `gap: 9px 6px` on the row: at 320px the third
  chip wraps to a second, centred row (verified — it reads as deliberate), and at
  390px and up all three sit on one line. If you grow the chip text, check 320px
  again.

### Verified (live preview, 390×844 / 320×568 / 1440×900)

- Hero 359×282 at 390; stat tiles 89px each at 320; feature rows 60–88px; no
  horizontal overflow at any of the three widths; no element has
  `scrollHeight > clientHeight` (nothing clipped inside a card).
- `vision` confirmed both halves of the page (hero/stats/who-made-it, and
  What's-inside/buttons/footnote) against the intended design at 390, and the
  chip wrap at 320.
- `#aboutCheckBtn` answered **"You're up to date · v2.7.59"** in green against
  the live manifest, and `#aboutUpdatelogBtn` still opens the Update log.

## Previously — 2.7.58 (2026-09-30)

The app is on **v2.7.58** — new source **#25, Chrysanthemum Garden**
(`chrysanthemumgarden.com`), the big home of translated Chinese danmei/BL
novels. The request was: *"Try number 4 that chrysanthemum garden"* — item 4 of
the source survey in `SOURCES-CANDIDATES.md`.

Everything for this source lives in `index.html`; there is no import. `cov:
()=>""` in its `SRC` entry (covers come from the cards, see below).

### Where it is wired in (all in `index.html`)

- `ID_PREFIX_SOURCES` → `cg: "Chrysanthemum Garden"`; `COVER_HOST_SOURCES` →
  `["chrysanthemumgarden.com", "Chrysanthemum Garden"]`.
- `SRC_ALIASES` → `chrysanthemumgarden`, `chrysanthemumgardencom`,
  `chrysanthemum`, `cg`.
- `BURST_SENSITIVE` → `"chrysanthemumgarden.com": 1`.
- `coverURLs` → CG branch returns `[url, weserv(url)]` (see covers below).
- `loadCoverImg` → added `&& !/chrysanthemumgarden\.com/.test(url)` to the
  chain that decides whether to set `crossOrigin`. **This was a real bug fix**:
  without it every CG cover failed, because the host serves with CORS headers
  that make a CORS-mode image request fail while a plain one succeeds.
- `sourceBaseURL` → `https://chrysanthemumgarden.com/`; `openWebnovel` → CG
  branch to `${CG_HOME}/novel-tl/${slug}/` (slug = bookId minus the `cg-`).
- `HEALTH_URLS` → `https://chrysanthemumgarden.com/books/`.
- `buildDiscoverJobs` → six shelves: `/books/`, `/genre/quick-transmigration/`,
  `/genre/unlimited-flow/`, `/genre/cultivation/`, `/tag/completed/`,
  `/tag/bl/`.
- `fetchBrowsePage` → `books = CG_parseBooks(html)`; the generic fetch gained a
  `{ require: CG_IS_PAGE }` special-case for this host.
- `feedLabel` → "Browse Chrysanthemum Garden".
- `SOURCES` → flower logo
  (`https://user.uploads.dev/file/b483bb308d90e449232e3d0291c2fa6b.jpg`),
  `icon:"CG"`, `color:"#c2410c"`, `status:"Connected"`,
  `desc:"Translated BL & danmei novels"`, `lang:"English"`.
- `SRC` → `{ cover: () => "", search: CG_searchBooks, getBook: CG_bookDetail,
  getChapter: CG_chapter }`.

The CG source block (a long comment plus `CG_HOME`, `CG_IS_PAGE`, `CG_SCRAMBLE`,
`CG_txt`/`CG_strip`/`CG_unscramble`, `CG_attr`/`CG_img`/`CG_el`, `CG_book`,
`CG_parseBooks`, `CG_chapterList`, `CG_chapterHTML`, `CG_searchBooks`,
`CG_bookDetail`, `CG_chapter`) sits immediately before `const SRC = {` in
`index.html`. The comment there is the authoritative explanation; the summary:

### The anti-scrape scheme (this is the interesting part)

The site protects its translations two ways, and both are handled.

1. **Invisible decoys inside the prose.** A 1px/0-width span carrying a 6-char
   marker (e.g. `xVKb7y`); an invisible paragraph about the story being
   translated by Chrysanthemum Garden and a "support our translators" line; and
   a transparent `<h3 …>CG Scrape Protection</h2>` — note the **mismatched
   closing tag**, so the decoy regex has to consume from the opening tag to the
   next closing tag of *any* kind. All removed by `CG_strip` before you read.
2. **Letter-substituted paragraphs.** Whole paragraphs are served as real
   English in a font whose glyphs have been re-ordered, so they render correctly
   on the site but copy as gibberish — e.g. `MwH Ii cxbVKKws xqbVaSq xqw` for
   "Wen Ai strolled through the". Each such paragraph is a span pointing at a
   `@font-face` woff2. The pool is **exactly three fonts** —
   `tHCyzNXaYj`, `tWrYbVzCVg`, `JhNJcENGey` — and the same three serve 6
   chapters across 4 different novels, so they are effectively static.

   The mappings in `CG_SCRAMBLE` were derived two independent ways that agreed:
   (a) comparing glyph outlines in the woff2 against stock Open Sans (all 52
   letters byte-identical to some Open Sans glyph → "unmatched 0"), giving
   glyph-index → character; and (b) **canvas-rendering** each font against the
   site's own Open Sans in the live page and reading off which glyph lands where.
   `CG_unscramble` applies the mapping to the span's text.

After decoding, chapters read as clean prose with the scrambled paragraphs in
the right positions and no leftover ciphertext.

### Measured

- All 6 feed shelves: 20 books each, **~0.5–1.1 s**. `/books/` yields 19/20
  covers (the site genuinely has no cover for "A Royal Pain"); genre/tag shelves
  20/20. Every card has genre, synopsis, status.
- Search `/?s=<q>&post_type=lb_novel` → works; 12 results for "demon".
- `getBook("cg-hbbg")` → **1.5 s**, "It's Hard Being the Bad Guy", author
  扣弦振雪, genre Quick Transmigration, tags BL/Romance/Doting Love
  Interest/Comedy/NSFW, cover, 31 published chapters (the page advertises
  "Total Chapters: 99 + 11" but only 31 exist).
- `getChapter` → **0.8 s**, 14,927 chars of readable prose, no decoys, no
  ciphertext, next/prev set.
- `probeSourceHealth("Chrysanthemum Garden")` → `ok`, stage `chapter`, 20 found,
  `coverOk: true`, via superFetch, **2.5 s**.

### Two traps specific to this host

- The app's `sf()` route returns the **rendered** page, not the raw HTML: images
  are lazy placeholders and quotes are normalised to double quotes, whereas raw
  HTML uses single quotes. Hence `CG_attr`/`CG_img`/`CG_el` are quote-agnostic
  and read `data-breeze`/`data-brsrc`/`data-src` **before** `src`, rejecting
  `data:` placeholders.
- `r.jina.ai` (which was useful while probing, saved in `scratch/probe/
  cg-*-jina.html`) returns a *markdown* shape that `sf()` does **not** return —
  don't write parsers against the jina files.

### Verification notes

- The source card in the Browse list was vision-confirmed.
- The grid was confirmed by DOM (cards 135×203 px in a 2-up grid, 6/6 on-screen
  covers decoded with `naturalWidth` 200/270). It could **not** be confirmed by
  `vision`/`snapshot.js`: those captures can't inline cross-origin CG covers
  (console warns "Network/CORS issue … A proxy may be required"), and
  `vision({selector})` on an `<img>` tainted by a cross-origin image throws.
  That is a harness limitation, not an app bug.

## Previously — 2.7.57 (2026-09-30)

The app is on **v2.7.57** — a one-line spacing fix on the developer message.
The request was:

> "One more twick, that Developer message (the bar) is so Close to the like it's
> touching the Email Logo."

"The bar" is the amber `DEVELOPER MESSAGE` pill and "the Email Logo" is the
envelope mark. The mark's halo ring (`::after`, `inset: -8px`) stands 8px proud
of the 90px tile, but the letterhead's row gap is only 12px, so the ring and the
pill's border came within **4px** of each other. `.noticeHero .announceIcon` now
carries `margin-bottom: 12px` of its own, so the ring's bottom sits **16px**
clear of the pill (measured on the live card: ring bottom 158, pill top 174).
Nothing else changed; the card is 12px taller when a note is long, which the
letter's own scroller absorbs.

## Previously — 2.7.56 (2026-09-30)

The app was on **v2.7.56** — still **twenty-four** sources and no functional
change: that one redrew the developer message as a letter. The request was:

> "Improve give it a much better new look."

"The developer message" is the **announcement dialog** — `showAnnouncement(ann)`
(index.html ~19540), built from the manifest's `announce` / `announceTitle`
fields. It is *not* the update dialog and *not* a toast; both were left alone.

### The redesign — a letter, not a notice

2.7.55 made the announcement big; it still looked like the update dialog with
different wording. It is now dressed as a letter, in `index.html` ~1495–1600,
scoped to `.announce*` / `#announceModal` only:

| piece | now |
| --- | --- |
| card | warm parchment dark (`#251e14 → #101016`) with an amber radial wash, `1px solid rgba(245,180,68,.24)`, 32px radius, `flex` column, `overflow: hidden` |
| ribbon | `.announceCard::after` — 4px amber gradient bar across the top edge, drawn out from the middle on open |
| mark | 90px amber tile, `color: #4a2b06`, **envelope** not megaphone, inside a `1.5px` amber ring (`::after`, 8px out) |
| badge | `.noticeKicker` as a solid amber pill (`rgba(245,180,68,.19)` fill, `.38` border, 1.4px tracking); its status dot is dropped here |
| headline | 29px, `#fffdf8`, warm text-shadow; 13.5px muted sub-line under it |
| rule | `.noticeHero::after` — full-width amber hairline under the head |
| letter | `.announceMsg` (frame: border, 4px amber **left** rule, asymmetric radius, `overflow: hidden`, flex column) wrapping `.announceMsgBody` (**the scroller**: 16px / 1.68, 19px 21px 24px 22px padding, thin amber webkit scrollbar) |
| fade | `.announceMsg::after` — 58px gradient to `rgb(31,28,30)` (measured off the rendered panel) so the last lines dissolve instead of being sliced |
| actions | bright amber *Got it* with a tick (`NOTICE_ICON.check`); *Open link* with a link glyph (`NOTICE_ICON.link`, added to `NOTICE_ICON`); `.noticeBtns.row` puts them side by side when a link exists |
| footer | `.noticeFoot` signature — `YueDu · v<APP_VERSION>` (`showAnnouncement` re-stamps it each open) |
| entrance | `announceRibbon` + `announceRise` staggered over the head, letter, actions, signature |
| backdrop | `#announceModal` — two warm radials over `rgba(7,5,9,.84)`, 12px padding |

Two structural details worth keeping:

* **The card does not scroll; the letter's body does.** `.announceCard` is a flex
  column (`overflow: hidden`) with the hero and foot `flex: 0 0 auto` and the
  message panel `flex: 1 1 auto; min-height: 0`. The frame therefore never
  scrolls, which is what lets a fade sit at the panel's foot over its own text
  while the frame's bottom border stays crisp. The first attempt put the
  scrollbar on the panel itself with the actions `position: sticky`; the text
  then vanished under the buttons in a hard mid-sentence cut. (Captures of
  *clones* of the dialog also restart CSS animations — freeze them with
  `style.animation = 'none'` on the clone and its descendants before capturing,
  or the screenshot catches elements at partial opacity and looks broken.)
* **The stock sub-line is suppressed.** The amber pill already says the note is
  from the developer, so when `ann.sub` is empty or the default
  `From the developer` the element is `hidden`; a manifest that writes its own
  line (`Regarding Sunday's outage`) still shows it.

### Verification (2.7.56)

* Measured at **390×844**: a three-line note gives a **367×600** card at top 122
  with no scrolling anywhere and one full-width *Got it*; the nine-line note
  gives **367×787** at top 28, the *card* not scrolling
  (`scrollHeight === clientHeight`) while the letter body scrolls (414 vs 358),
  with both buttons side by side (154px / 156px) and the footer inside the card.
* At **320×568** the card is **296×523**, inside the screen on both axes, buttons
  119.5px each, footer inside.
* Empty message: the panel is `hidden` and the card shrinks to 378px.
* The sub-line shows for a custom `sub` and is hidden for the stock one
  (checked both).
* Vision passes (freeze-the-animation captures) scored the long-note dialog
  **9/10 — "ship it"**, the short-note dialog **9/10**, and the close-up of the
  mark/pill/buttons confirmed the envelope reads as an envelope, the halo as a
  single clean ring, and both buttons as clearly clickable.
* The **update dialog is unchanged**: re-measured at **347×635**, no scroll, and
  its kicker still has no pill padding and its mark is still the 66px
  `NOTICE_ICON.update` — the announce rules are scoped, not shared.
* A toast raised during the checks still came back `.note ok`, one card.
* No syntax errors; the only console line was the pre-existing Firebase
  cross-origin `Script error.` (see note below).

## Previously — 2.7.55 (2026-09-30)

The app was on **v2.7.55** — still **twenty-four** sources and no functional
change: that one made the developer message *larger*, without redrawing it. The
request was:

> "Improve the developer message UI make the Ui much Larger."

"The developer message" is the **announcement dialog** — `showAnnouncement(ann)`
(index.html ~19421), the amber card built from the manifest's `announce` /
`announceTitle` fields (the `DEVELOPER MESSAGE` badge, headline, sub-line, the
message paragraph, and the `Got it` / `Open link` buttons). It is *not* the
update dialog and it is *not* a toast; nothing else was touched.

### What grew (index.html ~1500 — the block right after `.announceMsg:empty`)

Until 2.7.54 the announcement wore the update dialog's measurements exactly —
they are one selector pair (`.updateModalCard, .announceCard`, and so on). The
2.7.55 block sits **after** the shared rules and is scoped to `.announceCard` /
`.announce-*` / `#announceModal` only, so the update dialog is untouched while
the two still read as siblings.

| element | was | now |
| --- | --- | --- |
| `#announceModal` padding | 22px | 16px |
| card `max-width` | 420px | `min(470px, 100%)` |
| card padding | 24px 20px 20px | 34px 26px 26px |
| card radius / `max-height` | 26px / 88% | 32px / 94% |
| mark (`.announceIcon` in `.noticeHero`) | 66px, svg 31px | 88px, svg 42px |
| badge `.noticeKicker` | 10px | 11.5px, 1.5px tracking |
| headline `.announceTitle` | 23px | 29px, -.7px tracking |
| sub `.announceSub` | 12px | 14px |
| message `.announceMsg` | 13.5px / 1.62, 12px 13px pad | 16px / 1.68, 17px 18px pad |
| buttons `.announceBtn/.announceLink` | 15px pad, 14.5px | 19px pad, 16.5px |
| close button `.announceClose` | 30px | 36px |

### Verification (2.7.55)

* Measured on the live page at **390×844**: a three-line message gives a card of
  **359×644**, top 100, no scroll (`scrollHeight === clientHeight`) — 92% of the
  phone's width and most of its height.
* A long message (8 lines) gives **359×763** at top 40, so it scrolls ~33px
  inside the card (`.updateModalCard, .announceCard` already carry
  `overflow-y: auto`) rather than running off the screen. Intended behaviour.
* Two clone captures (a 3-line message carrying a link, and the long one) read as
  large, centred, both buttons equal width and stacked, the paragraph comfortable
  at reading size — no clipping, no overlap, nothing undersized.
* The update dialog was re-measured afterwards — **347×635** for a 4-note update
  at 390×844, `scrollHeight === clientHeight` — unchanged by the scoping.
* **A real bug found while touching the changelog:** 42 stray backslashes were
  rendering in the update log. Nine `UPDATES` entries (2.7.4 through 2.7.54) had
  quoted phrases written `\\\"` (three backslashes plus a quote) instead of `\"`,
  so the log printed a backslash before every opening and closing quote. Fixed by
  collapsing every `\\\"` run in the `UPDATES` region to `\"`. Verified: 0
  backslashes in the changelog DOM (was 42), no syntax error.
* `#logList` shows v2.7.55 as **Latest**; `aboutVersion` reads `Version 2.7.55`.
  No console errors, no `perchanceErrors`, no syntax errors.
* `src/DESCRIPTION.md` was **not** touched — no user-facing feature changed, so
  its "true of version 2.7.53 and later" stamp still holds.

## Previously — 2.7.54 (2026-09-30)

The app was on **v2.7.54** — still **twenty-four** sources and no functional
change: that one was the notification and notice UI. The request was:

> "Improve the notification ui. And the update notice ui, make it big like in the
> center of the screen."

### Notifications — `toast()` (index.html ~16149), `#toast` CSS (~1308)

The old `#toast` was one `<div>` of plain text: a `white-space: nowrap` pill with
`text-overflow: ellipsis`, so a long message was cut off, there was no icon, no
way to dismiss it, and two messages arriving together simply overwrote each
other (`t.textContent = msg`). It is now a **stack**:

* `#toast` is a flex column, `bottom: 92px`, `width: min(402px, calc(100% - 28px))`,
  `pointer-events: none` (children take their own), hidden while empty.
* `toast(message)` still works unchanged at all ~80 call sites. The signature is
  `toast(msg, title, kind)` and the second argument changes the shape: a **kind**
  (`ok`/`warn`/`err`/`info`/`update`/`book`) styles the same message, anything
  else is the **body**, and the first argument then reads as the card's bold
  heading (`toast("New version ready", "v2.8.0 is ready to install", "update")`).
* **The kind is inferred from the message when the caller does not name one**
  (`noteKindFor`): a line with a ✓ or opening with *added / saved / downloaded /
  removed / cleared / refreshed* wears the tick; one opening with *Couldn't /
  Failed / No … / Nothing … / Already …* or containing *refusing / blocked /
  failed / error* wears the warning. That is why the twenty-odd existing messages
  did not have to be edited one by one.
* A card draws a 30px icon tile in its kind's colour (`NOTE_ICON`, kept local to
  the toast code on purpose — `NOTICE_ICON` lives ~3000 lines further down and a
  message raised during startup would hit its `const` in the temporal dead zone),
  the message wrapping freely, and a 2px `.noteBar` that drains over the
  message's own time (`2100 + 45ms/char`, capped at 6.5s).
* **At most 3** stand at once (`NOTE_MAX`); the oldest is dismissed to make room.
  A message repeated while it is already showing is *found* by its
  body/heading/kind and its timer and bar restarted rather than stacked.
* The bar's restart has a trap worth remembering: assigning the `animation`
  shorthand **wipes every `animation-*` longhand**, so the duration has to be set
  *after* the shorthand is cleared (`animation:none` → reflow → `animation:""` →
  `animationDuration`) — and the CSS ships a 2600ms default so the bar can never
  run at 0s (which is `forwards`-instant, i.e. invisible) if the script is not
  the one that set it.

### The update notice — big and centred

* **The Update-log panel** (`#latestUpdateCard`, CSS ~1504, built by
  `renderLatestCard` ~19494): was a 327×70 row (38px icon, 13.5px bold, 12.5px
  sub, refresh button inline). It is now a **centred panel** — 58px icon tile,
  19px headline, centred sub-lines, the refresh button absolute in the
  top-right, and a full-width 15px-padded `Get update` button. Measured
  327×243 in the "update available" state.
* **The dialogs** (`showUpdateModal` ~19312, `showAnnouncement` ~19421): the head
  is now `.noticeHero` — a stacked, centred block (66px mark, centred
  `UPDATE AVAILABLE` badge, 23px centred headline, centred sub-line) instead of
  `.noticeTop` (icon left, text left). The version pills, the `WHAT'S NEW`
  label (with rules on *both* sides) and the footer are centred; the change list
  and the message body stay **left-aligned**, because a list item and a paragraph
  are not easier to read centred. Buttons are full-width, stacked, 15px padding,
  14.5px text; the card is `max-width: 420px`, `border-radius: 26px`, 24px pad.
* Both notice panels also had a real bug fixed: their `::before` glow was a
  `-150px/-110px` box with a `radial-gradient(ellipse at 50% 100%)` that did not
  reach transparency inside its own box, so its last row showed as a **visible
  band across the panel** (caught by looking at the rendered panel, not by
  reading the CSS). Both are now `inset: 0` with an explicit-size ellipse
  (`radial-gradient(120% 92% at 50% -22%, …)`), which fades out well inside the
  panel.

### Verification (2.7.54)

* Toast stack: 3 cards raised at once came back `.note ok noTitle` / `.note warn
  noTitle` / `.note update` (the kinds inferred correctly), the bars animating
  (`scaleX(0.87)` 400ms into a 2820ms drain), and a vision pass confirmed the
  icons, the wrapping second card, the even spacing and the coloured bottom
  lines — no clipping or overlap.
* Update panel: vision-checked in both states ("You're up to date" and
  "Update available · v2.8.0") — centred, large, no band in the background, the
  button full-width and clear of the refresh button.
* Update dialog: measured **347×703 inside a 390×844 viewport at top 71** — every
  part (hero, pills, list, both buttons, footer) inside the screen, no scroll
  (`scrollHeight === clientHeight`), and a whole-screen capture of the dialog over
  its dim backdrop read as "big and prominent, fully visible, perfectly centred".
* Developer message: the same hero, checked the same way.
* No `perchanceErrors` and no console errors; `#logList` shows v2.7.54 as
  **Latest**. Since nothing functional changed, `src/DESCRIPTION.md` was left
  alone (its "true of version 2.7.53 and later" line still holds).

## Previously — 2.7.53 (2026-09-30)

The app is on **v2.7.53** — still **twenty-four** sources, but now **every feed
card carries a cover and, where the site publishes it, the number of chapters**.
The request was:

> "Fix archive of our own. The feed novel covers is not showing, and also for all
> the sources in the feed. Add a number of chapters so user don't have to
> littleraly view every novels to see the number of chapters."

Both halves were measured before anything was written, and the measurements are
what the design came from — including one that changed the whole reading of the
first half.

### Covers: what was actually wrong (measured 2026-09-30)

A sweep of **all twenty-four feeds** (first six cards each, covers asked for and
awaited) found the covers **loading in every one of them** — `naturalWidth`
450-1200 on the card, in the feed, as you scroll (the one apparent failure was an
artefact of the test itself; see below). **The loader was never broken.** What was
missing is *picture-less cards*:

| source | cards in one listing with no picture | why |
| --- | --- | --- |
| Archive of Our Own | **all 40** | the site publishes no cover art at all |
| Syosetu (Narou) | **all 30** | same — a whole works page carries only the site's own logo |
| Novel Hall | **30 of 45** | its table listings (rankings, latest-release, search) are text rows; the app finds those covers on each novel's own page as you scroll — `COVER_FETCHERS` |
| every other source | 0 of the first 10 | — |

(One red herring worth recording: a first pass showed **Wuxiaworld 0 of 6
loaded**, and it was an artefact of that test's own bookkeeping — the feed
re-rendered the cards during the forced load, so the elements measured were not
the elements asked. Re-measured with element identity tracked: **6 of 6 at
`naturalWidth` 1200**, and its `cdn.wuxiaworld.com` covers answer both directly
and through the image proxy.)

So the fix is not a loader fix: **a card with no picture now gets one drawn for
it.** `coverSrcFor` (index.html ~4932) returns the site's own cover when the
listing carried one and a drawn cover otherwise, for **every** source. AO3 and
Narou are no longer special cases — any source can have a row without a picture,
and a card is never left as a bare letter tile for want of one.

### The drawn cover — `genCoverSVG` (index.html ~4883)

Drawn from what the card already knows: **title, author, fandom/genre, source,
bookId**. 300×450, a two-stop gradient whose hue comes from a hash of the
work's own id (so no two drawn covers match, and the same work always draws the
same cover), a coloured accent bar down the left, a darkened foot band, and the
**source's own two-or-three-letter mark** in the top-right corner —

* the mark is `sourceMeta(src).icon` from `SOURCES` (so **WN, RR, NA, FM, WL, FW,
  NL, NG, NC, NH, NB, NF, GN, SH, LR, WW, DR, NLH, RB, WP, CH, IK, AO3**), with
  **`Syosetu` → `NAROU`** because that is what its readers call it. Verified for
  all twenty-four names; a book with no source (an imported file) draws no mark
  rather than an empty one.
* **The title is measured, not counted.** `coverChW` gives a CJK character
  **1 em** and a Latin one **0.55 em**; `genCoverLines` wraps to a width in ems
  (Latin words kept whole, Japanese runs broken anywhere, since they have no
  spaces). `genCoverSVG` then picks the **largest font size** in
  `[30,28,26,24,22,21,20,19,18,17]` at which the whole title still wraps into
  **5 lines inside 244 units** — the fit test compares the *whitespace-stripped*
  join of the wrapped lines against the whitespace-stripped title, which is what
  makes a title that had to drop characters fail and a smaller size be chosen.
  Measured after the fix: `"All the Young Dudes"` → fs **30** (2 lines),
  `"Harry Potter and the Methods of Rationality"` → **30** (4), the
  every-second-word-long test title → **26** (5), `"転生したらスライムだった件"` →
  **30** (2), `"とんでもスキルで異世界放浪メシ"` → **30** (2). (Before the fix the
  whitespace comparison was lopsided and **every Latin title fell to fs 17**
  while CJK titles picked 30.)
* **The foot line stops short of the button.** `coverClipText(text, maxUnits)`
  trims `author · genre` to **17 em at 11px** and ellipsises it, because the
  round `+`/`▶` button every card wears sits over the cover's bottom-right
  corner and takes the last **76 of the cover's 300 units** (measured at a 135px
  card: the pill's box is 224..287 × 375..437 in cover units). Without it, the
  line ran into the button (`MsKingBean89 · Harry Potter - J. K. Rowling` is
  ~23 em at 13px against the 20 em the cover has).
* Drawn covers are **never cached**: `cacheCover(cid, img)` returns early when
  `img.src` starts with `data:`, and re-drawing costs nothing.
* `coverSrcFor` is what every cover site uses, so drawn covers appear in the
  **feed, the library grid, the history list, the chapter-updates list, the book
  hero and the book hero's backdrop**. `openCoverViewer` now uses it too, so
  tapping a drawn cover opens that cover full-size instead of an empty viewer.

### A picture that never arrives — `coverGiveUp` (index.html ~5136)

When a real cover has been asked for along every route and retried every round,
the old code hid the image (leaving the letter tile). Now the card takes a drawn
cover built from its own dataset instead, so a picture host that refuses one
device turns a shelf plainer rather than half-broken. A drawn cover that somehow
fails too still ends hidden, and the comparison `drawn !== img.src` is what stops
that from looping.

`data-cover-url` **keeps its old meaning: the site's own address only.** Drawn
covers live in `data-cover` alone, so:

* `requestCardCover` (Novel Hall's cover-finding) still sees a bare card as bare
  and still fills it from the novel's own page — **verified in the live feed**:
  Novel Hall row cards at `scrollTop 1400` came back with real
  `novelhall.com/upload/...` covers at `naturalWidth` 450-600 and chips
  (`1,043 ch`, `894 ch`, ...);
* `loadCoverImg` calls `requestCardCover(img)` for a drawn cover as well, which is
  how that fill is triggered now that a bare card is never `!url`;
* a bare card added to the library stores `cover: ""` (not a 2 KB data URL), and
  the library draws the cover from the book's own record.

### Chapter counts (the second half of the request)

`cardChaptersHTML` (~13392) / `chapterCountFrom` (~13365) / `chapterNoFromTitle` (~13382) + `data-chapters` +
the `.novelMeta`/`.cardCh` CSS. **The rule: the count is shown where the site's
own listing states it, and nowhere else** — no per-novel fetches behind a shelf.

| source | where the count comes from | measured example |
| --- | --- | --- |
| Archive of Our Own | `dl.stats` chapters (`done.done`) | `188 ch`, `1 ch` |
| Chikari | `chapter_count` (JSON) | `3,194 ch` |
| Dreame | `chapterNum` | `899 ch` |
| FanMTL | `<i class="material-icons">book</i> 1966 Chapters` | `1,966 ch` |
| FreeWebNovel / Novel Full / Novel Go / Lib Read | `<span class="s1">639 Chapters</span>` | `2,017 ch`, `3,911 ch` |
| Inkitt | `chapters_count` | `16 ch` |
| Novel Arrow | `totalChapter` (JSON) | `622 ch` |
| Novel Buddy | `stats.chapters_count` (JSON — **inside `stats`**, not top level) | `552 ch` |
| Novel Cool | `last_chapter_title` = `Ch. 2500 – Her Reflection` | `2,500 ch` |
| Novel Fire | `<i class="icon-book-open"></i> 3194 Chapters` | `286 ch` |
| Novel Hall | table rows' newest-chapter link, `Chapter 1043 - 864: …` → 1043 | `1,043 ch` (its **card** listings state none) |
| Novel Hi | `lastIndexName` = `Chapter 7518` | `7,518 ch` |
| Royal Road | `<span>109 Chapters</span>` | `109 ch` |
| Scribble Hub | `chapterCount` (JSON), or the series-finder's `<span class="nl_stat">Chapters: 55</span>` — `SH_searchBooks` runs both routes and now merges the count like it merges the cover | `548 ch` |
| Syosetu | `general_all_no` | `304 ch` |
| Wattpad | `numParts` | `75 ch` |
| WTR Lab | `chapter_count` in `__NEXT_DATA__` (the site's own card prints the translated count) | `112 ch` |

**Four sources state no count in their lists** and therefore show no chip —
**Webnovel** (its mobile search JSON carries no count; `totalChapterNum` exists
only on the chapter-content API), **GoodNovel** (its home rows have no such
field), **Wuxiaworld** (its Lite browse pages carry no count) and **Ranobes**
(only a sort option and a filter; a measured row reads
`Title 82 4.1 ( 34 ) 14 hours ago` — a star meter and a comment count, no
chapters). Opening a novel's own page twenty times behind every shelf is what
this feature exists to avoid, so they show nothing.

**FanMTL's feed jobs were reordered** for this: its list pages state a count in
every row and its front page states none, so `/list/all/all-onclick-0..2.html`
now come first and `/` last (all four carry covers — 30 and 86 novels
respectively). The health sweep still judges the source on a shelf that carries
novels, which the list pages do.

### Verification (2.7.53)

* All **24 feeds** swept: **20 show a chip on every one of the first ten cards**,
  and the four that do not are the four with no count to show. Novel Hall: 2 of
  the first 10 (its first eight are the cover-art cards, which carry no count by
  design). Novel Cool: 7 of 10 (some rows omit `last_chapter_title`).
* **Global search** swept the same way after the last edit — **255** results for
  `love` from **23** sources. **17 of them put a chip on every one of the twelve
  cards they contributed**; the rest are the four that publish no count
  (Webnovel, GoodNovel, Wuxiaworld, Ranobes), plus **Dreame** (its *search* rows
  carry no chapter field at all — `totalClick` only — though its home shelves do)
  and **Novel Cool** (3 of 12; some search rows omit `last_chapter_title`). The
  same sweep is what caught Scribble Hub's search route returning no count, now
  fixed by reading the finder's own stat row.
* Covers load in the feed for all 24 — the six-of-six `naturalWidth` check above,
  run per source.
* Vision-approved captures (rendered at 390px, four to six cards, and at a 2x
  scale for the small text): AO3's drawn covers with chips and legible, unclipped
  titles — the last check after the foot-line fix, confirming the foot line
  clears the `+` button — and Syosetu's Japanese drawn covers with no tofu and
  nothing clipped.
* `gridResult` unit-checked: a bare Novel Hall card renders `data-cover="data:image/svg…"`
  with `data-cover-url=""`; a card with a real cover keeps both as that URL.
* Geometry check at the real 135px card: pill 156..184 × 571..599 inside the
  cover box 55..190 × 402..605, chip 44×15 at the card's foot, **no overlap**.
* No `perchanceErrors` and no console errors after the change; `#logList` shows
  v2.7.53 with the *Latest* badge.

## Previously — 2.7.52 (2026-09-30)

The app is on **v2.7.52** — **one new source** (**Archive of Our Own**; the app
now carries **twenty-four**). The request was simply:

> "Do the archive of our own source"

`archiveofourown.org` (**AO3**) is the biggest fanfiction archive there is
(~468,957 works under its *Original Work* tag alone when measured), and it also
carries original fiction, so it is the single highest-value addition to the app.
It is read through **its own pages** — AO3 publishes no interface of its own to
read through, so this is one of the sources where scraping is the honest route.
It is **not** read through its download files (see below: they are wildly too
big).

### What AO3 actually answers (measured 2026-09-30)

| what | endpoint | measured |
| --- | --- | --- |
| its own search | `/works/search?work_search[query]=<q>` | **20 works a page**, ~150-240 KB of server-rendered HTML |
| a fandom's shelf | `/tags/<tag>/works?work_search[sort_column]=kudos_count` | **20 works**, **243,680 bytes** measured (Original Work) |
| a work (header **+ chapter 1 + the whole chapter list**) | `/works/<id>?view_adult=true` | the chapter list rides along: **188 `<option>`s** for *All the Young Dudes* |
| a chapter | `/works/<id>/chapters/<cid>?view_adult=true` | **27-95 KB**; the prose is `div[role="article"]` |
| the whole-work download | `/downloads/<id>/work.html` | **3.5 MB** for that same 188-chapter work — **rejected** |

Two things arrive **instead of** a page, both of them HTTP 200s, and both are
handled rather than parsed:

* **Cloudflare's "525: SSL handshake failed"** — the whole body is the error
  page, and it is common (measured: 4 of 7 requests while probing, with the same
  URL answering in **40 ms** a moment later). It carries none of AO3's markup, so
  `AO3_IS_PAGE` refuses it. The page also has to be *complete* (`</html>`),
  because a proxy that truncates a long page would otherwise hand over half a
  chapter list and it would look like a short book.
* **AO3's adult-content interstitial** — what a work rated *Explicit* shows to a
  reader who has not confirmed anything yet: a notice and no work.
  `?view_adult=true` (what the notice's own *Proceed* button sets) is on every
  work and chapter URL, and the interstitial is refused as a page as well.

### Things specific to this source

* **No API, only pages.** AO3 has no JSON anywhere; the feed, the search, the
  work and the chapter are all server-rendered HTML. `AO3_parseBooks` therefore
  works entirely off `li.work.blurb id="work_<id>"` cards, which is the *same*
  list on a search results page, a tag's works page and AO3's own fandom shelves
  — one parser reads all of them.
* **The whole chapter list comes free with the work page.** AO3 prints a
  `<select id="selected_id">` of `<option value="<chapter id>">7. The Sorting</option>`
  rows (the number is the site's own; `AO3_chName` strips it, so the app prints
  "Chapter 7" itself). A **one-chapter work has no select at all** — its page *is*
  the chapter — so `AO3_getBook` gives it a synthetic list of one entry with the
  sentinel id `"1"`, and `AO3_getChapter` fetches the work URL (not a
  `/chapters/` URL) when it sees `chs.length === 1 && chs[0].id === "1"`. A real
  AO3 chapter id is eight digits, so the single digit `1` can never collide.
* **`dl.chapters` is how a work's state is read.** `188/188` is finished,
  `7/9` is still being written, and `1/?` is one whose author plans more —
  `AO3_chaptersDone` reads all three and `AO3_status` turns them into
  `"completed"` / `"ongoing"`.
* **`dl` rows are read into a map, not by position.** `dl.work.meta.group` (the
  work's own tags) and `dl.stats` (chapters / words / kudos / hits / bookmarks)
  are runs of `<dt>`/`<dd>` rows whose *set* depends on the work — a work with no
  relationships has no relationship row — so `AO3_dl` keys each row by its `<dt>`
  class or label rather than by index.
* **The notes are kept, and labelled.** The author's start notes are a
  `<div id="notes">` *before* the prose and the end notes are a
  `.end.notes.module#chapter_<N>_endnotes` *after* it (both *outside*
  `div[role="article"]`, and both labelled "Notes:" by AO3 itself). `AO3_chapterHTML`
  emits them in that order, each under a plain `<p>Notes:</p>` the app draws, so
  a reader can tell the author's note apart from the story.
* **A scene break is a divider, not stray punctuation.** Authors type them as
  `* * *`, `***`, `- - -`, `— — —`, `~~~`, and AO3 keeps the author's `<p>`.
  `AO3_paraHTML` draws a run of separator characters as the app's own
  `<p class="rdv">` divider (so `* * *` → `***`, `— — —` → `———`, `~~~` → `···`)
  instead of letting "\\* \\* \\*" read as a sentence.
* **No cover art and no star rating.** AO3 files works by *maturity*
  (General / Teen / Mature / Explicit), not by score, and publishes no cover
  pictures at all, so `SRC["Archive of Our Own"].cover` is `() => ""`, AO3 is
  deliberately **absent** from `COVER_FETCHERS` and `RATING_ENRICHABLE`, and its
  cards wear the title's first character and show the work's **kudos** count in
  the vote slot (a card on the measured feed read **"325,077 votes"**).
* **One tag list is not one tag.** The work's own tags come from
  `dl.work.meta.group` (`fandom`, `relationship`, `character`, `freeform`,
  `warning`, `category`); a card takes the first fandom as its genre and the
  freeform tags (falling back to relationships) as its chips. On a listing the
  card's own `h5.fandoms a.tag` and `ul.tags li.freeforms a.tag` are used.
* **It is burst-sensitive.** `archiveofourown.org` is in `BURST_SENSITIVE`, so
  AO3 never gets two same-network requests at once — the site is a non-profit
  running on donations and this is simply polite.

### The card-score change (`gridStarsHTML`) — and why Wattpad changes too

`ratingCardLabel` returned `"0.0"` for a source with no rating, so every
rating-less card (Wattpad's, and now AO3's) showed five **empty stars and a
"0.0"** — a score they all appeared to share. A new helper `gridStarsHTML`
decides the whole score line instead:

* rating > 0 → stars + the number (unchanged);
* rating 0 but a `RATING_ENRICHABLE` source whose rating is still in flight →
  empty stars + `"…"` (unchanged);
* rating 0 and **votes > 0** → **no stars**, a `<span class="gridVotes">N votes</span>`
  instead (this is the AO3 and Wattpad case);
* rating 0 and votes 0 → nothing at all.

`gridResult` uses it, plus a `.gridVotes` CSS rule, and the book screen's
`bookHeroRating` got the matching logic. **This is what makes the 2.7.46
changelog's claim about Wattpad true** ("its cards carry the number of votes the
site shows" — they had been showing `0.0` instead). `ratingCardLabel` still
exists and is reached only when `rating > 0`.

### Touch points used (the 16-item list)

1 `SOURCES` (card: `icon "AO3"`, colour `#990000` — AO3's own red — "Fanfiction &
original fiction", `lang "English"`, vendored logo
`user.uploads.dev/file/3483da426799646c3ee085b727a0d1e6.png`, 144x144, white AO3
mark on a red square, taken from the site's own `/apple-touch-icon.png`, with the
google favicon as `logoFallback`) · 2 `SRC["Archive of Our Own"]` (`cover: () => ""`)
· 3 `ID_PREFIX_SOURCES.ao3`, `SRC_ALIASES` (`ao3`, `archiveofourown`, `archive`)
· 4 `sourceForURL` (`/archiveofourown\.org/i`) + `sourceBaseURL`
(`https://archiveofourown.org/`) · 5 `HEALTH_URLS` (the kudos-sorted search, one
row) · 6 `buildDiscoverJobs` (**9 jobs**: the kudos search page 1, page 2, then
seven tag shelves — Original Work, Harry Potter, My Hero Academia, Supernatural,
Marvel Cinematic Universe, Star Wars, Naruto) + `feedLabel` ("Popular on Archive
of Our Own") + `fetchBrowsePage` + `FEED_COVER_NOTE` ("AO3 publishes no cover
pictures — each card shows the title's first character.") · 8 `openWebnovel`
(`/works/<id>`) · 10 `BURST_SENSITIVE` · 13 `decodeText` + `escapeHtml` on every
string · 15 **the site's own pages** (there is no interface to prefer) · 12
`detail.status` from `dl.chapters` · 16 the 2.7.34 sweep picks it up with no extra
wiring — and deliberately **not** 7 (`RATING_ENRICHABLE`: AO3 has no rating), 9
(`CATALOGS`: its search is GET), 11 (no bundles), 14 (`coverURLs`: it has no
covers) or `COVER_FETCHERS` (deliberately absent — there are none to find).

### Verification (2.7.52)

* `APP_VERSION` "2.7.52"; `UPDATES[0]` is 2.7.52 with **6** items; `SOURCES.length`
  **24**, last entry "Archive of Our Own"; `SRC["Archive of Our Own"]` present and
  its `cover` a function; `feedLabel` / `sourceBaseURL` / `sourceForURL` /
  `healthURL` / `ID_PREFIX_SOURCES.ao3` / `SRC_ALIASES` (`ao3`→`Archive of Our Own`,
  `archiveofourown`, `archive`) all resolve; `buildDiscoverJobs` returns **9** jobs;
  `BURST_SENSITIVE["archiveofourown.org"] === 1`; `FEED_COVER_NOTE` set; `catPager`
  untouched.
* The trailing-escape trap: the whole AO3 block totalled **0** doubled escape
  sequences (`/\\\\/`) and the live `AO3_IS_PAGE` holds a literal
  `.indexOf('id="main"')` (checked in the file bytes, not by eye).
* `AO3_IS_PAGE` unit-checked in the live page: a page with `id="main"` and
  `</html>` → **true**; the same page carrying "SSL handshake failed" → **false**;
  carrying "could have adult content" → **false**; missing `</html>` (a truncated
  page) → **false**.
* Pure helpers: `AO3_chName("7. The Sorting")` → **"The Sorting"**;
  `AO3_chaptersDone("188/188")` → `{done:188,total:188}` and `"1/?"` →
  `{done:1,total:null}`; `AO3_paraHTML("* * *")` → `<p>***</p>`, `("~~~")` →
  `<p>···</p>`; the chapter-HTML synthetic tests confirm the notes labelled
  "Notes:", `<br>` line splitting, `<ul><li>` items kept as separate paragraphs, an
  author's own `<h3>` kept while AO3's `.heading`/`.landmark` are dropped, and
  separators normalised.
* Network, through the app's own routes: `fetchBrowsePage(job[0])` → **20** works;
  `fetchBrowsePage(job[2])` (Original Work) → **20** in **243,680 bytes**;
  `fetchBrowsePage(job[4])` (My Hero Academia) → **20**;
  `SRC["Archive of Our Own"].search("coffee shop au")` → **20**;
  `AO3_getBook("ao3-10057010")` (*All the Young Dudes*) → **188** chapters with
  right names and ids, **325,077** kudos, `status "completed"`, synopsis from the
  `blurb`; `AO3_getBook("ao3-2080878")` (*I Am Groot*) → **1** chapter, id `"1"`,
  **181,302** kudos; `AO3_getChapter` on the one-chapter work → **38**
  paragraphs (no `/chapters/` request — the sentinel works); on ch.188 → **316**
  paragraphs, 3 `rdv` dividers, 2 "Notes:" labels with the end notes at the tail,
  `prevId` set / `nextId` null; `sfHealth(healthURL("Archive of Our Own"))` →
  **"ok"**; `probeSourceHealth("Archive of Our Own")` →
  `{ok:true, kind:"ok", stage:"chapter", ms:1575, found:20, via:"jina",
  book:"All the Young Dudes"}`.
* UI, driven in the live preview: the source list renders **24** cards and the AO3
  row shows a legible white AO3 mark on a red square (vision-checked) with the
  green dot and the ENGLISH badge; the feed renders 20 cards with letter tiles +
  "NO COVER" and a **vision-confirmed** "325,076 votes" / "203,371 votes" line and
  **no stars and no "0.0"**; the book screen reads "✓ 188 chapters · Archive of Our
  Own", "325,077 votes", "Completed", its fandom and tag chips, and the synopsis;
  the reader opened ch.1 ("Chapter 1: Summer, 1971: St Edmund's", 65 paragraphs)
  and was vision-checked clean (legible, left-aligned, no stray tags, entities or
  merged words).
* The scene divider is **centred on the real page**: with the reader open,
  `getComputedStyle(p.rdv).textAlign === "center"` and the text's rendered centre
  sat **0 px** from the reader body's centre. (An earlier vision pass reported it
  left-aligned — that was the capture harness copying `text-align:left` into its
  wrapper, not the app.)
* Layout: no horizontal overflow at **390x844** (feed 20 cards, 2 columns) or
  **1920x1080** (20 cards).
* One transient note: a single `fetchBrowsePage(job[2])` returned **0** books
  before the same URL parsed 20 twice in a row — an odd partial answer from one
  route, not reproducible. Left as-is (no code change), recorded here so a future
  agent does not chase it.

## Previously — 2.7.51 (2026-09-30)

The app is on **v2.7.51** — **one new source** (**Inkitt**; the app now carries
**twenty-three**). The request was simply:

> "Add inkitt"

Inkitt (`inkitt.com`) is one of the biggest English-language original-fiction
sites there is — serials, finished novels and fanfiction, all posted by their
authors, plus a large fanfiction section — so it is a good complement to the
translated-catalogue sources. It is read through **its own interface**, with no
signing in and no key to carry, and it is the **eighth** source to work that way.

### What Inkitt actually answers (measured 2026-09-30)

It is a Rails + React app ("react-on-rails"). What a signed-out reader can get
out of it is small, and finding that out took most of the work:

| what | endpoint | measured |
| --- | --- | --- |
| its front-page shelf | `/api/1/homepage/trending_stories` | **20 novels in ~157 KB**, `{response:{type:"storyList", items:[…]}}` |
| its own title search | `/api/2/search/title?q=<q>&page=<n>` | **10 a page, ~40-51 KB**; pages 1-based (`page=0` errors), `q=""` returns nothing |
| a novel's record | `/api/1/stories/<id>` | ~32 KB: `title`, `blurb` (the *whole* synopsis), `story_status`, `overall_rating_cache`, `story_genres[{main_genre, sub_genre}]`, `pills[]`, `user`, `chapters_count`, `cover` **and** `vertical_cover` |
| its chapter list | `/api/stories/<id>` (**unversioned**) | ~7 KB: `chapters[{chapter_number, id, name}]` |
| a chapter | `/stories/<id>/chapters/<n>` (**HTML**) | 95-115 KB; the text is `<div id="chapterText">` and it appears **once** per page |

Everything else was a dead end, each checked live rather than assumed:

* `/api/1/homepage/genre_stories?genre=…&genre_type=…` — the client *has* this
  function (`getGenreStories`), but nothing calls it and it answers
  `{response:{type:"empty"}}` for every `genre`/`genre_type` tried
  (`romance`, `main`, `genres`, `2`, `fantasy`).
* `/api/1/homepage/shelves` → `{"response":[]}`; `/api/1/homepage/audiobook_shelves`
  → empty; `/api/2/constants` → empty; `/api/2/stories` (GET) → `{}`;
  `/api/3/stories` (the full `search`/`filter`/`ordering`/`page`/`per_page`
  catalogue the site's own story lists use) → `{}` — it is author-scoped.
* `/api/1/genres`, `/api/2/genres`, `/tags/…`, `/genres/<g>.json` → 404 or empty.
  A server-rendered genre listing exists (`/genres/<g>` — `initialStories` 20,
  `initialTotalCount` 15990) but it is a **606 KB** page, too heavy for a feed job.
* **The one that looked best and wasn't**: the 1.4 MB client bundle names
  `/api/2/search/blended` (tag / user / reading_list / story groups, 5 each) and
  `/api/1/homepage/fandoms` + `/api/1/homepage/reading_lists` (20 hubs and 20
  public lists, 5 stories each). Those story *previews* carry only
  `vertical_cover` + `id` — **no title, no rating, no like count** — so they
  cannot make a card. `/api/2/search/blended` also ignores `mode` and `per_page`
  (every combination returned the same 178 KB).
* The topics/tag route the client uses (`/topics/<name>`, and its API behind
  `st.tDL`, which lives in a vendor chunk we don't have) could not be reached:
  `/topics/werewolf` answers a 102 KB **MinimalFooter** page with no payload and
  no API path in it, and `/api/{1,2,3}/tags|topics/…` are all 404s.

**So the feed is its own front-page shelf plus its own title search** — nine jobs,
the shelf first (it is what the health sweep reads) and then eight broad words
(`love`, `the`, `romance`, `werewolf`, `alpha`, `vampire`, `billionaire`,
`dragon`), which is what gives a 20-novel shelf any breadth at all. The search
sorts by relevance and accepts no `sort`/`order`/`limit` (all tried and ignored),
so its results are the obscure end of the catalogue; they are still real novels
with real covers, and browsing a trope is a reasonable thing to want.

### Things specific to this source

* **Inkitt already scores out of five.** Its `overall_rating_cache` reads 4.6 /
  4.7 / 4.8, so unlike Chikari's `IK_rating` does **no rescaling** — a 4.6 here
  is the 4.6 Inkitt itself prints.
* **The cover is the vertical one.** `cover.url` is a **799×281 landscape
  banner** (wrong for a card); `vertical_cover.iphone` is **342×546**. `IK_cover`
  prefers `vertical_cover.iphone → .ipad → .url` and never falls back to the
  banner.
* **A listing gives a like count, a novel's record does not.** The listing's
  `story_likes_count` (806 on the first trending novel) is what a card shows;
  `/api/1/stories/<id>` has no like count at all, only `reviews_count` (117 on
  the same novel) — a genuinely *different* number, and a review is not a vote.
  `IK_getBook` therefore sets `detail.votes` to **0**, and the `detail.votes ||
  book.votes` line in `loadBook` lets the card's 806 flow through, so the book
  screen and the card agree instead of showing two different counts for one novel.
* **`IK_genres` reads both shapes and keeps the interesting half.** A listing has
  `genres` (bare slugs: `["romance","drama"]`); a novel's record has
  `story_genres` — one `{main_genre, sub_genre}` pair per genre the author picked,
  so `main_genre` repeats ("Romance" five times on one novel) while **`sub_genre`
  is the informative part** ("Alpha Male", "Dark", "Second Chance", "Workplace").
  One main genre is kept, every distinct sub-genre and `pills` entry joins it as
  a tag, all deduped — which is where a card's chips come from.
* **`IK_chName` blanks a bare "Chapter N".** The site writes *"Chapter 7"* for
  most chapters and the author's own words for the rest (*"When his gaze locked
  hers"*, *"Rejection"*), and the app prints "Chapter N" itself — so the bare ones
  are blanked rather than shown twice, and the written ones are kept exactly.
* **A chapter has no JSON, so its own page is read.** The story serializer carries
  only the first chapter's text, and `/api/1/…/chapters`, `/api/1/chapters/<id>`
  and `/api/2/chapters/<id>` are all 404. `IK_chapterHTML` parses the page with
  `DOMParser` and takes `#chapterText`; `<hr>` scene breaks (5 of them in the
  first chapter) are rewritten as `<p>···</p>` first, which `chapterInnerHTML`
  then draws as its own `<p class="rdv">` divider.
* **The patron gate is an empty body.** A story can be behind its author's patron
  subscription, and the site answers those chapters with an empty `#chapterText`
  (2 characters) rather than a refusal — measured on chapters 5 and 40 of story
  `1361109` (94 KB page, no next-chapter button), while its free first chapter
  comes back at 4.5 KB. `patron_tiers` is `[]` even for a gated story, so
  body-emptiness is the only reliable signal; `IK_getChapter` reports `locked`
  from it.
* **`cdn-gcs.inkitt.com` sends ACAO** (measured: a `crossOrigin` image loads and a
  canvas reads it back untainted), so this source needs only a `coverURLs` entry —
  **no `loadCoverImg` exception**.

### The locked-chapter notice names the right site now

`chapterInnerHTML` had a hardcoded *"This chapter requires a Webnovel
membership."* on its locked branch — which was already wrong for the one other
source that can lock a chapter (Novel Cool's `vipStatus`/`waitpayStatus` chapters
asked for a Webnovel membership). The message is built per source now
(Inkitt → "an Inkitt patron subscription", NovelCool → "a Novel Cool
membership", Chikari → "a Chikari membership", else Webnovel), and Webnovel's own
string is byte-identical to before.

### Touch points used (the 16-item list)

1 `SOURCES` (card: `icon "IK"`, colour `#e30e8d` — Inkitt's own magenta, 81
occurrences in its home page — "Original novels & serials", `lang "English"`,
vendored logo `user.uploads.dev/file/96e3de77…png`, 3,563 bytes, black square with
a white flared "I", found via `static-firebase.inkitt.com/manifest.json` because
the page declares no favicon — with the google favicon as `logoFallback`) · 2
`SRC["Inkitt"]` (`cover: () => ""` — covers come on the listing) · 3
`ID_PREFIX_SOURCES.ik`, `COVER_HOST_SOURCES` (`cdn-gcs.inkitt.com`, `inkitt.com`),
`SRC_ALIASES` (`inkitt`, `inkittcom`, `ik`) · 4 `sourceForURL` + `sourceBaseURL` ·
5 `HEALTH_URLS` (the title search, one row) · 6 `buildDiscoverJobs` (9 jobs: the
shelf + eight searches) + `feedLabel` ("Popular on Inkitt") + `fetchBrowsePage`
· 8 `openWebnovel` (`/stories/<id>`) · 13 `decodeText` + `escapeHtml` on every
string · 15 **the site's own interface first** (no scraping of listings, and the
one page read is the chapter page, which is the only place the text exists) ·
12 `detail.status` from the record · 16 the 2.7.34 sweep picks it up with no
extra wiring — and deliberately **not** 7 (`RATING_ENRICHABLE`: the listing
carries `rating`), 9 (`CATALOGS`: its search is GET), 11 (no bundles) or 14
(`coverURLs` entry only — the host sends ACAO).

### Verification (2.7.51)

* `APP_VERSION` "2.7.51", `UPDATES[0]` is 2.7.51 with **6** items and **0**
  backslashes (counted in the live page), `SOURCES.length` **23** (last entry
  Inkitt), `SRC["Inkitt"]` present, `feedLabel("Inkitt") === "Popular on Inkitt"`,
  `buildDiscoverJobs("Inkitt").length === 9` with the shelf first,
  `healthURL("Inkitt")` = the title search, `sourceForURL("https://www.inkitt.com/stories/123")`
  → "Inkitt", `sourceBaseURL("Inkitt")` → `https://www.inkitt.com/`,
  `ID_PREFIX_SOURCES.ik` → "Inkitt", `catPager` untouched.
* The trailing-escape trap: `IK_chapterHTML`'s `<hr>` rewrite counted **4**
  backslashes on its line in the file (one `\b`, three `\u00b7`) and the whole
  183-line Inkitt block totalled **19** with **0** doubled escape sequences.
* Pure helpers / inline rendering, checked directly: `IK_chapterHTML("")` → `""`;
  the locked notice now renders *"an Inkitt patron subscription."* for Inkitt,
  *"a Novel Cool membership."* for NovelCool and *"a Webnovel membership."* for
  Webnovel.
* Network, through the app's own routes: `fetchBrowsePage(trending)` → **20
  novels** (title, author, 342×546 cover, 4.6 / 806 likes / completed / romance);
  `fetchBrowsePage(job[1])` → **10**; `IK_searchBooks("shadow", 1)` → 10;
  `IK_getBook("ik-1720715")` → "[Moving to Galatea] What We Never Healed", Ava
  Reed, 16 chapters / 16 total, genre "Romance", tags `["Alpha Male","Dark",
  "Second Chance","Workplace"]` (deduped — it was `["Romance","Romance",…]`
  before `IK_genres` was rewritten), synopsis from `blurb`;
  `IK_getChapter(book, "1")` → 211 paragraphs / 5 scene-break dots, `locked:false`,
  `nextId "2"`, `prevId null`; `IK_getChapter` on `ik-1361109` ch.5 →
  `locked:true`; chapter 3 → `prevId "2"` / `nextId "4"`, chapter 6 → `prevId "5"`;
  author-written names survive (`"When his gaze locked hers"`, `"Rejection"`);
  `sfHealth(healthURL("Inkitt"))` → **"ok"**; `probeSourceHealth("Inkitt")` →
  `{ok:true, kind:"ok", stage:"chapter", found:20, via:"superfetch",
  book:"[Moving to Galatea] What We Never Healed", coverOk:true}` (2.5 s).
* UI, driven in the live preview: source list shows **23** cards and the Inkitt
  row renders its logo at `naturalWidth 192` with the green dot, the ENGLISH
  badge and "Connected · Original novels & serials" (vision-checked: portrait
  cover, title, **4.6** stars, author, on a grid card); the Inkitt feed's covers
  all load at **342×546**; the book screen reads "✓ 16 chapters · Inkitt" with
  its genre chips; the reader opened chapter 1 of the trending novel with 211
  paragraphs and the prose vision-checked as legible, left-aligned and free of
  stray tags, and the `···` scene divider vision-checked as three centred dots;
  the What's new screen renders 2.7.51 first with the "Latest" badge.
* Layout: no horizontal overflow at **390×844** (2 columns of 135 px, 171×273
  covers) or **1920×1080** (13 columns).
* `/stories/1720715` (what `openWebnovel` builds) answers **200**.


## Previously — 2.7.50 (2026-09-30)

The app is on **v2.7.50** — **one new source** (**Chikari**; the app now carries
**twenty-two**) — and it exists because of a follow-up on the 2.7.38 removal:

> "Try revisiting, that lignovekworld, pub, live, see if there t here's a way"

Three names were asked about. Two of them have an answer, and it is a good one.

### What the three sites turned out to be (measured 2026-09-30)

| asked about | state | verdict |
| --- | --- | --- |
| **LightNovelWorld** (`lightnovelworld.org`, the network's own flagship site) | **closed.** `/api/novel/<slug>/chapters/` — the clean JSON route LNReader's `lightnovelworld.ts` uses — now answers every request with a **10956-byte "This site has shut down" page**: *"It has been merged into chikari.moe. Your account came with us… Your comments, reviews, bookmarks and library are already there waiting for you."* | the catalogue **moved**, and it moved somewhere readable |
| **NovelLive** (`novellive.com`) | **online, still walled.** A listing answers 200 (~145 KB); a chapter is a coin toss — **chapter 2334 of Reverend Insanity** came back whole (200, 54 KB), **chapter 1 of Shadow Slave** came back **403 "Just a moment…"** (Cloudflare). The chapter that *does* come through is written with an **invisible U+200C (ZWNJ) between every word** | no honest route; unchanged from 2.7.38 |
| **LightNovelPub** (`lightnovelpub.com`) | the same network (its chapter links redirect to `novellive.app`); `lightnovelworld.org` is the site that had the JSON | same as NovelLive |

So the novels YueDu dropped in 2.7.38 are **not** lost — they are the
catalogue of **Chikari**, and Chikari answers in JSON.

### Chikari (`chikari.moe`) — a complete JSON interface

Chikari is a SvelteKit app (manga *and* novels; the novels are the LightNovelWorld
catalogue). Six endpoints, all unauthenticated, all checked live, none challenged:

| what | endpoint | measured |
| --- | --- | --- |
| catalogue / search | `/api/novels?sort=<s>&limit=<n>&offset=<n>[&genre=<g>][&q=<q>]` | 40 novels in **~10 KB**; `sort` ∈ `popular trending top_rated updated added most_bookmarked`; `genre=fantasy` narrowed 4,000+ to **1,518** |
| a novel's record | `/api/novels/<slug>` | 5 KB: `title`, `description`, `cover_url`, `authors[].name`, `genres[].name`, `tags[].name`, `status`, `chapter_count`, `rating`, `rating_count`, `views` |
| its chapter list | `/api/novels/<slug>/chapters?order=asc&limit=500&offset=<n>` | **500 chapters in ~72 KB**; answer carries `total` (3194 for Shadow Slave) |
| a chapter | `/api/novels/<slug>/chapters/<n>/read` | ~11 KB: a plain-text `body`, plus `prev_number`, `next_number`, `latest_number`, `locked`, `lock_reason` |

Four things worth remembering:

* **Chikari scores out of ten.** Its `rating` reads 9.5 / 9.7 / 8.7 / 10.0 / 6.5,
  while every card in the app is a **five**-star display (`ratingStarsHTML` clamps
  to 5, and NovelBuddy's own API publishes 4.94). A novel's score is therefore
  **halved** in `CH_rating` — Shadow Slave's 9.5 becomes the 4.8 a card shows,
  which is the same score NovelUpdates gives it. `votes` is `rating_count`.
* **Chapter titles carry the number twice, in two different formats.**
  *"Chapter 1 - 1: Nightmare Begins"* in the early chapters,
  *"Chapter 3191 There and Back Again"* in the late ones. `CH_chName` strips
  `^chapter\s*\d+\s*(?:[-–—:.]\s*\d+\s*[:.\-–—]?\s*)?` and then any leading
  separator, which yields **"Nightmare Begins"** and **"There and Back Again"**
  respectively (verified against four live shapes).
* **The body is plain text with a blank line between paragraphs, and nothing
  else.** Measured on chapter 1 of Shadow Slave: 10,566 chars, **95 `\n\n`, zero
  single newlines, zero carriage returns, no ZWNJ and no other invisibles** — so
  each blank-line-separated run is one paragraph and there is no markup to lose.
  That is unlike the NovelLive pages, which are deliberately poisoned.
* **`cdn.chikari.moe` sends ACAO.** Measured in the live page: a
  `crossOrigin="anonymous"` image of `novels/53/cover.webp` loads (450×600) *and*
  a canvas reads it back untainted, so `cacheCover` works and the host does **not**
  need the `loadCoverImg` exception list — only a `coverURLs` entry with weserv
  behind it. (`cdn.chikari.moe` before `chikari.moe` in `COVER_HOST_SOURCES` so a
  cover URL is attributed by its CDN.)

### Long catalogues: 500 with the novel, the rest on request

`CH_getBook` fetches the record and **page 1 of the list (500 chapters)** in
parallel — 912 ms for Shadow Slave, 3194 chapters total. The array carries its
own paging state, exactly as Wuxiaworld's and Narou's do
(`chapters._ch = {slug, offset, total, strikes, seen, done}`), `catPager` gained a
fourth branch, and **`CH_catMore`** walks the rest: two pages (1,000 chapters) per
tap with a 300 ms beat. Measured: 500 → **1500** (2.5 s) → **2500** (2.7 s),
numbering gapless. A page that answers nothing strikes once and stops on the
second, so the button can never sit there promising more for ever.

### One bug found while testing (and fixed)

`CH_getChapter` was first exercised with the object `getBook` returns
(`{detail, cat}`) rather than a book carrying `bookId`. The slug came out empty,
the request went to `/api/novels//chapters/1/read`, and that malformed URL
surfaced as **the app's own captcha screen** (the hedge reported it as a challenge
at a URL that does not exist). `CH_getChapter` now throws an honest error when
there is no slug, and the reader is never shown a captcha for a URL the app built
wrong.

### On the two sources that stay out

Re-tested, and recorded in the changelog so the question does not have to be
asked a third time: **there is still no way to read NovelLive / LightNovelPub.**
Their listings answer, their chapter pages are met by a Cloudflare challenge about
half the time (measured: 1 of 2), and the text behind the half that does come
through is written with U+200C between every word. Nothing in the app can pass
that honestly, so they remain removed (`RETIRED_SOURCES` unchanged). The novels
themselves are reachable — through Chikari, which is what the LightNovelWorld
network became.

### Touch points used (the 16-item list)

1 `SOURCES` (card: `icon "CH"`, colour `#5b9dd9`, "Novels (LightNovelWorld's new
home)", `lang "English"`, vendored logo `user.uploads.dev/file/b1debe23…png`
with the google favicon as `logoFallback`) · 2 `SRC["Chikari"]` · 3
`ID_PREFIX_SOURCES.ch`, `COVER_HOST_SOURCES` (`cdn.chikari.moe`, `chikari.moe`),
`SRC_ALIASES` (`chikari`, `chikarimoe`, `ch`) · 4 `sourceForURL` +
`sourceBaseURL` · 5 `HEALTH_URLS` (a one-row listing call) · 6
`buildDiscoverJobs` (9 jobs: six sorts + three genres) + `feedLabel` +
`fetchBrowsePage` · 8 `openWebnovel` (`/novels/<slug>`) · 13 `decodeText` +
`escapeHtml` on every string · 15 **the site's own interface first** (there is no
scraping anywhere in this source) · 12 `detail.status` from the record ·
16 the 2.7.34 sweep picks it up with no extra wiring — and deliberately **not**
7 (`RATING_ENRICHABLE`: the listing carries `rating`), 9 (`CATALOGS`: its search
is GET), 11 (no bundles) or 14 (`coverURLs` entry only — the host sends ACAO, so
no `loadCoverImg` exception).

### Verification (2.7.50)

* `APP_VERSION` "2.7.50", `UPDATES[0]` is 2.7.50 with **6** items and **0**
  backslashes (counted in the live page), `SOURCES.length` **22**,
  `SRC["Chikari"]` present, `feedLabel("Chikari") === "Popular on Chikari"`,
  `buildDiscoverJobs("Chikari").length === 9`, `catPager({_ch:{}})` → `CH_catMore`.
* Pure helpers, checked directly: `CH_chName` on all four live title shapes →
  "Nightmare Begins" / "There and Back Again" / "The Beginning" / "The Strings of
  Fate"; `CH_rating({rating:9.5})` → **4.8**; `coverURLs` → direct + weserv.
* Network, through the app's own routes: feed `fetchBrowsePage(job[0])` →
  **40 novels in 1.42 s**; `sfHealth(healthURL("Chikari"))` → **"ok"**;
  `SRC["Chikari"].search("shadow slave")` → **4 hits in 0.73 s**;
  `getBook("ch-shadow-slave")` → **912 ms**, 500 chapters / 3194 total, author
  "GuiltyThree", genre "Action", tags, synopsis, `status "ongoing"`, rating 4.8;
  chapters 1 / 500 / 3194 → 0.71 s / 1.19 s / 1.22 s, 96 / — / 89 paragraphs,
  correct names and neighbours (3194 is outside the loaded 500 and still gets
  `prev "3193"`, `next null`); `CH_catMore` 500 → 1500 → 2500.
* `probeSourceHealth("Chikari")` → `{ok:true, kind:"ok", stage:"chapter",
  found:40, via:"superfetch", book:"Shadow Slave", coverOk:true}` (2.7 s).
* UI, driven in the live preview: source list shows **22** cards and the Chikari
  row's logo is `complete`, `naturalWidth 192`, `loading="eager"`, `display:block`
  (vision-checked: the "C" mark, the green dot, the ENGLISH badge, the
  description); the Chikari feed rendered **40** cards whose covers all loaded
  (`naturalWidth` 193-600, `display:block`, **0** hidden) — one card
  vision-checked (real cover, title, **4.4** stars, the "Chikari" attribution);
  the book screen read "✓ 3194 chapters · Chikari" with `Chapter 1 – Nightmare
  Begins` first and the list paging 200 → 400 → 500 → "Load more chapters ·
  500/3194" → 1500; chapter 1 opened the reader with 96 paragraphs and the prose
  vision-checked as legible, correctly wrapped and free of stray tags.
* Layout: no horizontal overflow at **390×844** (card width 135, right edge 190)
  or **1920×1080**.
* `UPDATES[0]` rendered in the app's What's new screen.

## Previously — 2.7.49 (2026-09-30)

The app is on **v2.7.49** — **no new sources** (still **twenty-one**). This is the
*other* half of the same user report as 2.7.48:

> "I actually mean the Novel inside the sources. Some novel don't have a image.
> And also about the connection, I was talking about. Not seeing slow connection
> alert so the novel feed no image is probably not on the internet"

The user's own deduction was right: the missing feed pictures were **not** the
network (which is why no "Slow connection" pill appeared — and that pill's rules
are unchanged from 2.7.48; it deliberately needs two hosts). Two faults in the
cover machinery, both fixed here.

### 1. A picture the site *does* publish was being hidden (the actual bug)

A card's picture is asked for by two independent things: the on-screen scan
(`coverFallbackScan`, which walks `img[data-cover]` near the viewport) and the
`IntersectionObserver` inside `loadCovers`. Both can report the *same* element,
and `loadCoverImg` consumes `data-cover` on the first call — so the second call
found the attribute already gone and read that as *"this card's listing carried no
picture at all"*: it set `img.style.display = "none"` and queued a cover fetch
behind it. The picture already on its way then arrived **into a hidden element**,
and `patchCoverCard` declined to replace it (the card's `data-cover-url` already
equalled the cover that came back), so it stayed hidden for good.

Measured on one Novel Hall feed (2026-09-30): **11 of the first cards had `src`,
`naturalWidth` 193–300 and `display:none`** — loaded, on screen, invisible. Each
one also wasted a `NLH_coverFor` fetch: 33 requests / 9.2 MB spent on a feed whose
pictures were mostly already there.

Fix: `loadCoverImg` now tells *"still has something to ask for"* from *"has
already been asked about"* —

```js
const asked = img.dataset.cover !== undefined;
...
if (!asked) {
  if (img.getAttribute("src")) { img.style.display = ""; return; }  // unhide, drop out
  img.style.display = "none";
  requestCardCover(img);
  return;
}
```

A second report about an element that already has a `src` **unhides it and
returns**; only a genuinely bare card (no `src` at all) is hidden and queued.
`requestCardCover` additionally refuses any card whose `data-cover-url` is already
set, so a card whose listing carried a picture can never be fetched for.

### 2. A whole bare shelf could not finish filling itself

Novel Hall publishes its rankings, its latest-release tables and its search
results as plain text rows with **no picture in them** (measured: 40 of the first
48 novels its feed carries are bare, and its own front pages are 8 `.book-img`
cards above a 20-row table). The 2.7.45 machinery fetches each bare card's cover
from the novel's own page as the card reaches the screen — but `COVER_FILL_CAP`
was **20 per source per session** and `coverFillBudget` was never reset, so a
108-card shelf filled its first ~20 covers and sat bare past that however far the
reader scrolled.

Now:

* `COVER_FILL_CAP` is **150**, and the budget is reset per source every time a feed
  run starts (`coverFillReset(discover.src)` in `startDiscover`). Covers already
  found live in `NLH_META` (permanent), so a second visit is free for the novels it
  knows and only pays for what the reader has newly reached.
* A **byte budget** bounds it too: `COVER_FILL_BYTES` **24 MB**,
  `COVER_FILL_BYTES_SAVE_DATA` 2 MB, spent through `coverFillSpend(source, n, bytes)`
  with the page length the fetcher reports (`NLH_coverFor` now returns `bytes`).
  A novel's page runs ~30 KB to 1.05 MB (Martial Master), so a count alone is not a
  bound on cost — measured, 33 fills = **9.2 MB** (~280 KB each).
* `saveData` devices (`navigator.connection.saveData`) get `COVER_FILL_CAP_SAVE_DATA`
  **12**.
* A transient failure now removes the book from `coverFillQueued`, so scrolling
  back to that card may try again (a persistent "this novel has no cover" is still
  cached ten minutes in `NLH_COVER_MISS`).

### 3. The three tile states are readable now

A cover-less card used to be a monogram at 16 % white over a dark gradient —
indistinguishable from a load that failed. CSS only, no markup change:

* `.coverLetter` is `rgba(255,255,255,.22)`;
* `.coverWrap > .coverLetter` and `.bookHeroCover > .coverLetter` are
  `flex-direction: column` and carry a caption from `::after` — **"No cover"**, or
  **"Finding cover…"** while the wrap has `.coverPending`;
* `.coverWrap.coverPending > .coverLetter` pulses (`@keyframes coverWait`).

`coverPendingMark(bookId, on)` adds/removes `.coverPending` on
`.gridResult[data-book="…"] .coverWrap`: set when a card is queued, cleared when
the filled picture fires `load`/`error` (not when the *fetch* answers — the picture
still has to arrive), on failure, or after 15 s. The picture is at `z-index: 1`,
so it covers the tile and its caption the moment it arrives.

### 4. The two picture-less shelves explain themselves

`FEED_COVER_NOTE` + `feedNoteHTML(src)` render one quiet line under the feed label
(`.feedNote`, same grid-column span as `.browseLabel`), from the three
`ctn.innerHTML = …` sites in `startDiscover`:

* NovelHall — "This site's lists carry no pictures — each cover is found from the
  novel's own page as you scroll."
* Syosetu — "Narou publishes no cover pictures — each card shows the title's first
  character."

**Syosetu has no covers to fetch and none can be found** (verified 2026-09-30:
`ncode.syosetu.com/<ncode>/`, its `infotop` page and a chapter page carry no cover
`<img>` at all — only `sbo.syosetu.com/<ncode>/twitter.png`, a 1200×630 text-only
OGP card — and the Narou API has no cover field; `yomou`'s lists are text items as
well). Its cards being letters is correct: **do not add a fetcher for it.**

Scope check the same day, first two feed jobs per source: every other source had
**0** empty covers except **Dreame** (2 of 110 — genuine; those novels have no
cover on the site either).

### Verification (2.7.49)

* NovelHall feed, 391 px and 1920 px: **0 cards with `src` + `display:none`** (was
  11); no horizontal overflow at either width; the note spans the grid.
* Fills observed live: 33 novels fetched for 9.2 MB, `NLH_META` grew by 33,
  `dec` climbing while `pending` fell, and every filled card's `img` visible.
* Other sources: `coverFillBudget` stayed **0** for Wattpad / NovelFire /
  Wuxiaworld (no wasted requests) and 0 hidden pictures; covers still load as the
  feed is scrolled.
* Tiles read back with the vision tool at 2×: "NO COVER" and "FINDING COVER…"
  centred under the monogram, no clipping, no overlap, no stray fragments — on a
  grid card and on the book screen's hero tile.
* Feed note read back with the vision tool: label + dim sub-note, legible, no
  overlap.
* `UPDATES[0]` = 2.7.49 with **6** items and **no stray backslashes** — counted by
  char code, because the patch escape trap struck again (12 backslashes on the
  line); fixed by rewriting that one line in `execute_js` (`/\\+"/g` → `\"`).

## Previously — 2.7.48 (2026-09-30)

The app is on **v2.7.48** — **no new sources** (still **twenty-one**). This one
fixes pictures: the source list's icons never loaded, and a picture that stalls
had no way to show up anywhere.

> "Fix something goes wrong, all sources image doesn't show. There's no Slow
> connection Alert"

### The source icons were `loading="lazy"` and never came (the bug)

`sourceIconHTML` emitted every source's icon as
`<img class="sourceLogoImg" src="…" loading="lazy">`. The Browse list is built
while `#browseIdle` is `display:none` (the app opens on another screen), and a
lazy picture in a subtree that is not laid out is deferred until it intersects
the viewport — which, for this list, happens only after the screen is shown *and*
the engine re-evaluates. Measured in the live preview: **1 of 21 icons complete
5 s after the list became visible**, and 20 still pending; with the same 21
pictures loaded eagerly into a visible box, **all 21 finish inside 4 s**. So the
reader saw twenty-one white circles over a dark page — "all sources image doesn't
show".

Fix: icons are `loading="eager"` (the list is one short screen of 21 small PNGs,
so there is nothing to defer), plus `decoding="async"`, and `wireSourceIcons`
gives each one a deadline (`SRC_ICON_DEADLINE`, 5 s): a picture that has not
decoded by then is reported (`netNotePic`) and replaced by the source's letter
tile — and if the source names a `logoFallback` that has not been tried yet, that
is tried first. `setBrowseLogo` (the source header's own picture) got the same
deadline. `.sourceLogoImg` gained `object-fit: contain` so a non-square logo is
letterboxed rather than squashed.

### The icons are vendored now, not hotlinked to an icon service

Every source's `logoUrl` was `https://www.google.com/s2/favicons?domain=…&sz=128`
— a third-party lookup per icon, per page load, which is also the one thing that
would break the list entirely on a network where that host is unreachable (a real
consideration for the packaged app). All twenty-one are now **uploaded assets on
`user.uploads.dev`** (the same host the rest of the app's pictures use), with the
google URL kept as each source's `logoFallback` — a different host, so it is a
genuine second chance rather than a repeat of the first request.

How the set was built (repeatable): for each source, take the larger of
`www.google.com/s2/favicons?…sz=128` and
`t2.gstatic.com/faviconV2?…&size=256`; for the sources whose favicon is only
16-32 px, prefer a better source where one exists (NovelFull's own
`/web/images/favicon.png`, NovelHall's `og:image` logo, Wuxiaworld's
`apple-touch-icon.png` at 180 px, NovelHi's `/favicon.ico` at 32 px); decode each
candidate, prefer square (`0.82 < w/h < 1.22`, so a wide wordmark cannot be
squashed into the 24 px slot), then re-encode to PNG at native size and upload.
Sixteen of the twenty-one are ≥48 px; three are 16 px (Dreame, NovelHall, Scribble
Hub — no larger icon is published) and one is 64×60. Quality was checked by
building a montage of all 21 and reading it back with the vision tool, and the
finished list was captured and checked the same way: **all 21 rows show a visible
logo, 0 blank**.

### The connection pill can now see pictures (the second half of the report)

`NET_ALERT`'s evidence came from `netNoteFail`/`netNoteSlow`, which only the raw
`direct` transport ever calls — pictures, which the DOM loads itself, were
invisible to it, so a feed of blank covers produced no hint at all. Two changes:

* `netNotePic(url)` — a picture that never answered within its deadline. Called by
  `wireSourceIcons` (icons) and by `loadCoverImg` (a cover still undecoded 8 s
  on). `netOwnState` treats **3+ stalled pictures across 2+ hosts** as "slow" —
  one host is deliberately not enough, because one slow server is not a slow
  connection.
* `netState` now asks `netOwnState` **first**, and only falls through to
  `navigator.connection` when the app has seen nothing itself. The browser's
  report is a guess about the link (the Android WebView cheerfully reports "4g"
  for a line that is plainly struggling); a request that never answered is a fact.
  Previously our own evidence was consulted *only* when the browser had no report
  at all, which is why a reader with a screen full of blank pictures got no
  explanation.

Rules, verified against `netOwnState()` directly: 3 fails on one host → `""`;
4 fails across 2 hosts → `"offline"`; 1 slow host → `""`; 2 slow hosts →
`"slow"`; 3 stalled pictures on one host → `""`; +1 picture from a second host →
`"slow"`.

### Verification (2.7.48)

* After a reload with the Browse list shown: 21 `.sourceLogoImg`, all
  `loading="eager"`, all from `user.uploads.dev`, **21 complete / 21 decoded /
  0 broken** inside 3 s. Captured and vision-checked: every row shows a logo,
  none blank.
* `netOwnState()` thresholds as listed above; `NET_ALERT.pics` empties and the
  pill returns to `""`/hidden when the window passes.
* `setBrowseLogo` and the health screen (`#healthList` rows, via `healthPaint`)
  both go through `wireSourceIcons` again.
* Syosetu re-checked after the changes (search, feed, book, chapter) — unaffected.

## Previously — 2.7.47 (2026-09-30)

The app is on **v2.7.47** — **one new source** (**Syosetu**, the app's first and
only **Japanese-language** source; the app now carries **twenty-one**) — and the
Browse source list's **letter headings have been removed**, so it is a plain
alphabetical list again.

> "Remove those Headings at each first letter, it ruins the view. Add syosetu also"

The order stays alphabetical (that part was not the complaint); only the visible
`srcLetter` dividers are gone — see "The letter headings are gone" below.

### Syosetu (小説家になろう) — a real API for the catalogue, the site's own pages for the text

Narou is Japan's largest web-novel site and the origin of most of the novels the
app's other sources carry in translation. It is read two ways, and the split is
deliberate:

* **`https://api.syosetu.com/novelapi/api/`** — the catalogue, and it is a real
  JSON API (no key, no sign-in, CORS-open from the app's page). `order=` picks
  the shelf, `word=` searches, `lim` goes up to 500, `of=` names the output
  fields, and its `genre`/`biggenre` tables are embedded as `SY_GENRES` /
  `SY_BIGGENRES`. `of=` codes are **not** the same as the query-parameter names
  (`ir`/`ibl`/`igl`/`izk`/`its`/`iti` are the content flags, not
  `isr15`/`isbl`/…; `gp` is `global_point`, `a` is `all_point`, `ah` is
  `all_hyoka_cnt`, `ti` is `time`) — the full table is in the API reference at
  `dev.syosetu.com/man/api/`, and getting these wrong fails **silently**: an
  unknown code is simply left out of the answer.
* **`https://ncode.syosetu.com/<ncode>/`** — a novel's own page, which *is* its
  table of contents: `<a … class="p-eplist__subtitle">` rows, 100 to a page
  (`?p=2`, …), the last page named by the pager's `c-pager__item--last` link
  (662 episodes ⇒ `?p=7`). **A 短編 (one-shot) has no episode list at all** — the
  story is that page, so `SY_getBook` synthesises one chapter (`id "0"`) and
  `SY_getChapter` reads the page it is already on. Episodes are
  `/ncode/<n>/`; the text is `<div class="js-novel-text p-novel__text">` with one
  `<p id="L…">` per written line, plus optional `--preface` and `--afterword`
  siblings.

Things worth remembering:

* **`end` is inverted from every other source.** `0` = finished serial *or* a
  one-shot, `1` = still running — so it is read as `Number(r.end) ? "Ongoing" :
  "Completed"`, never as a boolean on the raw value.
* **Narou has no 5-star score, but it does have a genuine 1-5 average.**
  `global_point === fav_novel_cnt * 2 + all_point` held exactly on every novel
  checked, and one rater's verdict is worth 2-10 points (their stars, doubled) —
  so `SY_rating` is `all_point / (2 * all_hyoka_cnt)`, and `votes` is
  `all_hyoka_cnt`. 無職転生 (N9669BK) measures 4.84 ⇒ a card reading 4.8 with
  43,107 votes. This source therefore needs **no** `RATING_ENRICHABLE` entry.
* **There is no cover art.** Narou novels have no cover picture at all, so
  `SRC["Syosetu"].cover` is `() => ""` and cards wear the title's own first
  character on the app's gradient tile — which is what Narou's own readers see.
  Consequently `probeCoverLoad` is skipped and the health line reads "Novels and
  chapters open".
* **The API asks not to be hammered** ("利用制限は現在設けておりません" — no limit
  today, but be a good guest). Every request goes through **`SY_fetch`**, which
  serialises per host with a beat (`SY_HOST_GAP`: 400 ms on `api.syosetu.com`,
  250 ms on `ncode.syosetu.com`). The two hosts are separate budgets, so a
  chapter never queues behind the feed.
* **A route that returns a summary page in front of the JSON is refused**, not
  parsed hopefully: `SY_fetch` is given `require: SY_IS_JSON` (the text must
  start with `[`) and page fetches `require: SY_IS_PAGE` (the page must contain
  `p-novel__`). `SY_json` still trims to the first `[`/last `]`.
* **Search must ask for titles explicitly.** A bare `word=` matches the
  *synopsis*: `?word=無職転生` returned 37 hits that did not include 無職転生.
  `title=1&keyword=1` is what makes it a title search. `authorSearch` uses
  `wname=1`; both order by `favnovelcnt`.
* Chapter titles are kept as the author wrote them ("第一話「勇者召喚に巻き込まれた」")
  and ruby readings are dropped (`<rt>`/`<rp>` removed before tags are stripped),
  so the text reads 向田剛志 rather than 向田剛志(むこうだつよし).
* Long catalogues page in exactly like Wuxiaworld's: the chapter array carries
  `_sy` (`ncode/page/last/total/seen/done/strikes`), `catPager` has a third
  branch, and `SY_catMore` pulls `SY_TOC_STEP` (2) pages per tap with a 400 ms
  beat, capped at `SY_MAX_TOC` (100) — measured: 無職転生 (286 episodes)
  completes its list from 286 in one tap.

Feed jobs are built in `buildDiscoverJobs` as **real API URLs** (so
`discoverJobHost()` still reads a hostname): `order=favnovelcnt`, `weeklypoint`,
`monthlypoint`, `dailypoint`, `hyoka`, `new`, `impressioncnt`, then
`biggenre=2/1/3/4&order=weeklypoint` — 11 jobs × 30 novels.
`HEALTH_URLS.Syosetu` is a one-row listing call.

### The letter headings are gone

`renderSources` still sorts a copy of `SOURCES` with
`localeCompare(…, "en", { sensitivity: "base" })` — the order was fine — but it
no longer emits the `<div class="srcDivider srcLetter">` rows, `syncSourceLetters`
is deleted (along with its call in `applySourceFilter`), and the two
`.srcDivider.srcLetter` CSS rules are gone. `sourceCardHTML` and the `.srcDivider`
used by the AI card are untouched.

The language filter gained a **Japanese** option, and its `"Other"` branch is now
derived from the option list itself (`named` = every non-`""`/non-`"Other"`
value), so a new language can never be left unhandled: "Other" means any source
whose language is not one the list names.

### Touch points used (the 16-item list)

1 `SOURCES` (card: `icon "SY"`, colour `#0b7285`, "Japanese web novels (Narou)",
`lang "Japanese"`) · 2 `SRC["Syosetu"]` (+ `authorSearch`) · 3
`ID_PREFIX_SOURCES.sy`, `COVER_HOST_SOURCES` (`ncode.syosetu.com`, `syosetu.com`),
`SRC_ALIASES` (`syosetu`, `syosetucom`, `narou`, `sy`) · 4 `sourceForURL` +
`sourceBaseURL` · 5 `HEALTH_URLS` · 6 `buildDiscoverJobs` + `feedLabel` +
`fetchBrowsePage` · 8 `openWebnovel` (`/ncode/`) · 13 `decodeText` + `escapeHtml`
on every string · 15 **app interface first** (the novel-api, not scraping) — and
deliberately **not** 7 (`RATING_ENRICHABLE`), 9 (`CATALOGS`), 11 (no bundles
needed) or 14 (`coverURLs`: nothing to proxy, there are no covers).

### Verification (2.7.47)

* `APP_VERSION` "2.7.47", `UPDATES[0]` is 2.7.47 with 6 items, `SOURCES.length`
  **21**, `SRC["Syosetu"]` present, `feedLabel("Syosetu") === "Popular on
  Syosetu"`, `#sourceList .srcLetter` count **0**, `#sourceList .sourceCard` count
  **21**.
* `SRC["Syosetu"].search("無職転生")` → 20 rows in 1.1 s, first `sy-n9669bk`
  "無職転生 - 異世界行ったら本気だす -" / 理不尽な孫の手 / High Fantasy / 4.8 /
  43,107 votes / Completed. `authorSearch("伏瀬")` → 2 rows.
  `fetchBrowsePage(buildDiscoverJobs("Syosetu")[0], "Syosetu")` → 30 rows in
  1.7 s via `superfetch`.
* `getBook("sy-n9669bk")` → 286 total, first 100 episodes loaded, `_sy` state
  `{page:2, last:3, done:false, total:286}`; tags `["R15","Cruelty",
  "Reincarnated"]`. `getChapter("2")` → 199 `<p>`s, `nextId "3"`, `prevId "1"`,
  num 2/286; chapter 1 → `prevId null`. `SY_catMore` then loaded all 286 in 3.5 s
  (`page:4, done:true`).
* `getBook("sy-n2710db")` → 662 episodes, `last:7`, tags
  `["R15","Cruelty","Isekai Transfer"]`; its episode 1 carries the author's
  preface as the first two paragraphs and the ruby-free 向田剛志 in the text.
* `getBook("sy-n3801mu")` (a 短編) → 1 chapter (`id "0"`, named after the novel),
  `_sy.done:true`, and `getChapter("0")` reads 31 paragraphs end to end.
* `probeSourceHealth("Syosetu")` → `ok`, stage `chapter`, 30 novels found, 3.9 s,
  via `superfetch`.
* UI walked: the Syosetu feed renders 30 cards labelled "Popular on Syosetu"
  (Slime, Mushoku Tensei, Tondemo Skill, Kusuriya, Re:Zero, Arifureta …) with real
  stars; a card opens the book screen reading "✓ 286 chapters · Syosetu", rating
  "★★★★★ 4.8 43,107 votes" and genres High Fantasy / R15 / Cruelty /
  Reincarnated; the chapter list offers "Load more chapters · 100/286"; clicking a
  row opens the reader on "Chapter 2: 第一話「もしかして：異世界」" with 199
  paragraphs (vision-checked: clean indented Japanese prose, no leaked tags or
  ruby brackets). The source list and the feed were both captured and
  vision-checked.
* Language filter: `Japanese` → Syosetu alone; `English` → 20; `Other` → none
  (every source is a named language); `sy` → Syosetu alone; `zzz` → nothing.

## Previously — 2.7.46 (2026-09-30)

The app is on **v2.7.46** — **one new source** (**Wattpad**; the app now carries
**twenty**), and the Browse source list is **alphabetical, under a letter
heading each time the first letter changes**.

> "Add watppad, and also can you categorize the sources make it based on name.
> Like ABC alphabet."

### Wattpad — the site's own interface, and the first source read from it end to end

Wattpad was chosen from the source-recommendation shortlist because its whole
catalogue is reachable through the interface its own website and its own Android
app call — no key, no sign-in, and every route answers a plain cross-origin
request (measured from the app's own page: `www.wattpad.com/api/v3/stories`,
`www.wattpad.com/apiv2/storytext` and `img.wattpad.com` all pass a CORS-mode
fetch, while `ranobes.net` in the same probe is refused). That is what makes it
work in the packaged app's `file://` page as readily as on the web, with no bridge
and no proxy in the path for the ordinary case.

The three routes it uses, and the things about them worth remembering:

* **`/api/v3/stories`** — the catalogue. `filter=hot` is its site-wide hot list,
  `filter=new` its newest (spam-heavy, so the feed does not use it), `query=` its
  search, `category=<id>&filter=hot` one shelf's hot list, and `limit`/`offset`
  its paging. `filter` accepts `hot`/`new` only — `popular` and `random` answer
  `error_code 1005 InvalidValue`.
* **`fields` describes the whole answer, and a top-level list must name `stories`
  itself.** `?fields=id,title` is answered with a `nextUrl` and **no stories at
  all** — a body that looks exactly like an empty catalogue and is not one.
  `?fields=stories(id,title,…)` is the correct form. This cost several probes and
  is the single most important thing to know about this API.
* **`/api/v3/stories/<id>`** — one story, with **every one of its parts riding
  along**: `fields=…,parts(id,title)` returned all **106** parts of a 106-part
  story (4 KB), so a novel's whole chapter list arrives in one request with
  nothing to page in later. (`/stories/<id>/parts` does not exist — 404.)
* **`/apiv2/storytext?id=<part>`** — one part's text as `<p data-p-id="…">`
  paragraphs, into the app's usual extraction (markup dropped, `decodeText` then
  `escapeHtml`), like every other source's text.
* **A cover can be built from the id alone**: the catalogue hands out
  `img.wattpad.com/cover/<id>-256-<hash>.jpg`, and `…/cover/<id>-256` (no hash)
  answers the same picture — verified by fetching both. That is
  `SRC["Wattpad"].cover`, so a row that carried no cover still gets one.
* **Its `rating` field is a content flag, not a score** (1/2/3), so the source is
  deliberately **not** in `RATING_ENRICHABLE` and its cards show no stars. The
  number Wattpad's own readers go by is `voteCount`, which is what the cards carry
  as `votes`. `mature=true` was tried on both the browse and the search routes and
  changed nothing that came back (20/20 results `mature:false` for `smut`,
  `mature` and `bdsm`), so Wattpad's default answer is what the app uses.
* **`/api/v3/categories`** is the id→name table; it is embedded as `WP_CATS`, so a
  story's `categories:[4,0]` becomes its genre ("Romance") with no second request.
  `WP_chName` peels a leading `Chapter 12` off a part title where the author wrote
  one — Wattpad parts are as often a bare word ("glass", "mate").

Feed jobs are `wpf:hot:<page>` and `wpf:cat:<category>:<page>` (see
`buildDiscoverJobs` / `fetchBrowsePage`); `HEALTH_URLS.Wattpad` is a one-story
listing call. Nothing else was needed: no `CATALOGS` entry (its search is a GET),
no `authorSearch` (Wattpad has no user-search route — `/api/v3/search/users` is a
404, so the app falls back to a title search) and no rating enrichment.

### The source list is alphabetical, under letter headings

`renderSources` now sorts a **copy** of `SOURCES` with
`localeCompare(…, "en", { sensitivity: "base" })` and emits a
`<div class="srcDivider srcLetter" data-letter="…">` whenever the first letter
changes. The sort deliberately lives in the renderer and not in `SOURCES` itself:
that array is also what the health sweep, the discover feed and the migrate sheet
walk, and none of them has any business caring whose name sorts first.

`syncSourceLetters()` (called at the end of `applySourceFilter`) hides any letter
heading whose cards have all been filtered away — by the filter box, the language
filter or "hide unavailable sources" — so the list never shows a `W` standing over
empty space. The AI card is skipped by that walk (`n.dataset.ai === "1"`), because
it is not a source and sits below its own "Not a reading source" divider.

### Touch points used (the 16-item list)

1 `SOURCES` (card: `icon "WP"`, colour `#ff500a`, "Original stories & fanfiction")
· 2 `SRC["Wattpad"]` · 3 `ID_PREFIX_SOURCES.wp`, `COVER_HOST_SOURCES`
(`img.wattpad.com`, `wattpad.com`), `SRC_ALIASES` (`wattpad`, `wattpadcom`, `wp`)
· 4 `sourceForURL` + `sourceBaseURL` · 5 `HEALTH_URLS` · 6 `buildDiscoverJobs` +
`feedLabel` + `fetchBrowsePage` · 8 `openWebnovel` (`/story/<id>`) · 13
`decodeText` on every string · 14 `coverURLs` (`img.wattpad.com` → the direct URL,
then `images.weserv.nl`) — and deliberately **not** 7 (`RATING_ENRICHABLE`), 9
(`CATALOGS`) or 10 (no header and no special transport are needed).

### Verification (2.7.46)

* `APP_VERSION` "2.7.46", `UPDATES[0]` is 2.7.46 with 4 items, `SOURCES.length`
  **20**, `SRC["Wattpad"]` present, `buildDiscoverJobs("Wattpad")[0] === "wpf:hot:1"`,
  `feedLabel("Wattpad") === "Popular on Wattpad"`.
* `SRC["Wattpad"].search("werewolf")` → 24 rows with cover, author, genre
  ("Werewolf"), votes and status. `fetchBrowsePage("wpf:hot:1", "Wattpad")` → 20
  rows; `wpf:cat:22:1` → 13.
* `SRC["Wattpad"].getBook("wp-12702726")` → "Werewolf Committee", author "E",
  genre Werewolf, Completed, 44 chapters (all 44 parts), no `listNote`.
  `getChapter` on part 2 → "Prologue", 7,474 chars of HTML in 30+ `<p>`s, correct
  `nextId`/`prevId`, `locked:false`.
* `probeSourceHealth("Wattpad")` → `ok`, stage `chapter`, 20 novels found,
  `coverOk:true`, 2.1 s, via `superfetch`; `healthLine` reads "Novels, chapters
  and covers open". After a plain reload the Browse card reaches "Connected ·
  Original stories & fanfiction" from the background sweep.
* UI walked by hand: the Wattpad feed renders 33 cards with the right labels; a
  card opens a 132-chapter book ("132 chapters", cover cached — the base64 in the
  cover cache proves `img.wattpad.com` drew to a canvas, i.e. it sent ACAO); the
  reader shows real prose (vision-checked). The book screen carried no alignment
  note, as it should — Wattpad's list is a clean 1..N run.
* Alphabet, with the letter list both read from the DOM and captured and
  vision-checked: headings `D F G L N R S W`, and the order inside each group is
  right (`Wattpad, Webnovel, WTR Lab, Wuxiaworld` under `W`; `NovGo` after the
  `Novel*` names, which is correct — `novel…` < `novgo`). Filter box `"nov"`
  leaves F/G/N/W (FreeWebNovel, GoodNovel, the eight Novel*/NovGo rows and
  Webnovel — 11 cards); `"zzz"` leaves no cards **and no headings**; `"watt"`
  leaves `W` and the Wattpad card alone; the language filter "Other" leaves
  nothing and no headings.

## Previously — 2.7.45 (2026-09-30)

The app is on **v2.7.45** — **no new sources** (still **nineteen**). This one is
about the data the app shows being *right*: covers that were missing, pictures
that were never loaded, and chapter lists whose numbers skipped.

> "All Sources pass the health check, but novel hall sources, it's feed some covers
> doesn't have covers, fix it. And make the feed check if images are appearing
> properly, chapters are align like no skipping. Like example. Some novels on the
> chapter list doesn't have chapter 1, straight to chapter two, or entirely goes
> to like hundred chapters and ect"

### Why Novel Hall's covers were missing (source-level)

Novel Hall has **two listing shapes and only one of them has pictures**.
Measured 2026-09-25: `/home.html` and a genre page carry `.book-img` cards (8 a
page) *with* covers; `/ranking.html`, `/trending.html`, `/completed.html`,
`/all2022.html` and `?s=so&module=book&keyword=…` are `<tr>` tables and contain
exactly **one** `<img>` between them — the site's own logo. So roughly half of a
Novel Hall feed was rendered from rows with no cover to show.

There is no bulk cover index to steal from either: `/all2022.html` is a page of
plain links (no pictures), and the site's `c=api` interface answers only `hits`
and `search`. The cover exists on the novel's own page, so **`NLH_coverFor`**
reads it from there:

* `NLH_META` (localStorage `yuedu_nlh_meta_v1`) caches `{c: cover, s: slug,
  a: author, g: genre}` per novel — one request per novel, ever. The slug is part
  of it, which also removes the title-search `NLH_path` used to need when a book
  was opened from a card.
* Only the head of the page is parsed (`.slice(0, 64000)`): the detail block sits
  above the chapter list — `#morelist` starts at byte **18,764** of Martial
  Master's **1.05 MB** page — and a *chapter* page carries no cover at all
  (measured: 34,554 bytes, logo only). Failures are remembered in
  `NLH_COVER_MISS` for ten minutes so a dead novel is not re-fetched every time.
* `COVER_FETCHERS` in the cover machinery is the registry (`{NovelHall:
  NLH_coverFor}`), so another table-listing source is one entry.

### The cover machinery itself (read this before touching covers)

Three separate faults were found here, and all three are fixed:

1. **The fallback route was dead for NovelHall.** `coverURLs` gave Novel Hall a
   `images.weserv.nl` second route; weserv answers **404** for every
   novelhall.com picture ("The requested URL returned error: 403" — the *site*
   refuses weserv). It is now `npcProxy(url)`, the app's own fetch proxy, which
   returns the same cover at full size (measured 450×600 through it, and a vision
   check of the pixels confirms it is the real cover art). Ranobes still uses
   weserv, which works there (400×513).
2. **A card's picture was patched in the wrong place.** `patchCoverCard` used to
   look for `img[data-cover]` — but the very cards it exists to fix are the ones
   whose `img` has already been processed and hidden (an empty cover makes
   `loadCoverImg` take the attribute away and hide the element), so nothing was
   ever swapped in. It now takes the card's `img`, whatever state it is in.
3. **A cover only ever loaded if the observer said so.** `loadCovers` handed every
   picture to an IntersectionObserver, and in some frames that observer goes
   quiet while the page is otherwise fine — **measured in the editor's own
   preview: two of the forty pictures a feed had put on screen were ever
   reported**, so 38 covers sat blank in plain sight. `coverFallbackScan` now
   loads any picture inside the viewport band (±700px) on scroll, on resize and on
   a 2.5 s beat, whether or not the observer has said anything. It only touches
   `img[data-cover]`, which `loadCoverImg` consumes, so the two paths can never
   load the same picture twice. `coverFallbackWire` installs the listeners once.

`fillGridCovers`/`requestCardCover` are therefore driven by *looking*, not by
loading: a bare card asks for its cover when it reaches the screen, the library
and `NLH_META` are consulted first (no request at all for a novel already known),
and `COVER_FILL_CAP` (20 per source per session) bounds a first visit. Covers are
kept for good, so the cap only ever bites on a fresh install.

### Chapter lists that skip (source-agnostic)

Measured across sources: Novel Hall's *Martial Master* lists **5,569 chapters
numbered 1–5,589** (20 numbers the site no longer carries), *The Romance Of Mr.
Walton* 1,146 numbered 1–1,152, and a list can begin at its own chapter 2 (or
100) rather than at 1. Ranobes legitimately starts at **chapter 0**. Meanwhile
FreeWebNovel/NovGo/NovelFull arrive as `[1..40, 3189..3194]` for a moment — that
is a *partial* list their own loader is still filling, not a skip.

So the audit is: `chapterAudit(chapters)` → `{count, first, last, dupes,
nonMono, gaps, clean}`, `alignChapterNums(chapters)` → renumber to reading order
**only when the numbering is not a clean run** (`first > 1`, or a gap, a repeat or
a non-monotonic step), returning the sentence to put on the book, and
`syncListNotes(book)` → called from `renderBookScreen`, so the note is recomputed
from the list the device actually holds on every draw (nothing can sit there a
version behind). Rows read `Chapter 1 … N`, the book screen's note explains what
the source's own numbering was, and nothing else moves:

* `chapterListSettled(list)` gates it — a list with an unfinished `_ww`/`_rb`
  pager, or one in `catalogLoads` (WP_loadAjax / NF_loadCatalog / WP_loadRest),
  is never renumbered under a loader that is still appending.
* Reading position is by **chapter id** already; the two places that display a
  stored number now resolve it through `histChapterNum(book, hist)` (book screen's
  *Continue · Ch. N* and the history list), so an aligned list cannot leave a
  stale number on screen. `chapterItemHTML`'s "reading" highlight compares ids too.
* A clean run is left exactly as it is — `first <= 1 && !dupes && !nonMono &&
  !gaps` — which keeps chapter 0 lists (Ranobes) and every ordinary source
  untouched, and makes the pass idempotent (after aligning, the array is clean, so
  a second pass says nothing).

Novel Hall's own label parsing was fixed alongside it: some novels number the
**volume** in front of the chapter (`1 Chapter 12: Name`) and others write a bare
`12 Name` with no full stop — both are read now (`NLH_chNum`/`NLH_chName`), with
the bare number accepted only when it carries the sequence on (`n === prev + 1`),
so a title that opens with a number ("7 Days to Live") is never mistaken for one.

### Source health now checks pictures

`probeSourceHealth` gained a cover stage between the novel and the chapter:
`probeCoverLoad(url)` loads the cover the novel's own record names through the
same routes the feed uses, and the verdict travels with the report
(`res.coverOk`). `healthLine` reads "Novels, chapters and covers open" when it
passed, and "Novels and chapters open · its cover pictures would not load" (amber,
not red) when it did not — a source whose text is fine but whose pictures are
gone is no longer a silent pass.

### Verification (2.7.45)

* Novel Hall feed: 114 cards; covers filled progressively while scrolling
  (`url` 8 → 34, `loaded` 0 → 19, `broken` 0), 63 novels in `NLH_META`, no misses;
  a proxied cover was read back pixel-for-pixel and matches the book (vision).
* Novel Hall book: `nlh-16537` (Martial Master) — 5,569 chapters numbered 1…5569
  after alignment, note reads "This source's own numbering for these chapters runs
  1–5589 and skips 20 chapter numbers outright …", head says "5569 chapters";
  `nlh-6851` ("I am wet Daddy!!") opens 41 chapters, clean, no note, hero cover
  loads at 300px, names no longer repeat the number ("Chapter 1 – Cumm for me baby
  girl part 1"); `nlh-45354` really is an empty stub on the site (26 KB page, no
  chapter links), so 0 chapters there is correct.
* FreeWebNovel/NovelFire: `chapterListSettled` false while their loaders are
  filling (FreeWebNovel 46 → 3,184 chapters in 45 s), so nothing is renumbered
  mid-fill; NovelFire's list is clean and gets no note.
* Health: NovelHall / Ranobes / NovelFire / Scribble Hub all `{ok: true,
  stage: "chapter", coverOk: true}`; a deliberately dead cover URL returns `false`
  in 1.7 s and the row renders amber with the right wording.
* No console errors, no perchance errors, no syntax errors.

## Previously — 2.7.44 (2026-09-30)

The app is on **v2.7.44** — **two new sources: Novel Hall and Ranobes** (the app
now carries **nineteen**).

> "Novel Hall and Ranobes.net"

Both are scraped sources, which is the fallback rather than the preference: item
15 of "Adding a source — the touch points" says to read a site through the
interface its own app uses when one exists, and **neither of these has one**.
Novel Hall's `/index.php?c=api&m=…` answers exactly two methods, `hits` (a JSONP
view counter) and `search` (an HTML page) — everything else 404s; Ranobes has no
reader API at all, and its own chapter-search endpoint (below) is capped at 50
rows and takes no offset. So both are read from their own pages, which are small
and complete enough for the ordinary hedged routes.

### How Novel Hall is read (`novelhall.com`)

A home-grown CMS. All routes are plain headerless GETs, and HTML is the only
representation:

| what | route | notes |
| --- | --- | --- |
| search | `GET /index.php?s=so&module=book&keyword=<kw>[&page=N]` | 10 `<tr>` rows a page; rows carry cover, genre, author, the latest chapter and the synopsis |
| novel | `GET /<slug>-<id>/` | detail **plus the whole chapter list**, server-rendered into `#morelist` ("All Section Catalog"), oldest first |
| chapter | `GET /<slug>-<id>/<chapid>.html` | `<div class="entry-content" id="htmlContent">` (plain text with `<br>`); `<nav class="nav-single">` names both neighbours |
| front page | `GET /home.html` | `.book-img`/`.book-info` cards, 28 novels |
| rankings | `GET /ranking.html`, `/trending.html` | `<tr>` rows, 20 a page |
| genre | `GET /genre/<name><id>/` | `fantasy20223`, `romance20223` are pinned in the feed jobs |

Probed and dismissed: `book`, `novel`, `info`, `detail`, `chapter`, `content`,
`catalog`, `chapters`, `bookinfo`, `chapterlist`, `read`, `getchapter` all 404 on
`c=api`. There is no app interface to look for either.

**The one real quirk: a novel answers on several addresses.** The numeric id in
the URL *is* the novel, and the slug in front of it is decoration — all of
`/my-werewolf-system-23563/`, `/My-Werewolf-System-23563/` and
`/my-werewolf-system-novel-23563/` are live and identical. So `NLH_PATHS[bookId]`
remembers the exact spelling the site gave the book, `book.slug` carries it, and
`NLH_path(bookId, book)` falls back to a keyword search for the title when the
book is opened from the library with nothing remembered. Each chapter keeps the
`href` the site itself wrote, so the spelling can never drift mid-novel.

Two listing shapes, both read by `NLH_parseAny(html)` = `NLH_parseCards` (the
`.book-img`/`.book-info` cards: home page, genre "Popular Recommendation") then
`NLH_parseRows` (the `<tr>` tables: search results, "Latest Release", rankings).
A row's title is the first cell whose link addresses a novel, because a search
row's first cell is the *genre* link.

`www.novelhall.com` sends **no ACAO** (measured), so it is in `coverURLs`
(direct + `images.weserv.nl`) and in the `loadCoverImg` `crossOrigin` exception
list; covers load at 300×400.

Cosmetic note, left alone because it is the site's own stored text: some
chapters begin with the title glued to the first sentence ("Chapter 1: Chapter 1
Awakening Adrian crawled…").

### How Ranobes is read (`ranobes.net`)

A DataLife Engine site — Chinese web novels in translation, Japanese and Korean
ones, and a shelf of originals.

| what | route | notes |
| --- | --- | --- |
| search | `GET /search/<kw>/page/<n>` | 10 `.short-cont` rows a page, paginated |
| novel | `GET /novels/<id>-<slug>.html` | detail plus the **last 25** chapters |
| catalogue | `GET /chapters/<id>/`, `/chapters/<id>/page/<n>/` | 25 rows a page, **newest first**; a page number past the end is **clamped to the last page** |
| chapter | `GET /<rest>-<novelid>/<chapid>.html` | `<div class="text" id="arrticle">`; `id="prev"` is older, `id="next"` is newer |
| front page | `GET /novels/`, `/novels/page/<n>/` | `.short-cont` cards |
| rankings | `GET /ranking/`, `/ranking/bookmarks/` | `article.rank-story` |
| genre | `GET /tags/genre/<Genre>/` | `Action`, `Fantasy` are pinned in the feed jobs |

**It turns a plain request away: a headerless GET of `/` or of any novel page is
a 16-byte 401 "Bad Bot Detected"** (fetch_url and superFetch both refuse it). The
app's own `sf()` answers the real pages through r.jina.ai and the proxies, so
`sf()` is the route here, and in the packaged build the app's connection is a
browser request, which the site accepts — measured: three parallel requests, all
200, in 3.9 s.

**Pagination is the mirror of Wuxiaworld's, and it is why `catPager` exists.**
Pages run newest-first and a too-large page number clamps to the last one, so
`RB_getBook` asks for the novel page and `/chapters/<id>/page/999999/` **in
parallel**, lists the **oldest** chapters first (reversed — that is where a
reader starts) and stores `chapters._rb = {id, slug, page: pages_count - 1,
last: 1, total, strikes, seen: Set, done}`. `RB_catMore` then walks *backwards*
through the pages (RB_TOC_STEP = 4 pages a tap, 600 ms beat), **appending** newer
chapters in reading order. The load-more machinery used to be hardcoded to
Wuxiaworld (`_ww` / `WW_catMore`); 2.7.44 generalised it to `catPager(chapters)`,
which returns `{w, more}` for `_ww` **or** `_rb`, and `renderChapterMore` /
`appendMoreChapters` now go through it. **Any further paged source goes in
`catPager`, not in a third copy.**

Row data lives in the page's own `window.__DATA__` JSON blob (`RB_json`), which
carries `chapters[]` (newest-first), `count_all`, `pages_count`, `cstart`,
`limit`, `book_title`, `book_link` — so the totals come from the site, not from
counting what we happen to have. The site's chapter search
(`POST /engine/mods/reader/ajax.php`) answers **at most 50 rows and takes no
offset** (probed `page/cstart/start/offset/from/p/limit` — all ignored), so it
cannot read a list; 25-row pages are the only way, and the app asks for them
only when the reader asks.

Two number/name helpers, both because Ranobes' list contains rows a reader still
wants openable: `RB_chNum` prefers `/\bchapter\s*(\d+)/`, else the first number,
and keeps names monotonic (`> prev` else `prev + 1`, with `prev` starting at
**-1** so "Chapter 0" keeps its 0); `RB_chName` strips everything up to
"Chapter N" and returns "" unless the remainder has a letter or digit. The
chapter page's `<span hidden> | </span>` is stripped so names like "|" cannot
leak.

The score is written two ways: `/novels/` prints `<strong>4.1</strong>`, the
search page prints the star meter instead (`class="current-rating"
style="width:84%"` = score × 20). Votes come from `id="vote-num-id-<id>"`.
`ranobes.net` sends **no ACAO** (measured), so it is in `coverURLs` and the
`loadCoverImg` `crossOrigin` exception list; covers load at 225×300.

### Verification (2.7.44)

Both sources were walked end to end in the live preview on the phone viewport
(390×844), on the web build and on the packaged build (simulated by deleting
`root.superFetch`, then restoring it):

* Novel Hall — search "werewolf" → 10 rows (genre/author/latest chapter parsed);
  `getBook("nlh-43497")` → 102 chapters, ch1 "Awakening" num 1 … ch102 num 112
  "Back From The Market", detail = title/author "Masheen"/Fantasy/cover/ongoing;
  `getChapter` ch1 = 47 paras / 5853 chars with both neighbours named, ch7 = 6009
  chars; `home.html` → 28 books, `ranking.html` → 20 rows with status;
  `sfHealth` ok; `probeSourceHealth("NovelHall")` → `{ok, stage:"chapter",
  found:28, via:"superfetch"}`; packaged build search 10 / book 102 / chapter
  5853; feed "Popular on NovelHall" 55 cards; reader rendered 14,444 chars.
* Ranobes — search "shadow" → 10 rows with covers, 4.2 / 1274 votes, genre,
  tags, synopsis; `getBook("rb-1205249")` **with no `book` argument**, to
  exercise the slug fallback → "Shadow Slave"/Guiltythree, 20 chapters, total
  3195, ch0 num 0 name "", ch1 "Nightmare Begins", `_rb.page` 127; `getChapter`
  ch1 = 90 paras / 11011 chars, next/prev correct; ch0 next `rb-1806169`, prev
  null; **ch3194 (`rb-3277609`), the last chapter, opened through the derived
  href** = 89 paras / 9210 chars, next null, prev `rb-3276735`; one "Load more
  chapters" tap grew 20 → 120 chapters (page 127 → 123, numbers monotonic and
  contiguous, 4 `onGrow` calls); `/novels/` → 10 (4.1 / 34), `/ranking/` → 20
  with covers; `sfHealth` ok; `probeSourceHealth("Ranobes")` → `{ok,
  stage:"chapter", found:10, via:"jina"}`; packaged build search 10 / book 22 of
  2647 / chapter 8017 chars; feed "Popular on Ranobes" 31 cards; the book screen
  showed "✓ 418 chapters · Ranobes", ★4.1 / 34 votes, Ongoing and five genre
  pills, and "Load more chapters · 18/418" growing to 118/418.
* Layout: the Ranobes book hero was measured at 390 px — title t80, author t131,
  meta t153, rating t176, status row t200, genre pills t232/t258 (two rows),
  all left 142 / width 233, and a full pairwise `getBoundingClientRect` overlap
  scan over every leaf with text in `.bookHero` reported **zero overlaps**
  (the snapshot is low-resolution enough that `vision` reports the blurred
  background art as "overlapping text" — trust the rects).
* No console errors, no perchance errors, no syntax errors.

### Not the usual touch points

* `catPager` — see above; the load-more path is no longer Wuxiaworld-only.
* `refreshUpdates` now calls `src.getBook(b.bookId, b)` (it passed only the id
  before). Ranobes needs the book object to know its slug, so the feed's
  "new chapters" check would otherwise have failed on every Ranobes novel.
* `NLH_*` and `RB_*` are the prefixes: NovelHi already owns `NH_*`, which is why
  Novel Hall's helpers are `NLH_*` (a first attempt at `NH_*`/plain `NLH_` gave
  duplicate-declaration SyntaxErrors).

## Previously — 2.7.43 (2026-09-30)

The app is on **v2.7.43** — **one new source: Dreame** (the app now carries
**seventeen**).

> "Add the sources dreamezand snovel"

`dreamez` is Dreame: `dreamez.com` is a parked "domain for sale" page, and the
real site is `dreame.com`. The second name was **not** built — `snovel.com` is a
parked lander, `snovel.net` answers 404 to every path, no app store has a reader
under that name (searched Play, the iTunes API and APKPure; the only exact hit is
an unrelated Indian audio-stories app), and Brave autocorrects "snovel" to
"novel" — i.e. it is a typo for something. See "The unresolved second name"
below.

### How Dreame is read

`dreame.com` is a Next.js shell; every piece of data behind it comes from
**`wap-api.dreame.com`**. The routes and their parameters were read out of the
site's own bundles — **module 91568 of `pages/_app-…js`** is where the client
defines its API hosts (`o5` → `wap-api.dreame.com`, `H` → `api.dreame.com`, and
`GR.H5 === "wap"` / `GR.PC === "web"` for the `port` parameter), and each route's
call site sits in the same bundle with the exact parameter object it sends.

All routes are plain **headerless GETs** — no key, no account, no signature, and
no `Token`/`requestId`/`platform` header (the client sends those; the routes
answer without them). Measured live 2026-09-24:

| what | route | notes |
| --- | --- | --- |
| search | `GET /search/getsearch?kw=<words>&pn=<page>` | 10 rows a page; rows carry cover, author, category, tags and the **synopsis**; 8504 matches for "werewolf", and it offers **five** pages whatever the total |
| novel | `GET /novel/detail?nid=<id>` | `data.novel` — title, `author_name`, `descr`, `cover_url`, `chapter_num`, `word_count`, `category_name`, `tag[{tag_name}]`, `status` |
| chapter list | `GET /novel/getcatelog?nid=<id>` | `data.pager.chap_list[]` — **the whole list in one answer**, oldest first, each row `{title, id, encode_id, size, is_free, vip}`; `data.book` carries the same novel record plus `status_text` |
| chapter text | `GET /novel/getChapter?bid=<id>&cid=<chapterId>&filter=1&port=wap` | `content` is **base64 of UTF-8 bytes** (not the site's usual entities); `nearby{pre,next}` names the neighbours; `word_count` is the declared size |
| front page | `GET /discover/channelV1` | `data.list[]` — seven shelves (`name`, `descr`) of ten novels each, books under `list[]` with `{id, name, imageUrl, authorName, tags:[{ID,Name}], descr, status}`. Also `subChannels[Hot, Fantasy, New, Free]`, `rankData`, `banner` |
| editor's picks | `GET /index/indexBookList` | `data.list[]` — 14 novels in the shelf spelling (`bid`, `cover_url`, `author_name`, `category_name`) |

Note the two spellings of the same row: the search answers with
`coverUrl`/`authorName`/`categoryName`, the shelves with
`cover_url`/`author_name`/`category_name`, and the discover shelves with a third
(`imageUrl`, capitalised tag objects). `DR_bookFrom` reads all three.

### The things specific to this source

* **It is a shop, and it answers with a teaser instead of refusing.** A chapter
  Dreame sells comes back from the *same* route with real text — but only the
  opening of it, and **nothing in the answer says so**. Measured on
  `dr-2647351552`: free chapter 1 = 5815 bytes / 1094 declared words; paid
  chapter 8 = **807 bytes / 944 declared words**, ending mid-sentence
  ("I'm waiting all thre"). So the tell is the length: a real chapter costs
  ~5.1–5.3 bytes per declared word, a teaser 0.85. Under **two bytes per word**
  is a teaser, and it is returned as `notice: "preview"` — the same treatment
  Wuxiaworld's truncated chapters and GoodNovel's paid ones get. The chapter
  stays in the list and opens; dropping it would leave a 438-chapter novel
  showing seven.
* **Two shapes of chapter text**, as GoodNovel has: the paid teasers come wrapped
  in a single `<p>`, the free chapters as plain text with a blank line between
  paragraphs. `DR_chapterHTML` does not trust the markup either way — block tags
  become paragraph breaks, the rest is escaped, and soft line breaks inside a
  paragraph are folded back into spaces, so neither shape can leak markup into
  the reader and neither reads as one wrapped line per paragraph.
* **Headings the site writes without a number.** A novel can open on a
  "Prologue" and close on an "Epilogue" (measured on `dr-1287479040`), and its
  numbered rows are written "CH 1". As with GoodNovel, a heading's number is only
  believed when it moves the count forward; anything else is the next chapter in
  the list. The 155-chapter novel therefore numbers Prologue→1 … Epilogue→155,
  monotonic and complete.
* **The status number means the opposite of what `normStatus` assumes.**
  Dreame writes `status: 1` for a **finished** novel and `0` for a serial still
  updating (verified against the site's own words: "be over" on a finished
  155-chapter novel, "In the serial" on a 438-chapter one that was updated the
  same day) — and `normStatus` reads the string `"1"` as *ongoing*.
  `DR_status` therefore maps the number itself and only defers to the site's own
  wording when `normStatus` understands it.

### Touch points that were not the usual ones

* **Covers send no ACAO** (measured: a CORS-mode fetch of both
  `assets.dreame.com` and `files.dreame.com` covers fails from our page), so
  Dreame is in **both** lists: `coverURLs` (direct URL, then
  `images.weserv.nl`) and the `crossOrigin` exception chain in `loadCoverImg`.
  Verified by loading the real URLs (`naturalWidth` 512 and 1043) and by the
  card/hero covers rendering in the UI.
* **`novel_url` from the API is a dead end** (`/novel/<slug>.html` answers "Page
  Not Found"), but **`/story/<id>` resolves on the bare numeric id** (measured on
  two novels, no slug needed), so that is what "Open site" uses.
* **The search has a floor of five pages** whatever the total, so the feed's
  search jobs use different keywords rather than deeper pages for breadth.
* `HEALTH_URLS.Dreame` is the search route itself (a small JSON answer, no
  header), which is what `sfHealth` probes.

### Verification (all measured in the live preview, 2026-09-24)

* `SRC["Dreame"].search("werewolf")` → 10 books with covers, genres, tags,
  synopsis and status; `authorSearch` uses the same route.
* `buildDiscoverJobs("Dreame")` → 11 jobs; `fetchBrowsePage` on the shelf job
  → 10, on `drapp:pick:1` → 14, on a search job → 10; the Browse feed shows
  **70 cards** under the label "Popular on Dreame".
* `SRC["Dreame"].getBook("dr-2647351552")` → full detail + **438 chapters from
  one request**; `getBook("dr-1287479040")` → 155 chapters, Prologue→1,
  Epilogue→155, status `completed`.
* `getChapter` on a free chapter → 52 paragraphs / 6069 chars of HTML, no
  notice; on the paid chapter 8 → `notice: "preview"`, 12 paragraphs / 862
  chars.
* `sfHealth(healthURL("Dreame"))` → `ok`; `probeSourceHealth("Dreame")` →
  `{ok:true, kind:"ok", stage:"chapter", ms:2006, found:10, via:"superfetch"}` —
  the whole front-page → novel → chapter sweep passes in 2s.
* **The packaged build works**: with `root.superFetch` deleted (which is what
  `packagedBuild()` tests for), search, `getBook` and `getChapter` all came back
  through the fetch-plugin proxy — search 10 rows, the 155-chapter novel, a
  39-paragraph chapter.
* In the UI: the Dreame card (17 cards now), the feed, the book screen at 390px
  (title wrapping over two lines, "Ongoing" / "STEAMY STORIES" / "ADVENTURE"
  pills, "Continue · Ch. 1", no clipping — `docScrollWidth === innerWidth`,
  zero element overlaps by `getBoundingClientRect`), and the reader showing the
  chapter as clean paragraphs with no markup.
* `localStorage` was snapshotted before opening a chapter in the reader and
  restored afterwards (only `pocketnovel_history` and
  `yuedu_chapcache_v2` had changed).

### The unresolved second name

"Add the sources dreamez and snovel" — `dreamez` was Dreame and is done. For
`snovel` every avenue was tried and nothing matched: `snovel.com` is a parked
lander, `snovel.net` (and `www.`) answers 404 to `/`, `/home`, `/en/`, `/api/`
and `/novels`, sixteen other TLDs do not resolve, Play/APKPure/iTunes have no
reader by that name, and the search engines either block the request or
autocorrect the word away. The nearest real things found were **`csnovels.com`**
(a webnovel site, whose Play app is the top fuzzy hit for "snovel" because it
contains the substring) and **SheNovel** (a romance reader on Play). It is named
in this file so the next agent does not have to repeat the search — the user was
asked which they meant rather than having a guess built.

## Previously — 2.7.42 (2026-09-30)

The app is on **v2.7.42** — **a layout fix for the packaged app** (no source
changes).

> "Fix, the intro not properly spaced. It's going right"

Reported from the APK (`com.example.yuedu.MainActivity`, phone screenshot):
the welcome screen's introduction ran off the right edge — every line lost its
last few characters ("Webno" for "Webnovel") — and the right side of the
Continue button was off-screen.

### The cause

`index.html` was relying on styling that **the Perchance output iframe injects**
and that the standalone/APK build does not have. The engine wraps the page in a
small global reset:

```css
html { margin: 0; padding: 0; width: 100%; height: 100%; box-sizing: border-box; }
*, ::before, ::after { box-sizing: inherit; }
body { margin: 0; padding: 0; text-align: center; }
[hidden] { display: none !important; }
```

`index.html` declared none of it — nothing in the file sets a global
`box-sizing` — because in the preview the engine always had. So in the packaged
build `box-sizing` fell back to `content-box`, and every rule shaped
`width: 100%` + horizontal padding laid its element out wider than its parent.
`.introBody { width: 100%; padding: 26px 32px }` therefore ran **64 px past the
right edge** of a 600 px viewport, clipped by `#introScreen { overflow: hidden }`.

### The fix

The engine's baseline is now declared in `index.html` itself, in the early
`<style>` block (the one that also sets the black background), so the packaged
build carries what the preview used to supply: the `border-box` reset,
`[hidden] { display: none !important }`, and `button, input, optgroup, select,
textarea { font: inherit; margin: 0 }`, plus `html { -webkit-text-size-adjust:
100% }` for mobile WebViews.

This is deliberately **the whole baseline, not just `box-sizing`** — the other
rules in that reset were the same kind of latent APK-only bug (anything using
the `hidden` attribute together with an author `display` rule, or a `<button>`
that relies on inherited type size). The app's own stylesheet comes later in the
document, so in the preview every one of these is overridden exactly as it was
before and the web build is unchanged; the only build whose layout moves is the
APK, and it moves onto the preview's.

### Verification

Measured in the live preview at a **600 px** viewport (the standalone's
`<meta name="viewport" content="width=600 …">` layout width, i.e. the width the
APK lays out at). The APK's condition was reproduced by deleting the engine's
reset rules from the document via CSSOM — they are same-origin and writable —
then measuring:

| condition | `.introBody` | intro text | Continue button |
| --- | --- | --- | --- |
| engine reset present (the preview) | 0→600 | 32→568 | 32→568 |
| engine reset **deleted** — APK **before** | 0→**664** | 32→**632** | 32→**660** |
| engine reset **deleted** — APK **after** | 0→600 | 32→568 | 32→568 |

After the fix the two conditions are **identical**, so the preview and the
packaged app now lay the app out the same way. `.introBody` was then captured
and eyeballed: the text wraps inside the block with margins on both sides,
"Webnovel, Royal Road and NovelArrow" is complete, nothing is clipped, and the
paragraph has clear space above and below it.

## Previously — 2.7.41 (2026-09-30)

The app is on **v2.7.41** — **one new source: GoodNovel** (the app now carries
sixteen).

> "Add goodnovel"

GoodNovel (`goodnovel.com`) is the first source in a while that needed **no
credentials and no scraping at all**: the site's own H5 client posts JSON at
`/hwyc/…` on the site's own host, and those routes answer a stranger. Everything
below was measured live on 2026-09-30.

### The routes it uses (all live-checked 2026-09-30)

| what | route | notes |
| --- | --- | --- |
| search | `POST /hwyc/book/search` | body `{keyword, pageNo, pageSize}`; a paged answer (`current/size/total/records/pages`) — 500 matches for "werewolf", 25 pages of 20; each record carries the cover, `pseudonym` (author), `ratings` (out of **ten**), `genreNames`, `newTagsNames`, `writeStatus`, `chapterCount` and `bookResourceUrl` |
| novel | `POST /hwyc/book/detail` | body `{bookId}` → `data.book` — the same record plus `introduction` (the synopsis); `bookResourceUrl` is the site's own page slug (`Werewolf-Bond_31000001732`) |
| chapter list | `POST /hwyc/chapter/list` | body `{bookId, pageNo, pageSize}` → `data[]` — **the whole list in one answer**, grouped by volume (`volumeName`), oldest first; rows carry `chapterName`, `unlock`, `charge`. A 550-chapter novel came back complete in one ~60 KB response |
| chapter text | `POST /hwyc/chapter/detail` | body `{bookId, chapterId}` → `content` (the text), plus `previewContent`, `nextChapterId`, `prevChapterId`, `wordNum` |
| front page | `POST /hwyc/home/index/v2` | body `{language:"ENGLISH"}` → `data.pageColumns[]` — a dozen columns of six novels each (Popular, Werewolf, Love Stories, Mafia, MM Romance, Fantasy, YA/TEEN, Paranormal, Urban, Short Werewolf, Short Romance), each item the same shape as a search record |
| genres | `POST /hwyc/book/getBookTypes` | body `{language:"ENGLISH"}` → `{genres, shortGenres}` (not used for the feed; recorded because it exists) |

**A GET is 405 and a form/text body is 415** — `Content-Type: application/json`
is not optional, which is what says these are the H5 client's own routes rather
than a page. No `Token`, no `requestId`, no `platform` header is needed; the app
sends them but the routes answer without them (measured both ways).

### Three things specific to this source

* **It is a shop, and the API says so.** A chapter GoodNovel sells comes back
  with `content: ""` and a ~500-character `previewContent` instead — the teaser
  its own app shows before asking for coins (measured: 9 free and 77 charged
  chapters on an 86-chapter novel). Those rows are **kept** in the chapter list
  and still open: `GN_getChapter` wraps the teaser in the app's existing
  `notice: "preview"` treatment (the same one Wuxiaworld's truncated chapters
  get — `chapterInnerHTML` already renders it as a banner) rather than marking
  them `locked`, because `locked` swaps in the fixed *"requires a Webnovel
  membership"* message, which is a lie here. Dropping them, as the official
  plugins do, would leave a 416-chapter novel showing eleven chapters — a source
  that looks broken instead of paid.
* **Its chapter headings are not trustworthy, so the list's numbering is
  guarded.** Headings come as `"12: A name"`, plain `"Chapter 12"`, a bare
  `"12"`, or `"Epilogue"`; three real cases bite — `MAFIA RULES` writes its first
  hundred chapters as words (`"Chapter One-Hundred-One"`) and then continues with
  bare numbers **that restart in the thirties**, `I will never be yours` ends
  with two `"Bonus chapter 1"/"Bonus chapter 2"` rows, and `A Woman Worth
  Billions…` starts at 7 and ends at 422 for 416 chapters. So `GN_chapters` only
  believes a heading's number when it moves the count **forward** (`num > prev`),
  and otherwise numbers the row as the next chapter in the list — the order the
  site itself reads them in. Verified monotonic with no duplicates on six novels
  (26 to 1095 chapters).
* **A chapter's text arrives in two shapes, in the same novel.** Some chapters
  are `<p dir="ltr">` blocks; others are plain text with hard line breaks and not
  one tag (`The Luna Queen's Rebirth` chapter 1: 6450 characters, no `<`). The
  first goes through `SH_apiChapterHTML`; the second is split at its line breaks
  and each line escaped into its own `<p>` (`GN_chapterHTML`). Without that, the
  flattener returned nothing and the reader showed *"This chapter appears to be
  empty"* — which is exactly how the health sweep first reported it
  (`stage: "chapter"`, *"Novels open, but the chapters would not"*).

Also: **scores are out of ten and the app's stars are out of five**, so
`GN_rating` halves them (9.3 → 4.7). Covers come from `acf.goodnovel.com`, which
**does** send ACAO (measured with a CORS-mode fetch) — so it stays *out* of
`loadCoverImg`'s exception list, and only gets a `coverURLs` entry (direct URL,
`images.weserv.nl` behind it).

### What was added (the touch points)

`GN_API` / `GN_HEADERS` / `GN_PAGE_SIZE` / `GN_CHAP_PAGE` / `GN_post` /
`GN_rating` / `GN_numFromName` / `GN_chName` / `GN_bookFrom` / `GN_parseRows` /
`GN_searchBooks` / `GN_homeColumns` / `GN_homeColumn` / `GN_chapters` /
`GN_getBook` / `GN_chapterHTML` / `GN_getChapter` — the block sits after Novel
Fire's and before the source registry — plus the `SOURCES` card (`icon` "GN",
colour `#ee3799`, desc "Original web novels"), `SRC["GoodNovel"]` (`search`,
`authorSearch`, `getBook`, `getChapter`), `ID_PREFIX_SOURCES.gd`,
`COVER_HOST_SOURCES` (`goodnovel.com`), `SRC_ALIASES` (`goodnovel`,
`goodnovelcom`, `good`), `sourceForURL`, `sourceBaseURL`, `HEALTH_URLS`
(the site root — the API routes are POST-only, so they cannot be a health URL),
`buildDiscoverJobs` (five front-page columns + four keyword searches),
`feedLabel` ("Popular on GoodNovel"), the `fetchBrowsePage` `gnapp:` branch,
`coverURLs` (`acf.goodnovel.com` → direct, then the image proxy), and
`openExternal` (the `bookResourceUrl` slug; a title search when a shelved book
has none).

No `RATING_ENRICHABLE` entry (the rows carry the score) and no `CATALOGS` entry
(its search is a POST, but it is a *paged, complete* search, so the offline
sitemap index is not needed).

`buildDiscoverJobs` uses pseudo-URLs, like Novel Cool's `ncapp:` and Scribble
Hub's `shapp:`: `gnapp:home:<column>` and `gnapp:search:<keyword>:<page>`. The
home answer is ~190 KB, so `GN_homeColumns` keeps it for five minutes and the
five column jobs cost one request between them. The **first** job is a front-page
column, since the health sweep judges a source on the first shelf it can read.

### Verified in the live preview (2026-09-30)

* `sfHealth(healthURL("GoodNovel"))` (the site root) answers; `probeSourceHealth("GoodNovel")`
  → `{ok:true, stage:"chapter", ms:~4.4s, found:6, book:"Once a Doormat, Now Untouchable"}`
  after the two-shape chapter fix (before it: `stage:"chapter"`, *"Novels open,
  but the chapters would not"*).
* Search `"werewolf"` → 20 rows (500 matches, 25 pages); author search
  `"Oluna15"` → 2 rows; all nine feed jobs return books (6 per column, 20 per
  search) and the feed renders them under "Popular on GoodNovel" (70 cards once
  deduped).
* `getBook` on six novels from the feed and search — 26, 86, 121, 216, 229, 416,
  550 and 1095 chapters — **all monotonic, no duplicates**, names read off the
  headings where the site writes one and blank where it writes only "Chapter N".
* `getChapter` on first, middle and last chapters of two novels: full text (7872
  and 6445 characters) for the free ones, the ~300-460-character teaser with
  `notice: "preview"` for the sold ones, correct `nextId`/`prevId` in both
  shapes.
* The **packaged build** works: with `root.superFetch` removed (the
  `packagedBuild()` simulation) a novel, a chapter and a search all came back
  through the fetch-plugin proxy route — the same route Novel Cool's POST uses.
* Screens looked at as images: the source card (16 cards, GoodNovel among them)
  and a feed card at desktop; the book hero at 390×844 (cover, title, author,
  4.2★, tag pills, "Completed", "86 chapters", nothing clipped — `docScrollWidth
  === innerWidth`); and **the reader itself** for both a full chapter (heading +
  proper paragraphs) and a sold one (the 🔒 preview banner above the teaser),
  with `localStorage` snapshotted and restored around that check so the reader's
  own history was left exactly as it was.

## Previously — 2.7.40 (2026-09-30)

The app was on **v2.7.40** — **one new source: Novel Fire** (the app then carried
fifteen).

> "Add novel fire"

Novel Fire (`novelfire.net`) runs the **same site software as FreeWebNovel and
NovelFull** — the same `novel-item` cards, the same `/book/<slug>` novel and
`/book/<slug>/chapter-<n>` chapter addresses, the same `#content` chapter body —
under its own URL shapes, and unlike those two it answers a **plain headerless
GET on every route**, so nothing here needs a header, a key or a second address.

### The routes it uses (all checked live, 2026-09-30)

| what | route | notes |
| --- | --- | --- |
| search | `GET /search?keyword=<q>` | server-rendered HTML; the site's own result block (20 rows). **Not paged** — the `page` parameter is ignored, so that first stretch is all there is |
| author search | `GET /search?keyword=<name>&type=author` | the same page and block ("2 results" for `guiltythree`) |
| listing | `GET /genre-all/sort-<sort>/status-<status>/all-novel[?page=N]` | 24 novels a page, 814 pages for the whole catalogue; every card carries the cover, the rank badge and the star rating. (`/ranking` is 176 KB and writes a different card, so it is not used) |
| novel | `GET /book/<slug>` | cover (`og:image`), rating and voter count (the page's own JSON-LD `AggregateRating`), genres (`.categories`), synopsis (`.summary .content`), and `Ongoing`/`Completed` (`<strong class="ongoing|completed">` + `<small>Status</small>` — which `statusFromHTML` already read for FanMTL's shape) |
| chapter list | `GET /book/<slug>/chapters[?page=N]` | 100 chapters a page, **oldest first**, page count in its own pagination — so the list is `WP_loadRest`'s job (queryPage `?page=`) |
| chapter text | `GET /book/<slug>/chapter-<n>` | the body in `#content` (plain `<p>` blocks, the site's adverts outside it); neighbours in `.prevchap` / `.nextchap` |

`?page=N&sort_by=desc` also works (newest first); `pageSize`, `limit`, `n` and
`perPage` are all ignored — the page size is fixed at 100.

There is **no chapter-list AJAX**: `/ajax-chapter-list` and
`/ajax-chapter-option` (the endpoints NovelFull and NovGo answer, the ones
`NF_loadCatalog` reaches for) are **404** here, and
`?ajax=chapters&page=…&pageSize=…` (the FreeWebNovel / Lib Read endpoint) just
returns the book page. The one small route the site does have is
`GET /ajax/searchLive?keyword=<q>&type=<title|author|both>` (~1 KB of JSON, 6
rows) — too few rows to be the search, but small and headerless, which is why it
is the health URL.

### What was added (the touch points)

`NFIRE_HOME` / `NFire_abs` / `NFire_parseBooks` / `NFire_parseChapters` /
`NFire_searchBooks` / `NFire_authorSearch` / `NFire_rating` / `NFire_votes` /
`NFire_genres` / `NFire_synopsis` / `NFire_getBook` / `NFire_getChapter` — the
whole block sits just before the source registry — plus the `SOURCES` card
(`icon` "NF", colour `#ff5c39`), `SRC["NovelFire"]` (`search`, `authorSearch`,
`getBook`, `getChapter`), `ID_PREFIX_SOURCES.fi`, `COVER_HOST_SOURCES`
(`novelfire.net`), `SRC_ALIASES` (`novelfire`, `novelfirecom`, `fire`),
`sourceForURL`, `sourceBaseURL`, `HEALTH_URLS`
(`/ajax/searchLive?keyword=novel&type=title`), `buildDiscoverJobs` (five
listings: popular, newest, popular p2, completed, newest p2), `feedLabel`
("Popular on Novel Fire"), the `fetchBrowsePage` parse branch, `coverURLs`
(`novelfire.net/server-*` → direct, then the image proxy), `loadCoverImg`'s
`crossOrigin` exception list, and `openExternal`.

No `RATING_ENRICHABLE` entry is needed — the listing cards carry the star rating
themselves (like NovelHi and NovelBuddy). The novel id **is** the slug
(`fi-shadow-slave`), so there is no slug map and `openExternal` is a one-liner.

### Three things specific to this source

* **The chapter list is paged HTML, and that is the honest cost.** Shadow Slave
  (3194 chapters) is 32 pages of ~65 KB. Measured: ten of them, three at a time,
  came back in 3.8 s (0.8-1.4 s each) with no bot check, so the whole list costs
  ~12 s of background pumping that streams into the chapter list exactly as Lib
  Read's does. The host has not needed `BURST_SENSITIVE` (it has never refused a
  burst, and `markPolite` would cover it if it ever did).
* **Two things the parsers have to read *around*.** (a) Only rows inside
  `ul.chapter-list` count: the page repeats its newest chapter in a "Latest
  Release:" line above the list **with the same address**, so reading the whole
  page puts a phantom second copy at the end of the list *and* lets that copy
  claim the id the real row needs when its own page arrives (measured: chapter
  286 appeared twice, the second as `286~2`). (b) `NFire_parseBooks` reads only
  the first `ul.novel-list`: the search page's own results are a
  `novel-list horizontal col2 chapters` block while its "popular novels" sidebar
  is a second `novel-list col6`, and the sidebar is not part of the answer.
* **The cover host sends no ACAO** (measured: a `crossOrigin="anonymous"` image
  fails while a plain `<img>` loads 450×600), and it is the same host that serves
  the pages, so `novelfire.net` joins `loadCoverImg`'s `crossOrigin` exception
  list with the image proxy as the second route — covers are displayed but not
  canvas-cached. It **is** reachable from the packaged app, though: with
  `root.superFetch` removed (the `packagedBuild()` simulation) both a listing and
  a chapter came back through the **bridge** transport.

### Verified in the live preview (2026-09-30)

* `sfHealth(healthURL("NovelFire")) === "ok"`; `probeSourceHealth("NovelFire")`
  → `{ok:true, stage:"chapter", ms:2399, found:24, via:"superfetch", book:"Shadow Slave"}`.
* Search `"shadow"` → 20 rows; author search `"guiltythree"` → 2 rows.
* All five feed jobs → 24 books each, with titles, covers and ratings; the feed
  renders them under "Popular on Novel Fire" (101 cards once deduped).
* `getBook("fi-shadow-slave")` → **3194 chapters, no gaps, no duplicates, no
  empty names**: first `Nightmare Begins`, last `Fellow Wanderer`, detail with
  title / author `Guiltythree` / genre `Action` / status `ongoing` / rating `4.6`
  / 818 votes / synopsis / cover.
* `getBook("fi-i-write-novels-in-a-zerg-prison")` → 286 chapters; `getChapter`
  on 1, 150 and 286 with working `prevId`/`nextId` (the last chapter's `nextId`
  is `null`) and 55-353 paragraphs of text each.
* The source list (15 cards), a feed card and the book hero were looked at as
  images at desktop and phone width (390×844): nothing clipped, nothing
  overflowing, no horizontal scroll.

## Previously — 2.7.39 (2026-09-30)

The app was on **v2.7.39** — **one new source: NovelBuddy** (the app then carried
fourteen).

> "Do novel buddy for now"

NovelBuddy is read through **the interface its own reader app uses**, not by
scraping its pages — the same approach as Novel Cool and Scribble Hub ("Adding a
source", item 15). The site puts `window.__API_URL__ = "https://api.novelbuddy.me"`
on every page it serves, and that host answers plain headerless GETs with JSON:
**no Cloudflare, no key, nothing to sign** (measured 2026-09-30 — the API answers
in about a second through the app's own `superfetch` route while the site's own
HTML pages sit behind a challenge).

### The routes it uses (all checked live, 2026-09-30)

| what | route | notes |
| --- | --- | --- |
| search | `GET /titles/search?q=<q>` | rows carry id, slug, cover, status, rating, genres, summary, `stats.chapters_count` |
| catalogue | `GET /titles/search?sort=<sort>&page=<n>` | **no `q` at all** — the whole catalogue, 20 a page, `pagination.total` 10000. `sort` accepts `popular`, `rating`, `newest`, `views`, `chapters`, `alphabetical`…; an unknown one answers `{"success":false}` with "Sort field must be one of…", which `NB_api` throws on instead of quietly yielding an empty list |
| novel | `GET /titles/<id>` | everything nested under `data.title` (name, alt_name, summary, status, rating, `stats`, `authors[]`, `genres[]`, `cover`); its own `chapters[]` is only the **last 50** — hence the separate list route |
| chapter list | `GET /titles/<id>/chapters` | every chapter, **newest first**: `data.chapters[]` with id/slug/name/number/updated_at |
| chapter text | `GET /titles/<id>/chapters/<chapterId>` | `data.chapter.content` is the whole body as HTML (`<div><p>…</p></div>`, translator/proofreader boxes included), plus `next_chapter`/`previous_chapter` — they mean *later*/*earlier*, and the newest chapter's `next_chapter` is `null` |

One quirk worth remembering: an **empty `q` together with `page`/`limit`**
answers an empty list, while `/titles/search?page=2` answers the catalogue — so
the feed jobs never send `q`.

The site's own pages are `https://novelbuddy.me/<slug>` and
`https://novelbuddy.me/<slug>/chapter-<n>` (that is what `openExternal` builds).

### What was added (the touch points)

`NB_API` / `NB_SITE` / `NB_IS_JSON` / `NB_api` / `NB_bookFrom` /
`NB_parseList` / `NB_searchBooks` / `NB_getBook` / `NB_chapterHTML` /
`NB_getChapter` — the whole block sits just before the source registry — plus the
`SOURCES` card, `SRC["NovelBuddy"]` (`search`, `authorSearch`, `getBook`,
`getChapter`), `ID_PREFIX_SOURCES.nb`, `COVER_HOST_SOURCES` (`novelbuddy.me`),
`SRC_ALIASES` (`novelbuddy`, `novelbuddycom`, `buddy`), `sourceForURL`,
`sourceBaseURL`, `HEALTH_URLS` (`/titles/search?q=novel` — a headerless GET
that answers JSON), `buildDiscoverJobs` (five API jobs: two pages of
`sort=popular`, then `sort=views`, `sort=rating`, `sort=newest`),
`feedLabel` ("Popular on NovelBuddy"), the `fetchBrowsePage` parse branch,
`coverURLs` (`rs.novelbuddy.me` → direct, then the image proxy),
`loadCoverImg`'s `crossOrigin` exception list, and `openExternal`.

Chapter text **reuses Scribble Hub's flattener** (`SH_apiChapterHTML`, wrapped as
`NB_chapterHTML`): the app API hands over the same `<p>`-block markup, so the
bold/italic/`<br>` runs and the block handling come for free. No `RATING_ENRICHABLE`
entry is needed — the listing rows carry `rating` themselves (like NovelHi).

### Two things specific to this source

* **Neither the API host nor the cover host sends an ACAO header** (measured: a
  plain cross-origin `fetch`, and a `crossOrigin="anonymous"` image, both fail
  from the app's own origin, while the same URL through a proxy answers 200 and a
  plain `<img>` loads the cover 300×400). So `rs.novelbuddy.me` gets the image
  proxy as its second route and `novelbuddy.me` joins `loadCoverImg`'s
  `crossOrigin` exception list — the same arrangement as Scribble Hub,
  Wuxiaworld and Lib Read — which means covers are **displayed but not
  canvas-cached** (a canvas would be tainted). It also means NovelBuddy is *not*
  readable straight from the packaged app's `file://` page; it goes through the
  app's transports like everything else.
* **The book id is opaque and separate from the slug** (`nb-eDkM6O8Q` ↔
  `/shadows-oath`) and a browse card carries no slug, so the pairs are kept in
  `NB_SLUGS` (localStorage `pocketnovel_nbslugs`, filled in `NB_bookFrom` and
  `NB_getBook`, snapshotted by `healthCacheGuard` alongside `WL_SLUGS` /
  `SH_SLUGS`). `openExternal` reads it, and with no slug at all it opens the
  site's own search for the title rather than a broken link — the same pattern as
  WTR Lab's `WL_SLUGS`.

### Verified in the live preview (2026-09-30)

* `sfHealth(healthURL("NovelBuddy")) === "ok"`; `probeSourceHealth("NovelBuddy")`
  → `{ok:true, stage:"chapter"}` — it opens a novel, reads a chapter and finds real
  text in it.
* Search `"shadow"` → 20 rows (`Shadow's Oath`, `Shadow Slave`, …).
* Each of the five feed jobs → 20 books; the feed renders them under "Popular on
  NovelBuddy" (87 cards over a few jobs).
* `getBook("nb-eDkM6O8Q")` → 110 chapters in order with status/rating/genre/
  author/synopsis filled; `getChapter` mid-list → ~12 KB of `<p>` text with
  `nextId`/`prevId` from the list and `num` 56.
* Source list and book screen looked at as images at desktop and phone width
  (390×844): 14 cards, one column, nothing clipped or overflowing.

## Previously — 2.7.38 (2026-09-30)

The app was on **v2.7.38** — **NovelLive and LightNovelPub were removed**.

> "They are the same, novelive and lightnovelpub. They aren't working fine. Find
> another way to make them work. Like not the way we used to get sources. If you
> can't find them. Just remove those two sources."

### Why they went, and what was tried first (2.7.38)

The two entries were one site (every mirror serves byte-identical pages), and it
had become unreadable *from YueDu* while still working in the reader's own
browser. Everything checked in this session:

| route | result |
| --- | --- |
| `api.novellive.org` — the site's own app interface (see 2.7.36) | **526 Invalid SSL certificate** from Cloudflare: the name resolves (`104.21.69.45` / `172.67.204.85`), the origin behind it does not answer. `api.novellive.com/.app/.net`, `api.lightnovelpub.me` and `api.noveltrust.com` are all **NXDOMAIN** (checked over DoH). The app that owned it was abandoned in Feb 2024 |
| chapter pages on all six mirrors (`novellive.com/.app/.net/.org`, `lightnovelpub.me`, `noveltrust.com`, plus their `www.` forms) | **403 "Just a moment…"** (Cloudflare challenge) on every one — with and without browser headers, from the perchance proxy, from `r.jina.ai`, and from Google Translate's own renderer (`lightnovelpub-me.translate.goog`) |
| listing / book / `/ajax/` pages on the same hosts | 200 — the wall is on `/book/<slug>/<chapter>`, not on the host |
| path tricks (`?x=1`, trailing slash, `BOOK/`, `//`, `%2D`, `%09`, `/./`) | all still challenged |
| public CORS proxies (codetabs, corsproxy.io, corsfix, cors.eu.org, cors.lol, test.cors.workers.dev, everyorigin, whateverorigin, textise, yacdn, isomorphic-git, allorigins) | rate-limited, dead, or themselves Cloudflare-blocked; microlink had already spent its daily quota |
| the Wayback Machine | no snapshot for the chapters sampled |

Chapters that *did* load were the ones already sitting in a cache — which is
exactly why the source felt flaky (a few chapters read, most refused). No route
is left from a web page to that site's chapter text, and the instruction was to
remove the sources if no other way could be found. So they were removed.

### What "removed" means in the code (2.7.38)

* Gone entirely: `SOURCES` entries, `SRC` behaviour, `HEALTH_URLS`, `CATALOGS`,
  `RATING_ENRICHABLE`, `ID_PREFIX_SOURCES`, `COVER_HOST_SOURCES`, `SRC_ALIASES`,
  `sourceForURL`, `sourceBaseURL`, `buildDiscoverJobs`, `feedLabel`,
  `fetchBrowsePage`, `ratingForBook`, `openExternal`, and the whole 365-line
  `NLP_*` section (`NLP_HOSTS`, `nlpFetch`, every parser). `sfPost` and its
  transports **stay** — Novel Cool and Scribble Hub still search by POST.
* **A shelved novel is not orphaned.** `RETIRED_SOURCES = { nl: "NovelLive",
  lp: "LightNovelPub" }` and `retiredSrc(name)` sit just after
  `ID_PREFIX_SOURCES`: `sourceFromId` still answers for an `nl-`/`lp-` id, and
  `SRC["NovelLive"]` / `SRC["LightNovelPub"]` are stubs whose `getBook` and
  `getChapter` throw an error tagged `.retired`. That matters because four call
  sites do `SRC[book.source] || SRC["Webnovel"]` — without the stubs a retired
  novel would be silently handed to Webnovel's parser.
* The reader has a dedicated card for it (`} else if (e && e.retired)`), saying
  the source is gone and offering **Find on another source** (wired by
  `wireCaptchaHint`); the two book-screen catches (`enrichBookDetails`,
  `enrichBook`) show a toast. A chapter already saved in
  `yuedu_chapcache_v2` still opens and reads normally — the retired card only
  appears for a chapter that has to be fetched.
* The `e.blocked` reader branch lost its NovelLive special case: nothing else in
  the app is mirrored, so the "every address was asked" wording and
  `readerBlockCard`'s `swept` parameter were dropped with it.

Verified after the change: `SOURCES` and `HEALTH_URLS` both list **13** sources;
`sourceForURL("https://novellive.org/book/x") === ""`; `sourceFromId("nl-x") ===
"NovelLive"`; `SRC["NovelLive"].getBook(...)` rejects with `.retired` set; the
reader card renders (checked with `vision`) and writes no history; the history
screen still lists both retired novels from stored data; and the reader's own keys
(`pocketnovel_library` 142,819 B, `pocketnovel_history`, `pocketnovel_progress`,
`yuedu_chapcache_v2`) were untouched by the work.

### If a future agent is asked to bring them back

Don't. The only route that can read those chapters is a real browser on the
reader's own connection — a WebView render (`LitNative.challenge`) or `direct` in
a packaged build with universal file access — and that is device-side: it cannot
be done from the perchance page at all, which is where most readers use the app.
The 2.7.36 section below still holds the endpoint table in case that API ever
comes back, and the mirror list is in "Previously — 2.7.37".

## Previously — 2.7.37 (2026-09-30)

The app was on **v2.7.37** — NovelLive / LightNovelPub gained a **fifth address**,
`novellive.org`.

> "Look for other reading apps like LNReader. And check it's plugin, maybe you
> may find it, or find another way to make it work."

### NovelLive's fifth address (2.7.37)

`NLP_HOSTS` had four addresses. lncrawl's `novellive.py` names two more mirrors —
`novellive.org` and `noveltrust.com` — so both were measured through the app's own
transport:

| address | book page | chapter page |
| --- | --- | --- |
| `novellive.org` | **200**, 678 ms, chapter list present | **403** (Cloudflare challenge), twice — 10.7 s, 51.7 s |
| `noveltrust.com` | 403 (challenge) | timeout at 60 s |

`novellive.org` therefore joins the list **last**, and `noveltrust.com` does
**not** join it (a 60-second timeout is worse than not asking). Being last is
what makes it free: `nlpFetch` staggers the addresses 2.5 s apart and stops
starting new ones once something has answered, so the fifth address is only ever
started if the first four have all failed — a chapter that already loads never
touches it, and a chapter every other address refuses gets one more chance. Its
own chapter pages are walled from the app's *shared* route, but in the packaged
app the request comes from the reader's own address, where the challenge may not
appear at all; that is the case it is there for.

Also updated: `sourceForURL` now maps `novellive.org` to NovelLive (so a blocked
chapter on that address is attributed to the right source).

Verified after the change: `NLP_ordered("NovelLive")` ends with
`https://novellive.org`; `sourceForURL("https://novellive.org/book/…")` →
`"NovelLive"`; a chapter still comes back clean (chapter 1 → 91 paragraphs, no
site noise, `Nightmare Begins`); the novel screen still gives the 486-character
synopsis and 3,179 chapters; `NLP_GOOD_HOST` is untouched (novellive.com answered
first, so nothing was promoted).

**Nothing else implements this site.** The survey of every other reader and its
plugin set, and the app API found in the official APK, are in
"Previously — 2.7.36" immediately below — read that before touching anything
NovelLive-shaped (the source itself was removed in 2.7.38; the section above says
why).

## Previously — 2.7.36 (2026-09-30)

The app was on **v2.7.36** — the welcome screen **comes back when you reload**,
instead of being skipped as "already seen".

> "Fix the intro, I just reload the generator, the previous version like many
> old version ago, when reload it goes back to The Intro. Here it doesn't"

### The welcome screen is no longer "once per browser" (2.7.36)

`yuedu_intro_seen` plus `if (introSeen()) hideIntro();` made `#introScreen` a
first-run-only screen — added back in 2.7.21, when a reader coming back from a
captcha in the APK kept being dumped on the Continue button ("*I get the
YueDu logo and the Continue button*"). The reader now wants the opposite:
**reloading should land on the welcome screen**, the way older builds did, so
that is what it does.

The flag is gone — `INTRO_SEEN_KEY`, `introSeen()` and the read on load were
removed, and the Continue handler is now just `hideIntro()`. Nothing is written
on dismissal, so **every fresh load of `index.html` shows the splash**.

### The Continue button sits under the copy again (2.7.36)

2.7.35 moved the button out of the copy and into a footer strip pinned to the
bottom of the screen. That kept it reachable, but it left the button stranded far
below the text on any screen with room to spare — the reader's next question was
literally *"Why is the Continue button on the very down?"* The button is back
**inside `.introBody`, directly under the paragraph** (`margin-top: 26px`) and
`.introFoot` is gone.

Safety now comes from two places instead of a pinned footer:

- **`.introScroll` wraps the whole thing** — logo, heading, paragraph **and**
  button — so an intro taller than the screen scrolls, and the button scrolls
  into reach instead of being lost. (The old `overflow: hidden` is what used to
  make it unreachable.)
- **`@media (max-height: 640px)`** shrinks the logo (56px), heading (20px) and
  paragraph (11.5px / 1.52) so that in practice nothing scrolls on a short screen.

Measured: 209×565 (editor pane) — no scroll, paragraph ends y 432, button
y 461–501 (gap 29), fully visible; 390×844 — gap 40, button y 606–651;
700×360 (landscape) — no scroll, button y 263–303; 360×240 — scrolls
(347 > 240), button reachable at y 184–224. Vision-confirmed at phone size:
"Continue button directly below the intro paragraph; paragraph a complete
sentence; nothing overlapping or clipped."

What makes this safe now is 2.7.21's *other* half: the app shows a source inside
its own in-app site view instead of navigating its own document away, so
YueDu no longer reloads itself mid-task — a reload only happens when the
reader reloads (or, in the packaged app, when Android recreates the WebView,
which is the case where the splash coming back is most likely to be noticed).

### NovelLive's app API — found, and currently broken (2.7.36 investigation)

2.7.35 concluded "these two sites have no app interface". That was **wrong**, and
the reader was right to push on it: the interface is `api.novellive.org`, which
none of the earlier probing tried (it went after `api.novellive.com`, `.app` and
`.net` — all dead — and never the `.org`). The site does ship an Android app.

**How the API was found** (repeat this if it is ever needed again): the app is
*Novel Live* by **BeesFun**, package **`com.beesfun.novellive`**, 27.9 MB,
**Flutter** (v1.0.2, Feb 2024; no longer on Google Play — `play.google.com/store/apps/details?id=com.beesfun.novellive` is a 404). It was fetched from
`apk.support`/`mi9.com` (its download page carries a one-shot signed link to
`downloadapks.androidcontents.com/…`). An APK is a zip; **the interesting code is
in `lib/arm64-v8a/libapp.so`, not in `classes.dex`** — a Flutter release build
compiles the Dart to AOT in that `.so`, so a plain regex for URLs over the raw
`.so` bytes lists every endpoint the app knows (the dex only yields Google ads
and Firebase hosts, which is why a dex-only scan looks like "no API"). The fields
below came from the same `.so` as bare strings; they are Dart snapshot strings,
so read them as *hints*, not as a schema.

**The endpoints** (all under `https://api.novellive.org/`):

| endpoint | likely use |
| --- | --- |
| `/api/novel/search-novel` | search |
| `/api/novel/get-novel-by-id` | one novel (blurb, author, genres, status…) |
| `/api/novel/get-novel-by-author` | author's other works |
| `/api/novel/get-novel-by-genre` | genre browse |
| `/api/novel/get-trending-novel` | home shelves |
| `/api/novel/get-completed-novel` | home shelves |
| `/api/novel/get-most-novel` | home shelves |
| `/api/novel/get-lastest-novel` | home shelves (their spelling) |
| `/api/chapter/get-list-chapter-by-novel-id` | **the whole chapter list** |
| `/api/chapter/get-chapter-by-id` | **one chapter's text** |
| `/api/user/saveToken`, `/api/user/addNovelToLib`, `/api/user/removeNovelFromLib`, `/api/user/checkUpdate` | account/library — not needed |

Query names seen in the snapshot: `novel_id`, `chapter_id`, `offset`, `limit`,
`token`, `deviceId` (each URL is stored ending in `?`, so parameters are appended
at run time). Response field names seen: `success`, `message`, `data`, `total`,
`novel_id`, `novel_name`, `chapter_id`, `chapter_name`, `image`, `description`,
`content`, `genre` / `genres`, `status`, `views`, `rating`. Covers are
`https://media.novellive.org/novel/<slug>.jpg` (the same path as the website's
`media.novellive.com`, which works).

**Current status: DOWN — do not build on it yet.** Every request fails with
**Cloudflare error 526, "Invalid SSL certificate"** (Cloudflare cannot validate
the certificate on the origin). Verified through `r.jina.ai` (which prints the
526 page) and from the live page (`fetch` → `TypeError: Failed to fetch`;
`mode:"no-cors"` returns an opaque response, i.e. *a* response, which is what the
526 is). Over plain HTTP the host reaches an `nginx/1.20.1` origin that **404s**
the `/api/…` paths, so there is no HTTP fallback either. Because the app itself
talks to that exact host, **the official Novel Live app is broken too** while this
is true — so the API being down is not something YueDu caused or can work
around. Re-check it with a single request to
`https://api.novellive.org/api/novel/get-lastest-novel` before doing any work
here.

The rest of the `.org` family is alive: `https://novellive.org/` serves the same
site (a mirror that is **not** in `SOURCES`) and `media.novellive.org` serves
covers. The site's own pages never call the API — the website is fully
server-rendered — so the API is app-only, as expected.

**No LNReader-family plugin covers these sites** (checked 2.7.36, so a future
session does not have to look again):

- **LNReader** itself (`LNReader/lnreader-plugins`, 280 plugins): no NovelLive.
  Its only "lightnovelpub" entry is **LightNovelPub Vip → `lightnovelpub.vip`**,
  a *different* site on the "webnovelworld" (Web Novel Pub) multisrc theme, and
  it does not answer at all (timeout).
- **Nekori-plugins** (`Yuneko-dev/Nekori-plugins`, branch `plugins/v3.0.0`): **34
  plugins**, exactly one of them English (`CosplayTele`). No NovelLive, no
  LightNovelPub (the tree has no file with either name).
- **QuickNovel** (`LagradOst/QuickNovel`, ~90 providers): has
  `LightNovelPubProvider.kt`, but it targets `www.lightnovelpub.com` — a
  different site — and **the whole class is commented out** (the author's note
  reads "THEY RATE LIMIT THE FUCK ON THIS PROVIDER"). No NovelLive provider.
- **`grep.app` code search** for `novellive`, `novellive.org` and
  `api.novellive` finds only HTML scrapers — `lncrawl/lightnovel-crawler` and
  `dteviot/WebToEpub` — and **zero references to the API** anywhere public.
- **App stores**: searching APKCombo for "novellive" returns exactly one relevant
  app, the BeesFun *Novel Live* already dissected above; "lightnovelpub" returns
  only unrelated apps from other publishers.

**The extra mirrors do not rescue the chapter route.** `lncrawl` names two
addresses beyond the four in `NLP_HOSTS`: `novellive.org` and `noveltrust.com`.
Measured through the app's own transport (2.7.36): `novellive.org/book/shadow-slave`
(book page) **200 in 678 ms** with its chapter list present, but
`novellive.org/book/shadow-slave/chapter…` **403, Cloudflare challenge**, twice
(10.7 s, 51.7 s); `noveltrust.com` challenges its book page too and its chapter
page timed out at 60 s. So both are live mirrors whose chapter pages are walled
from the shared route — adding them to `NLP_HOSTS` would only add a request that
fails. (They might answer from the packaged app's *device* route, where the
request comes from the reader's own address rather than the shared one; that is
untested and is the one reason to revisit them.) lncrawl's selectors for the site
(`.m-read .txt` for the body, `.m-desc .txt` for the synopsis, `.m-newest2` /
`ul-list5` for the chapter list) match what 2.7.35 implemented, which is a
useful cross-check that the current extraction is the standard one.

**If it ever answers again:** ask it first for search, the chapter list and the
chapter text, keep the current reader-page extraction as the fallback (exactly the
Novel Cool / Scribble Hub shape: interface first, `try`/`catch`, pages behind it),
and validate the parsed result before trusting it — the response shape above is
inferred from strings, not observed, so the first live response should be dumped
and inspected rather than assumed.

## Previously — 2.7.35 (2026-09-30)

The app was on **v2.7.35** — two reader-reported fixes: the welcome screen's
**Continue button was off-screen** and is back, and **NovelLive / LightNovelPub
chapters** stop carrying the site's own text.

> "It's good, but can you fix the like intro? When you open YueDu, there's
> like Introduction. YueDu is your way into the world of... Where's there's a
> continue button, now it's gone fix it. And also for novelive and lightnovelpub,
> make it not websites make it like novel cool way of getting the sources that
> android thing."

### The intro's Continue button was below the fold (2.7.35)

`#introScreen` was `justify-content: center; overflow: hidden` and `.introBody`
was a single centred block containing the logo, the heading, the paragraph **and**
the Continue button. On a short viewport the block was taller than the screen, so
centring pushed its bottom — the button — past the viewport edge, and
`overflow: hidden` meant it could not be scrolled to. Measured: the button sat at
**y = 636 in a 565 px viewport** — unreachable, which reads to the reader as "the
button is gone, there is no way in".

The layout is now a column with a scrolling body and a fixed footer:

- `#introScreen` — `display: flex; flex-direction: column; overflow: hidden`
  (centring removed).
- `.introScroll` (new) — `flex: 1 1 auto; min-height: 0; overflow-y: auto`,
  wrapping the logo + heading + paragraph.
- `.introBody` — `margin: auto 0` (so a short intro stays vertically centred, but
  an over-long one starts at the top and scrolls, rather than being clipped at
  both ends). Kept `position: relative` / `padding` / `width: 100%`.
- `.introFoot` (new) — `flex: 0 0 auto`, the footer strip; the Continue button
  moved into it and lost its old `margin-top: 30px`. The strip carries
  `padding-bottom: calc(20px + env(safe-area-inset-bottom, 0px))`.
  *(2.7.36 removed `.introFoot` again — the button is back inside `.introBody`,
  directly under the copy; see the current version.)*

Verified at 209×565: the button sits at y = 500 (fully visible), `.introScroll`
`scrollHeight` 794 > `clientHeight` 490 (it scrolls), `.introBody` starts at y = 0.
At 390×844 no overflow (button y = 780). Clicking hides and removes the intro and
sets `yuedu_intro_seen = 1`. Vision-confirmed: "Continue button fully visible,
not clipped". The intro's copy was not changed.

### NovelLive / LightNovelPub no longer read like the website (2.7.35)

**There is no app interface for these two sites.** Unlike Novel Cool
(`api.novelcool.com`) and Scribble Hub (`/wp-json/fictionapp/v1/`), NovelLive and
LightNovelPub are one server-rendered Express app with no app-facing API to read
from. **(2.7.36 correction — there *is* an app API: `api.novellive.org`, found by
decompiling the official app. It is not usable because it is broken right now.
See "NovelLive's app API — found, and currently broken" in the current-version
section; the hosts tried below simply did not include `.org`.)** Recon (this is the evidence, do not redo it): `/api/*` 404s ("Cannot GET")
for 20+ shapes; the only `/ajax/*` routes are `get-list-chapter`, `rate-novel`,
`report-chapter`; no `/.well-known/assetlinks.json`, no
`apple-app-site-association`, no `/manifest.json`, no `/app` `/download` `/mobile`
pages, and no app links on the home page; `api.novellive.com/.app/.net`, `app.*`,
`m.*`, `v2.*` and `api.lightnovelpub.me` are all dead; identical HTML for
plain/okhttp/dart/android-app/webview user agents; **not** CORS-open (plain
`fetch` fails for the book page, the ajax list and `media.novellive.com`);
grep.app finds only HTML scrapers (`lightnovel-crawl`, `WebToEpub`) and zero API
references. The one thing that *is* an interface — `/ajax/get-list-chapter` — was
already used by `NLP_tocAll` (2.7.20). So the app reads their reader page, and this
release fixes *how* it reads it.

**What was wrong.** The chapter page has no `chapter-content` marker, so the old
extractor fell through to `body = html` — `const body = html` after a failed
marker search — and harvested every `<p>` on the **whole page**. That is why every
NovelLive / LightNovelPub chapter ended with the site's own two sentences
("Visit and read more novel to help us update chapter quickly. Thank you so
much!" and "Use arrow keys (or A / D) to PREV/NEXT chapter") — confirmed live:
93 paragraphs, last two are those. The chapter name came from the page `<title>`
("Shadow Slave - Chapter 1 Nightmare Begins"), leaking the novel's title into the
reader's header. And the book synopsis was the truncated `og:description`
(214 chars) instead of the page's full SUMMARY block (491 chars).

**The fix** — three helpers next to `NLP_getChapter`:

| helper | anchors on | gives |
| --- | --- | --- |
| `NLP_contentParas(html)` | `class="m-read"` → `class="txt"`; cut at the first of `class="chapter-end"` / `class="ul-list7"` / `class="footer"` after the start | the chapter's own `<p>`s, decoded, with `NLP_CHAPTER_NOISE` filtered (`visit and read more novel` / `use arrow keys` / `report chapter` / …) |
| `NLP_summary(html)` | `class="abstract"` → `<div class="txt"><div class="inner">…` | the full blurb |
| `NLP_getChapter` | `og:novel:chapter_name` / `<span class="chapter">` | clean `name` (`^chapter N` stripped), `num`, `nextId` / `prevId` / `total` as before |

`NLP_getBook` now prefers `NLP_summary(html)` and falls back to the old
`og:description` (via `||`, so a site without the abstract keeps working).
`NLP_summary` is a function declaration defined *after* `NLP_getBook`, which is
fine — it hoists.

Verified live: chapter 1 → 91 paragraphs (93 − the 2 noise lines), no "visit and
read more novel", no "arrow keys", first paragraph "A frail-looking young man…",
last paragraph `[Aspirant! Welcome to the Nightmare Spell. Prepare for your First
Trial…]`, `name === "Nightmare Begins"`, `num === 1`. Chapter 31 ("Low Tide", id
`chapter31-low-tide`) → 52 paragraphs, clean. LightNovelPub (same backend, `lp-`
name) → identical 91-paragraph result. `NLP_getBook("nl-shadow-slave")` → 486-char
synopsis ending "…potentially fatal side effect…" (the full SUMMARY, not the
truncated meta), 3,179 chapters.

## Previously — 2.7.34 (2026-09-30)

The app is on **v2.7.34** — it now **tests its own sources in the background**
and shows the reader the verdicts, so a source that has quietly stopped working
turns up on a screen instead of in the middle of a chapter.

> "Add another buttons or something inside more. You can create another buttons
> like settings and ect, or decide where it will be placed under. This is for
> checking the health of the source. When you are using YueDu, it silently
> Looked at each sources. Like try if chapter loads or ect. And you can go and
> see the results it's automatically. If there's a lot of sources in the future,
> I'm afraid I will be too lazy to check."

### Source health: silent sweeps, and the screen that shows them (2.7.34)

**What it is.** A background sweep walks the active sources one at a time and
does on each of them exactly what a reader would do — **open its front page,
open a novel from it, and read a chapter of that novel**. The verdict is only
`ok` when a chapter came back with real text in it (`healthChapterGood`: the
reader's own `reader-error` placeholder never passes, and under 120 characters
of text is not a chapter). A home page that still answers while its chapters
have stopped opening is the failure a reachability ping never sees, and it is
the one the sweep exists to catch.

**Stage by stage.** `probeSourceHealth` (`probeSourceHealthRaw` + the guard and
clock in the wrapper) records the *furthest* stage it reached and, when it
fails, which one failed:

| stage | what it does | failure it reports |
| --- | --- | --- |
| `feed` | `buildDiscoverJobs(name)` → `fetchBrowsePage` — **up to 3 of the source's own list URLs**, stopping at the first that returns books (NovelFull's home page is a landing page with no novels; its second job is the real shelf). Two thrown fetches in a row ends it. | "Its front page would not load" / "Its front page answered, but no novels were on it" (`empty`) / "The site refused us (captcha)" (`blocked`) |
| `book` | `SRC[name].getBook(bookId, feedBook)` on up to 3 feed novels; two consecutive failures end it | "Novels open, but their chapter lists came back empty" (`empty`) |
| `chapter` | `SRC[name].getChapter(book, id)` on the first chapter, plus #2 and #n/3 if that one is a stub; two consecutive failures end it | "Novels open, but the chapters would not" (`down`) / "The site is asking for a captcha" (`blocked`) |

A whole probe is on a clock (`HEALTH_PROBE_MS = 45000`): a source that accepts a
connection and then dribbles cannot hang a sweep, and running out of time is
itself a verdict. A captcha is never retried around (`e.blocked`, or a
captcha/robot message) — it stops that stage immediately.

**It leaves no trace.** A probe visits a source through the real source code, and
a real visit fills the app's own slug caches (`SH_SLUGS` → `pocketnovel_shslugs`,
`WL_SLUGS` → `pocketnovel_wlslugs`, both `const` objects persisted by their own
writers). `healthCacheGuard()` snapshots both objects **and** both localStorage
strings before the probe and puts them back in a `finally`, so the sweep cannot
grow, shrink or evict anything the reader owns. It never touches `chapterStore`
(the probe calls `SRC[...].getChapter` directly, not `fetchChapter`, which is the
only thing that writes `yuedu_chapcache_v2`), and it never touches library,
history or progress. Verified: probing Webnovel, WTR Lab, Scribble Hub, Novel
Cool and Royal Road in a row changed **no** localStorage key
(`yuedu_srchealth_v1` excepted, which is the feature's own data).

**It is a deliberately polite guest.**

- One source at a time, `HEALTH_GAP_MS = 3000` between them.
- `healthWaitForQuiet(60000)` before every probe: it will not start while any
  request the app makes is in flight, and it will not start while the app is in
  the background. If it cannot get a quiet moment it **stops the sweep there**
  and the next kick picks up whatever is still stale — it never sits on one
  source, and it never races the reader.
- **`healthNet`** is how it knows: `hedgedGet` — the one function every fetch in
  the app goes through — is wrapped once (`hedgedGetUnmetered`), incrementing a
  busy counter and stamping a last-activity time. No caller was touched. (Note
  the wrapper is a *reassignment of the function declaration*, so it must run
  **after** `hedgedGet`'s declaration in the same script — it does, the health
  section sits around line 9600.)
- A source is only re-probed when its last result is older than
  `HEALTH_FRESH_MS = 6 hours`, unless the reader asks. So in practice: one full
  pass per session, then nothing for the rest of it.
- Scheduled from `healthBoot()` at the end of the script: a 12 s first sweep
  (after the app's own first requests have settled), a 15-minute interval that
  only fires when something is actually stale, and a `visibilitychange` kick
  that is **suppressed for the first 10 s** (`health.bootAt`) so returning to the
  tab cannot pre-empt the boot delay.

**The verdicts persist.** `yuedu_srchealth_v1` →
`{v:1, finishedAt, sources:{<name>:{at, ok, kind, stage, ms, reason, found, book, hist, lats}}}`.
`hist` is the last 14 outcomes as a `"1011…"` string and `lats` the last 14
durations, both trimmed — `healthPaint` only uses `hist` length indirectly today
but the shape is there for a trend view. `kind` is one of `ok` / `down` /
`blocked` / `empty` (the `empty` and `blocked` cases render **amber**, `down`
**red**).

**The screen.** More → **Source health** (`data-health` row, `#healthScreen`,
a `.subScreen`). It has a summary card (headline, "Last full check …",
`Check all now`), a **bar of one tick per source** (`#healthBar`, green/red/amber/
grey — the at-a-glance answer), and a row per source with its icon, name, a
`sourceDot` in the same `data-mode` vocabulary the Browse list uses, the verdict
line ("Novels and chapters open · 10.8s · 8m ago") and a `↻` retry button.
**Tapping a row re-tests just that source** (`healthCheckOne`). Painting is
in-place: rows are rebuilt only when the set of active sources changes
(`#healthList`'s `data-sig`), so the logos don't reload on every tick.

**The More tab row carries the state**: `#moreHealthSub` reads "All 15 healthy" /
"2 of 15 need attention" / "Checking sources…" / "Not tested yet", and
`#moreHealthDot` (the existing `.rowDot`) lights up whenever anything is wrong —
so the reader never has to go looking.

**What was deliberately not done.** No new data source, no new transport, no
per-source hardcoded book ids: the sweep uses `buildDiscoverJobs` +
`fetchBrowsePage` + `SRC[...].getBook`/`getChapter`, so it tests exactly the code
a reader exercises and self-adapts when a book disappears from a shelf. The
reachability probe on the Browse screen (`sfHealth` / `checkSourceHealth`,
2.7.19) is unchanged and still owns the status pills in Sources & extensions.

**Verified** (page, live): a full forced sweep of all 15 sources → all 15 `ok`,
each naming the novel it opened (Webnovel → My Vampire System, Royal Road →
Mother of Learning, Novel Cool → Shadow Slave, Scribble Hub → The Young Master in
the Shadows, …), each having read a real chapter (Novel Cool 41.7 s end to end,
Wuxiaworld 1.6 s). Failure classification exercised with a temporary edit to
`buildDiscoverJobs`: `example.com` as the shelf → `empty` ("Its front page
answered, but no novels were on it"); three `.invalid` hosts → `down` ("Its front
page would not load"). With `SRC[...]` stubbed: empty catalog → `book`/`empty`;
throwing `getChapter` → `chapter`/`down`; the reader's `reader-error`
placeholder → `chapter`/`down`; `{blocked:true}` → `chapter`/`blocked`. Screen
checked at 390×844: the summary card, the 15-tick bar (15 × 19 px + 14 × 3 px gaps
= 327 ≤ 329 available), 15 rows with loaded logos (`naturalWidth` 16–128) and no
overflow (`scrollWidth === clientWidth` on the card and the top row). A seeded
failing pair renders as designed — red "Novels open, but the chapters would not"
with a red dot, amber "The site refused us (captcha)" with an amber dot, headline
"2 sources need attention", `barModes` `1110w1111…`, More-tab dot lit. Row tap
re-checked Royal Road (2.4 s, `ok`).

## Previously — 2.7.33 (2026-09-30)

The app was on **v2.7.33** — Scribble Hub is read through the site's own **app
interface** now, the same move that made Novel Cool work in 2.7.29, which is
what fixes the three things the reader reported.

> "Fix Scribble Hub, it doesn't show novel cover in the page and ect. Some
> chapters are also missing, like goes immediately to chapter 280 and ect
> instead of 1. Don't copy the lnreader sources. Because it doesn't work. But I
> want you to do the same approach. That android own thing. Like used in novel
> cool."

### Scribble Hub: the site's own app interface (2.7.33)

Scribble Hub is a WordPress site, and the WordPress REST layer it already runs
exposes the **app's own interface**:

```
GET https://www.scribblehub.com/wp-json/fictionapp/v1/stories/<id>
GET .../stories/<id>/chapters?perPage=200&page=N     (oldest first; meta.totalPages)
GET .../chapters/<id>                                (content + previousChapterId/nextChapterId)
GET .../search?q=<text>
GET .../stories?sort=trending|rating&order=desc&genre=<id>&page=N
GET .../genres                                       (the site's own genre ids/slugs)
```

Measured, unauthenticated, from the live page:

| what | answer |
| --- | --- |
| `/stories/526583` | title, `author.displayName`, `coverUrl`, **full** `description`, `status`, `genres`, `mainGenre`, `tags`, `ratingAverage`, `ratingCount`, `chapterCount`, `firstChapterId` |
| `/stories/526583/chapters?perPage=200` | 200 chapters (~43 KB) in ~1.2 s, `meta.totalPages: 7`; **page 1 is the oldest**, so a novel opens at chapter one; `perPage` caps at **200** (`per_page`/`limit` are ignored) |
| `/chapters/1048273` | the chapter as `<p>` markup (91 paragraphs) plus its prev/next ids |
| `/updates`, `/stories?page=N` | the app's catalogue lists (20 a novel) — the browse feed |

**Why this works in the packaged app (the "android own thing").** WordPress's
`rest_send_cors_headers` *echoes the request's `Origin`*, so the interface is
CORS-open — verified in the page: a plain `fetch(SH_API + "/stories/1048265")`
**resolves and reads its body** (~5.4 KB), while a plain fetch of
`/series/1048265/` is CORS-blocked as always. That is the same property that
makes Novel Cool's app API (`api.novelcool.com`) reachable from a `file://`
WebView: a plain `fetch` gets the data, no proxy and no universal-access
setting needed. Verified with `root.superFetch` deleted (the packaged
simulation): novel, chapter list, chapter text, search and feed all answer.

**The three reported bugs.**

1. **No cover.** `loadCoverImg` sets `img.crossOrigin = "anonymous"` for every
   host *not* in its exclusion list, and `cdn.scribblehub.com` was not in the
   list. That CDN sends **no ACAO header**, so a CORS-mode image request is
   refused and the card/book screen fell back to the coloured letter.
   Measured: `crossOrigin="anonymous"` → `error`; the same URL without it →
   loads (`naturalWidth: 250`). Fixed by adding `scribblehub\.com` to the
   exclusion list and a `cdn.scribblehub.com` case in `coverURLs` (direct URL,
   then `images.weserv.nl`).
   Side effect, same as the other non-CORS hosts (NovelCool, Wuxiaworld, Lib
   Read, NovelHi): a non-CORS image **taints a canvas**, so `cacheCover`'s
   `toDataURL` throws, the `catch` swallows it, and those covers keep no
   `coverCache` entry. Display is unaffected.
2. **The list opening at chapter 194/280.** The old route paged the site's web
   table of contents 15 chapters a page (`?toc=N`, newest first) and depended on
   the `wp-admin/admin-ajax.php` POST (`wi_getreleases_pagination&pagenum=-1`)
   for the whole list. That POST is rate-limited and was measured **refused**
   ("Couldn't reach the site") two runs in five — and when it is refused and the
   paging does not finish, the list stays at the newest fifteen. Now the list is
   `/stories/<id>/chapters`: 200 a page, oldest first, in order, complete.
3. **No author / a cut-off synopsis.** The author regex (`fp_authorname`) is
   stale — the site writes the author only into its `ld+json`/app record — so
   `book.author` was always empty, and the synopsis was `og:description`, the
   blurb the site truncates mid-sentence. Both now come from `/stories/<id>`.

**Chapter number.** The app's `number` is a running index, not the chapter's
number: for `sh-1048265` the glossary is `number: 1` and "Chapter 1" is
`number: 2`. `SH_numFromName(name, fallback)` therefore keeps using a number
written into the title (`^chapter\s*(\d+)`, `^(\d+)\s*[.):]`) and only falls
back to the index for entries whose title has none — which is what keeps
"0.Glossary" from colliding with chapter 1.

**Chapter text.** `/chapters/<id>` hands over the post as `<p>` blocks with
`<strong>`/`<em>`/`<br>` inside, wrapped in the site's spoiler boxes
(`<div class="sp-wrap">` → an `sp-head` title + an `sp-body`). `SH_inline` /
`SH_blocks` / `SH_apiChapterHTML` walk that DOM: paragraphs keep their bold and
italic runs and line breaks, a whitespace-only paragraph is dropped, and a
spoiler's title — which the *site* renders as HTML (`&lt;strong&gt;Status
System&lt;/strong&gt;` is bold "Status System" on the site) — is decoded,
un-marked-up and put in bold above the body it folds.

**What is deliberately kept.** Per the standing instruction (see "WTR Lab"
below), LNReader's plugin sources are never ported. This is the site's own
interface — the same *approach* as Novel Cool — and the site's HTML pages stay
as the fallback: `SH_getBookHTML` / `SH_getChapterHTML` / `SH_parseBooks` /
`SH_tocAll` / `SH_loadRest` are unchanged behind `SH_getBook` / `SH_getChapter`,
and `SH_appPage` falls back per feed job to `latest-series/?pg=N`,
`series-ranking/?pg=N` and `genre/<slug>/?pg=N` (all verified to parse 25 books).

**Verified end to end** (page, live): `sh-1048265` → 883 chapters from
`0.Glossary`/`Chapter 1` in 2.2 s; `sh-526583` → 1243 chapters (5 pages) in
4.8 s; `sh-747093` → 2262 chapters in ~8 s; six chapters spread across the
1243-chapter novel all open (27–579 paragraphs); chapter 600's prev/next are the
list's 599/601; search "shadow slave" → 5 merged results with covers, authors and
ratings; all nine `shapp:` feed jobs answer 20 books each; the same flows pass
with `superFetch` hidden (the packaged simulation). No library, history or
progress change.

## Previously — 2.7.32 (2026-09-30)

The app was on **v2.7.32** — two user-reported fixes, one of them the reason
read-aloud was never usable in the packaged app.

> "Fix tts, when you want to turn it on it will just say, tts turned off. Like
> there's no way to on. And also on WTR novel source there's like title of novel,
> %{Soul Land|RG91bHVv} Peerless: The Demon Emperor Sacrifices, the Martial Soul
> Gaioka, %{Cosmic Star World|U3dhbGxvd2VkIFN0YXI}: After Choosing One of the
> Five, Save Luo Hongguo"

### Read aloud: three engines, and why the switch refused itself (2.7.32)

The bug was not in the switch. `tts.supported` was computed once as
`!!(window.speechSynthesis && window.SpeechSynthesisUtterance)` — and **a WebView
has neither** (MDN browser-compat-data: `webview_android: false` for both
`SpeechSynthesis` and `SpeechSynthesisUtterance`; the browser feature lives in the
Chrome app, not in the WebView). The packaged APK *is* a WebView, so on the phone
`tts.supported` was false, and both toggle handlers did:

```js
READER_SETTINGS.tts = b.dataset.tts === "1";
if (READER_SETTINGS.tts && !tts.supported) { toast("Text-to-speech not supported on this device"); READER_SETTINGS.tts = false; }
...
if (READER_SETTINGS.tts) { ttsPrime(); toast("Read aloud on — …"); }
else { ttsStop(); toast("Read aloud off"); }      // ← the second toast covered the first
```

So tapping **On** flipped the setting straight back and said *"Read aloud off"* —
the "not supported" message was under it — which is exactly what the report
describes. The handlers are now just "set the flag, say so", and everything about
*which voice* happens behind one engine layer:

| engine | who speaks | why it exists |
| --- | --- | --- |
| `web` | the page's `speechSynthesis` | every real browser (the perchance page) |
| `native` | the APK's Android `TextToSpeech`, via `window.LitTts` (the optional bridge in `src/android-plugin/`) | offline, the phone's own voices — the *only* way to speak from inside an app |
| `remote` | an online voice: one GET per sentence of an MP3, played in an `<audio>` element | works anywhere, including a `file://` WebView, with no native code |

- `tts.engine = ttsPickEngine()` — web if it exists, else native if the bridge is
  there, else remote. **`tts.supported` is now always true**: remote needs only a
  connection, so a failure says what went wrong instead of pretending the feature
  does not exist.
- The three engines sit behind `ttsSpeakWeb` / `ttsSpeakNative` / `ttsSpeakRemote`
  and one tiny contract — `onStart`, `onBoundary(from,len)`, `onEnd`, `onFail` —
  so the sentence walker, the highlight, the sleep timer, "keep reading",
  background-pausing and the lock-screen media session are untouched.
- **Media playback is not subject to CORS.** That is the whole reason `remote`
  works in the packaged app: `<audio src="https://translate.google.com/translate_tts…">`
  plays from a `file://` page where no `fetch` could.
- The online voice is **one voice per language**, so its picker is a *language*
  picker (28 of them) and the label says "Language"; the default is the device's
  own language, not English. Three addresses are tried in turn
  (`TTS_ROUTES` = translate.google.com, translate.googleapis.com,
  code.responsivevoice.org/getvoice.php) with a per-session memo of the one that
  worked, and a sentence longer than the ~190-character limit is cut at spaces and
  chained part by part. **StreamElements' Polly endpoint — this was built on it
  first — now answers `401 {"message":"No API key was found"}`, so it is gone.**
- Two hard-won details, both about *not* walking the ladder twice for one failure:
  every attempt gets its **own** `<audio>` element plus a per-attempt record, and
  every event checks that record is still current. A dead request reports itself
  **twice** (a media `error` *and* a rejected `play()`), and a replaced element
  reports late events of its own; measured with two dead addresses followed by a
  working one, the old single-element version burned all three rungs on the first
  address and gave up while a working backup was mid-load.
- No word timings exist in a fetched MP3, so the word highlight is derived from the
  element's clock: the played fraction of the sentence applied to its characters,
  snapped back to a word start (and, when the service streams without a length,
  from an average reading pace instead — otherwise the highlight just sits there).
- An engine that is a *shell* (the browser reports `speechSynthesis`, but the first
  sentence is still silent 2.5 s later with the engine claiming to be idle) is
  swapped for the next one, once, with a message. Verified with a stubbed silent
  engine: web → remote inside 3 s, reading continues.
- A speed change applies to the sentence being spoken: `playbackRate` for the
  online voice, "say the sentence again" for the two speech engines.
- Both settings screens now carry an honest one-liner about which engine is in use
  (`ttsEngineNote` / `ttsEngineNote2`, filled by `renderTtsEngineNote()`).

The Java side is `LitNative.Tts` (`window.LitTts`), registered by the same
`LitNative.attach()` call: `speak(id,text,rate,voice)`, `stop()`, `voices()`,
`ready()`, with events back through `window.__litTts(id, json)`
(`start` / `range` from `onRangeStart`, API 26+ / `end` / `error`). Documented in
`src/android-plugin/README.md`.

**Note for a future session:** the user's APK is built by the browser-side
HTML→APK converter (`perchance.org/2ket13lr99`), which patches a prebuilt
template APK and **cannot compile Java** — so the `native` engine is not
available in *their* build, and `remote` is what actually speaks on their phone.
Don't "fix" read-aloud by assuming the bridge is there.

### WTR Lab titles stop leaking the site's own markup (2.7.32)

The title in the report is WTR Lab's inline "translated name | original"
wrapper: `%{Soul Land|RG91bHVvIERhbHU}` is `Soul Land` (`Douluo Dalu`), and
`%{Giant Hero World|VWx0cmFtYW4}` is `Giant Hero World` (`Ultraman`). It leaked
into the feed, search, the book screen, the reader header and chapter names.
`wtrCleanTitle()` (next to `wtrCleanText`) keeps the readable half and drops the
wrapper; it is applied in `WTL_parseBooks`, `WTL_novelDetail`, `WTL_getChapter`
and the WTR chapter list. `repairBook` cleans titles on load and
`repairWtrTitles()` (boot, 4 s in) cleans the ones already saved in the library
and the history, so a novel added before this update is renamed too.

## Previously — 2.7.31 (2026-09-30)

A user-reported fix: **a page's own punctuation comes out as punctuation,
everywhere, not as `&#8217;`.**

Reported from the packaged app with a screenshot of a NovelFull chapter full of
`City&#8217;s` and `&#8220;quotes&#8221;`, plus "the name of the novel in the feed
has strange symbols too, I forget which sources". The cause was that four
different "clean this text" chains in `index.html` each decoded a *hand-written
list* of entities — `&nbsp; &amp; &quot; &apos; &lt; &gt; &#39;` — and every site
here uses the **numeric** ones (`&#8217;`, `&#8220;`, `&#8221;`, `&#8212;`). Those
went straight to the reader.

### The fix: one decoder, every path (2.7.31)

```js
function decodeEntities(s) { const t = document.createElement("textarea"); t.innerHTML = s; return t.value; }
function decodeText(s) {   // decode until the text stops changing (max 3 passes)
  let out = String(s == null ? "" : s);
  for (let i = 0; i < 3 && out.indexOf("&") >= 0; i++) {
    const next = decodeEntities(out);
    if (next === out) break;
    out = next;
  }
  return out;
}
```

- `decodeEntities` is the browser's own parser (a `<textarea>`), so it knows
  *every* entity — named and numeric — instead of the handful the old chains
  listed. `decodeText` runs it repeatedly, because some of these sites escape
  their text **twice**: Lib Read's chapter titles (`Blessing &amp;amp; Magic`,
  known since 2.7.11), a NovGo chapter name (`&amp;quot;Science&amp;quot; Behind
  Flying`) and the NovelFull chapter bodies above. Decoding until it stops
  changing handles one escape level and two with no per-source guessing; the loop
  returns immediately for text with no `&` in it, so the common case is free.
- **All 106 existing `decodeEntities(...)` call sites are now `decodeText(...)`**
  — every feed card title, book-screen title/author/synopsis, chapter name and
  app-API field goes through it.
- The four hand-rolled chains are gone; the chapter-text cleaners
  (`WP_chapterText` — FW/LR/NF, `NC_chapterText`, `FM_extractChapter`) and the
  one-off pipelines (Webnovel, Scribble Hub, NovelLive/LightNovelPub, NovelHi,
  NovelArrow, and `wtrCleanText` for WTR Lab, whose API returns HTML-escaped
  bodies) now wrap their tag-stripped text in `decodeText` once.
- Also fixed while auditing every tag-stripper in the file: **Royal Road titles
  were being stripped of every entity rather than decoded**
  (`.replace(/&[^;]+;/g, "")` — "A Dragon&#8217;s Tale" arrived as "A Dragons
  Tale"; four sites in `RR_parseFictions` and `fetchBrowsePage`), FanMTL's novel
  title and author and NovelArrow's synopsis were never decoded, and
  `NLP_tocAll`'s chapter names (NovelLive/LightNovelPub) were not decoded either.

### Already-read chapters are repaired, not refetched (2.7.31)

Two places hold a chapter the reader has already seen, and both were written by
the old code — so both would have kept showing `City&#8217;s`:

- the 60-chapter localStorage ring (`yuedu_chapcache_v2`), repaired in place
  at boot (the same shape as the existing WTR watermark purge);
- the deliberate **downloads** in IndexedDB (`yuedu_offline`), repaired by a
  single background cursor pass (`offRepairEntities`, guarded by the
  `yuedu_offline_repair_v1` flag so it runs once per install).

Both use `repairChapterHTML`, which is safe because a stored chapter is one
`<p>` per paragraph and nothing else: the text is decoded out of the stored html
and escaped again, which is idempotent ("no `&` → unchanged"). Measured: a seeded
`<p>City&#8217;s weather…</p><p>&#8220;Hello,&#8221;…&amp;amp;…</p>` came back
`City’s weather…` / `“Hello,”… & …` through both paths, with no refetch.

### Verified (2.7.31)

Every source, live, reading real chapters and scanning the **visible** text (the
rendered html decoded once, so properly-escaped `<` isn't mistaken for a bug):
NovelFull, NovGo, FreeWebNovel, Lib Read, Novel Cool, FanMTL, Webnovel,
NovelArrow, NovelHi, Royal Road, Scribble Hub, Wuxiaworld, WTR Lab — chapter
text, chapter names, titles, authors and synopses all free of entity codes, with
real `’ “ ”` characters present in the text (e.g. NovelFull ch.1: 36 of them).
NovelLive and LightNovelPub could not be read on the day (their backend timed out
/ answered a bot check; they share `NLP_*` with the rest and their *chapter
names* were verified clean through their book listings).

## Previously — 2.7.30 (2026-09-30)

The app was on v2.7.30, which takes the same lesson Novel Cool taught in 2.7.29
and applies it to the four "readnovelfull" sites: **their chapter lists are read
as data, not scraped off their pages.** Nothing about a novel's *details* or its
*chapter text* changed — this is the chapter-list route only, and every one of
them keeps the page-scraping route underneath as a fallback.

### Chapter lists from the sites' own JSON (2.7.30)

Three new loaders in `index.html` (`WP_loadAjax`, `NF_loadCatalog`,
`NF_parseChapterOptions`, all next to `WP_loadRest`) replace the old per-page
HTML pump for FreeWebNovel, Lib Read, NovelFull and NovGo. Measured before any of
it was written, on *My Vampire System* (2,545 chapters):

| Source | Route | Shape | Cost |
| --- | --- | --- | --- |
| FreeWebNovel | `GET /novel/<slug>?ajax=chapters&page=N&pageSize=200` | `{code, html, page, pageSize, totalPage, totalChapters}` — `html` is the same `<li>` anchors the book page embeds | 13 × ~40 KB, ~3.3 s (was 64 whole book pages of ~87 KB) |
| Lib Read | `GET /libread/<slug>-<id>?ajax=chapters&page=N&pageSize=200` | identical (one theme, two hosts) | 13 × ~41 KB, ~3.4 s |
| NovelFull | `GET /ajax-chapter-option?novelId=<id>` | the novel's own chapter dropdown: every chapter as one `<option>`, `value="/<slug>/chapter-N-title.html"` | **1 × ~290 KB, ~2.9 s** |
| NovGo | same as NovelFull | same | 1 request |

- `pageSize` is capped at 200 by the FW/LR hosts (asking for 5000 still answers
  200 and reports the true `totalPage`), so the pump knows exactly how many pages
  there are instead of guessing. It fetches them six at a time, three in flight —
  the same shape as the old `WP_loadRest` loop it falls back to.
- The fwn dropdown is **one request for the whole list**, and it is richer than
  the book page's list: every option's label is the chapter's full title, so
  titles read "Chapter 1201: The Dalki leaders".
- `novelId` is the numeric id the book page publishes for its own endpoints
  (`#list-chapter[data-novel-id]`) — *not* the slug. `/ajax-chapter-list?novelId=`
  with the slug answers `{"code":404,"message":"Novel not found."}`.
- If the dropdown is short of the page's `data-total-chapters`, the rest comes
  from `GET /ajax-chapter-list?novelId=<id>&page=N` (`{code, html, totalPage}`),
  the endpoint the site's own "load more" calls. If *that* adds nothing, the list
  is the site's own complete answer and the loader stops: **Shadow Slave's
  dropdown carries 3,189 of the 3,193 its page claims, with no duplicates at all**
  — the missing four are genuinely absent from the dropdown, so treating that as
  a failure would re-crawl the whole book page for chapters that do not exist.
  The completeness count is options that carry a chapter URL, so a placeholder
  `<option>` cannot inflate it.
- **Fallback, tested:** an empty fragment (the site changed its markup), a
  non-JSON answer, a bot check, or a 404 falls back to the old page-by-page pump
  — `WP_loadRest` for FW/LR, and the same cfg for NF/NG. Verified live by
  pointing both loaders at novels that do not exist (`no-such-novel-xyz`, a bogus
  `novelId`, and an empty `novelId`): the fallback fires in all three cases.

### The fwn sites' own URL typos, and chapters listed twice (2.7.30)

Two real defects in these sites' data, both found while measuring the dropdowns:

- **Mistyped chapter addresses.** Shadow Slave has `/shadow-slave/chatper-276-black-door.html`,
  `chpater-2812-…`, `chaoter-2843-…` and `chapter-entertaining-guest.html` (no
  number in the URL at all, labelled "Chapter 3189 Entertaining Guest"). The old
  parser matched `chapter-([\d.]+)`, so those four chapters were not in the app's
  list and could not be opened from it — Shadow Slave listed 3,189 of its 3,193.
  The URL match is now `/ch[a-z]*-` and the number comes from `NF_numFrom` (the
  URL's leading digits first, the label's first number as the fallback), so all
  four are listed and readable (45/58/54/95 paragraphs, verified): **3,193/3,193**.
  `NF_labelName` uses `^ch[a-z]*\s*[\d.]+…` for the same reason, so a typo'd
  label loses its prefix like every other row ("Chatper 276 Black Door" →
  "Black Door"). The reader header still shows the site's own page title, typo
  and all.
- **Two chapters under one number.** `/my-vampire-system-v122` lists both
  "Chapter 1074: The Mighty Cruncher" and "Chapter 1074: Millennial History Part
  2" (also 1641, 1962, and 4 such pairs on Shadow Slave). Folding by number —
  what both parsers did — lost the second one outright. `NF_uniqueId` now gives
  the later one a titled id (`1074~millennial-history-part-2`) while keeping
  `num: 1074`, and `NF_getChapter` falls back to a numeric match, so a bare
  number (which is what the chapter page's own `data-nav` anchors report) still
  resolves to the first chapter carrying it. Verified: both halves of 1074 read
  as different chapters, and a plain `"1074"` still opens the first.

### What was *not* done, and why

The audit that led here also read LNReader's plugins for the other sources. Two
things worth recording so a future session does not redo them:

- **Do not port WTR Lab's API route.** LNReader's `wtrlab` plugin (`/api/chapters/<rawId>`,
  `POST /api/reader/get` with an AES-GCM body whose key is dug out of the site's
  JS bundles) is **explicitly off-limits** — the user has said in as many words
  that that source does not work and cannot get anything, and that YueDu's
  own WTR route is the one with the advantages (it asks from the device's own
  connection, so the per-address limit is the user's, not the shared server's,
  and the Unlock flow can hand a challenge to a real WebView). YueDu's WTR
  implementation stays exactly as documented under "WTR Lab" below.
- **The rest have no such API to take:** FanMTL (`readwn`), Royal Road, Scribble
  Hub and Wuxiaworld are scrape-only in that repository (Wuxiaworld is
  gRPC-web + protobuf behind `api2.wuxiaworld.com`, not worth it), NovelArrow
  already reads `api-web/novels/…` JSON (2.7.x), and Webnovel already reads its
  own API. So FW/LR/NF/NG were the whole remaining win.

## Previously — 2.7.29 (2026-09-30)

The app was on v2.7.29, which **makes every Novel Cool novel readable in the
app** — including the ones the site wraps its chapter links on, which is what the
four versions before it were circling. The way in is the one thing that had not
been tried: Novel Cool's **own Android app API**.

### Novel Cool: reading it the way its own app does (2.7.29)

Asked, reasonably, *"How is LNReader fine, and ours not?"* — with the LNReader
plugin repository as the pointer. Reading that repository answers it exactly:
LNReader's Novel Cool plugin never touches the website. It POSTs to
`api.novelcool.com` carrying the *app's own* identity (`appId`, `secret`,
`package_name`, `lang`), and that API hands over the whole catalogue (the
reference is `github.com/LNReader/lnreader-plugins`, branch `plugins`,
`.js/src/plugins/english/NovelCool[novelcool].js`, indexed by
`.dist/plugins.min.json`):


| Endpoint | What it answers |
| --- | --- |
| `POST /book/search/` | `keyword`, `lc_type:"novel"`, `page`, `page_size` — novels with cover, author, intro, genres, rating/votes and the numeric book id |
| `POST /book/info/` | `book_id` — one novel's details (`name`, `author`, `intro`, `category_list`, `rate_star`, `completed`, `first_chapter_id`, `last_chapter_id`, …) |
| `POST /chapter/book_list/` | `book_id` — **every chapter**: `id`, `title`, `is_locked`, `order_id`, newest first |
| `POST /chapter/info/` | `chapter_id` — **the chapter text** (`info.content`), plus `prev`/`next` |
| `POST /elite/{hot,latest,new_book}` | the app's front page, 20 novels a page |

The credentials are the published Android app's own and sit in `index.html` next
to `NC_APP` (`package_name` is Novel Cool's own `com.zuoyou.novel`, appId
`202201290625004`). **Verified before a line of it was written** — through the
app's `sfPost` and through the bare `fetch-plugin` proxy route the packaged build
falls back to: a novel's page is ~3KB of JSON and its whole chapter list ~300KB,
where the site's own equivalents are 0.5–3MB of cloaked markup, and a chapter is
~8KB.

What that changes:

- **A Novel Cool novel opens with its whole chapter list readable.** The list comes
  from `/chapter/book_list/`, numbered from the chapter titles with the same
  helpers the site route uses (`NC_numFromTitle`/`NC_chName`), the rows a novel
  lists twice folded into one (2,556 chapters for *My Vampire System*, 1,201 for
  *Beast Taming: Starting From Zero*), and **no note** — `NC_listNote` returns ""
  because every chapter has a link. The ↗ "opens on Novel Cool" note + arrow of
  2.7.25–2.7.28 is gone for every novel the app carries.
- **Chapters read in the reader**, from `/chapter/info/`, so the download arrow is
  back on every row. Each chapter keeps the site's shareable address
  (`/chapter/x/<id>.html` — the slug in a Novel Cool chapter URL is decorative,
  verified on two ids) as its `href`, which is also the fallback if the API refuses
  that one chapter. The app's chapter id is the same id the site's pages use, so
  stored reading positions, bookmarks and history still line up.
- **Chapter text arrives in two shapes**, both handled by `NC_appText`: proper
  `<p>…</p>` markup, or *bare* opening `<p>` tags with no newlines at all
  (`…<p>Then a dreaded thought hit his head.<p>****`). The second shape is why an
  opening block tag counts as a paragraph break, not just a closing one — measured
  at 43–110 paragraphs per chapter across both shapes. Chapters of other novels are
  plain text with blank lines, split on newlines. A leading line that is the
  chapter's own heading is dropped, since the reader prints the heading itself.
- **Search** asks the app *and* the site's own ajax search (`NC_apiSearch`) at once
  and keeps the union, app rows first — the two catalogues do not hold the same
  books (app 15 / site 10 for "Beast Taming", and the site adds the manga beside
  them). App rows carry `appId`, so a novel is filed with the id its chapters need
  and its card gets cover, rating, author and genres. `appId` is plumbed through
  `gridResult` → `data-appid` → both card click handlers → `openBookDetail` /
  `addToLibrary`, and `enrichBookDetails` copies it into the library record.
- **The Novel Cool shelf** (`buildDiscoverJobs("NovelCool")`) is the app's front
  page now: `ncapp:<hot|latest|new_book>:<page>` jobs, handled at the top of
  `fetchBrowsePage`, giving 20 novels a page with covers and ratings where the
  site's category pages were 0.5–3MB each and their novels arrived wrapped. Label:
  "Popular on NovelCool".
- **Finding the app's book id** for a novel already in a library: `NC_appFindId`
  takes `book.appId` when the record has it, the number in an
  `/novel/original/id-NNNNNN.html` bookId (that number *is* the app's book id —
  verified on two such novels, whose `/book/info/` name matches the web page), and
  otherwise searches the app's catalogue by the novel's title, believing a row only
  when its slug or its whole name matches. The id is written onto the book
  (`book.appId`) so later opens skip the lookup.
- **Nothing was thrown away.** Every Novel Cool route still falls back to the site's
  own pages — search, `NC_getBookFromSite`, and `NC_getChapter`'s chapter page — so
  if these credentials stop being accepted the source degrades to precisely its
  2.7.28 behaviour (verified: the site route still returns MVS's 2,556 chapters
  with 1 readable and 2,555 siteOnly). Rows the app marks `is_locked` (VIP) are left
  out of the list, as the official plugins leave them out — 0 across 15 sampled
  novels, so in practice nothing is missing.

**Superseded:** the Novel Cool sections below (2.7.28, 2.7.27, 2.7.26, 2.7.25)
describe the site route's limits — "only the newest chapter opens here", the
stored-links fix, the note and its Migrate button. They remain accurate *about the
site route* and are kept as history; the app route above is what the source uses
first now.

## Previously — 2.7.28 (2026-09-30)

2.7.28 made the Novel Cool **note** honest and useful:
it is recomputed from the chapter list the device is holding every time a novel's
screen is drawn (it used to be written onto the book once and left there, so it
could sit a version behind — a reader's screenshot still showed 2.7.25's wording —
and could stay on a novel whose chapters all open), and when the note is real it
now carries a **button** straight into *Find on another source* (filing the novel
first if it is not in the library), instead of a sentence pointing at a Migrate
button that is greyed out for exactly that novel. 2.7.27 is underneath it — the
Novel Cool correction and the stored-links fix — and the sections for both are
below; 2.7.26 (Find on another source does the looking), 2.7.25 (the Novel Cool
chapter list work) and the rest of the roll-up follow them.

### Novel Cool: the note on the book, and the arrow where the download button sits (2.7.28)

Reported from the APK, on *My Vampire System*: *"Why is the message still there,
and the thing that replaced the download icon?"* Both halves are answered by the
same fact — that novel's chapter links are wrapped, so the app has no address for
those chapters — but the first half was also a real bug:

- **The note was stored, not derived.** `listNote` is part of the book record, and
  a book that already has a chapter list *and* a synopsis is never asked for again
  (`openBook` only enriches a book with no synopsis or no catalog), so the note
  written by whichever version first fetched the list stayed on the screen — the
  reader's screenshot still carried 2.7.25's wording — and would have stayed on a
  novel whose chapters all open, too. `syncNCNote(book)` now runs at the top of
  `renderBookScreen`: for a Novel Cool book it recomputes the note from
  `book.chapters` (`NC_listNote`) and writes it back to the library only when it
  changed. A novel that reads is never told that it does not.
- **The note now has the way out in it.** `chapterListHead` puts a
  `.clnBtn` — *Find this novel on another source →* — inside the note for a Novel
  Cool book that has one; `ncMigrateFromNote(book)` files the novel in the library
  first (the same route the reader's captcha screen uses, because the progress
  that travels needs a record to travel with) and opens `openMigrateScreen`. Before
  this, Migrate was disabled for a novel with chapters that is not in the library
  yet — precisely the novel whose note says to use it.
- **The arrow.** `chapterItemHTML` shows the download icon when it has a link, a
  lock for a VIP chapter, and the ↗ "open on Novel Cool" icon when the chapter is
  `siteOnly`. A chapter the app has no address for cannot be downloaded by any
  build (the wrapped ad-redirect *is* its only address), so the arrow is the one
  useful thing that slot can do. Chapters that *do* have links — everything on a
  novel Novel Cool serves plainly, and anything kept from a stored list — keep
  their download arrows unchanged.

## Previously — 2.7.27 (2026-09-30)

The app was on **v2.7.27**, which **corrects the Novel Cool conclusion of the two
versions before it**, and then fixes the thing the correction exposes: Novel Cool
wraps the chapter links of *some* of its novels, not all of them, so a Novel Cool
novel the site serves plainly has always read in the app like any other novel —
and a refresh now keeps chapter links the device already has instead of replacing
them with "opens on Novel Cool" stubs (which is what made a novel that read fine a
moment earlier stop reading, while the old 2.4.2 build kept reading it by
accident). Both sections are below; the raw evidence for the wrapped links is kept
under them.

2.7.26 is underneath it — **Find on another source** does the looking: it asks
every other active source for the novel's title at once, and when one of them lists
it, the best match (exact title, most chapters) is selected with its result already
listed — two taps from "this source cannot serve this novel" to reading it
somewhere that can (`migrateAutoFind`). For *My Vampire System* that lands on
**NovelArrow**, which carries the **complete 2,545 chapters** (chapter 1 through
"The Last Goodbye, Goodbye Quinn Talen") and reads them in the app. 2.7.25 is under
that — a Novel Cool novel opens with its **whole chapter list** (2,556 chapters for
*My Vampire System*, chapter one to the newest) instead of the single newest
chapter, and each chapter the app cannot fetch itself is **one tap from your
browser**, carrying the site's own link for that exact chapter. 2.7.24 is under
that (the packaged app asks from the device), 2.7.23 under that (NovelLive /
LightNovelPub are one site with four addresses), and the rest of the roll-up is
below.

### Novel Cool: which of its novels can actually be read in the app (2.7.27)

2.7.26 answered the reader's question — *can Novel Cool be read in the app?* — with
**No**. That was too broad: Novel Cool wraps the chapter links of **some** of its
novels and leaves others alone, so the answer is a property of the novel, not of
the site. The reader who pushed back had built the old 2.4.2 standalone to check,
and was reading a Novel Cool novel in it — "goes to like 800 chapters" — which is
exactly what an unwrapped novel does. Measured (all through the app's own `sf`, in
one session, on the same day):

| novel | page | chapter rows | rows with a plain `/chapter/…` link |
| --- | --- | --- | --- |
| *My Vampire System* | `/novel/My-Vampire-System.html` | 2,610 | **2** (the newest chapter, listed twice) |
| *Beast Taming: Starting From Zero* — the novel in the reader's own library | `/novel/original/id-263564.html` | 1,201 | **1,203** — every chapter |
| *The Strongest System* | `/novel/The-Strongest-System.html` | 1,158 | 1 |
| *Seized by the System* | `/novel/Seized-by-the-System.html` | 1,166 | 1 |
| *God of Soul System* | `/novel/God-Of-Soul-System.html` | 757 | 1 |
| *Fantasy System* | `/novel/Fantasy-System.html` | 290 | 1 |
| *Ultimate Assassin System* | `/novel/Ultimate-Assassin-System.html` | 13 | 1 |
| *Unscientific Beast Taming* | `/novel/Unscientific-Beast-Taming.html` | 1,962 | 1 |

Everything sampled from the site's **search results** (the modern
`/novel/<Slug>.html` template) was wrapped, and the one unwrapped novel found is the
**legacy `/novel/<folder>/id-<n>.html`** form the reader's library still holds —
a form the site no longer links: 145 novel URLs harvested from eight
`/search?name=` pages contained **zero** of them, so there is no "ask for the
unwrapped URL instead" trick to generalise from. (`/novel/original/id-156617.html`
— a wrong novel id — answers the site's 498 KB catch-all page, not a novel.)

What that means in practice:

- A wrapped novel: only the newest chapter reads in the app; the rest need the
  browser or Migrate. That is what 2.7.25/2.7.26 described.
- An unwrapped novel (the reader's own): **every** chapter reads in the app —
  verified `NC_getBook("nc-original~id-263564")` → 1,201 chapters, 1,201 with a
  link, no note. Nothing in 2.7.25/2.7.26 changed that, and nothing needed to.
- **What is wrapped is the link, never the chapter page.** A
  `/chapter/<slug>/<id>.html` address fetches and parses exactly as it always did
  (re-verified: My Vampire System 2545 → 53 paragraphs, 9,536 chars, read through
  `NC_getChapter`). So a link saved before the site started wrapping is still good
  — which is the whole of the next section.

### Novel Cool: a refresh no longer throws stored chapter links away (2.7.27)

Because chapter pages were never wrapped, a library entry saved while Novel Cool
still handed its links out holds a chapter list that **still works**. 2.4.2 never
lost it: its `NC_getBook` threw when a parse came back with no chapters, and
`enrichBookDetails`' catch left `book.chapters` alone — so the novel kept reading,
which is why the older build "works well". 2.7.25 made `NC_getBook` stop throwing
(so a book screen could explain itself), and the same refresh then **replaced** the
stored list with the fresh one, in which every chapter but the newest is
`siteOnly`. A novel that read a moment earlier stopped reading.

Measured on the 2.7.26 code, with a stored list on a cloaked novel
(*My Vampire System*, chapter 100 given a link), `enrichBookDetails(book)`:

- before (2.7.26): chapter 100 → `{ id: "ncnum-100", siteOnly: true }` — the link and
  the real id **gone**; 1 readable chapter in 2,556.
- after (2.7.27): chapter 100 → `{ id: "11111111", href: "/chapter/…/11111111.html" }`
  — link and id kept; a chapter the fresh list no longer carries at all is kept
  too; 3 readable in 2,556.

The rule now lives in one place: `NC_mergeStoredLinks(fresh, stored)` keeps every
link (and real id) the stored list had, matched by chapter number, and keeps
stored chapters the fresh list does not have; `applyFreshChapters(book, fresh, lib)`
applies it for Novel Cool books only (other sources may legitimately renumber);
`noteOn(book, cat)` rebuilds the note from the list the device ends up with, so a
novel with restored links is no longer told that only the newest chapter opens.
All three are used by `enrichBook`, `enrichBookDetails` and `doRefresh` — every
path that can put a fresh list on a book. The general principle, now written into
the comments: a source that comes back **thinner** than the device must never wipe
what the device has.

### Novel Cool: what those wrapped links really are (2.7.26)

*(2.7.26's "can it be read in the app? **No**" is corrected above: it holds for a
novel whose links are wrapped, which is most of the novels the site's search
returns, but not for one it serves plainly. The evidence below is still what
applies to a wrapped novel.)*

The user asked directly: *"any is there a way to make it work by the Apk Forge?
That ad protected fix it on novelcool."* The answer is **no**, and this is the
evidence, so nobody spends another day on it.

- The wrapped links go to `mechanismexplained.com` / `explorefunctionality.com` /
  `workexplained.com`, which are **ad-arbitrage domains** — the real destination is
  chosen server-side and never exposed, and anything that is not a JS-capable
  browser gets a monetised page instead of the chapter. Measured: Google's "enable
  JavaScript" page (`<title>Google Search</title>`, `/httpservice/retry/enablejs`),
  a *WeReviewAiTools* article ("Tavern AI Review: Taverna cards…") rendered by
  `r.jina.ai`'s headless Chrome, and `HTTP 429` pages whose `<title>` is
  `https://www.google.com/search?q=wereviewaitools`. Full Chrome navigation headers
  (mobile UA, `Accept-Language`, `Sec-Fetch-*`, `Upgrade-Insecure-Requests`, a
  novelcool.com `Referer`) change nothing, and neither does the packaged app's
  own device-side request. So the destination is **not derivable** by any request
  the app can make.
- A WebView **navigation** would follow the redirect (its JavaScript runs), but the
  page it lands on is cross-origin — the app's own JavaScript cannot read it, and
  the chapter cannot be lifted out of it. `window.name`, `postMessage`, a hidden
  iframe, a service worker: none of them bridge a cross-origin navigation.
- **The APK Forge (`2ket13lr99`) cannot close that gap.** Read out of the template
  DEX, its only knobs are `url` / `sourceType` (`url` | `local`),
  `localEntryFile`, `links`, `darkMode`, `nonFullScreen`, `edgeToEdge`,
  `disablePullToRefresh`, plus package name, version, label and icons. There is no
  key for injected JavaScript and no way to add native code; the only JavaScript
  bridge is `ToAppExport` (`saveBlob`, `recordExportName`). No build setting can
  make the app read another origin's page.

**What does work, and what the app now points at:** the app's own site screen or
the phone's browser for that one chapter (`NC_openOnSite` → `NC_resolveAd`), and —
the better answer for actually *reading* — the same novel on another source:
**NovelArrow** (`na-my-vampire-system`, all 2,545 chapters, verified: ch1 8,434
chars, ch2545 9,540 chars), FanMTL (`fm-my-vampire-system`), FreeWebNovel,
NovelFull, NovGo, Lib Read. `migrateAutoFind` finds and offers them itself.

### Novel Cool: the whole list, and where the chapters open (2.7.25)

Reported from the APK: *"Fix novel cool"*, with a screenshot of *My Vampire System*
showing the red note and a single chapter (2545).

**What the site does.** A Novel Cool book page (2.9 MB for that novel) carries its
*entire* chapter list — 2,610 `<div class="chp-item">` rows — but each row's link
is `<ad-domain>/go/rds/?data=<ciphertext>` (`mechanismexplained.com`,
`explorefunctionality.com`, `workexplained.com`), and **only a real browser can
follow one**: every fetch of those addresses from the app (superFetch, plain `sf`,
jina, corsworker, allorigins, codetabs, and the packaged app's own device request)
comes back with **Google's "enable JavaScript" interstitial**. The page's own
scripts do exactly what a person does: `document.location.href =
$("#prev_chp_url").text()`.

**What could not be worked out.** The clear numeric id in a chapter URL is
mandatory and globally auto-incremented — **not** contiguous per novel (11647474 /
11647475 are C2544 / C2545 of this novel, but 11645930 is a different novel and
11647373 does not exist), so ids cannot be derived arithmetically; the slug is
decorative (`/chapter/x/11647474.html` serves C2544). The ciphertext is real AES
output (256–352 hex chars, no repeating XOR key) and is **resealed on every page
load** — the same chapter gets a different blob on each fetch — so an old blob is
not safe to keep. `/ajax/<guessed>/` answers a 5-byte `wrong`,
`api.novelcool.com` answers `{"error_code":"1000","error_msg":"wrong app info"}`,
`robots.txt` is a 404 page, and the site's `sitemap.xml` lists 401 URLs of which
only the newest chapters site-wide are chapters. LNReader has no Novel Cool plugin
to borrow from.

**What the app does now.** `NC_parseChapters` reads the list from the ad-wrapped
rows themselves (each row's `title` carries the chapter number and name), merges in
the clear links (the newest chapter, which keeps its real numeric id — that is what
reading history is filed under), and folds the 54 rows Novel Cool lists twice into
one. Chapters with no clear link are marked `siteOnly` and get an arrow in the list
where the download button would be; `NC_getChapter` throws `{siteOnly: true}` for
them, and the reader's error branch shows the "opens on Novel Cool" card whose
button calls `NC_openOnSite`. That re-reads the novel's page **at the moment you
ask** (`NC_resolveAd`), because the seals are per-load, and hands the fresh link to
the wrapper's WebView screen, a new tab, or the in-page site screen. The ad links
are never written to the library — 2,556 × ~390 bytes is most of a megabyte of
localStorage, where the library and every other novel live — and the session map
`ncAdLinks` (three novels' worth) is only the fallback for when the site will not
answer at all.

## Previously — 2.7.24 (2026-09-30)

The app was on **v2.7.24**, which changes **who asks** in the packaged app: the APK
now makes its requests **from the phone itself** instead of through the shared
perchance proxy the page uses. That is what the user's converter-built APK was
always capable of — the ToApp-style shell enables `setAllowUniversalAccessFromFileURLs`
for local sources — but YueDu never had a route that used the device, so every
request in the APK left through the same proxy address that NovelLive /
LightNovelPub's bot check refuses. Details and the reverse-engineering below.

2.7.23 is underneath it: **NovelLive and LightNovelPub are one site with four
addresses** — `novellive.com`, `novellive.app`, `novellive.net`,
`lightnovelpub.me` — and the check in front of them decides **address by
address**, not chapter by chapter. Measured: chapters 4 and 17 came back from
`lightnovelpub.me` in ~8s while `novellive.com` refused one and hung on the other,
and chapter 3 came back from `novellive.com` *and* `lightnovelpub.me` in 30ms
(cached) while `novellive.app` and `novellive.net` were both challenged. That is
exactly the "novelpub works, NovelLive doesn't" report from the APK — same site,
different address in front of it. `nlpFetch` asks them in a staggered race and
remembers which one answered.

2.7.22 is under that, and it is what corrected 2.7.21's wrong claim that those two
sites can never be read by the app: their bot check turns away *runs* of requests
and then lets one through, so a refusal is not a verdict. 2.7.21 is under that: the
"open the site" flow — the app's own page is never navigated off YueDu, the
logo splash is a first-run thing, and the app no longer announces "reconnected ✓"
and teleports to the source feed after a probe that only ever asked the site's
front page.

The four 2.7.20 source fixes are below that: **Scribble Hub opens from chapter
one, with the whole list**, **Novel Cool covers** in the browse/search feed and
**Novel Cool novels opening properly**, and **NovelLive / LightNovelPub no
longer spinning for ever** on a chapter. The 2.7.19 fix is under that — **the
source health check is quick and honest**, asking the transport layer (which
hedges its routes) instead of walking each route one at a time. The three
2.7.18 fixes are under that: **the reading percentage** on continuous scrolling
carries as many decimals as it takes for one chapter to move it, a **NovelHi
novel no longer opens announcing it has no chapter list** (a proxy was handing
back a cleaned copy of the page with the list stripped out), and the **shelf
picker is a centred card** like the sleep timer. Underneath those is 2.7.17's
set of six, each with its own section: **continuous scrolling**, **reader
shelves**, **incognito reading**, **read aloud in the background**, the **sleep
timer** card, and the **readers-online count** in Settings → Advanced. Below are
2.7.16's **offline downloads** and 2.7.15's rebuilt read-aloud engine.

### The packaged app asks from the device now (2.7.24)

Reported from the APK: *"the novelpub works, but not novellive"* — and the answer
turned out to be about **who is asking**, not only about the sites.

The user's APK is built by an HTML→APK converter generator (`perchance.org/2ket13lr99`,
a browser-side clone of ToApp; the user attached its rendered page). It patches a
prebuilt 8.5 MB WebView **template APK**: it rewrites `assets/app_config.json`,
patches the binary `AndroidManifest.xml`, bundles the user's files into
`assets/web/`, renders the launcher icons and re-signs (APK Signature Scheme v2) —
all in the browser.

What that shell does for a local source, read out of the template's DEX
(`MainActivity.setupWebView`, via the converter's own `src/apk/dex.js` parser):

| config / API | shell behaviour |
| --- | --- |
| `sourceType: "local"` (what the converter writes for **Single HTML** and **ZIP**) | `WebSettings.setAllowUniversalAccessFromFileURLs(true)`, `setAllowFileAccessFromFileURLs(true)`, `setMixedContentMode(…)`, `setMediaPlaybackRequiresUserGesture(false)` |
| `url` | `file:///android_asset/web/index.html` for local sources (`assets/web/` is where the files are bundled) |
| cookies | `CookieManager.setAcceptCookie(true)` + `setAcceptThirdPartyCookies(webView, true)` |
| user agent | a desktop Chrome UA (`…Chrome/131.0.0.0 Safari/537.36`) via `setUserAgentString` |
| JS bridge | one interface, `ToAppExport` (`saveBlob`, `recordExportName`) — for saving exports; no network call on it |

Two consequences:

1. In the APK the page **can** fetch any site straight from the phone — universal
   access from file URLs is exactly what switches CORS off for a local page — and
   the third-party-cookie setting means the WebView's jar (a `cf_clearance`
   collected in the in-app site screen) rides along on those requests.
2. YueDu never asked. `getTransports` offered `superfetch`, the perchance
   proxies, `jina`, `corsworker`, `allorigins`, `cors.lol` and the bridge — **no
   route that used the device**. Every request in the APK therefore left through the
   same shared proxy address as the page, and that is the address NovelLive /
   LightNovelPub's check refuses on every page that is not already cached.

What 2.7.24 adds: a **`direct`** transport, offered **first** in the packaged build
(`packagedBuild()` — i.e. no `root.superFetch`), asking with
`credentials: "include"` so the WebView's cookies go with it. It is listed in the
`FOREIGN` map with the other not-our-network routes, so the hedge treats the device
as a separate network. In the page it is not offered at all; in a wrapper that did
**not** enable universal access it fails immediately and the fallback is exactly the
old behaviour — measured in the preview with `root.superFetch` hidden: `direct`
failed in ~0.6 s (a browser's CORS refusal) and the chapter still loaded, 38,360
bytes in 1.9 s, via the bridge route. `httpText` grew a fifth `init` argument (merged
into the `fetch` init) so the `credentials` mode can be set per transport.

`NovelHi` already had a `direct` route of its own (`NH_routeDirect`); `NH_standalone()`
is now just `packagedBuild()`, so there is one definition of "this is the packaged
build".

Still true from 2.7.23, and complementary: NovelLive and LightNovelPub are one site
with four addresses, each caching a different set of chapters, so `nlpFetch` still
asks all four in a staggered race. In the APK the direct route makes that dance
largely unnecessary — from the phone there is no shared address to refuse.

#### Inspecting the converter (recipe for a future session)

`fetch_generator("2ket13lr99")` returns its `main.pjs` + `index.html`; the APK
building lives in its `src/`, whose files are hosted at
`https://user.uploads.dev/file/<key>.<ext>`. The live page embeds the whole
manifest, so load it and read the `"<path>":{"key":"<32-hex>.<ext>","size":N}`
pairs, then `fetch_url` each key of interest. `src/template.apk` is the shell
(`src/apk/build.js`, `axml.js`, `sign.js`, `zip.js`, `dex.js`, `icon.js` are the
machinery). `src/apk/dex.js` is a real DEX reader/patcher — it parses
`string_ids`/`method_ids`/`class_defs` and walks code items, which is how the
`setupWebView` call list above was read and how the Immersion Mode patch rewrites a
`show()` call to `hide()`. Note the template's shell is Kotlin + Jetpack Compose:
`classes.dex` is 13 MB and `classes2.dex` 8.3 MB, and `com.example.template.MainActivity`
is the WebView host.

### One site, four addresses — the NovelLive fix (2.7.23)

Reported from the APK: *"the novelpub works, but not novellive"*. That report is
the fix: those two are **the same backend** — the same slugs, the same chapter
ids, the same bytes — so if one of them reads and the other does not, the
difference is the **address**, not the chapter.

Measured here (Sept 2026), through the app's own transport (`sf()` →
`hedgedGet` → the perchance proxy):

| what | result |
| --- | --- |
| `/ajax/get-list-chapter?novel_id=shadow-slave` on `.com` and on `.me` | both 200, both **398,861 bytes** — identical |
| `/book/shadow-slave/chapter4-mountain-king` on `.com` / `.me` | `.com` refused (~7.6s) / `.me` **200, 40,009 bytes** (8.9s in the first run, 2.5s once staggered) |
| `…/chapter17-three-simple-words` | `.com` timed out (30s) / `.me` **200, 39,306 bytes** |
| `…/chapter3-the-strings-of-fate` | `.com` and `.me` both **200, 38,360 bytes** in ~25ms (cached); `.app` and `.net` both challenged |
| `…/chapter2-slave-caravan` | refused on all four at once (25s to find that out) |
| `novellive.app`, `novellive.net` | the same backend (ch1 was 200 in 4.8s on `.app`) — their own CF zone and cache state |
| `lightnovelpub.com` | **a different, shut-down site** ("Light Novel World Platform Shut Down") — not part of the pool |
| `novelpub.com` | a different site entirely |

How it is wired (all in `index.html`):

- `NLP_HOSTS` maps each source to its four addresses, primary first;
  `NLP_ordered` puts the address that answered last time (NLP_GOOD_HOST) in
  front.
- `nlpFetch(name, path, opts)` races them **staggered by 2.5s** — the first
  address immediately, the next a couple of seconds later if nothing has
  answered, the rest never started once one has answered — so a mirror with the
  page cached wins in ~2.5s instead of waiting out the address in front of it.
  An `e.notFound` / `e.contentless` answer is the site's answer about *that URL*
  and is re-thrown rather than swept.
- `NLP_GOOD_HOST[name]` remembers the winning address for the session; measured,
  the chapter after a mirror win came back in **19ms** (and a cached primary in
  **15ms**).
- On a mirror win the source's dot is put back to `ok` and `healthSticky`
  cleared — the refusal that preceded it was about the other address, and the
  health check must not skip the source for ten minutes because of it.
- `sourceForURL` now maps `novellive.app` / `novellive.net` to **NovelLive**, so
  status, `lastBlockedUrl` and the "open the site" hints all agree.
- `NLP_getChapter`, `NLP_tocAll`, `NLP_getBook` and the rating fetch go through
  `nlpFetch`. `NLP_searchBooks` (a POST), `NLP_loadRest` (the paging fallback)
  and the browse feed URLs keep their existing behaviour deliberately.
- The 2.7.22 reader retry is **skipped for these two sources**: four addresses
  have already been asked, so `startReaderBlockRetry` would be the same four
  refusals again. The card goes straight to the honest final message, with
  wording for it ("*Every address NovelLive answers on was asked …*") —
  `readerBlockCard(book, chapterId, final, swept)`.

Measured in the preview after the change (NovelLive, Shadow Slave, memory
cleared before the first call): chapter 4 **2.5s** (won on `.me`), chapter 2
**25s → refused on all four** (honest card), chapter 301 **20.7s → refused on
all four**, and with `.me` already remembered chapters 17 and 3 came back in
**19ms** and **15ms**. Before the change the same chapter 4 took **17.6s** (it
waited `.com` out first) and finding out that every address refuses took **~100s**,
because the addresses were asked one after another with no stagger.

### NovelLive / LightNovelPub are readable, intermittently (2.7.22)

The reader asked for this to be checked properly — pick a novel on each and see
whether *any* chapter can be read — and the answer is **yes**.

Measured here (Sept 2026), through the app's own transport (`sf()` →
`hedgedGet` → the perchance proxy), with a **cache-buster** on every repeat so a
cached copy cannot be mistaken for a live read:

| what | result |
| --- | --- |
| `novellive.com/book/shadow-slave` (book page) | 200, full page |
| `…/ajax/get-list-chapter?novel_id=shadow-slave` | 200 — **3,179 chapters** in ~0.04s (via `NLP_tocAll`) |
| `…/book/shadow-slave/chapter1-nightmare-begins` | **200, full chapter text** (41 KB, 5.5s; re-asked with `?cb=` → 200, 40.8 KB, 9.5s) |
| `…/chapter2-slave-caravan` | 403 first, then **200, full text** (5.7s) on a later ask |
| `…/chapter3-the-strings-of-fate` | **200, full text** (38 KB, 9.5s; `?cb=` → 200, 38.4 KB, 6.8s) |
| `…/chapter16-…` and `…/chapter17-…` | **403 "Just a moment…"** six asks in a row (18-45s each) |
| `…/chapter4-…`, `…/chapter50-…`, `…/chapter500-…`, `…/chapter3186-…` | 403 / one 2-minute hang |

`lightnovelpub.me` is the **same site underneath** (its chapter links 302 to
`novellive.app`; `novellive.app` itself is CF-challenged). Its book page answers
200 ("Shadow Slave - Light Novel Pub - Reading Novel Free"), chapter 1 and
chapter 3 returned the identical byte-length pages as `novellive.com`, and
chapter 4 hung for 125s.

So a refusal is **not** a verdict: the check turns away runs of requests and then
lets one through, and a success arrives in **5-10s** while a refusal costs
**18-45s**. It also comes and goes over time — the same early chapters that read
fine in one window were refused in another.

`NLP_getChapter` was already happy with the pages it got: the chapter body is in
`<p>` tags and the site no longer emits a `chapter-content` element, so the
parser's fallback (slice from `chapter-content` if present, otherwise use the
whole document) is what makes it work. The only rubbish it picks up is the site's
own footer lines ("Visit and read more novel to help us update chapter quickly.",
"Use arrow keys (or A / D) to PREV/NEXT chapter").

What the app does about it (`startReaderBlockRetry` in `index.html`):

- A chapter that comes back `err.blocked` is **asked once more** (3s later)
  before anything final is said — `READER_BLOCK_MAX_TRIES = 2`,
  `READER_BLOCK_WAIT_MS = 3000`.
- While it does, the card says what is actually happening
  ("`<source>` is turning this chapter away … trying once more…") rather than
  showing an opaque spinner or a verdict. After the second refusal the card
  reads "*Asked twice and both requests were refused*" and keeps **Try again**,
  **Find on another source** and **Open site ↗** on it.
- The count is per novel+chapter (`readerBlockKey`), so a fresh `openChapter`
  after a failure cannot restart it, and it is cleared on a successful load and
  by `openChapter`'s success path (`stopReaderBlockRetry`).
- It is deliberately **one** retry, not a loop: a refused ask costs 20-45s, and
  the pre-2.7.20 six-try loop is exactly the "spinning for ever" the reader
  complained about. The alternative — no retry — would tell the reader a chapter
  is unreadable when a second ask usually is not.

Verified in the preview with a synthetic NovelLive book (incognito on, so nothing
is written): attempt 1 → the 26s "Still loading…" card → the
"turning this chapter away … trying once more…" card at ~44s → attempt 2 → the
"still turning this chapter away / Asked twice" card at ~92s, no further attempts.

**Since 2.7.23** this retry does not run for NovelLive / LightNovelPub — by the
time a refusal reaches the reader, `nlpFetch` has already asked all four of their
addresses and remembered the winner — so those two go straight to the final card
(which says so: "*Every address … was asked*"). Every other source keeps the
retry exactly as described above.

### Opening a site no longer takes the app over (2.7.21)

Reported from the APK (NovelLive / LightNovelPub): *"It asks the same captcha
every time. I solve it, sometimes another one shows up, and it directs me to
the site. The back mechanism doesn't work — I'm stuck in there. If I try to get
out I get the YueDu logo and the Continue button, and then it goes straight
to that source's feed saying reconnected."*

Three separate things were wrong, and all three are fixed:

1. **`location.href` on the app's own page.** Both `openCaptchaExternal()`
   ("Solve ↗" / "Open site ↗") and `openWebnovel()` (⋮ → View on site) did
   `window.open(url, "_blank")` and then, when that returned null — which is
   *every* plain Android WebView, since `window.open` only works with a
   `WebChromeClient.onCreateWindow` — fell back to
   `window.location.href = url`. That navigates the **app's own document** to
   the site: the reader is left in the site with no YueDu chrome at all, and
   the only way out (Android's back button) is a *history* step back to
   `index.html`, which the WebView lays out from scratch — the splash, and then
   `resumePendingCaptcha()`.
2. **The splash came back on every load.** `#introScreen` is static markup with
   no "seen" flag, so *any* reload (including the one above) put the big
   Continue button in front of the reader.
3. **A dishonest reconnect.** `resumePendingCaptcha()` (and the live
   `captchaProbe()` path) asked `sfHealth(healthURL(src))` — the source's
   **front page** — which answers `"ok"` even while the site is refusing its
   chapter pages (that is precisely what a site's bot check does to chapters).
   So it announced `${src} reconnected ✓` and called `resumeSourceBrowse(src)`,
   dropping the reader on the source feed for a block that had never lifted.

The fix:

- **Nothing navigates the app's page off YueDu.** New helpers in the captcha
  block: `openExternalURL(url)` (a bare `window.open(url, "_blank")` — **no**
  `"noopener"` feature string, because per spec that makes the call return
  `null` and the return value is the only signal that a window opened), and an
  in-app **site view**: `#siteviewScreen`, `openSiteView(url, title, opts)`,
  `closeSiteView()`, `dismissSiteView()`. The site's page is shown in a frame
  **inside** YueDu with its own chrome — back arrow, title, reload,
  open-in-browser — and the reader can come back at any time.
- **Android's back button closes the site view, not the app.** `openSiteView`
  pushes one history entry (`history.pushState({lrSiteView:1}, "")`) so the back
  gesture has something to pop; a `popstate` listener closes the overlay. The
  push only happens when `window.top === window.self` — never in an embedded
  frame (the perchance editor preview, a generator embed), where it would walk
  the *host* page's history instead.
- **A frame is not always possible.** A Cloudflare challenge response carries
  `X-Frame-Options: SAMEORIGIN` (measured on
  `novellive.com/book/shadow-slave/chapter1-…`: 302 → `403`, `Cf-Mitigated:
  challenge`, `Content-Security-Policy: default-src 'none' …` and
  `X-Frame-Options: SAMEORIGIN`), so a CF-protected chapter **cannot** be shown
  in that frame. Rather than a dead end, the strip above the frame says so and
  offers *"Open it full-screen instead (your phone's back button returns
  here)"* — the old `location.href` behaviour, now *labelled and deliberate*
  instead of happening behind the reader's back.
- **The native bridge is used first when the app has one.** `nativeObj()` finds
  a wrapper object exposing `challenge`, and `nativeOpenChallenge(url, title,
  onDone)` opens the wrapper's own WebView screen (see `src/android-plugin/`) —
  a real page, with a Done button, whose cookies go into the app's shared jar so
  the *next* device request is already through. That is the only route that can
  actually get past a bot wall, so it is preferred over both a popup and the
  frame. Its answer arrives through the existing `window.__litNative` hook,
  which now dispatches to `window.__litNativeChallenge` first (the request
  bridge's own waiters are consulted after it).
- **The splash is a first-run thing** (`yuedu_intro_seen` in localStorage,
  `hideIntro()`), so a reload no longer stops on Continue. *(Reversed in 2.7.36:
  the flag was removed and the splash comes back on every load, at the reader's
  request.)*
- **The reconnect is honest.** `resumePendingCaptcha()` now probes
  `p.url` — the page that was actually blocked — not just the source's front
  page, and when it does not answer it clears the pending entry *silently*: no
  toast, no captcha screen, no moving the reader anywhere.

Verified in the preview: with `window.open` stubbed to return null,
`openCaptchaExternal()` opens the site view titled
`novellive.com — pass the check` (with both the "I've passed the check — try
again" and the full-screen buttons) instead of navigating; `openWebnovel()`
falls back to the site view on `https://novellive.com/book/shadow-slave`; a
`popstate` closes the overlay; and with a stubbed `window.LitNative.challenge`
the bridge screen is used and the site view is *not* opened.

**Corrected in 2.7.22:** the closing note here used to say NovelLive /
LightNovelPub chapter pages *cannot* be read by the app. That was wrong — see
"NovelLive / LightNovelPub are readable, intermittently (2.7.22)" at the top.
The fix in 2.7.21 was only ever about not stranding the reader while they try.

### Scribble Hub: the whole chapter list, in one request (2.7.20)

> **Superseded by 2.7.33** — the list (and the novel's details and its chapter
> text) now come from the site's own app interface
> (`/wp-json/fictionapp/v1/`), not from this AJAX endpoint or `?toc=` paging.
> What is below is the history of the web-page route, which is still the
> fallback (`SH_getBookHTML` / `SH_tocAll` / `SH_loadRest`). Kept because the
> endpoint, the `?toc=` order and the paging rule are all still true.

Symptom (from the reader): *"Scribble Hub novels start at chapter ~862 instead
of 1."*

Cause: Scribble Hub's series page renders only the **newest fifteen chapters**
on its front screen — the full list lives behind `?toc=N` pages, newest first.
`?toc=1` is the newest page and `?toc=59` holds chapters 1-11. So the old
`SH_getBook` + `SH_loadRest` paged `?toc=` all the way down. It mostly worked,
but `SH_getBook` passed the *pre-canonical* `slug` (empty on a first visit) to
`SH_loadRest`, so the paging was skipped entirely and only the first screen
(newest ~15) was kept — a list that starts at chapter 862, not 1.

Fix: **`SH_tocAll(id)`** — one POST to Scribble Hub's own AJAX endpoint:

```
POST https://www.scribblehub.com/wp-admin/admin-ajax.php
     action=wi_getreleases_pagination&pagenum=-1&mypostid=<id>
```

(found in the site's `fic_page.js` `toc_fic_show_all()`). It returns the
**complete** `<ol class="toc_ol">` in a single ~260 KB response. Measured:
`sh-1048265` → **882 chapters**, first item "Chapter 0 – 0.Glossary" then
"Chapter 1 – WHAT THE F%#@", in **2.3s**; `sh-522416` → **747 chapters**
starting at Chapter 1, in **2.2s**.

Details:
- `SH_parseToc` now scans **all** `<ol class="toc_ol">` blocks and dedupes by
  chapter id, and derives `num` from a **leading number in the name**
  (`^(\d+)\s*[.):]`) when the name isn't `Chapter N` — this is what keeps
  "Chapter 0 – 0.Glossary" from colliding with a later "Chapter 0".
- `SH_getBook` `Promise.all`s the series page and `SH_tocAll`, resolves `slug`
  from the canonical link **before** it is used, and only falls back to
  `SH_loadRest` when the one-request TOC failed.
- `SH_loadRest` now walks `?toc=N` from the **oldest** page down
  (`order = [pages…2]`), re-rendering on the first landing page and then every
  8th, keeping the "Loading all N chapters…" toast.

### Novel Cool: covers in the feed (2.7.20)

Novel Cool's cards are **lazy-loaded**:

```html
<img src="/files/images/default/default_pic.jpg" class="lazy-img"
     lazy_url="https://img.novelcool.com/logo/…jpg">
```

`NC_parseBooks` read `src` — the relative placeholder, which resolved against
the app origin and 404'd, so every card in the browse/search feed was blank.

Fix: read `lazy_url` / `data-src` / `data-original` / `src` in that order,
absolutise relative URLs against `NC_HOME`, and blank any
`/files/images/default/` placeholder. Measured: 48 novels on
`/category/popular.html`, all covers real `img.novelcool.com` URLs, first card's
`<img>` loads (naturalWidth 300 — novelcool.com is in the non-`crossOrigin`
group, so it can't be canvas-captured but does display).

### Novel Cool: opening a novel showed loading, then nothing (2.7.20)

Symptom (from the reader): opening a Novel Cool novel shows a loading skeleton
and then a blank screen.

Two causes:
1. `NC_parseChapters`'s `numM` required the literal `Chapter`, so the very
   common short form in chapter URLs — `-C2545-` (My Vampire System and many
   others) — matched **nothing**. Zero chapters parsed → `NC_getBook`
   `throw`-ed → `enrichBookDetails` never produced a detail → the screen kept
   its skeleton for ever.
2. The manga case also `throw`-ed.

Fix:
- `numM = /(?:\/|-)C(?:hapter)?[-_]?(\d+)/i`.
- `NC_getBook` **never throws**: it returns the detail plus a `cat.note`
  explaining the manga case / an empty list / a partial list.
- `NC_summary(html)` tries `bookinfo-summary > span[itemprop=description]`,
  then `bk-summary-txt`, then the og/meta description, treating `N/A` as empty.
  The author is cleaned of its `Author:` label.
- `NC_chName(raw, num)` strips the book name + `Chapter N` / `C2545` / `END 1394`
  prefixes and turns slug dashes into spaces. `NC_parseChapters` collects the
  anchor's `title`, its inner text (bounded 400 chars, via `m.index` /
  `indexOf("</a>")`) and the URL slug as candidates and keeps the **longest**
  — because the first sighting of a chapter URL is the *cover's* anchor, whose
  inner text is only an `<img>`.

Verified: `nc-My-Vampire-System` → title / author "JKSManga" / cover / synopsis
/ note + "Chapter 2545 – The Last Goodbye Goodbye Quinn Talen" in **2.6s**;
`nc-Shadow-Slave` → "Chapter 2500 – Her Reflection"; `nc-The-Formidable-Son-In-Law…`
→ "Chapter 1394 – The Final Chapter of Happiness";
`nc-Reincarnation-Of-The-Strongest-Sword-God` → "Chapter 951 Pseudo Tier 7 Mana".

*(Superseded in 2.7.25: the row `title`s are read as well as the clear links, so
this novel now opens with its whole 2,556-chapter list instead of one chapter. See
"Novel Cool: the whole list, and where the chapters open (2.7.25)" at the top of
this file.)*

### NovelLive / LightNovelPub: stop spinning, say so, move on (2.7.20)

Symptom (from the reader): NovelLive chapter reading *"takes really long
loading"* and never opens.

Cause (a): NovelLive / LightNovelPub **chapter** pages are behind a Cloudflare
managed challenge on **every** transport the app has. Measured 403 "Just a
moment…" via the perchance fetch proxy, `r.jina.ai`, `corsproxy.io`,
`test.cors.workers.dev`, `api.cors.lol`, `api.allorigins.win`,
`api.codetabs.com`, Google Translate, `translatetheweb.com`, plus superFetch
with Chrome / Googlebot / Bingbot UAs and varied `Accept` headers, `www.`/`m.`
host forms, http/https, trailing slash, uppercase and `.html` URL mutations.
Their **book** pages and `/ajax/` JSON endpoints answer fine in ~0.6s — so it
is chapter pages only. (The `-C`/`Chapter` sibling hosts `lightnovelworld.co`,
`lightnovelworld.com` and `lightnovelpub.com` are shut down.) This is the
"Cloudflare-403 on every transport" row in the timings table. **The
"unfixable" half of that row was wrong** — measured properly in 2.7.22, the
check turns away runs of requests and lets single ones through; see
"NovelLive / LightNovelPub are readable, intermittently (2.7.22)".

Cause (b): `startReaderCaptchaRetry` re-opened the chapter **every 7s
forever**, and its gate `sfHealth(sourceBaseURL(source))` reads the
*homepage* — which answers fine — so the retry never stopped. That is the
"really long loading".

Fix (a): **`NLP_tocAll(name, slug)`** GETs
`https://<home>/ajax/get-list-chapter?novel_id=<slug>` — one ~400 KB JSON body
with every chapter (3179 for Shadow Slave), replacing the old 80-page crawl.
`NLP_getBook` `Promise.all`s the book page and `NLP_tocAll`, uses the JSON list
when present (`total: toc.length`), and only calls `NLP_loadRest` when it
failed.

Fix (b): `openChapter`'s catch has a new **first** branch: when `e.blocked`,
it renders a dedicated card — *"**<source> won't serve this chapter to
YueDu** … protects its chapter pages against outside readers with its own
bot check, even though its novel lists answer normally …"* with
`data-find-source` first, plus Try again / Open site — and calls
`stopReaderCaptchaRetry()` (no background loop). **Changed in 2.7.22:** that
card's wording was wrong (the sites are not a wall), and the branch now calls
`startReaderBlockRetry()` instead — one more ask, with the card saying what is
happening. See "NovelLive / LightNovelPub are readable, intermittently
(2.7.22)". The generic captcha branch no
longer mentions `e.blocked`. `startReaderCaptchaRetry` is now **bounded**
(`READER_CAPTCHA_MAX_TRIES = 6`, keyed by `readerCaptchaKey = bookId + ":" +
chapterId`, so re-triggering doesn't reset the count); on exhaustion it swaps in
a "still refusing this chapter / Find on another source" card. `openChapter`'s
success path clears `readerCaptchaKey` / `readerCaptchaTries`.

`wireCaptchaHint`'s `[data-find-source]` handler is now `async` and
**auto-files an unfiled novel** via `addToLibrary({bookId, source, title,
author, cover, slug, rating, votes}, {book: b})` before
`openMigrateScreen(b)` — previously it only toasted "Add this novel to your
library first".

Verified in the preview: `openChapter(<synthetic NovelLive book>,
"chapter1-nightmare-begins")` ends on the refusal card with
`readerCaptchaTimer === null` (no loop).

**Note:** the refusal card still appears after ~8-40s, because Cloudflare's own
403 latency (0.6s or ~10s) plus `hedgedGet`'s 7s `blockedGrace` plus
allorigins' 9s hang add up. The 7s grace is deliberately tuned (see the
transport notes) — shortening it made the app declare "blocked" on requests the
proxy was still about to fulfil — so it was left alone. A "Try again" bypasses
nothing here: the refusal is honest and immediate enough.

### The source health check (2.7.19)

Symptom (from the reader): *"On the browse, only FanMTL is slow connecting — like
it's checking… far longer than others. And soon goes to the unavailable status,
but when you clicked it, it's working fine."*

Cause: `sfHealth()` walked its probes **one at a time**, awaiting each fully
before starting the next, with its own long timeout on every one
(`withTimeout(superFetch, 8s)` → `bridgeFetch(8s)` → `httpText(jina, 7s)` →
`allorigins(7s)`). FanMTL is the worst case for that order: its own route is
Cloudflare-slowed (measured 4.4s here, worse on a phone) while **jina hands the
same page over in ~0.5s** — but jina was third in the queue, so the check paid
for two slow routes first. If the walk ended with every route timed out or
challenged it returned `"down"`, and `healthSticky` then kept the pill reading
"Unavailable" for **ten minutes**, with no way to re-ask (`checkSourceHealth`
honoured the sticky even when `force` was passed, so even the refresh button in
the Discover sheet could not clear it).

Measured here (`healthURL("FanMTL")`, one probe each): superfetch 4.4s ok,
bridge 1.2s, jina 1.0s, allorigins aborted at its 7s limit — i.e. a *sequential*
walk costs ~7-13s even when it succeeds, and can only reach "down" after
everything has failed.

The fix is two lines of intent:

- **`sfHealth(url)` is now `await hedgedGet(url, { deadline: 12000 })`** →
  `"ok"`, or `"captcha"` when the rejection carries `blocked` (which the
  transport layer only sets when *our own* route was challenged — foreign
  routes that are challenged are merely retired), or `"down"` otherwise. The
  properties the captcha flow depends on are unchanged and in one place: a
  challenge is only believed when no route could answer, and `captchaProbe()`
  still only acts on `"ok"`.
- **`checkSourceHealth(force)` lets a manual refresh bypass `healthSticky`**, so
  the reader asking again is always believed (the automatic 60s throttle is
  unchanged).

Measured after the change: `sfHealth` FanMTL **2.7s** (via jina), Webnovel
**1.3s**, a dead host **12s → "down"** (deadline-bounded), and the whole source
list — 15 sources, `mapLimit(active, 4)` — settled in **3.5s**, every card
"Connected".

### The reading percentage (2.7.18) — decimals on a long novel

In continuous mode the reader is shown `contNovelPct()` — how far through the
**novel** they are — rather than how far down the joined page (`updateReaderProgress`
keeps the day's split: the *scrubber* still tracks the scroll, because that is
what it drives, and what is *written down* is still the chapter percentage). The
percentage is therefore one chapter wide, and on a 1000+ chapter novel that is
under 0.1% per chapter, so a whole number never changed.

`contNovelPct()` now returns the unrounded percentage and `readerPctText(v, total)`
writes it with `round(log10(total/10))` decimals, clamped to 0–2: two on a very
long novel (1000+ chapters), one on a long one (100+), none on a short one. Both
the floating pill (`#readerPctFloat`) and the footer (`#readerFootPct`) use it.
The non-continuous path and the scrubber's own label stay whole numbers.

### NovelHi's chapter list on a cold start (2.7.18)

Symptom: on the standalone build the first NovelHi novel opened after launch said
*"NovelHi has no chapter list for this novel yet"*, and pulling it open again
showed the chapters.

Cause: `NH_chapters()` parses `<a class="mobile-chapter-item">` out of
`…/chapters`. The **jina** transport (`r.jina.ai`, an HTML *cleaner*) hands that
page back with **zero** chapter items in it — measured, 10144 items through
superfetch/npc-proxy, 0 through jina — while still answering 200. On a cold start
the device's own bridge (an iframe of this generator, which takes a couple of
seconds to boot) misses the first hedge window, so jina's cleaned copy won; it
was parsed as an empty list and the novel was announced as having none. Once the
bridge was warm the same request went down a route that hands over the real page,
which is why re-opening it worked.

The fix is in the transport layer, as a general primitive:

- `hedgedGet(url, { require })` — `require` is a predicate on the response text.
  A transport that answers with a page that does not contain what was asked for
  is settled as a **failed** route (`"<name> answered without what was asked
  for"`), so the hedge carries on to another route and the first 200 no longer
  wins by default. The check sits *after* the challenge/403/404 handling, so a
  Cloudflare page from one of our own routes still takes the blocked path.
- If every route that returned a *body* returned one without the marker, the
  request fails with `contentless: true` and the message "The site answered, but
  not with the page that was asked for". `sf()` treats that as final (no
  re-asking the same routes, no captcha probe, no marking the source down) and
  rethrows; a route that timed out does not count, because retrying may genuinely
  reach it.
- `sf(url, opts)` — the second argument is now an options object (it was an
  unused `attempt`), and `opts.require` is passed through.
- `NH_chapters()` asks with `{ require: (t) => t.indexOf("mobile-chapter-item") >= 0 }`.
- `NH_getBook()` no longer says "no chapter list for this novel yet" for a page it
  could not really read. Withdrawn novels (the copyright-protected flag) are
  answered from the flag with no request at all; a failed list fetch says "didn't
  hand over the chapter list just now — pull the book open again"; and a book
  page with **no canonical path** in it is re-fetched once (it is a cleaned copy
  of the page, not a novel without chapters) before anything is claimed.
  `NH_PATHS` is used as a fallback for the canonical path as well.
- Self-healing: `bookCatalogMissing(book)` (a non-local novel with no chapters
  *and* a `listNote` or no synopsis) makes `openBook()` ask again, throttled by
  the `catAttempt` map (20s per novel). `enrichBook()` (the add-to-library path)
  now applies the same guard as `enrichBookDetails()` — an empty catalog never
  overwrites one that is already on the device.

### The shelf picker is a centred card (2.7.18)

`#shelfModal` (`.sleepModal` — the same scrim + centred card as the sleep timer,
with `.shelfGrid` / `.shelfOpt` styles) opens from both `#cardMenuShelf` and the
book screen's `#bookShelfBtn`. `openShelfMenu(book)` rebuilds
`#shelfMenuBody` every time (so the current shelf is always the marked one),
`closeShelfMenu()` is called by the scrim, the Close button and after choosing a
shelf. The old anchored `#shelfMenu` `.cardMenu` and its document-level
outside-click handler are gone; the `anchor` argument is still accepted and
ignored.

### Reader shelves (2.7.17) — what a novel means to *you*

Publication status (`book.status`) is what the *source* says. A **shelf**
(`book.shelf`) is what the *reader* says: one of `reading`, `interested`,
`finished`, `holding`, `dropped`, `notinterested` (or absent). The whole feature
is one block in `index.html` immediately after the status block (before the
`library rendering` banner): `SHELF_META` / `SHELF_KEYS` / `SH_ICON` (inline
SVGs), `shelfMeta`, `shelfTagHTML`, `bookShelfChipHTML`, `setBookShelf`,
`autoShelf`, `openShelfMenu` / `closeShelfMenu`, and `renderShelfRow` just
under the banner.

Set from a card's **⋮ → Add to shelf** (`#cardMenuShelf` → `#shelfModal`) or from the
chip on the book screen (`#bookShelfBtn`, rendered next to the status chip in
`#bookStatusRow`). `renderShelfRow()` paints `#shelfRow` — the chip row
*above* `#statusRow`, hidden until at least one novel is shelved. The filter is
`state.shelfFilter`, applied in `renderGrid()` next to `state.statusFilter`
(`shelfFilterPresent()` clears a filter whose chip has gone, exactly like
`statusFilterPresent`), and the shelf is printed on the card as `.shelfTag`
inside the `novelSource` line.

`autoShelf(book, key)` fills in the two moments that are obvious anyway — the
first chapter opened (`reading`) and the last chapter finished (`finished`) —
and **never** overrides a shelf the reader chose (the one exception is
reading → finished). It is skipped entirely while incognito is on, and saves
quietly (`{quiet:true}`) so it does not re-render the library while you read.

### Continuous scrolling (2.7.17) — chapters joined into one page

`READER_SETTINGS.cont` (default off), toggled from the reading-settings sheet
(`#rsContChk`) or Settings → Reading (`#rscContChk`); `setContinuous()` saves the
setting and, if the reader is open, re-opens the current chapter in the new mode.

The whole feature is the `continuous scrolling` block after `openChapter`:
`cont` (live state — `segs`, the sections in DOM order), `contOpen`,
`contAppendNext`, `contPrependPrev`, `contTrim`, `contTick` / `scheduleContTick`,
`contJump`, `contVisibleSeg`, `contChapterPct`, `contNovelPct`, `contSyncNav`.
`openChapter` branches into `contOpen()` when the setting is on, and otherwise
renders one chapter with `chapterInnerHTML()` — the paragraph/heading builder
factored out of the old inline code so both paths share it.

Things that matter if you touch it:

- Chapters live in `<section class="rdCont" data-cid>`; the separator between
  them is CSS (`.rdCont + .rdCont`), not an element, and there is no wrapper
  markup to keep in sync.
- **The current chapter is the one under the middle of the screen**
  (`contVisibleSeg()`). Measuring from the top edge is wrong: after a prepend a
  sliver of the previous chapter's last line is still on screen, so it read as
  current and the header jumped a chapter back at every join. The middle is also
  what `contChapterPct()` measures from, so the two always agree.
- Prepending corrects `scrollTop` by the `scrollHeight` delta so the words under
  your eye do not move. That correction is exact — verified by measuring a
  section's offset before and after. Don't "simplify" it.
- Only `CONT_KEEP` (3) chapters either side of the visible one are kept in the
  DOM; the rest are removed. Trimming is held off while `tts.reading`, because
  the TTS segment list points at those elements.
- A chapter is fetched only when the reader is within ~900 px of an edge, one at
  a time (`cont.busyBot` / `cont.busyTop` guards), and the one beyond it is
  `preloadChapter`d so the next join is instant. Nothing here hammers a source.
- The scrubber describes the scroll, because that is what it drives; the
  percentage labels show `contNovelPct()` — progress through the *novel* —
  because a scroll percentage walks backwards as chapters arrive. Since 2.7.18
  that number is written by `readerPctText(v, total)` with enough decimals to
  move one chapter at a time — see "The reading percentage (2.7.18)".
- `updateReaderProgress()` writes `contChapterPct()` (0–100 *within* a chapter)
  to PROGRESS in this mode, not the scroll percentage, so "read" and "finished"
  stay right.
- The footer Next/Back call `contJump()` (turn the page on the same page, loading
  it first if needed); a chapter chosen from the picker re-opens the reader
  there instead.
- `ttsEndChapter()` has its own branch: it appends the next chapter, re-collects
  segments and continues at the first paragraph of the new one.

### Incognito reading (2.7.17)

`INCOGNITO.on` plus `applyIncognito()` / `incognitoSet()` sit next to the
`LIBRARY` / `HISTORY` / `PROGRESS` load in `index.html`; the switch is
`#incognitoChk` (Settings → Privacy) and it is remembered in
`yuedu_incognito`. `#incognitoBadge` is shown at the top of the reader while
it is on.

While it is on, every write about *what is being read* is skipped: `HISTORY` in
`openChapter`, `PROGRESS` / `markChapterDone` in `updateReaderProgress`, the
localStorage chapter ring in `fetchChapter`, `toggleBookmark`, `autoShelf`, and
the presence heartbeat (`fbRefreshPresence` removes the node instead of setting
it, so an incognito reader is not counted). Writes that are *managing the
library* rather than recording reading — adding a novel, shelving it — are
deliberately not gated.

### Read aloud in the background (2.7.17) — the wall

`READER_SETTINGS.ttsBg` (default **true**). The `visibilitychange` handler now
pauses on the way out when the page goes hidden (`tts.bgPaused = true`) and
resumes when it comes back. Only *that* pause is auto-resumed: a call is still
the keep-alive clip's call to resume (see "Incoming calls and other apps"
below). Setting it to false restores 2.7.16's behaviour — playing on with the
screen off. This deliberately reverses part of 2.7.16 for the backgrounded case,
at the user's request, and is the one setting in the TTS tab that changes what
happens *outside* the app.

### Sleep timer card (2.7.17)

`#ttsSleepModal` — a big centred card, opened by the moon button
(`openSleepModal()`, wired in `ttsInit`): 5 / 15 / 30 / 45 / 60 / 90 minutes, end
of chapter, and off, with a live countdown (`refreshSleepModal()` on a 1 s
interval while open) and a **Stop reading now** button. `tts.sleepMins` remembers
the raw choice so the picker can highlight it again (the old `ttsSleepValue()`
only rounded to the nearest select option); `#ttsSleepSel` in the settings sheet
shares `ttsSetSleep()` and grew the 45 and 90 options.

### Offline downloads (2.7.16) — chapters kept on the device

There are two chapter caches in `index.html` and they must not be confused:

| | `chapterStore` (`yuedu_chapcache_v2`) | the offline store (`yuedu_offline`) |
| --- | --- | --- |
| what | the last **60** chapters the reader passed through | every chapter the reader **asked** to keep |
| where | localStorage (a JSON blob) | IndexedDB (one record per chapter) |
| evicted | yes — oldest first, on every save | **never**; only "Remove downloads" deletes |
| purpose | a speed cache for Next/Prev | reading with no connection |

`fetchChapter` consults, in order: memory (`chapterCache`) → the localStorage
ring → **the offline store** → the source. A chapter served from IndexedDB comes
back with `offline: true`, and is deliberately *not* then written into the
localStorage ring (it is already stored properly, and letting it in would push
something else out of the sixty).

**The database.** `yuedu_offline`, two stores: `chapters` (keyPath `key` =
`` `${bookId}:${chapterId}` ``, plus an index `byBook` on `bookId`) and `books`
(one small record per novel: `{bookId, title, source, cover, total, done, bytes,
ts}`). Every open/read/write is wrapped so that *any* failure resolves to
null/`[]`/false rather than throwing — "no offline copy" is an ordinary answer
here, and the standalone/WebView has to keep working when IndexedDB does not.
`offChapterIds(bookId)` uses `index.getAllKeys()` and strips the `` `${bookId}:` ``
prefix, which is exact even for ids containing a colon of their own.

**In memory:** `offlineIds` (bookId → `Set` of chapterId — what the chapter-list
arrows and `offHas` read) and `offlineMeta` (bookId → the `books` record — what
the library badge reads, loaded once at boot by `offAllMeta`).

**The downloader** (`dlRun`) is deliberately dull: strictly one chapter at a
time, a pause between them (`dlDelayFor`: 300 ms, 700 ms for burst-sensitive
hosts, 1200 ms for NovelHi), `dlSaveMeta` every ten chapters, and an immediate
stop if a fetch comes back as a wall (`blocked` / `rateLimited` /
`captchaBlocked`) — telling the user rather than making the block worse. Only
*missing* chapters are queued, so "resume" is just running it again. Locked (VIP)
chapters are skipped entirely.

**The screens:** the book screen's Download button (`#bookDlBtn`) opens
`#dlSheet` (Next 100 / Next 500 / Whole novel / Stop / Remove downloads); each
chapter row's `.dlIcon` toggles that one chapter (filled pink = on the device);
the library grid shows `.offBadge` with the count. `dlMarkOne`/`dlMarkIcons`
re-paint only the arrows that changed, so a long chapter list never re-renders
under the reader's scroll position.

**Known limit:** "Whole novel" can only download the chapters *in the list we
hold*. Wuxiaworld serves its catalog a page of a hundred at a time
(`chapters._ww`), so a novel there downloads what has been loaded so far; the
sheet says so ("N more chapters aren't in the list yet").

> **Do not re-add the Foxaholic source.** It was added in 2.7.11 and removed at
> the user's request in 2.7.12 — its Cloudflare wall refuses every route. Do not
> re-add `FOX_*`, `DEVICE_FIRST_HOSTS`, `standaloneBuild()`,
> `deviceOnlyBlocked()` or `deviceOnlyHint()`; they are gone.

### Novel status (2.7.14) — Ongoing / Completed / Hiatus / Dropped

One field on a library book: `book.status`, one of `ongoing`, `completed`,
`hiatus`, `dropped` (or absent). It is written by

- the source, whenever `getBook()` (or a browse card) hands back
  `detail.status` — every `enrichBook` / `enrichBookDetails` / `addToLibrary` /
  `doMigrate` path copies it onto the book, and
- the reader, from a novel's **⋮ → Set status** or from the chip on the book
  screen (both open the same `#statusMenu` picker).

The code is one block in `index.html`, immediately before the
`library rendering` banner: `ST_META` / `ST_KEYS` / `ST_ICON` (hand-written
inline SVGs), `normStatus`, `statusFromHTML`, `statusBadgeHTML`,
`bookStatusChipHTML`, `setBookStatus`, `openStatusMenu`, and
`checkLibraryStatus`; then `renderStatusRow()` just under the banner, and the
`state.statusFilter` branch inside `renderGrid()`.

`normStatus(t)` is the single funnel: it lowercases, accepts the four words
themselves, the `og:novel:status` codes `1`/`2`, and the usual synonyms
(`on going`, `updating`, `paused`, `on hold`, `full`, `finished`, `ended`,
`cancel*`, `discontinu*`, `abandon*`, `suspended`). Anything it does not
recognise becomes `""` (= no status).

`statusFromHTML(html)` returns a **labelled** status only — every pattern hangs
off something the site wrote the word next to, so prose like "the ongoing war in
the north" can never decide it. The patterns, verified against live pages:

| source | pattern | reads |
| --- | --- | --- |
| Webnovel | `>Ongoing · 120.4M Views<` in the **catalog** page (the "· N Views" tail is what makes a bare word safe to match) | ongoing / completed |
| NovelFull, NovGo, NovelLive, LightNovelPub | `<meta property="og:novel:status" content="…">` | ongoing / completed |
| FreeWebNovel | the theme's `title="Status"` row | ongoing |
| NovelHi | `Status：Ongoing` | ongoing |
| FanMTL | `<strong>Ongoing</strong><small>Status</small>` | ongoing |
| Novel Cool | the `/category/updated.html` link it wraps the word in | ongoing |
| Wuxiaworld | the JSON search result's own `status` field (licence = it is finished) | completed |

**No status is published by: Royal Road, NovelArrow, Scribble Hub, Lib Read,
WTR Lab.** Their books simply show no badge (verified — those pages carry no
status word anywhere near a label). Don't re-probe them without a reason.

`checkLibraryStatus()` (the library's ⋮ → **Check novel status**) walks the
books that have no status yet, one source request at a time, and stops as soon
as the library screen is left. It is deliberately the only bulk fetch here.

### Read aloud / TTS (2.7.15) — one sentence at a time

> **Since 2.7.32 there are three engines behind this** — the browser's own speech
> engine, the app's native one, and an online voice — because an Android WebView
> has no Web Speech API at all and the packaged app therefore had none. See
> "Read aloud: three engines" at the top of this file before touching anything
> here; the sentence walker below is shared by all three.

All of it lives in the `/* ===== TTS read aloud ===== */` block at the bottom of
`index.html` (`ttsSynth`, the `tts` state object, `ttsChunks`, `ttsSay`,
`ttsAdvance`, `ttsEndChapter`, `ttsSetSleep`, `ttsMediaSession`, and an init IIFE
that wires the panel and the drag handle).

**The unit of speech is the sentence, not the paragraph.** Chrome cuts an
utterance off after roughly fifteen seconds and a long paragraph makes the reader
look dead while it talks, so `ttsChunks(text)` splits a paragraph on
`[.!?…] + space` (keeping abbreviations and lone initials attached — see
`TTS_ABBR`), falling back to a comma cut for a sentence over 260 characters.
Every cut is stored as `{text, start}` where `start` is an **offset into the
paragraph's own `textContent`** — that is what makes the highlighting possible.

**Highlighting never touches the chapter's HTML.** `ttsRangeIn(el, from, to)`
walks the paragraph's text nodes to map an offset back to a `Range`, and the
range is handed to the CSS Custom Highlight API (`CSS.highlights.set(...)`),
styled by `::highlight(tts-sent)` (whole sentence, translucent) and
`::highlight(tts-word)` (the word `onboundary` reports, solid accent). Feature
test with `ttsCanHighlight()`; a browser without the API keeps the older
whole-paragraph tint (`.rdTts`), which is still applied on every sentence.
A live word/sentence highlight therefore **cannot be seen in a snapDOM capture**
(the clones have no `CSS.highlights`), so verify it by reading
`CSS.highlights.get("tts-word")` and the `::highlight` rules in
`document.styleSheets` instead.

**Carrying on into the next chapter.** When the last sentence of the last
paragraph ends, `ttsEndChapter()` either stops (sleep timer set to the chapter
end, "Keep reading" off, or no next chapter) or calls `openChapter(book,
state.nextId)` itself and starts again at paragraph 1. The catch: `openChapter()`
kills the speech on entry — it must, since every other way into a chapter should
stop the reading. So `ttsEndChapter` sets `tts.skipStop` first and `openChapter`
consumes it instead of calling `ttsAbort()`. After the await it re-checks
`tts.reading && state.chapterId === nextId && state.currentBook === book` (the
reader may have navigated away mid-fetch) and only restarts if the new chapter
really rendered (`readerBody` has an `h2` — a locked or failed chapter has none).
`tts.reading` stays true across the whole handoff, and `tts.loadingNext` shows
"Next chapter…" in the panel meanwhile.

**Sleep timer** (`ttsSetSleep`) is a countdown or "end of chapter"
(`sleepAtChapterEnd`). It is deliberately *not* cleared by `ttsAbort()` — moving
to another chapter must not cancel the timer the listener just set. Only
`ttsStop()` clears it. `ttsSleepValue()`/`ttsSleepLeftTxt()` keep the panel's
moon button, the settings row and the countdown text in sync.

**Robustness, in the order the bugs bite:**

- `alive()` (inside `ttsSay`) requires `tts.reading && !tts.paused` — *paused* is
  in there so a stray `onend` or boundary event while paused can't advance the
  reading.
- A **watchdog** polls `synth.speaking`/`synth.pending` and only advances once
  the engine agrees it has nothing left to say. This is what saves a chapter
  when an engine swallows an utterance (Android after a pause) and reports
  nothing at all.
- **Pause that doesn't pause**: some Android engines accept `synth.pause()` and
  talk on. 300 ms later, if `synth.paused` is still false, the utterance is
  cancelled instead; the resume path (which re-speaks when the engine is idle
  400 ms after `resume()`) then says the sentence again from its start.
- The sleep timer's countdown is re-rendered on every sentence boundary, so it
  never needs a timer of its own for the UI.

**Voices** (`ttsVoiceOptionsHTML`) are grouped by language with the device's own
language first; `""` is a real choice ("System default", no voice override, just
`u.lang = navigator.language`). Voices arrive late on Android, so
`ttsLoadVoices` keeps polling for up to ~32 s. `ttsApplyVoiceChoice` is the one
place that rebuilds both `<select>`s (`#ttsVoiceSel` in the reader settings,
`#rscVoice` on the Reading screen).

**Incoming calls and other apps (2.7.16).** The web platform has no "a call is
arriving" event; what it has is **audio focus**. So while the reader is speaking
it also plays a *silent looping clip* (`ttsSilentClip` — a one-second WAV built
at runtime, silent by content but unmuted, so it holds focus like any other
player) and watches it. Losing that clip is a call; locking the phone is not. Two
details make it work:

- The clip's `pause` **event is never the signal** — media events are queued, so
  a pause we asked for can arrive after we have asked to play again (rapid
  pause/resume used to fake an interruption). Instead `ttsKeepAliveWatch` polls
  `a.paused` every 1.2 s, and only counts it once the clip has actually played at
  least once (`kaWantPlaying`, set by the `playing` event) — so a browser that
  refuses autoplay can never fake an interruption either.
- Resuming is likewise the clip's call: after an interruption `ttsInterrupted`
  asks for the sound back every 2 s, the `playing` event starts a 1.2 s
  confirmation (an engine can report `playing` for a moment while a call still
  holds focus), and only then does the reading pick up. `visibilitychange` to
  visible only *asks* for the sound back — it never resumes on its own say-so, so
  an ongoing call can't be talked over.

> **Changed in 2.7.17:** the same `visibilitychange` handler now also *pauses* on
> the way out (the background wall), and only that pause is auto-resumed on the
> way back. See "Read aloud in the background (2.7.17)".

**Media session** (`ttsMediaSession`) sets the chapter title, the book, the cover
and the play/pause/stop/next/prev handlers, which is what makes a headset button
work with the phone in a pocket. Everything is behind `navigator.mediaSession` +
try/catch.

### Wuxiaworld (2.7.13) — the licensed originals, through its e-reader site

Everything comes from **`lite.wuxiaworld.com`**, Wuxiaworld's own
server-rendered edition for e-readers: plain HTML, no JavaScript, ~45 KB a
page. The full site is a 150 KB SPA whose data arrives over gRPC, so the one
thing taken from it is its legacy JSON search endpoint.

| what | endpoint | size | notes |
| --- | --- | --- | --- |
| search | `www.wuxiaworld.com/api/novels/search?query=…&count=10` | 1-20 KB | title-substring match; `count` capped at 10 server-side; items carry `slug, name, coverUrl, synopsis, genres, reviewScore, chapterCount, status` but **no author** |
| feed | `lite.wuxiaworld.com/novels` + `?sort=…` / `?status=…` | ~43 KB / 24 books | 8 jobs (popular, newest, most chapters, rating, A-Z, ongoing, completed, on-hiatus) cover **116** of the 251 novels in the catalogue |
| book | `lite.wuxiaworld.com/novel/<slug>` | ~46 KB | title, `Status · Author: X · N chapters`, cover, synopsis, chapter list |
| chapter list | the same page at `?toc=N` | ~46 KB / 100 chapters | the pager says "Page N of M" |
| chapter | `lite.wuxiaworld.com/novel/<slug>/<chapterId>` | 50-80 KB | text, prev/next links, `<h1>` title |

Parsers/code: `WW_parseBrowse`, `WW_parseToc`, `WW_parseHead`, `WW_parseChapter`,
`WW_chapterTitle`, `WW_bookFromApi`, `WW_searchBooks`, `WW_apiForSlug`,
`WW_getBook`, `WW_getChapter`, `WW_catMore`, `WW_hostAlive`, `WW_rating`, and
`WW_fetch`. Every Wuxiaworld request goes through `WW_fetch` — the book page,
chapter pages, `?toc=` pages, the JSON search — and `fetchBrowsePage` uses it for
this source's feed pages too. It is `sf()` plus three things that this host
needs, all measured (see "The Lite host answers a 404 when it is asked too
fast" below):

1. **A retry asks for a different URL.** Our requests go through perchance's
   fetch plugin, which caches what the host answered — the 404 included — so
   re-asking for the same URL replays the cached 404 (measured: the same chapter
   404'd three times in a row at ~11 ms, i.e. answered from the edge, while the
   full 64 KB chapter arrived at once at ~700 ms on a variant URL carrying a
   fresh `?r=` parameter). So retries append `?r=<random>`, which the cache has
   never seen and the host ignores; the first attempt is left alone so an
   already-cached good page is still served instantly (~20-40 ms).
2. **Before believing a 404, it asks whether the host is answering at all** —
   one request to `/novels?r=<random>` (fresh key, so the answer isn't cached),
   memoised for 10 s. Alive → this URL really is missing, report it as such (two
   requests, ~2.5 s). Refusing everything → the host is busy, back off
   (400/1200/2500 ms) and keep asking.
3. **While the host is busy, it holds off the source's other traffic**
   (`WW_cooldown`, 2.5 s) and throws the failure *without* the `notFound` flag,
   so the reader's ordinary auto-retry path takes over instead of claiming the
   chapter was removed. The message is "Wuxiaworld is refusing requests for a
   moment (it answered the last few too fast)." — deliberately free of the
   words "captcha"/"robot", which `captchaBlocked()` matches and would route to
   the captcha screen.

Things worth knowing:

- **Chapter numbers restart with every "book"** (`cd-book-5-chapter-5`), so the
  number the reader shows is the chapter's **position in the novel**, stamped as
  `WW_catMore` assembles the list (`c.num = chapters.length + 1`) — the app
  sorts chapter lists by `num`, and the site's own numbers would repeat and
  reorder the list. `WW_chapterTitle` reduces the site's label
  ("Book 12, The Descent of the Gods – Chapter 1, Coming Home") to the chapter
  title, because this site separates it with a comma as often as a dash while
  the app's shared `cleanChName` only knows the dash. The `<p>Previous
  Chapter</p>` / `<p>Next Chapter</p>` placeholders the site puts *inside* the
  chapter body (at either end of a novel) are dropped in `WW_parseChapter`.
- **Only the opening stretch of a novel is readable.** Wuxiaworld answers a
  signed-out reader with a truncated teaser (~1.1-3.4 KB of text ending in
  "…") for every later chapter; the full site's own JSON confirms it
  (`isTeaser: true`, `karmaInfo.isKarmaRequired`) — a paywall, not a parser
  problem. `WW_parseChapter` flags it (`preview`) and the reader shows
  "This is a preview — the rest of this chapter is locked on Wuxiaworld"
  instead of a chapter that stops mid-sentence. Measured: teasers < 3.4 KB,
  real chapters ≥ 6 KB, so the test is "short **and** trails off in an ellipsis".
  (Coiling Dragon: book 1 free, book 5+ teasers. Nine Star Hegemon Body Art:
  chapters 1-89 free.)
- **The chapter list grows on demand, never in the background.** The book page
  carries page 1 of the `?toc=` pager (100 chapters), so the book screen opens
  at once; `WW_catMore` fetches the next three pages (300 chapters, 600 ms
  apart) when the reader reaches for them. Two triggers, both the reader's:
  the "Load more chapters · <loaded>/<total>" button, and the book screen's own
  list — scrolling to its end fires the same call through the IntersectionObserver
  (`appendMoreChapters(ctn, true)`), but **only for `#bookChapters`**: the
  reader's chapter picker (`#chapterModalList`) fetches on an explicit tap only,
  so opening a chapter never races a catalog request. `WW_MAX_TOC = 80` pages
  caps it (8000 chapters; the largest catalogue is 7315). The paging state lives
  on the array itself (`chapters._ww` — `slug, page, last, total, strikes, seen,
  done, busy`), which survives `book.chapters = cat.chapters` and is invisible
  to `JSON.stringify`, so saving a library book is unaffected.
  **The reason it is on demand rather than a background pump** (the 2.7.13
  implementation, and what the first attempt at it did): a pump that fetched
  these pages while the reader was reading kept the host in its 404 state, and
  chapter opens failed five times out of five while it ran. A pump also calls
  `refreshChaptersUI` on every page, which re-runs `setupChapterList` and jumps
  the reader's list back to the top — for a 7000-chapter novel, repeatedly, for
  the ~20 s it took to fill. On-demand has neither problem.
- **Covers**: `cdn.wuxiaworld.com` sends **no ACAO**, so `wuxiaworld.com` is in
  the `crossOrigin` exclusion in `loadCoverImg`, and `coverURLs` gives
  `[direct, weserv]`. Verified: the direct cover loads (1200 px wide).
- **Feed cards carry no rating**, so `Wuxiaworld` is in `RATING_ENRICHABLE` and
  `ratingForBook` looks the rating up via the search endpoint by slug (the slug
  *is* the title). Verified: 96 of 116 feed cards picked up real ratings.
- `reviewScore` is a 0..1 fraction the site shows out of five, truncated to one
  decimal (0.87 → 4.3), so `WW_rating()` floors rather than rounds.

Known gaps, if a future agent wants them:

- **No author search**: the JSON search matches titles only and carries no
  author field, so tapping the author chip on a Wuxiaworld book falls back to a
  title search and usually finds nothing.
- Search returns at most 10 items, one query at a time.
- **The chapter-list jump box only reaches loaded chapters.** "Jump to chapter"
  matches against the list as it stands, and the list starts at 100 chapters; a
  number past that finds nothing until the reader scrolls to the end (or taps
  "Load more chapters"). Other sources aren't affected because their catalogs
  arrive whole. Fixing it properly would mean fetching just the `?toc=` page
  that contains the number (`page = floor((n-1)/100)+1`, one request) and
  splicing it in, which leaves a gap in the list and makes the "N/total" on the
  button a lie — or fetching every page in between, which is the burst this host
  dislikes. Left alone deliberately.
- **The Lite host's 404s are coped with, not cured.** `WW_fetch` now tells the
  host's "too fast" 404 from a genuinely missing page and retries accordingly
  (see above), and nothing is fetched in the background any more, which is what
  used to keep the host in that state. If it ever gets worse, the next lever is
  to serialise this source's requests app-wide (mark `lite.wuxiaworld.com`
  polite, or add it to `chapterQuotaTight` in `preloadChapter`) at the cost of
  slower feeds.

### 2.7.12 — Webnovel: it was the pages, not the requests

Webnovel was the slowest source by a wide margin, and the reason was structural:

| what | before | after |
| --- | --- | --- |
| feed pages | 7 × ~350 KB, each through a **third-party** proxy | 6 × ~53 KB on **our own** route |
| feed first covers | ~2.3 s | ~0.6-1.9 s |
| feed complete | ~11 s | ~2.8-5 s |
| one search page | ~350 KB / 1-2 s | ~53 KB / ~0.5-0.8 s |
| requests for the feed | 7 (incl. the 440 KB home page) | 6 |

Measured (Sept 2026, warm preview; the numbers swing with the shared preview IP,
so re-measure rather than trusting these exactly):

- **The site's HTML pages are enormous**: a search page is ~350 KB for **20**
  books (its `__NEXT_DATA__` alone is ~149 KB) and the home page is ~440 KB for
  ~25. The book catalog page is **1.36 MB** (1472 chapters) — that one is not
  the problem (it is one request at ~2.3 s, in line with NovelHi's ~2.4 s) and
  the catalog ignores `?pageIndex=`, so it stays as-is.
- **Our own routes are challenged for those pages.** `root.superFetch` answers a
  Webnovel *page* with ~7 KB of Cloudflare challenge (in 2-10 s!), so every page
  ends up going through `corsworker` (a third-party Cloudflare Worker) — which
  is why a Webnovel page cost 1-2 s and a burst of them cost 11 s. That is what
  `hedgePartner`/`BURST_SENSITIVE` have been compensating for.
- **Its JSON endpoints are not challenged.** The H5 site's own book list,
  `/go/pcm/search/result?keywords=…&pageIndex=1&pageSize=20`, answers
  `root.superFetch` directly: 20 books in ~53 KB in ~0.8 s, `pageIndex` walks
  further pages, `pageSize` is capped at 20 server-side, and page 1 for
  `keywords=magic` carries **exactly** the search page's `ItemList` in the same
  order (verified). It returns `bookId, bookName, authorName, categoryName,
  totalScore, description, tagInfo[]` — i.e. author and rating too, which the
  HTML feed never had.

So `WN._apiUrl(q, pageIndex)` + `WN._parseApi(text)` are now the primary path:
`WN.search` tries the API and falls back to the HTML page/`WN._parseBooks`, the
feed's six jobs are API URLs (the 440 KB home-page job is gone), and
`fetchBrowsePage` parses JSON first and keeps the HTML parsers as its fallback.
`BURST_SENSITIVE` is left alone on purpose: the site's *pages* (catalog,
chapter, book) still need the foreign route, so the politeness/hegde tuning
still earns its keep.

The other JSON endpoints found in the bundle, for a future agent (the route to
find them: fetch `m.webnovel.com/search?keyword=x` and grep its `_next/static`
chunks for `/go/pcm/`):

- `/go/pcm/book/getBookDetail?bookId=…` → 24.5 KB, `bookInfo` with
  `bookName, authorName, categoryName, totalScore, voters, chapterNum,
  description, tagInfos, firstChapterId` — a cheap replacement for the 187 KB
  book page if `WN.getBook`'s catalog fetch ever needs splitting.
- `/go/pcm/search/getHotSearch`, `/go/pcm/search/get-tag-list`,
  `/go/pcm/recommend/getRecommendList`, `/go/pcm/category/getRankList`
  (the last one answers `1001 parameters error` — it wants different params).
- A chapter-list endpoint does **not** exist in plain form:
  `/go/pcm/book/getChapterList` 404s and `/go/pcm/seo/book/getChapterList`
  returns an encrypted blob. The catalog stays HTML.
- `/_next/data/<buildId>/search.json` returns an HTML page, not JSON.

## 2.7.11 — Lib Read + the FreeWebNovel truncation fix

The app was on **v2.7.11**: 2.7.10 plus one new source, **Lib Read**
(`libread.com`) — fourteen sources now — and a chapter-truncation fix on
FreeWebNovel that came out of writing it.

- **Lib Read is a mirror of FreeWebNovel** (same site software, same novel ids,
  same `/files/article/image/...` covers, and its chapter pages even carry
  `freewebnovel.com` in their `<link rel="canonical">`), so `LR_*` is a thin
  variant of `FW_*` — but *not* a copy: three things differ and each one is a
  trap that a copy would have walked into.
  - **URL shapes.** A novel is `/libread/<slug>-<id>`, a chapter
    `/libread/<slug>-<id>/chapter-<n>`, and its chapter list is path-paged by
    **path** (`/libread/<slug>-<id>/2`, 40 chapters a page) rather than `?page=N`.
    Since 2.7.30 the list itself comes from `?ajax=chapters&page=N&pageSize=200`
    (`WP_loadAjax`, 200 a request) and the path paging is the fallback — which is
    what `WP_loadRest({ queryPage: "/" })` takes. Chapter ids keep the site's own
    leading zero (`01`, `041`, `0201` — it is literally `"0" + number`, on the
    ajax route and the book page alike, so stored positions and history still
    line up), so the chapter's `href` is stored and used rather than rebuilt.
  - **The page's own Prev/Next anchors are wrong for this host.** They point at
    freewebnovel.com's shape (`/novel/<slug>/chapter-867`, verified 404 on
    `libread.com`), so navigation is computed from the chapter list only —
    `LR_getChapter` never reads those anchors.
  - **Its covers are its own host**, `libread.com/files/...`, which serves them
    happily but sends **no ACAO** (a `crossOrigin="anonymous"` load fails
    outright, measured), so `libread.com` is excluded from the crossOrigin group
    in `loadCoverImg` and its route list is `[direct, weserv]`. Measured: the
    direct route answers, and a scrolled feed loads every cover.
  - Everything it serves is server-rendered behind a plain GET — no header, no
    scrambling — so an ordinary `sf()` (and therefore the packaged app's existing
    **bridge**) reads it with no changes; `sfHealth("LibRead")` → `"ok"`,
    measured 0.8s for the first feed page (7 cards) and 50 cards from
    `/sort/most-popular`.
  - Its `/sort/most-popular-novels` (the link the site itself shows) **404s**;
    `/sort/most-popular` works, and the feed's five jobs use that. Search is
    `GET /search?searchkey=` — the site's own form POSTs, but the same page
    answers a plain GET. Listing cards often show `0.0` even for a rated novel,
    so LibRead is in `RATING_ENRICHABLE`, reading the real figure from the book
    page's `<p class="vote">4.4 / 5 ( 80 votes )</p>`.
- **FreeWebNovel chapters were being truncated** — a 56-paragraph chapter
  rendered as 14. The site injects ad `<div>`s *inside* `#article`, and
  `FW_getChapter` matched it non-greedily, so the chapter stopped at the first
  advert. It now uses `NF_divRegion` (the tag-balance walk the "fwn" theme
  already had) — measured before/after on the same chapter: 14 → 56 paragraphs,
  with the last paragraph the real end of the chapter. `LR_getChapter` uses the
  same walk from the start.

## 2.7.10 — NovelHi in the packaged app

The app was on **v2.7.10**: 2.7.9 plus the fix that makes NovelHi chapters read in
the **packaged app**. The old write-up below ("NovelHi (2.7.7)") says the worker
is the one transport that can carry NovelHi's `X-Requested-With` header. That was
wrong, and the correction is what this version is built on:

- **Every proxy here forwards `x-cors-headers`, just not a plain header.** Sent
  as a JSON cors-anywhere `x-cors-headers` object *alongside* the plain one
  (either alone is refused), NovelHi's chapter endpoint answers `200` through
  **`root.superFetch`** (identity, the perchance proxy), the **fetch-plugin
  proxy** (`npcProxy`) and the **cors worker** — measured: 4/4, 8/8 and 1/1.
  `NH_HEADERS` is now that pair (`index.html`, with the measurements in the
  comment), which means:
  - the **app's bridge page** carries it, because its `superFetch` branch passes
    `init.headers` straight through — so **the packaged app reads NovelHi
    chapters without the bridge page being re-saved** (verified against the
    *deployed* page, which predates NovelHi entirely: `bridgeFetch` with the
    pair returned the chapter JSON in 4.7s);
  - the browser build no longer needs the worker for NovelHi at all.
- **A 429 is per route, not per novel.** `NH_fetchContentRaw` is now a sweep
  over routes (`native` → `direct` → `superFetch`/`bridge` → `worker` →
  `proxy`), each route being a different address with its own free allowance.
  A refused route hands over to the next one, the route that answered last is
  tried first next time (`NH_lastRoute`), and the per-novel two-minute block is
  only set when *every* route has refused. Measured: "Bewitching Prince", the
  novel the worker permanently 429s, now reads (34 paragraphs, 1.6s) through
  `superFetch` — the metering complaint from 2.7.7 largely evaporates.
- Two extra routes are wired but only exist in a packaged build: `direct` (works
  when the APK wrapper allows universal access from file URLs) and `native`
  (`window.LitNative`, the optional Android bridge described in
  `src/android-plugin/README.md` — the app now actually uses it, as that
  document always claimed).

2.7.9 was 2.7.8 plus the second round of NovelHi field fixes — covers were
*still* going missing, and some novels open with no chapter list at all. Both are
measured and written up under "NovelHi (2.7.9)" below:

- **Covers refuse in bursts, so they are now retried** (`loadCoverImg` walks its
  route list and then tries the whole list again — three quick rounds plus one
  after 8s — instead of hiding the image on the first refusal). Measured: a
  201-cover burst used to end with 39 covers hidden; it now ends with **201
  shown** (~11s, 11 of them through `npcProxy`), and a 60-cover burst loads in
  ~2s. Note a query string on these URLs is refused outright (`?r=1` errors
  every time), so retries reuse the same URL rather than cache-busting.
- **NovelHi's withdrawn novels say so.** A novel it has pulled from free reading
  keeps its book page but every chapter route answers with that same page, and
  the page carries `#copyrightProtectedFlag = true` — exactly the 2 of 12 books
  whose chapter list came back empty. `NH_getBook` reads that flag and the book
  screen explains it ("NovelHi has withdrawn this novel … use Migrate") instead
  of the old "no chapter list yet", and Migrate is now enabled for a novel with
  nothing to read here even before it is in the library.

The app was on **v2.7.8**: 2.7.7 plus two NovelHi problems that only showed up in
use — its covers came up empty, and a metered-out novel read like a broken
chapter. Both are measured and written up under "NovelHi (2.7.8)" below; the
short version:

- **Covers.** `img.novelhi.com` turns away many browser-hot-linked requests
  (they 403 outright much of the time; image proxies such as weserv are refused
  too), so NovelHi's *fallback* cover is now `npcProxy()` — the same
  fetch-plugin route the app already uses for text — and its host was taken out
  of the `crossOrigin="anonymous"` group in `loadCoverImg` (that host sends no
  ACAO, so asking for CORS made the image fail outright, on *every* cover).
- **Chapters.** A metered refusal arrives as a CORS-less response the browser
  reports as `Failed to fetch`, so it is now classified as a rate-limit, and the
  reader shows a dedicated "NovelHi is pausing this novel" card — plain words
  plus Try again / Find on another source / Open site — with **no** auto-retry
  loop (retrying every 7s against a spent allowance was a lie and a wasted
  request).

The app was on **v2.7.7**: 2.7.6 plus one new source, **NovelHi** — thirteen
sources now (see "NovelHi (2.7.7)" below for its listing API, its scrambled
chapter text, and the one transport that can carry the header its chapter
endpoint demands). Two small things came with it: `bridgeFetch(url, {via})` now
relays a transport choice to the bridge page (the packaged app has to make the
NovelHi chapter call through it), and a latent bug in `NLP_lastPage` was
repaired — its regex-escape string had been mangled into a literal
`\const SRC = {`, which only mattered for a slug containing a regex
metacharacter (real slugs are letters and hyphens, so nothing had broken yet).

2.7.6 was the optional **Roleplay AI** feature (see "Roleplay AI" below) — a
texting-style chat with AI characters, switched on from Settings → Features,
which then shows up at the bottom of the Browse source list behind a *Not a
reading source* divider. It is a self-contained extra: no import, no key, and it
works in the packaged app too. Nothing in the fetch layer or the sources changed
in 2.7.6.

2.7.5 was 2.7.4 plus the source fixes described under
"FreeWebNovel: chapter 1 was missing from every novel (2.7.5)" (chapter 1 was
missing from *every* FreeWebNovel novel, plus two dead feed jobs there and two on
Novel Cool). 2.7.4 was the Webnovel speed work, described under
"Webnovel speed (2.7.4)" — a burst-sensitive host now races a fast foreign
route (jina / `corsworker`) against its own slow one instead of waiting the
slow route out, remembers which foreign route answers it quickly, serialises
chapter prefetches, and gets a faster health probe. Also earlier: 2.7.1's
Webnovel captcha fixes, 2.7.3's "a refusal is asked about again", and the
connection pill. `index.html` is the
source of truth and `src/standalone/index.html` is generated from it (same file
with a `<!DOCTYPE html>\n<meta charset="utf-8">\n` prefix). The user supplied a
**v2.4.2** standalone as the last build where Webnovel was dependable — read
"Webnovel: why it showed a captcha" and "Webnovel speed (2.7.4)" before
touching `WN.getChapter`, `sf()`, `hedgedGet()` or `sfHealth()`.

The 2.8.x/2.9.x work was reverted (a batch of regressions) and is **not** here.

**Some sections of this README describe 2.8/2.9 code that is no longer here.**
As of 2.7.0 the following do **not** exist — treat any mention of them as
future-work notes, not as documentation:

- Native bridge (`window.LitNative`, `nativeAvailable`, the WTR device route).
  **Partly back in 2.7.21:** the client no longer offers a general native
  *transport* (only NovelHi's own `NH_*` route uses `fetch`), but
  `nativeObj()` / `nativeOpenChallenge()` do drive the wrapper's `challenge`
  screen when the app has one.
- In-app site view. **Back in 2.7.21 in a minimal form:** `openSiteView` /
  `closeSiteView` / `dismissSiteView` and `#siteviewScreen` exist (frame +
  back/reload/open-in-browser chrome + one pushed history entry so Android's
  back closes it). What is *not* here is the 2.9 `data-site-view` wiring into
  every failure card, the WTR gated card's frame, and `solveInWebView`.
- Connection test (`runNetTest`, `netReportText`, its display/Window rows).
- WTR "Unlock" flow (`wtrGatedCard`, `solveInWebView`).
- The once-per-browser intro gate: `yuedu_intro_seen` / `introSeen()` existed
  from 2.7.21 and were **removed in 2.7.36** — the reader asked for the splash to
  come back on reload, so `hideIntro()` is now the whole of the intro logic.
- The `width=device-width` viewport fix: 2.7.0's tag still says
  `width=600, maximum-scale=1, ...` (see "Things that will bite you").

`src/DESCRIPTION.md` was written against 2.6.1 and still advertises the WebView
"Solve in a WebView" / site-view features, so re-sync it before publishing. Its
source list (now 33 sources, comics included), its "### Comics" section, the
"At a glance" bullets and the short/medium blurbs are current for **2.8.0**.

## Files

- `index.html` — **the whole app.** HTML + CSS + one classic `<script>`. ~25k
  lines (1.40 MB). No framework, no build step. Everything is in here (sources
  registry `SRC`, screens, the two readers — text and comic — updates, comments,
  settings, and the optional Roleplay AI under `/* ===== roleplay AI ===== */`).
- `main.pjs` — Perchance config only: `$meta` (title/description/tags) and the
  `superFetch = {import:super-fetch-plugin}` import. `root.superFetch` is how
  all cross-origin source fetching works in the browser build (it is the
  CORS-free proxy); `sf()` wraps it with retries/proxies/captcha detection.
- `src/standalone/index.html` — **generated** standalone copy of `index.html`
  for the packaged WebView app (Android). Never edit it directly.
- `src/DESCRIPTION.md` — the user-facing description of the app (what it does,
  feature by feature) plus the short/medium blurbs used for publishing (the
  short one is mirrored into `main.pjs` → `$meta.description`). Keep the feature
  list in sync when features change.
- `src/android-plugin/` — `LitNative.java` + its README: the JavaScript interface
  the **APK wrapper** (the user's own HTML→APK converter, not this generator) can
  register so the app can make requests from the device's own connection and open
  a real WebView to pass a site's check. YueDu detects it automatically and
  falls back to the proxies when it is absent, so this folder is documentation +
  a drop-in for the user, not something the shipped generator executes. Read its
  README before touching the "native bridge" block in `index.html`. The same file
  also carries `LitNative.Tts` (`window.LitTts`), the device speech engine behind
  read-aloud's `native` engine — see the README section "Read aloud" there.

## Version bumps

`APP_VERSION` in `index.html` (search for `const APP_VERSION`) is the displayed
app version; every release also gets a `{ ver, date, items: [...] }` entry at
the **top** of the `UPDATES` array (that entry is badged "Latest" in Settings →
About → update log, which is also what the in-app update check compares against
the console manifest). Bump both together, then rebuild the standalone.

### NovelFull / NovGo (shared "fwn" theme)

Both sites (and the code path is shared — `NF_*`, selected by `NF_HOME` vs
`NG_HOME`) moved to a new theme in Sept 2026 and **the old parsers silently
matched nothing** (feed showed "Couldn't load NovGo"). Current shape:

- Listing/search pages: `<div class="li-row">` cards, title in
  `<h3 class="tit"><a href="/<slug>.html">`, rating in
  `<div class="core" title="Rating 4.4/5"><span>4.4</span>`.
- Novel page: a **JSON-LD `Book`** block (name/image/description/author/genre)
  plus `<div class="score" id="novel-score" data-avg="4.4">`, and
  `#list-chapter` carrying `data-total-chapters` (the true total) **and the
  numeric `data-novel-id` the site's own chapter endpoints want**. Since 2.7.30
  the whole list comes from `/ajax-chapter-option?novelId=<data-novel-id>` (the
  site's own chapter dropdown, one request) with `/ajax-chapter-list?novelId=&page=`
  (JSON, `{code, html, totalPage}`, 40/page on NovelFull and 50 on NovGo) filling
  any gap — both in `NF_loadCatalog`. Only the fallback is the old shape: page 1
  inline plus `?page=N` for the rest, which is what `WP_loadRest` still uses.
- Chapter page: body in `#chapter-content.chapter-c`, title in
  `<h1 class="chapter"><span class="chapter-title">`, prev/next links carry
  `data-nav="prev|next"`. **The site injects ad `<div>`s inside the chapter
  body**, so a non-greedy `…</div>` match truncates the text — `NF_divRegion`
  walks the tag balance instead (`NF_contentRegion`).
- Chapter 1's "Read first" shortcut repeats chapter 1's URL with a junk label,
  so `NF_parseChapters` skips `read first|last|now` labels and lets the real
  list entry win. Chapter slugs can look like `chapter-94-93-slug` (site
  numbering - original numbering); the **first** number is the id used
  everywhere. Since 2.7.30 the URL match is `/ch[a-z]*-` rather than `chapter-`,
  and the number falls back to the label's first number (`NF_numFrom`) — that is
  what recovers the site's own typo'd addresses (`chatper-276-…`, `chpater-2812-…`,
  `chaoter-2843-…`, `chapter-entertaining-guest.html`) and gives Shadow Slave its
  last four chapters. Two chapters under one number keep both rows: the later one
  gets a titled id from `NF_uniqueId` (`1074~millennial-history-part-2`) while
  keeping `num`, and `NF_getChapter` resolves a bare number to the first one.
- **`NF_HOME` is `novelfull.net`** — `novelfull.com` serves the pages but its
  chapter URLs 404; the `.com` pages even link to `.net`. Host checks accept
  both.

## Rebuilding `src/standalone/index.html`

It is **exactly** `index.html` with `<!DOCTYPE html>\n<meta charset="utf-8">\n`
prepended (the browser build is body-only HTML because Perchance supplies the
document wrapper; the WebView shows a real document). Regenerate after every
`index.html` change, then verify by reversing the prefix and checking the
result is byte-identical to `index.html`:

```js
const main = await fs.readTextFile("index.html");
const DOCTYPE = "<!DOCTYPE html>\n<meta charset=\"utf-8\">\n";
await fs.writeTextFile("src/standalone/index.html", DOCTYPE + main);
```

There are **no other deltas any more** — the standalone-specific `sfPost()`,
the POST-capable fetch bridge (`bridgeFetch(url, {method, headers, body})` +
the `__litBridge` message listener) and the offline catalog index all live in
`index.html` itself, so the two files can never drift.

### How the standalone reaches the network

A WebView on a `file://`/app origin has no `root.superFetch` and no CORS, so
`sf()`/`sfPost()` fall back to a hidden `<iframe>` pointed at
`https://12c16b23b865115bd819d5748612064f.perchance.org/lrreader#bridge`
(`BRIDGE_URL`). The app `postMessage`s `{__litBridge:id, url, method, headers,
body}` into it; the perchance page fetches with `root.superFetch` and replies
with `{ok, status, text}`. If the bridge iframe dies, `bridgeDead` latches and
the app degrades to direct/proxy URLs.

`sfPost` is what the **Novel Cool app API** goes through (2.7.29) — a
form-encoded POST to `api.novelcool.com`. Every route that carries it was
measured working: `root.superFetch` in the browser build, the bare
`fetch-plugin.perchance.org/proxy1/…` URL (which is the route a packaged build
without the bridge iframe uses), and the bridge itself. So Novel Cool reads in
the APK as well as on the generator page.

A request may instead carry `via:"corsworker"` (`NH_xhr` in the NovelHi block).
The listener then fetches through `test.cors.workers.dev` rather than
`root.superFetch` — that is how a source needing an `X-Requested-With` header is
read in the packaged app, because the worker is the only transport that forwards
one. See "NovelHi (2.7.7)".

**Consequence: the bridge's POST support only exists in the *saved* generator.**
Until the user saves, the deployed bridge page ignores `method`/`body`, so the
bridge returns the (body-less) search page. `sfPost()` therefore tries a
**direct** POST *before* the bridge — both NovelLive and LightNovelPub allow
that from the perchance page origin, so search works even with a stale bridge —
and only then falls back to the bridge, the proxy URL, and finally the catalog
index (still correct results, just fewer). Saving the generator makes the
bridge POST path usable too (needed for origins where direct CORS POST is
blocked, e.g. a `file://` WebView). The built `index.html` above only reaches
the app after re-copying/rebuilding it.

### Offline catalog index (`pocketnovel_catalogs`)

NovelLive/LightNovelPub only answer a **POST** search, and NovGo's own
`/search?keyword=` returns nothing at all (its old code then showed the
front-page feed as if it were results — that's the "unrelated novels" bug).
So `CATALOGS` in `index.html` keeps a cached slug index built from each site's
sitemap (NovGo ~5.7k slugs, NovelLive and LightNovelPub ~5k each; slugs are
`nl-`/`lp-`/`ng-` + the URL slug, so they match the generated-id scheme).
`catalogSearch(source, q)` scores slugs by token overlap (2 = every token,
1 = ≥60% of tokens), then `catalogEnrich` fetches ≤`CATALOG_ENRICH_MAX` (12)
detail pages (og:title/og:image/og:novel:author + rating) to replace the
slug-derived title (bounded by a 2.6s budget so a slow source can't stall the
search). All three catalogs together are ~585 KB of localStorage, under the
`CATALOG_STORE_MAX` (900 KB) cap — a store that would exceed the cap drops its
oldest source first. TTL is `CATALOG_TTL` (7 days).

**Sitemaps can be indexes.** `catalogSlugs` handles both `<urlset>` and
`<sitemapindex>` (`walk()`, up to `CATALOG_SUBS_MAX` children, one level deep,
2 concurrent). This matters: NovGo switched to an index whose child holds the
novel list, which silently left the source with *no* catalog (search found
nothing in a fresh install while a device with an older cached catalog still
worked — the "works here but not in the standalone" bug). If a refresh fails
entirely, the previous (expired) store entry is used anyway rather than
reporting nothing. `warmCatalogs()` runs 6s after boot and builds whichever
catalogs are missing/stale in the background, so the first search in a fresh
install is instant instead of waiting on a multi-hundred-KB download.

Search order for those three sources: real site search (POST via `sfPost` for
NovelLive/LightNovelPub, `/search?keyword=` for NovGo) → catalog index → if
both are empty, "No results" (NovGo) or the captcha/network error. It can
never return an unrelated novel. NovelArrow instead uses its JSON API
(`/api-web/search`) and falls back to its SSR `/novels/search?keyword=` page
(only when the page `<title>` actually contains the query); the old
`r.jina.ai` markdown scrape (which could return the site's *home* page) is gone.

Also: a search increments `searchRun` and sets `discover.paused = true`, and
`pumpDiscover()`'s two "replace the spinner with an error card" branches
require `discover.sentinel.isConnected` — otherwise a slow browse feed could
hijack a search that was still loading and paint "Couldn't load X" over it.

## Mobile text input (read this before touching the search bars or `main`)

Four things used to make the search fields misbehave on real phones (caret
flickering, focus lost, typed characters never appearing). All four are fixed
and must stay fixed:

1. **Pull-to-refresh must never start on a control or after < 8px of movement.**
   `pullMain` is `<main>`, so the pointerdown that taps the search bar used to
   start a pull gesture and flash `#pullEl` on every single tap ("that fade and
   show repeatedly"). Now: no gesture when the target is an `input`/`textarea`/
   `select`/`button`/`a`/`label`, `pull.shown` only flips true after dy > 8px,
   and `focusin` on an editable cancels any latched gesture.
2. **The fullscreen layout class must not flicker while the keyboard opens.**
   The inline script at the top of `index.html` toggles `.fs-immersive`
   (padding) from `screen.height - innerHeight`. That delta sweeps through
   every value while the IME animates, so the old version re-toggled padding
   over and over, re-laying-out the page under the caret. It now requires the
   same delta on two consecutive checks 220ms apart, and ignores `diff > 120`
   (keyboard open) entirely.
3. **Never rewrite an input's `value` while it is focused** (see
   `searchAuthorWorks`). Also `clearTimeout(searchTimer)` in
   `enterSourceMode`/`exitSourceMode` so a debounced search from the previous
   source can't fire into the new one.
4. **Don't rebuild big DOM under a focused field on every keystroke.** The
   library filter (`#searchInput`) is debounced (130ms); the browse search
   debounces 450ms and sets `discover.paused = true` immediately so the
   discover feed stops appending cards mid-typing. Both search fields also blur
   on Enter so the keyboard gets out of the way.

All text inputs also get `-webkit-text-fill-color` + `caret-color` +
`color-scheme: dark` from one rule (search "keep typed text + caret visible"),
because a WebView that algorithmically darkens the page can otherwise render
input text invisible.

## Top spacing / fullscreen (`.fs-immersive`) — read before touching any header padding

Every top row carries `env(safe-area-inset-top, 0px)` (always give the
fallback, or an engine that doesn't know `env()` throws the whole declaration
away). On top of that, the app has two layout modes:

- **normal** — the header keeps its own small padding (12–18px).
- **`.fs-immersive`** — set by the inline script at the top of `index.html` when
  `screen.height - innerHeight < 2` (i.e. the page really owns the whole
  screen, which is what an edge-to-edge APK/WebView looks like). Here the
  headers must sit *just* below the system's top-edge swipe strip:
  `calc(env(safe-area-inset-top, 0px) + 10px)` for `.library-header`,
  `.screenTitle`, `.reader-header`, `.bookHeader`, `.readerSearch` (`top`, +63).
  `.reader-body` is **not** part of this mode any more — its top padding is the
  same 78px + inset in fullscreen and in normal mode (see below) so the reader
  text never moves.

The numbers were 42/46/40/95/110px until 2.6.1, which in an APK (where
`env(safe-area-inset-top)` is normally **0**, unlike in a notch-y browser) left
a fat empty band above every header. Don't raise them again without a real
screenshot from a device; the values must stay small because the strip they are
clearing is usually invisible in fullscreen.

The reader is the one screen whose header *floats over* the text
(`position:absolute`, like video-player controls), and **its top padding must
not depend on the chrome state**: users reported that tapping the screen (which
toggles the chrome) *moved the paragraph they were reading*. So:

- `.reader-body` → `padding: calc(env(safe-area-inset-top, 0px) + 78px) … 60px`
  in **both** states. 78px clears the floating header in normal mode (14 + 40 +
  13 = 67px) and in fullscreen (10 + 13 + 40 = 63px). Padding on a *scrolling*
  element scrolls away, so once you scroll past the first screenful it costs
  nothing — and the chapter's first lines are always readable when it opens.
- `#reader:not(.chrome-hidden) .reader-body` → `padding-bottom: 110px` only
  (the floating footer is 72px). Growing the bottom padding changes the scroll
  range, not the position of the text you are looking at.

Do **not** reintroduce a `padding-top` that varies with `.chrome-hidden` — that
is exactly the 2.6.1 mistake (reverted in 2.7.0).

## Notification UI (update + developer message)

One design system, shared CSS, two elements (both created lazily in JS and
appended to `<body>`):

- `#updateModal` / `.updateModalCard` — `showUpdateModal(manifest)`: pill row
  `v<current> → v<new>`, "what's new" note cards with the check glyph drawn as
  a data-URI SVG (not a text `✓` — the fallback font rendered it as a flower),
  Get update / Not now, backdrop tap dismisses (and snoozes 24h).
- `#announceModal` / `.announceCard` — `showAnnouncement({id,title,sub,message,link})`
  from the manifest's `announce*` fields. Amber theme, `white-space: pre-wrap`
  so multi-line dev messages keep their line breaks. The link/id are stashed on
  the element (`modal._link`, `modal._annId`) because the modal is created once
  and reused — the old closure captured the first announcement forever.
- The Update log screen's `#latestUpdateCard` (`renderLatestCard`) mirrors the
  same look, and `#latestIcon` switches between the download / tick / warning
  glyph. JS appends the Get update button to the card, so the card layout is a
  column (`.latestRow` on top, button full-width below).
- **Notification dot:** `refreshUpdateDot()` shows `.navDot`/`.rowDot` (More
  nav item + Update log row) while a newer version is known and
  `localStorage.yuedu_seen_version` isn't that version;
  `markUpdateSeen()` clears it, called from `openUpdatelogScreen()` and from
  the Get update buttons.

## Connection pill (`#netAlert`) — "Slow connection" / "No internet connection"

A one-line pill, top-center of the screen, that appears while **the reader's own
connection** is struggling, so a feed or chapter that takes fifteen seconds reads
as "my signal is weak" rather than "YueDu is broken". Deliberately not a
panel: a 7px dot, one short line, `pointer-events: none`, and it fades out by
itself. Rules worth keeping:

- **It never measures the network by itself.** No probe requests, no `fetch` of
  its own — the app is already careful about request volume (see Webnovel), and
  a background poller would both cost requests and count against sources that
  rate-limit. Sources of truth: `navigator.onLine` + `online`/`offline` events,
  and the Network Information API (`navigator.connection.effectiveType` / `rtt`
  / `downlink`, read on a 5s timer and on its `change` event). The Android
  WebView the APK uses **does** provide that API, which is exactly where the
  user's readers are; the numbers are read, never fetched.
- **Where there is no API** (iOS Safari, Firefox) it only believes the app's own
  raw transports failing: `httpText`'s catch calls `netNoteFail` for a request
  that never reached anyone (a TypeError — an `AbortError` there is usually just
  `hedgedGet` retiring a route that lost the race, and must never be blamed on
  the reader) and `netNoteSlow` when our own deadline fires; `bridgeFetch`'s
  timeout calls `netNoteSlow` too. **Two different hosts must fail inside 15s**
  before the pill blames the connection, so one dead public proxy (allorigins
  and cors.lol are flaky by nature) can never put it on screen.
- **Placement is `top: calc(env(safe-area-inset-top, 0px) + 110px)`** — 110px is
  measured: the tallest header block on any screen is 109px (Updates/History:
  title 0-43 + subtitle 43-70 + tool row 70-109). Anything smaller puts the pill
  on top of the Library tab row (61-90). The pill floats over content by design
  (over the first row of cards, or between the reader's chapter title and its
  first paragraph) — same idea as `#toast`. It is `z-index: 30`, i.e. under
  `#toast` (40) and under `#introScreen` (100), so the intro still covers it.
- **The hide is debounced 4s** (`NET_ALERT.hideT`): one lucky request in the
  middle of a bad patch must not blink it off and on. `netRefresh()` re-checks
  before actually hiding.
- State: `NET_ALERT` (`fails`/`slows` are `{at, host}` lists, windowed to 15s),
  `netState()` → `"" | "slow" | "offline"`, `netRefresh()` renders.
  Verified: 2g/3g-with-high-rtt and `downlink < 0.5` → "Slow connection" (amber
  dot, pulsing); `onLine === false` → "No internet connection" (red dot, no
  pulse); back to 4g → fades ~4s later. Measured centred to the pixel
  (centre x 234 in a 469px-wide capture at 1.199× scale).

## Online readers count (presence)

Firebase Realtime Database (config `FB_CONFIG`, rules documented in a comment
next to it in `index.html`). Each client writes `presence/<uid> = serverTime`
every 45s and on focus/visibility/online; `fbCountFromSnap` counts entries newer
than 120s. **Moved in 2.7.17: the UI now lives in Settings → Advanced**, still as
`.readersCard` (`#readersSub` status line, `#readersPill` + `#readersCount`, and
`#readersRefreshBtn` → `fbCheckReaders()`, which re-writes our presence and
does a one-shot `once("value")` read so the ⟳ button gives an instant answer).
(The ids are unchanged, so the presence code does not care where the markup is —
only one `.readersCard` may exist.) It is deliberately *not* on the library tabs.
**Incognito readers are not counted**: `fbRefreshPresence` / `fbInit` remove the
presence node instead of setting it while `INCOGNITO.on` is true. `READERS`
(`{count,on,busy,everOn}`) drives the status text: `Connecting…` / `Checking…` /
`Waiting for the count…` / `You're the only one here right now` /
`Live · updates automatically` / `Couldn't connect — tap ⟳`. **If the Firebase
SDK loads from gstatic and fails, you get the usual cross-origin
"Script error." noise in the console — that is expected, not a regression.**

## Fetch layer (why the standalone used to crawl) — read before changing `sf`/`bridgeFetch`

One page = one `sf(url)` call. The old implementation tried transports **one
after another**, each with an 18s timeout, up to 12 attempts, and it set
`bridgeDead = true` on the *first* bridge timeout — which disabled the fast
route for the rest of the session, so everything after that walked a chain of
slow public proxies (or never finished). Seven rules now:

**The list starts with the native bridge when the packaged app has one**
(`nativeAvailable()` prepends `{name: "native"}` to `getTransports()` and
`sfPostTransports()`): it asks from the device's own connection with the app's
cookies, which is the only route a per-address bot gate cannot touch, and every
rule below still applies as the fallback chain after it.

0. **Ask a page from at most two routes, and make the second a different
   network.** `MAX_PARALLEL = 2`; `spawn()` arms the next start and the
   transport that settles re-arms it 550ms later, so the chain still advances
   quickly but one page can never fan out into a burst. The promoted second
   route is **jina** (`FOREIGN`), not the next same-platform proxy: two
   requests from the *same* proxy IP is exactly what gets that IP
   rate-limited, and they fail together. **A host gets one request at a time
   in one case:** it has refused every route recently (`politeHosts` /
   `markPolite`, 4 min, set only where `sf()` concludes the *source* refused
   us — never from a single transport's transient 403, because FanMTL's proxy
   403s while jina answers fine and must stay parallel). A host that answers
   every burst with a bot check *permanently*, from the first request —
   `BURST_SENSITIVE` (`m/webnovel.com`) — is the other case, and it is handled
   **per network rather than per page** since 2.7.4: our own routes share one
   network and the foreign ones (jina, `corsworker`, allorigins, cors.lol) are
   different datacenters, so one request from *each* side may be in flight at
   once and no route can ever be duplicated. That host can therefore keep the
   fast foreign route as its hedge instead of waiting out our slow one (see
   "Webnovel speed (2.7.4)"). The feed still runs
   `DISCOVER_CONCURRENCY` (2) pages at once, which is exactly how the last
   dependable build (2.4.2) asked Webnovel. Previously blocked hosts
   are gentler still: `discoverPolite()` → concurrency 1 +
   `DISCOVER_POLITE_GAP` (1.4s) between pages.
1. **`hedgedGet(url, opts)`** (used by `sf` and `sfHealth`) starts transport
   #1 only, then starts #2 every `hedge` ms if nothing has answered, and
   resolves with the **first** success (`via` names the winner). Losing requests
   are aborted. `lastGoodTransport` moves the last winner to the front and
   widens the hedge to 4.2s, so a healthy route is used most of the time but is
   never a single point of failure. Total time is bounded by `deadline`
   (20s first try, 12s for retries, which also use a 1.8s hedge). **`sf()`
   clears `lastGoodTransport` whenever an attempt fails** — a stalling route
   must not keep its front-of-queue bonus and slow the retry down. `sf()`
   passes `hedge: undefined` on the first attempt so the normal default applies.
   **The hedge has to be scheduled when a transport *starts*, not only when one
   fails.** It used to be scheduled from `settle()` (failure) only, so the
   "race" was really a serial chain: a route that *worked but slowly* held
   every faster route behind it (FanMTL's Cloudflare-slowed superfetch took
   4-6s and nothing else was tried, while jina would have answered in ~1s).
   `spawn()` now arms the next-start timer, `schedule()` clears it before
   re-arming, and a transport that fails within 1.2s shortens the gap to 550ms
   (it is definitely out — don't make the user wait a hedge for it).
   **`opts.require` (2.7.18)** is a predicate on the response text. A transport
   that answers with a page which does not contain what was asked for is settled
   as a *failed* route (`"<name> answered without what was asked for"`) instead
   of winning the race, and the hedge moves on; the check runs **after** the
   challenge/403/404 handling, so a Cloudflare page from one of our own routes
   still takes the blocked path. If every route that produced a body produced one
   without the marker, the request rejects with `contentless: true` and "The site
   answered, but not with the page that was asked for" — a route that never
   answered (a timeout) does **not** count towards that, so `sf()` still retries
   rather than declaring it final (a cold bridge is exactly the route a retry
   reaches). `sf()` also treats a `contentless` failure as final: no re-asking the
   same routes, no captcha probe, and the source is not marked down, because it
   answered. NovelHi's chapter list is the only caller so far — see "NovelHi's
   chapter list on a cold start (2.7.18)".
2. **Per-host hedge memory (`hedgeMemory`, keyed by hostname).** After a page
   that took >3s from a host, later requests to that host hedge at 700ms;
   after a fast (<1.5s) page the entry is dropped. FanMTL's book page goes from
   ~5s to ~1.1s and its chapter/catalog pages to ~0.7-1.4s (all via jina).
   Hedge defaults: 1.5s (2.5s if `lastGoodTransport` is known); a
   burst-sensitive host uses `BURST_HEDGE` (600ms) on its first page and
   `BURST_HEDGE_KNOWN` (2500ms) once a fast foreign route is known for it — see
   "Webnovel speed (2.7.4)".
3. **A 403/challenge only condemns the transports that share our network.**
   `blockedNow()` drops the rest of the queue but immediately starts the
   *foreign* transports (`FOREIGN = {jina, corsworker, allorigins,
   allorigins-get, cors.lol}` — servers in completely different datacenters)
   under a 7s grace
   window, because Cloudflare rate-limits a range, not the whole internet. This
   is what makes FanMTL and Scribble Hub chapters work again: our perchance
   proxy gets a 403 in ~0.6s, jina gets the real page in ~0.9s, and the chapter
   renders in ~1.5s instead of failing (FanMTL was ~12s, Scribble Hub ~15s or a
   refusal). If a foreign transport can't get in either, the honest refusal
   error arrives instead of a 20s hang. **A burst-sensitive host gets at most
   two of those last chances, not the whole list** — five requests from five
   networks at a host that has just refused us is itself a burst, and a burst
   is what makes the refusal stick. **Two hard-won details:** (a) the
   grace window was 3.5s, which is less than jina sometimes needs — a page the
   proxy was still about to fulfil got rejected as "blocked"; and (b) **a
   challenge *from a foreign transport* must not call `blockedNow()` at all.**
   jina/allorigins sit on IP ranges Cloudflare challenges constantly, so their
   403 says nothing about whether *we* can fetch the page — treating it as a
   verdict on the host killed requests that our own route was still about to
   answer, and that is what put the captcha screen in front of Webnovel. A
   foreign block now just retires that one route (`settle(name + " blocked")`);
   only our own routes being refused means the reader is being turned away.
   **`blockedNow()` must be reached with the blocked transport's in-flight slot
   already released** (`release()` in the challenge branch): leave it counted and
   `active` never reaches 0, so the attempt waits out `blockedGrace` (7s) instead
   of failing the moment the last foreign route gives up. See "A refused request
   is asked again (2.7.3)".
4. **`probeBlocked(url)`** answers "is the *site* refusing us or is the network
   just slow?" by fetching the URL through r.jina.ai (which returns the target
   site's own interstitial verbatim). It is (a) started only after an attempt
   has failed, (b) run **alongside** the retry, never cancelling it — jina's IP
   is often challenged where ours isn't, and vice versa — and (c) cached per
   host for 120s (plus an in-flight map) so the source-level retry loop can't
   hammer it. Its verdict only decides the *final* error: a refusal gets
   `err.blocked = true` (honest "this source is refusing YueDu" UI,
   `sfHealth() === "captcha"`) instead of "couldn't reach the site".
5. **A dead bridge is recoverable.** `dropBridge()` only latches `bridgeDead`
   after 3 failures; a success resets the counter. `ensureBridge()` recreates
   the hidden iframe, and `prewarmBridge()` (standalone only, called ~300ms
   after boot) loads the bridge page *and* makes one throwaway request so the
   first real page fetch doesn't pay for a cold perchance page load. Measured in
   the null-origin (APK-like) harness: warm bridge ≈0.8-1.6s per page, feed 40
   cards in 1.6s, chapter text in 2.0s.
6. **`sf()` only retries a handful of times** (3) with short backoffs and keeps
   the captcha/`lastBlockedUrl` bookkeeping. `checkSourceHealth` runs 4 at a
   time. **`sfHealth()` (rewritten in 2.7.19) is a single hedged probe** —
   `hedgedGet(url, { deadline: 12000 })` — answering "ok" when any route hands
   the page over, "captcha" only when the host refused *our own* route (the
   transport layer's rule, so every route was refused or challenged), and "down"
   otherwise. It used to be a strictly sequential walk of up to four routes with
   a long timeout on each, which is what left FanMTL sitting on "Checking…" long
   after every other source and then reading "Unavailable" while jina was
   answering its page in half a second; the walk was introduced to stop a
   single-route probe reporting "captcha" the moment one route was blocked (a
   false "captcha" means the captcha screen can never clear itself) — hedgedGet
   already refuses to condemn a host for a route that lost the race, so the
   property is kept without the wait. A *manual* refresh
   (`checkSourceHealth(true)`) also bypasses the ten-minute `healthSticky`
   window, so one bad verdict can no longer leave a working source reading
   "Unavailable" until the window expires.
7. **A refusal is not a captcha, and the UI must not confuse them.**
   `sf()` throws a Cloudflare/403 refusal with `err.blocked = true` and a
   message that never contains "captcha"/"robot" (see `lastRefusal`);
   `captchaBlocked(err)` returns false for `err.blocked`, so the "Solve"
   screen is not offered for something the user cannot solve (they tap Solve,
   the site shows no check at all, and the return-to-app flow has nothing to
   detect — the original FanMTL complaint). Refusals get honest copy plus
   Try again / Open site / **Find on another source** (`feedFailHint`,
   the reader error card, and `book.listError`'s card in the chapter list).
   `openSiteExternal()` opens the site with a synthetic
   `<a target="_blank">` click — never `location.href`, which navigates the
   WebView away from the app and is why "come back when you're done" could
   never work. The real captcha screen keeps the retry/watch flow and gains
   "Read this novel from another source →".
   `resumePendingCaptcha()` now restores the chapter/book/browse screen
   **first** (even while the source is still refusing) so an app restart
   during a check never drops the reader at the home screen.

`npcProxy(url)` (the perchance `fetch-plugin` proxy) is in the GET transport
list too — it is faster than allorigins on some sources, and `cors.lol` /
allorigins are kept mainly for the blocked-site path above. `corsworker`
(`test.cors.workers.dev`) is the newest transport; it is documented under
"Webnovel speed (2.7.4)".

### Source-by-source status (measured Sept 2026, warm preview, seconds)

| source | search | book | chapter | notes |
| --- | --- | --- | --- | --- |
| Webnovel | ~0.6 (API) | ~2.6-3.5 | ~0.5-1.4 | Since 2.7.12 the **feed and search use the site's own book-list API** (`WN._apiUrl`: 20 books in ~53 KB / ~0.5-0.8 s, answered by **our own route**) instead of its ~350 KB search pages, which only ever came back through a third-party proxy — the feed went from ~11 s to ~3 s and the home-page job is gone. See "Webnovel (2.7.12)" above. Chapters: reader page first, `getChapterApi` only as the fallback (`WN.getChapter`) — see "Webnovel: why it showed a captcha". The catalog stays a 1.36 MB HTML page (~2.3 s, in line with NovelHi). `BURST_SENSITIVE` and the hedge tuning still apply, because the site's *pages* are what its bot wall challenges. |
| Royal Road | ~1.0 | ~1.2 | ~0.9 | Nothing to fix; the fastest full source. |
| NovelArrow | ~1.0 | ~1.4 | ~0.8 | JSON API with SSR fallback. |
| FanMTL | ~2.8 | ~1.0 | ~1.0 | **Was ~11.5/6.0/12.1** — the chapter/book pages now come back through jina (~0.9s) after the 403 fast-path. Two search endpoints are raced with `firstListOf`. |
| WTR Lab | ~1.6 | ~1.0 | per-address gate | Their API counts requests **per internet address** (15, then a Turnstile check). YueDu's shared server is permanently over it; the user's own connection is not, so the app reads it (native route) and the reader offers an Unlock flow when the device's own address is over the limit too. See "WTR Lab" below. (`WTR_MARKER_RE` strips its watermarks.) |
| FreeWebNovel | ~0.9 | ~0.8 | ~0.2 | Chapter 1 is back in every list since 2.7.5 (the site's "Read first" shortcut was replacing it — see "FreeWebNovel: chapter 1 was missing from every novel"). Feed is five pages (`/sort/most-popular` + `/sort/latest-release` were dead/missing) and parses the home page's recommendations: **87 cards, ~1.7s**. Chapter list since 2.7.30 from `?ajax=chapters&page=N&pageSize=200` (200 a request; 2,545 chapters ≈ 13 requests / 3.3s). |
| NovelFull | ~0.8 | ~0.9 | ~0.9 | Shared "fwn" theme parser. Chapter list since 2.7.30 from `/ajax-chapter-option?novelId=` — the whole list in one request. |
| NovGo | ~1.1 | ~0.8 | ~0.9 | Shared "fwn" theme parser + offline catalog. Chapter list since 2.7.30 from `/ajax-chapter-option?novelId=` (one request); its own search still returns nothing, so search runs off the cached sitemap index. |
| NovelCool | ~0.9 | ~2-13 | ~2.2 | Search now uses the site's own AJAX search API (`NC_API_SEARCH`, raced with the HTML scrape). The book page is slow server-side. Two dead feed pages were replaced in 2.7.5 (see "Novel Cool: two dead feed pages"): the feed went from ~30 to **92 unique cards** in ~2.2s. **2.7.20:** feed covers are read from the card's `lazy_url` (the `src` is a placeholder that 404s), `NC_parseChapters` accepts the short `-C2545-` chapter form, `NC_getBook` never throws (it returns a note), and chapter names are cleaned by `NC_chName` — see "Novel Cool: opening a novel showed loading, then nothing (2.7.20)". The site still hides some chapter lists from outside readers and says so. |
| Scribble Hub | ~1.3 | ~1.2 | ~1.1 | **Since 2.7.33** every route is the site's own app interface (`/wp-json/fictionapp/v1/…`, see "Scribble Hub: the site's own app interface (2.7.33)"): the novel is one small JSON answer, the whole chapter list is 200 chapters a page (a 2262-chapter novel = 12 answers, ~4–8 s end to end), the chapter text is another small JSON answer, and none of it goes through a proxy or a bot check (the interface is CORS-open). Measured numbers in that row are the HTML fallback (`SH_getBookHTML` / `SH_getChapterHTML`), which is still there. |
| NovelLive | ~0.6 | ~0.04 | 5-10 ok / 18-45 refused | **Not a wall — measured 2.7.22.** `novellive.com` chapter pages answer `403 Just a moment…` (Cloudflare, `Cf-Mitigated: challenge`) for *runs* of requests and `200` with the full text for others: Shadow Slave chapters 1, 2 and 3 read in full (live, cache-busted), chapters 16/17 refused six times running. A success costs 5-10s, a refusal 18-45s, and some asks hang (2-minute timeouts seen). A chapter that comes back `err.blocked` is asked once more by `startReaderBlockRetry` before the app says anything final — see "NovelLive / LightNovelPub are readable, intermittently (2.7.22)". Chapter **lists** come from one `/ajax/get-list-chapter?novel_id=` request (3179 for Shadow Slave, ~0.04s) instead of an 80-page crawl. |
| LightNovelPub | ~0.6 | ~0.04 | same as NovelLive | The **same site underneath** — its chapter links 302 to `novellive.app`, and its book page reads "… - Light Novel Pub - Reading Novel Free". Identical byte-length chapter pages to `novellive.com`, same intermittent refusal. |
| NovelHi | ~0.6 | ~2.3 | ~1.2-1.9 | The whole catalogue is one listing API, so search and feed are cheap (60 cards ≈0.8s); a book's full chapter list is one server-rendered page (1644 chapters in ~2.3s). Chapter text needs a header, sent as the `x-cors-headers` pair (see "NovelHi (2.7.10)") — that works through superFetch, the fetch-plugin proxy *and* the worker, so the packaged build reads it over its bridge, and a route that 429s hands over to the next (each has its own allowance). Covers 403 in bursts → retried ("NovelHi (2.7.9)"). Read 2.7.7/2.7.8/2.7.9/2.7.10 before touching it, and treat the 2.7.7 header conclusion as superseded. **2.7.18:** the chapter list is asked for with a required marker (`mobile-chapter-item`), because jina's cleaned copy of that page has **zero** chapter items in it yet answers 200 — see "NovelHi's chapter list on a cold start (2.7.18)". |
| Lib Read | ~0.8 | ~1.0 | ~1.0 | FreeWebNovel's mirror under its own URL shapes (`LR_*`, source name `"Lib Read"`): plain server-rendered GETs, no header, no scrambling, so the packaged build reads it over its **existing** bridge (measured 1.3s for a chapter page through `bridgeFetch`) — nothing had to be saved for it to work. Feed page 1 in 0.85s (7 cards), `/sort/most-popular` in one request (50 cards). Chapter list since 2.7.30 comes from `?ajax=chapters&page=N&pageSize=200` (200 a request, 13 requests for 2,545 chapters ≈ 3.4s; path-paged 40-a-page + `WP_loadRest` is the fallback). Covers are on its own host with no ACAO → excluded from the crossOrigin group, `[direct, weserv]` routes. Ratings come off the book page's `.vote` line. |

Two standing realities, not bugs: sources with Cloudflare will 403 the
perchance proxy after a burst of requests (the foreign-transport path is what
saves those chapters), and the preview IP is shared, so numbers swing a lot
between runs — always re-measure before believing a change.

### NovelHi (2.7.7)

Adding a source is normally "find its listing URL, write a parser". NovelHi is
two exceptions in one, both measured against the live site, and both written
down here so nobody has to re-derive them:

**1. Its catalogue is one JSON API.** `GET
https://novelhi.com/book/searchBookListWithShelfState?curr=<n>&limit=<n>`
answers to a plain request with no header, and also takes `&keyword=`,
`&bookStatus=1` (completed; `0` is ongoing) and `&bookGenres%5B%5D=<id>`
(ids in `NH_GENRE_IDS`). **The genre brackets must be percent-encoded.** Sending
`bookGenres[]=<id>` unencoded is not an error — it is silently ignored and the
*entire* catalogue (2319 books) comes back, so a "Fantasy" job would quietly
return the same thing as page 1. `NH_parseList` reads `data.list[]` (`id`,
`bookName`, `authorName`, `picUrl`, `rate`, `genres[]`). Ids are
`nh-<numericId>`; covers are `https://img.novelhi.com/cover/<numericId>.webp`
(host added to `COVER_HOST_SOURCES`).

**2. A chapter's text is gated twice over — a header and a scrambled font.**

- *The header.* The chapter page (`/book/<numericId>.html`, which is the
  canonical `/novel/<genre>/<slug>/<n>`) embeds two hidden inputs,
  `#chapterContentPath` and `#chapterContentToken` (32 hex, per page load), and
  the site's own `/javascript/chapter-content-loader.js` then fetches
  `<path>?token=<token>` **with `X-Requested-With: XMLHttpRequest`**. Without
  that header the endpoint answers 403 `{code:"500"}`; with it, 200
  `{code:"200", data:{content, fontClass:"novelhi-chapter-obf", fontFaceCss, …}}`.
  **No transport in the ordinary list can set a plain header** — perchance's own
  proxy strips `X-Requested-With` in particular, and `root.superFetch`, the
  `fetch-plugin` proxy, cors.lol, allorigins, codetabs, corsproxy.io, cors.eu.org
  and whateverorigin were each measured and each lose it. *(Corrected in 2.7.10:
  they all forward the header when it is also sent as an `x-cors-headers` JSON
  object — see "NovelHi (2.7.10)" above, which supersedes the rest of this
  bullet.)*
  `test.cors.workers.dev/?<url>` (the `corsworker` transport added in 2.7.4 for
  the Webnovel speed work) *does* forward it, so `NH_xhr()` uses it directly —
  and falls back to `bridgeFetch(url, {via:"corsworker"})`, which `req.via`
  carries into the bridge page, whose message listener then makes the same
  worker fetch. That fallback is not optional: the worker **refuses a `null`
  origin** (verified with a `<iframe sandbox="allow-scripts">`), which is what
  the packaged WebView sends. Same consequence as the bridge's POST support:
  **in the packaged app this only works once the generator has been saved**,
  because the deployed bridge page is the one that runs the
  `via:"corsworker"` branch. The token is not bound to the IP or to the page
  route (page fetched with `sf()`, content with the worker, five chapters read
  back to back, no daily-limit hit), so the two-hop flow is fine.
- *The scrambled text.* The returned `content` is obfuscated against scrapers:
  **letters are ROT13'd and digits shifted by five**, tags and punctuation left
  alone, and each response also carries `fontFaceCss` for a webfont
  (`/fonts/chapter-obf/novelhi-chapter-obf.woff2?v=1`) that re-maps those glyphs
  so a human sees the real letters. `NH_decode()` is that font's inverse. It was
  verified by rendering the font's own glyph grid and reading it: A-Z draws as
  `NOPQRSTUVWXYZABCDEFGHIJKLM`, `0123456789` draws as `5678901234`, punctuation
  is identity — i.e. exactly ROT13 and `+5 mod 10`. **Tags are never obfuscated,
  only text**, so `NH_parseContent` strips the ad `<script>`/`<ins>` blocks
  *before* decoding (decoding first would ROT13 the script bodies and leave junk
  in the prose). `<br><br>` is the paragraph break, and the body carries no HTML
  entities.
- *The chapter list is one page, however big.*
  `/novel/<genre>/<slug>/chapters` is fully server-rendered: a 1644-chapter book
  (441KB) and a 7518-chapter book (2.39MB) both arrive in a single request, with
  no pagination and no JSON equivalent (`/book/queryNewIndexList` answers with 10
  items, `/book/queryUserRecentIndexList` with 5), so `NH_chapters` just walks the
  `<a class="mobile-chapter-item">` anchors. Read the chapter *label* from the
  `<span class="mobile-chapter-item__name">` only — every item also carries
  `<i class="layui-icon">&#xe65b;</i>`, and `decodeEntities` turns that icon into
  a private-use character, which had been landing on the end of every chapter
  title. `NH_PATHS[bookId]` remembers the canonical `/novel/<genre>/<slug>` path
  learned from a book page, because chapter URLs are built from it.

**4. It meters what it will serve an address — per novel.** The content endpoint
answers **429** once the free allowance for *that novel* on that address is spent,
while other novels on the same connection keep reading normally; the site's own
error state is a "you've exceeded your reading limit for today" shell that its
template carries for anonymous visitors, and that is the business model — read a
few free chapters, then log in. Every route YueDu may use for this is a
*shared* proxy (the Zibri worker runs in a Cloudflare datacenter thousands of
scrapers also use), so one novel's allowance can be spent by other people.

Measured in one sitting: chapter 1 of three books read back to back (75, 100 and
50 paragraphs, ~1.4-1.9s each); then the chapter of a 7464-chapter book that had
just been the subject of a test burst was refused, while two other books still
read fine in the same minute; and it answered again ~4 minutes later with nothing
changed on our side. The sentence to remember: **a refusal is one book, not the
source** — again and again the check that settled it was "does a *different*
novel read right now?".

What the app does about it (`chapterQuotaTight("NovelHi")` in `preloadChapter`,
plus `NH_xhr`):

- **Content requests are serialised with a 900ms gap** instead of three chapters
  in flight, and a **failure is retried once** after 1.6s (the site's own loader
  retries too, at 1.2s and 3s).
- **Prefetching drops to one chapter ahead**: the "next +1" and "previous"
  prefetches are skipped for this source, because a prefetched chapter spends the
  same allowance on a chapter the reader may never open.
- **A refusal gets its own message** (since 2.7.8: "It counts how many free
  chapters it serves each address, per novel, per day — and this novel's share is
  used up for the moment. It frees up again by itself, usually within a few
  minutes."), surfaced by the **"NovelHi is pausing this novel"** card in the
  reader rather than a raw `Failed to fetch` — see "NovelHi (2.7.8)".
- **A refusal is remembered per book for two minutes** (`NH_contentBlocked`, keyed
  by the canonical `/novel/<genre>/<slug>`), so a chapter known to be refused fails
  in ~0.7s instead of paying for another doomed round-trip, and no other novel is
  affected.
- **The browser build does not use the bridge for this at all** — only the
  packaged app needs it. There the worker *is* the route, and a bridge round-trip
  costs 20-45s before the very same failure (measured: 70s to reach an error
  before this rule was added, ~2.8s after).

Listing, search and book pages are unaffected (their API needs no header), so the
source stays browsable and searchable whatever the chapter endpoint is doing.
When re-examining this endpoint, note the *failure* mode to look for: **429**
(readable when the worker passes CORS through) or a CORS `Failed to fetch` (the
same 429 with no CORS headers). A **403** means something else — a wrong token or
a stripped header, i.e. the transport broke.

Measured, warm preview: search 0.6s; feed 60 cards 0.8s; book + 1644-chapter list
2.3s; a chapter 1.5-1.7s, with the prose decoding correctly at chapters 1, 900
and 1644. `sfHealth("NovelHi")` → "ok" (the listing API needs no header, so the
ordinary probe covers it).

### NovelHi (2.7.10) — "the header can't be forwarded" was wrong

This is the correction to the 2.7.7 write-up below, and the reason packaged-app
NovelHi chapters work at all. Read this before touching `NH_HEADERS`.

**The measurement.** NovelHi's content endpoint wants `X-Requested-With:
XMLHttpRequest`, and 2.7.7 concluded that only the Zibri worker can carry a
header, because a plain `X-Requested-With` through every other route came back
403. What was missed: a cors-anywhere proxy does *not* forward a plain header
(`X-Requested-With` is deliberately stripped) — it forwards the **JSON
`x-cors-headers` object**, whose entries it merges into the outbound request.
And it only does that when the plain header is present as well. Measured on the
same live content URL:

| what was sent | superFetch | `npcProxy` | worker |
| --- | --- | --- | --- |
| plain `X-Requested-With` | 403 | 403 | **200** |
| `x-cors-headers` JSON alone | 403 | 403 (4/4) | 200 |
| **both, together** | **200** (1.2s) | **200** (8/8, ~0.9s) | **200** |

`NH_HEADERS` is that pair. Consequences:

- **The bridge carries it in the packaged app.** The bridge page's listener puts
  `d.headers` into `init` and calls `root.superFetch(url, init)` — so a
  `bridgeFetch(url, {headers: NH_HEADERS})` works *without the deployed bridge
  page being up to date*: verified against the live deployed page (which has no
  `via:"corsworker"` branch and predates NovelHi in its source entirely) — it
  returned the chapter JSON in 4.7s. This is why the packaged app reads chapters
  now, and why `via:"corsworker"` is no longer needed for this source (it is
  still honoured by the listener for anything that needs it).
- **The worker is no longer the browser build's only route**, and superFetch is
  first because it is the fastest of the three (~1.2s against ~0.9s for the
  worker is within noise, but it needs no third-party service).

**A 429 belongs to a route, not to the novel.** The 2.7.7 note "a refusal is one
book, not the source" is true per *address*: each route is a different
datacentre, each gets its own free allowance for a novel, and the worker's
address in particular is shared with every other user of the public demo.
Measured: "Bewitching Prince" refused through the worker in every attempt this
session (and in 2.7.7's) — with the pair, `superFetch` served it in 1.6s, 34
paragraphs. So `NH_fetchContentRaw` is a sweep, not a single route:

```
native  (window.LitNative, packaged only)
direct  (packaged only; works if the wrapper allows universal file access)
superfetch  (browser build)  /  bridge  (packaged build)
worker
proxy   (npcProxy + the header pair)
```

- Each route either returns text or throws; a `429` throws `rateLimited` so the
  sweep moves on. If nothing answered, the sweep runs once more after 1.6s and
  only then decides: every route rate-limited (or every route dying on the
  network) → `NH_tooMany()` and a **two-minute block for that novel**
  (`NH_contentBlocked`); a readable non-429 error (e.g. a 403) keeps its own
  message.
- `NH_lastRoute` remembers which route answered and is tried first next time, so
  the second chapter costs one request rather than a sweep.
- `NH_routeNative` speaks the documented `LitNative.fetch(reqId, url, method,
  headersJson, body)` protocol, with answers arriving via `window.__litNative(id,
  json)` (or a synchronous return). A bridge that throws marks itself dead for
  the session; it is never the only route. This is the app side of
  `src/android-plugin/README.md`, which claimed the app already did this.

### NovelHi (2.7.9) — covers fail in bursts, and the withdrawn novels

**1. A cover refusal is momentary, so retry it.** `img.novelhi.com` is an
object store behind Cloudflare, and under any real burst it answers **403** for
a slice of requests — server-side too, so it is not the app: 8 of 60 covers
403'd on one pass, and a *different* 8 on another, while the same URLs answered
`200 image/webp` a minute later (142KB, 83KB, 19KB, 16KB). Two measurements pin
the behaviour down:

- **A query string kills the request.** `…/cover/<id>.webp?r=<anything>` fails
  in ~350-650ms *every* time; the bare URL loads. So never cache-bust these.
- **It is a rate/burst thing, not a per-file thing.** 25 covers loaded at once
  from the browser: 25 OK. 60 in a burst: 60 OK in ~2s. 201 at once: it used to
  end with 39 hidden, and now ends with **201 shown in ~11s**.

`loadCoverImg` is therefore a small retry machine: it walks `coverURLs(url)`
(two or three routes), then tries the whole list again — rounds at ~1.2s, 2.4s
and 8s — and only hides the image after all of them. Nothing is displayed until
it either loads or truly fails (the gradient + letter placeholder is behind it
the whole time). This is the fix for "some novel still doesn't have a cover".

**2. Some novels are withdrawn, not broken.** NovelHi marks a pulled novel with
`#copyrightProtectedFlag = true` on its book page, and then *every* chapter
route (`/chapters`, `/1`, …) answers with a copy of the book page itself — 200,
~39KB, zero `mobile-chapter-item`s. **Measured: exactly the books with the flag
true (Invincible, Martial God Asura) are the ones whose chapter list came back
empty (2 of a 12-book sample); all ten unflagged books listed thousands of
chapters.** `NH_getBook` now reads that flag and returns a note that says what
happened ("NovelHi has withdrawn this novel — it marks it copyright-protected
there … use the Migrate button above"), the list header reads "No chapters
available here" instead of "No chapters yet", and `bookMigrateBtn` is enabled
for a novel with no chapters even before it is in the library (migration is the
only useful action left, and `doMigrate` was already fine with a book that is
not in the library — it just copies progress across when there is any).

### NovelHi (2.7.8) — the covers, and the paused-novel card

Both of these were found in use, not by reading the site, so both are written up
with the measurements that settled them.

**1. Covers: `img.novelhi.com` refuses hot-linked requests.** The image *files*
are all there — fetched server-side they are all `200 image/webp` (142KB, 83KB,
19KB, 16KB for four feed covers) — but from the page itself the same URLs failed
intermittently: `400-600ms` "error", for the *big* files in particular, with
`403 application/xml` visible when the request is looked at through a proxy.
Nothing about the app's own code was involved, and the first fix was a real bug
anyway:

- **`crossOrigin="anonymous"` was killing every NovelHi cover.** `loadCoverImg`
  asks for CORS on any host not in its exclusion list (so the canvas cover cache
  can re-encode the image), and `img.novelhi.com` sends **no
  `Access-Control-Allow-Origin`** — measured: the same URL loads with no
  `crossOrigin` and errors instantly with it. `novelhi.com` is now in that
  exclusion list (as NovelArrow, FanMTL, WTR Lab, FreeWebNovel, NovelFull/NovGo,
  NovelCool, NovelLive and LightNovelPub already were). **This was the bug that
  hid the covers**; every NovelHi cover, in the feed and on the book page, failed
  because of it.
- **The fallback cover is `npcProxy(url)`** (the fetch-plugin route — the same
  one `sf()` already uses), because no image proxy will fetch this host:
  `images.weserv.nl` / `wsrv.nl` answer `error` in ~120-700ms, the Zibri worker
  returns **403** (the same XML the CDN hands a hot-linked request), and
  `api.allorigins.win` only reaches the host for *text*. `npcProxy` returns the
  bytes as a real image (~2.8-3.8s, 600x800), which `loadCoverImg`'s existing
  error→fallback wiring picks up automatically. Verified in the source-mode
  search grid: 4 NovelHi cards, **4 covers** (3 direct, 1 through the proxy),
  where before the fix the failing ones showed only the gradient+letter
  placeholder. Note the cover cache cannot hold these (no ACAO ⇒ a tainted
  canvas), which is already handled by `cacheCover`'s `try/catch`.

**2. A spent allowance shows as a CORS-less response, not a 429.** `NH_xhr`
already treated `Failed to fetch` as a possible refusal (matched in its retry
classifier, which is why the honest message did appear), but the reader sent it
down the generic "Couldn't load chapter / trying again automatically" path and
then polled `openChapter` every 7s. Since a refusal is per *novel* and lasts
minutes, that was both misleading and pointless. Now an error carrying
`rateLimited: true` gets its own reader card — "**NovelHi is pausing this
novel**", the plain-words message, and Try again / Find on another source /
Open site ↗ — and deliberately **does not** start `startReaderCaptchaRetry`.
Measured: the card is on screen ~2.8s after tapping the chapter of a
metered-out book, while a book with allowance left opened in 1.6s (75
paragraphs) and another in the same minute returned 51 paragraphs.

### Webnovel: why it showed a captcha (fixed in 2.7.1)

The user supplied a **v2.4.2** standalone as the last build where Webnovel was
dependable. The Webnovel source code itself turned out to be essentially
*identical* between 2.4.2 and 2.7.0 apart from one method — so the fix was that
method plus three regressions in the shared fetch layer. Do not undo any of
these; each was measured, not guessed:

1. **`WN.getChapter` must try the reader page first, not race the API.**
   2.4.2 did `getChapterSSR` → on failure `getChapterApi`. 2.7.0 raced them
   (`firstOf([getChapterApi, getChapterSSR])`) to halve chapter latency, but
   `https://www.webnovel.com/go/pcm/chapter/getContent` is *the* URL Cloudflare
   refuses, and its 403 arrived as a `blocked` error from `sf()` before the SSR
   answer could be used — so opening a chapter showed the captcha screen even
   though the reader page was fine. Now SSR first, `notFound` rethrown, API as
   fallback (measured: reader page ≈3s, 6-8KB of real prose, no captcha).
2. **A challenge from a foreign transport must not condemn the host.** See
   fetch-layer rule 3(b): jina/allorigins get Cloudflare-challenged constantly,
   and letting their 403 call `blockedNow()` aborted pages our own route was
   still about to answer. This was the other source of phantom captchas.
3. **`sfHealth` must try every route before saying "captcha".** See rule 6:
   `captchaProbe()` uses it to decide the source has come back, so a false
   "captcha" pins the reader on that screen permanently.
4. **Ask Webnovel one request at a time, from the very first request.**
   `BURST_SENSITIVE` in `isPolite`'s neighbourhood, while the discover feed still
   runs two pages at once — exactly 2.4.2's request pattern. 2.7.4 restated that
   as *one request per network* rather than *one request per page* (see "Webnovel
   speed (2.7.4)" point 1) after measuring how much time "per page" cost: our own
   route is 3-5× slower than jina/`corsworker` for every Webnovel page, so
   strictly one-at-a-time meant every page waited out the slow route.
   Measured effect of the *old* burst pattern (2.7.0's, hedge armed on start with
   no cap): a burst of requests
   makes Cloudflare answer **403 "Just a moment…" for the homepage, catalog and
   chapter URLs on every route, jina included**, and it clears by itself a few
   minutes later. Reproduce a trip with ~4 back-to-back `superFetch` calls, then
   wait and watch it recover. With the current pattern the Webnovel feed fills 139
   cards in 4-9s and 6 concurrent page requests came back with no refusal.

Also note `prewarmBridge()` fires one throwaway request at the default source
(Webnovel) ~2.6s after boot; that is one request, not a burst.

### A refused request is asked again (2.7.3)

Reported symptom: on Webnovel the **feed was fine**, but tapping a novel sat on
"loading", failed with "can't load the chapter list", then flashed the captcha
screen ("checking the connection"), then said "Webnovel connected" — and *then*
the chapter list and chapters worked perfectly. The user's summary: "I hate that
long wait for the captcha connecting." Three separate causes, all fixed:

1. **One refusal was treated as final.** `sf()` did
   `if (e.blocked) { captchaHits = MAX_ATTEMPTS; break; }` — the first refused
   attempt ended the whole call. But a Webnovel refusal is almost always
   *momentary* (the challenge is per-request and clears in a second or two; the
   user's own second request, a second later, worked). Now a refusal is asked
   about again: `captchaHits++`, then `continue` after a breather — **3 attempts
   for a burst-sensitive host** (delays 1.0s, 1.6s), **2 for anything else**
   (700ms). Only then is it a captcha. v2.4.2 also required two refusals.
   Guarded by **`quickRefusal` (`Date.now() - attemptStart < 4000`)**: a *slow*
   refusal means the host really is turning us away, so it is not retried and
   the honest answer arrives promptly. Verified with a stubbed transport: one
   challenge then success → `sf()` resolves (2 superfetch calls); every route
   challenged quickly → throws `blocked` after 3 attempts in ~2.6s.
2. **A blocked transport leaked its in-flight slot.** `blockedNow()` was called
   from inside `spawn()`'s `.then()` *before* that transport had decremented
   `active`, so the foreign transports it started could never bring the count to
   zero and the attempt waited out the whole **7s `blockedGrace`** instead of
   rejecting the moment the last foreign route gave up. That 7s *was* the "long
   wait". The non-foreign branch now does `release()` before `blockedNow()`:
   a fully-refused page now fails in ~0.7s (was ~7s per attempt), measured.
   **Keep that `release()` before `blockedNow()`.**
3. **The feed itself was setting off the check.** Tapping a novel fires the
   chapter-list request seconds after the feed's 7 pages, which is what got it
   refused in the first place. `DISCOVER_BURST_GAP` (500ms) now spaces the
   burst-sensitive feed: still 2 pages in flight (`DISCOVER_CONCURRENCY`), just
   not back-to-back. Feed fill is barely affected (20 cards in ~4-5s).

Also: `enrichBook()` opened the captcha screen even for `e.blocked` (an outright
refusal), unlike `enrichBookDetails()`. Both now `toast` the honest
"is refusing requests from YueDu right now" for a refusal and reserve the
captcha screen for a solvable check — a screen the user cannot pass is a lie.

### Webnovel speed (2.7.4)

The user's follow-up after 2.7.1-2.7.3 made Webnovel dependable: *"Good, but
improve webnovel performance speed."* Measured first, warm preview, one request
at a time (`sf()` on a Webnovel URL, `via` = the winning route):

| page | our own route (superfetch / npc-proxy) | jina | `corsworker` |
| --- | --- | --- | --- |
| home (0.44 MB) | 4.0-6.0s | 1.1-1.6s | 1.2-1.5s |
| search (0.37 MB) | 3.7-4.0s | 1.4-1.9s | 1.1-1.7s |
| chapter list (2.35 MB) | 8.5-12s | 2.5-3.2s | 4.4s |
| chapter page (0.14 MB) | 3.1-3.4s | 1.0s | 0.9s |

So the fastest route for Webnovel is **3-5× faster than our own**, and 2.7.1-2.7.3
(one route at a time, to avoid its bot check) meant every Webnovel page waited
out the slow one. Five changes, each measured:

1. **The burst-sensitive host races a foreign route instead of waiting.**
   `MAX_PARALLEL` for a burst host is 2 again, but the *classes* are counted, not
   the page: `ownInFlight` / `foreignInFlight` — our routes share one network,
   the foreign ones are separate datacenters — and `startNext()` picks the next
   route whose network is free, skipping (not losing) a route whose network is
   busy. Nothing from the same network is ever in flight twice for that host, and
   a slow route can no longer hold a fast one on another network behind it.
   `BURST_HEDGE` = 600ms is how long the first route gets before the other
   network joins.
2. **The route that works is remembered and promoted (`hedgePartner`).**
   A foreign route that answers this host in under 2.5s is remembered for 3
   minutes and promoted to the FRONT of the queue, so the common case costs one
   request that comes back in ~1s; our own route is the hedge underneath it
   (`BURST_HEDGE_KNOWN` = 2500ms, i.e. long enough that a healthy partner answers
   alone). `forgetHedgePartner()` drops the entry the moment that route fails, so
   a proxy that goes bad mid-session is escaped within one page and the other
   foreign route takes the front. **This is why the transport order in
   `getTransports()` is what it is**: `rest = [bridge, npc, jina, corsWorker,
   allorigins(raw, get), cors.lol]` — the two routes that actually answer are
   ahead of the two that are usually dead, which matters for the blocked-path
   volley below.
3. **`corsworker` is new** (`https://test.cors.workers.dev/?<url>`, a Cloudflare
   Worker proxy — a different network from both the perchance proxies and
   r.jina.ai). It answered every Webnovel page tested at a time when jina was
   being challenged, so the hedge has somewhere to go when jina is in a bad
   patch. It is in `FOREIGN` and in `getTransports()` (and so in every hedged
   request, the health check included).
4. **Chapter prefetching is serialised for a burst host** (`preloadChain` in
   `preloadChapter`). `openChapter` preloads the next chapter, the one after it
   and the previous one; for Webnovel that was three chapter requests into the
   site at once — a burst, and a burst is what its check answers. They are now
   one-in-flight-at-a-time chained. Measured at a normal reading pace (1.2s
   between taps), 19 of 20 chapter opens were served from the cache in 26-49ms.
5. **`sfHealth` asks a burst host through the routes that answer it first**
   (jina → corsworker → superfetch → bridge → allorigins; unchanged order for
   every other source). The verdict is identical — any route answering is "ok",
   a challenge is only believed when *every* route was challenged — but the probe
   went from **11.5s to 0.7s**, and `captchaProbe()` re-probes every 7s, so the
   old order could still be running when the next probe started.

   > **Changed in 2.7.19:** this hand-rolled ordering is gone. `sfHealth` is one
   > `hedgedGet` probe, so the burst host's route order, the politeness rules and
   > the "only condemn a host that refused *us*" rule all come from the transport
   > layer. The measurement above still explains why jina and corsworker exist in
   > `getTransports()`. See "The source health check (2.7.19)".

Measured on a cold page afterwards: feed first 20 cards **1.3-1.7s**, all 139
cards **3.8-8.6s**; chapter list 2545 chapters **2.6-3.3s**; a chapter opened
**0.5-1.8s** (occasional ~2.7s when the remembered partner is slow and the hedge
has to take over); reading on **instant**. A 6-page concurrent burst all came
back via jina/corsworker with no refusal. `sfHealth` "ok" for all 12 sources,
Royal Road / FanMTL / Scribble Hub / NovelFull feeds and a FanMTL chapter all
unchanged. **The 2.7.1-2.7.3 properties that must not regress:** no captcha
screen from a foreign transport's challenge, a fully-refused page failing in
~0.7s, and `release()` (not `active--`, no leaked slot) before `blockedNow()`.

### FreeWebNovel: chapter 1 was missing from every novel (2.7.5)

Reported: *"All the novels there it's chapter 1 is always missing, it starts with
chapter 2."* One cause, and it is specific to FreeWebNovel:

- **The site's "Read first" shortcut is the first anchor in the chapter list and
  it repeats chapter 1's URL.** `FW_parseChapters` marked a chapter id as seen
  *before* checking the label, so the shortcut for chapter 1 poisoned the
  duplicate set and the real `Chapter 1: …` entry further down the list was
  skipped as a duplicate. Every list therefore began at chapter 2 (and `total`
  was one short). The label check now runs first, which is what
  `NF_parseChapters` (NovelFull/NovGo) already did — see the fwn-theme note
  above. Verified: the same novel's list went from 16 entries (2…17) to 17
  (1…17), and six feed books all report chapter 1 first.

Two feed bugs found and fixed in the same pass (all verified against the live
site; neither is a parser-shape problem):

- **`/sort/most-popular-novel` 404s.** It was one of the four discover jobs, so
  it silently contributed nothing to the FreeWebNovel feed. The site's own nav
  points at `/sort/most-popular`; `/sort/latest-release` also carries cards and
  was added, so the feed is five pages now.
- **The front page was never parsed.** Its recommendations are
  `<div class="li home-rec-item">`, not the `<div class="li-row">` the parser
  split on, so the feed's first job returned zero books. `FW_parseBooks` splits
  on `/(?=<div class="li[- ])/`, which covers both (the inner markup — `h3.tit >
  a`, `img`, `div.core` — is identical), and its rating regex now tolerates the
  trailing space inside `<span>4.3 </span>` that the home cards have.
  Measured: the FreeWebNovel feed went from 47 to 87 cards, still deduped, done
  in ~1.7s.

### Novel Cool: two dead feed pages (2.7.5)

Same bug class, found while checking the fix above: `/category/new_list.html` is
the site's *new chapters* page (50 chapter links, no `book-item` cards) and
`/list/New-Updated/` answers with an empty body, so two of the four Novel Cool
discover jobs listed nothing. Replaced with `/category/popular.html` (48 books),
`/category.html` (21) and the existing `/category/original.html` (21) + `/` (16):
the feed went from ~30 to **92 unique cards**, done in ~2.2s. Novel Cool's
*chapter list* limitation is unchanged and separate: the site hides chapter
links from outside readers, so a book can come back with only its newest
chapter. `NC_getBook` already detects that (the `Chapters N` count in the page)
and returns the honest `note` telling the reader to use Migrate — do not
"fix" that by inventing chapters.

### Nothing spins forever

`watchSpinner(ctn, label, onRetry)` (browse/search/author results) and the
`openChapter` timers (`chapterLoadTxt` elapsed seconds + the 26s `slowTimer`,
with a `chapterOpenSeq` guard so a stale response can't paint over a newer
chapter) turn a stuck spinner into a "taking too long" card with Try again /
Open site. `feedWatchdogArm()` does the same for the discover feed. The
original request is never cancelled, so a late answer still renders.

**The hedge must be armed when a transport *starts*.** For a while `hedgedGet`
only armed the next-transport timer when a transport *failed*, so a route that
"worked" but was slow (FanMTL's Cloudflare-slowed superfetch took 4-6s, and
hangs took its 18s `withTimeout`) held every faster route behind it — the
reader sat on "Loading chapter…" with jina's ~1s answer never tried. `spawn()`
now calls `schedule()` as soon as it starts a transport, `schedule(gap)` clears
before re-arming, and a transport that fails in <1.2s shortens the next gap to
550ms. `hedgeMemory` (keyed by hostname) drops the gap to 700ms for a host
whose last page took >3s (and forgets it once a page comes back in <1.5s).

**A definitive 404 is final.** `hedgedGet` rejects at once when a
non-FOREIGN (own-route) transport returns 404/410 — retrying the whole
transport chain for it walked ~45s per attempt ×3. `sf()` rethrows an
`err.notFound` without retrying or probing, and `openChapter` shows "this
chapter isn't on <source> any more" (no auto-retry loop) instead of the
generic card. FanMTL serves its own not-found screen as **HTTP 200** with
`<title>Message hint</title>` / `class="system-message"`; `FM_getChapter`
catches that and throws the same `notFound`.

### Captcha: "solve it in the browser, then come back"

**Changed in 2.7.21** — read "Opening a site no longer takes the app over
(2.7.21)" at the top first. `openCaptchaExternal()` no longer sets
`location.href` (it goes: wrapper `challenge` screen → `window.open` → the
in-app site view), and `resumePendingCaptcha()` now probes the blocked page
(`p.url`), not the source's front page, and clears silently when it still does
not answer. The rest of what follows is unchanged and still true.

`openCaptchaExternal()` used to `hideCaptchaScreen()` (which stopped the
auto-retry) and to treat `visibilitychange` as a *return* — but that event fires
the moment the app is **hidden**, i.e. as the browser opens, so it retried too
early and then never again. Now:

- The captcha screen **stays open** in a waiting state (3 numbered steps,
  `#captchaWaitNote`, "I've solved it — check now" → `captchaCheckNow()`), and
  `startCaptchaAutoRetry()` keeps probing every 7s (`captchaProbe()` skips while
  `visibilityState === "hidden"`, so it doesn't waste requests while the user is
  away).
- `watchCaptchaReturn()` only treats a transition *to visible* (or a focus >
  5s after opening) as "the user is back" and probes immediately.
- **The captcha screen can only clear itself if `sfHealth()` is honest** —
  `captchaProbe()` probes the source's health and shows "reconnected ✓" only
  for `"ok"`. That is why `sfHealth` reports "captcha" only when no route could
  answer on our own connection (since 2.7.19 that rule lives in `hedgedGet`: a
  challenged *foreign* route is retired, only our own being challenged counts);
  a single-route probe that called one block a verdict reported "captcha" for
  sources that were reachable through another route, which pinned the screen open
  forever. Likewise, a challenged *foreign* transport no longer condemns the host
  (fetch-layer rule 3b) — those phantom verdicts were what the screen was mostly
  reacting to.
- **A "reconnect" that immediately re-blocks is not a captcha, and must not
  loop.** The health probe is one request; a source that rate-limits a *burst*
  (Webnovel's feed fires homepage + keyword searches back-to-back) answers that
  one request and then refuses the next real one, so the app used to do
  `reconnected ✓ → feed → openCaptchaBlock()` forever. Now `openCaptchaBlock`
  records `captchaReconnectAt` and counts a block inside
  `CAPTCHA_STRIKE_WINDOW` (15s) as a strike; two strikes put the source on
  `captchaCooldownUntil` (`CAPTCHA_COOLDOWN_MS` = 60s), during which
  `captchaProbe` returns without touching the network and the screen says
  "<host> is limiting requests right now". "I've solved it — check now"
  (`captchaCheckNow`) clears the backoff and forces a probe, and a lapsed
  cooldown resumes the 7s auto-retry. `resumeDiscover()` also no longer resets
  `discover.jobIdx`/`books`: re-fetching the whole feed on every reconnect was
  itself re-tripping the limit. `buildDiscoverJobs("Webnovel")` is down from 15
  pages to 7 for the same reason, and it still fills the feed (106 cards
  measured). The feed also carries a **run guard**: `discover.run` is bumped
  whenever `startDiscover` (re)initialises, and every in-flight job checks it
  before appending or re-pumping. Without it, a page that lands after the
  reader switched source was appended to the *new* source's feed — the label
  read "Popular on FanMTL" over a grid of Webnovel novels (reproduced while
  testing this, now fixed).
- `yuedu_pending_captcha` persists `{src, url, ts, kind, bookId,
  chapterId}`; `resumePendingCaptcha()` runs ~1.2s after boot in the standalone
  and, if the source answers now, reopens the chapter/book/browse where the user
  was (and shows the captcha screen again if it still blocked). Entries expire
  after 30 minutes.

### WTR Lab: a per-address request limit, not a wall (measured Sept 2026)

> **Known gap (verified 2.7.32):** `WTL_novelDetail` returns empty fields.
> `https://wtr-lab.com/en/novel/<id>/<slug>` ships only `{"providers": …}` in its
> `__NEXT_DATA__` now (the novel itself is loaded client-side), and the obvious
> API guesses (`/api/series/<id>`, `/api/series/get?raw_id=`, `/api/novel/<id>`)
> are all 404; `/api/chapters/<id>` carries the chapter list and nothing else. So
> a WTR book screen has no synopsis and no author — it falls back to the title,
> cover and genre the search/feed item carried. Don't re-probe this without a new
> idea; the title cleaner (`wtrCleanTitle`) is what those fields needed.

> **Read this first (user instruction, 2.7.30):** do **not** reimplement this
> source from LNReader's WTR-LAB plugin. The user's words: *"Don't copy it's WTR
> source. Ours have the advantages. Their lnreader sources wter doesn't work and
> can't get anything."* Their route (chapter list at `/api/chapters/<rawId>`,
> content at `POST /api/reader/get` with an AES-GCM-encrypted body whose key is
> scraped out of the site's JS bundles) does not work for them, and YueDu's
> own route below does — because it asks from the reader's **own** connection
> with the reader's own session, and the Unlock flow can hand a challenge to a
> real WebView. Leave this source's code alone.

`POST https://wtr-lab.com/api/reader/get` answers
`{"success":false,"requireTurnstile":true,"threshold":15,"count":N}` once the
requesting **internet address** is over its limit. Facts, all verified twice:

- `count` climbs by exactly one per request and never falls — 318 → 347 while
  testing, including 170s of complete idle. It is not a rolling window, and it
  tracks the address, not YueDu: every transport YueDu has (perchance
  `fetch-plugin.proxy1`, `superFetch`, the bridge) leaves from the same shared
  address, so it is permanently over the 15-request limit.
- Spoofing does not work: `X-Forwarded-For` / `X-Real-IP` / `CF-Connecting-IP` /
  `User-Agent` / `Cookie` / `Accept-Language` changes and omitting params entirely
  all return the same gate, with the same (incrementing) count.
- A **valid** Turnstile token is what lifts it: sending a bogus
  `turnstileToken` gets `"Invalid Turnstile verification. Please try again."`, and
  `/api/reader/get` **never** answers without a token once `count > threshold`.
  `/api/reader/task` is not gated (it answers `{"success":false,"error":"Task not
  found","code":4004}`) but is useless without a task created by a gated call.
- Their own page renders the check itself when it gets that answer
  (`turnstile-challenge` card: "We've detected unusual reading activity from your
  IP address"), which is the giveaway that this is per-address: their site, the
  user's browser and the user's phone all pass it, transparently.
- The widget's sitekey (`0x4AAAAAABdTx0ekcJVVPAYZ`) is domain-locked: rendered from
  another origin it fires `error-callback("110200")`, so YueDu can never display
  the puzzle itself. `/api/reader/get` sends no CORS headers either.
- The chapter text is not in the server-rendered page (`__NEXT_DATA__` carries only
  the series), so the API really is the only way in — but the *page* is the way to
  pass the check, and that is what the unlock flow uses.

So the app asks from the user's own connection, in this order, and stops at the
first real answer (`WTL_post`): **native bridge** (the app, device + cookies) →
**plain `fetch()`** (device, browser-style; works in a wrapper with
`setAllowUniversalAccessFromFileURLs`, and a CORS failure is remembered for 5
minutes so it isn't paid for twice) → **the shared perchance route**. Which route
answered and what the site said is kept in `WTR_ROUTE_LOG` / `WTR_GATE` and shown
by the connection test.

When the answer is the gate, `wtrGatedError()` (`err.wtrGated`) reaches the reader,
which renders `wtrGatedCard()`:

- In the **packaged app**: *Unlock WTR Lab reading* → `solveInWebView()` → the
  wrapper's challenge WebView (`nativeOpenChallenge`) or, failing that, the in-app
  site view, on the exact chapter URL (`lastBlockedUrl`, set by `WTL_getChapter`);
  the chrome then offers "I passed the check — read it in YueDu" (`onRetry` →
  `openChapter`). The retry now asks from the device, so it is the site's own check
  that lifts the limit for that address — the LNReader sequence.
- In a **browser**: there is no device route, so the card says so and offers the
  in-app site view (the site's own page, framed, on the user's connection) rather
  than a retry that cannot work.

Do **not** bring back the old in-app Turnstile widget: the sitekey rejects our
origin, so it could only ever say "Puzzle can't load here".

Still working in-app either way (verified): `/api/search`, `/api/chapters/<raw_id>`
and the novel page's `__NEXT_DATA__` — search, novel details and chapter lists.

### Native bridge (`window.LitNative`) — what the packaged app adds

The wrapper (the HTML→APK converter) can register one JavaScript interface object;
`src/android-plugin/` has a ~150 line, dependency-free `LitNative.java` doing exactly
that, plus a README with the 15-line wiring and the one-line alternative
(`setAllowUniversalAccessFromFileURLs(true)`).

Client side (all in the "native bridge" block of `index.html`):

- `nativeObj()` finds it under any of `NATIVE_NAMES`, or any object exposing
  `fetch`+`cookies`; the scan is **guarded** — reading a property off a cross-origin
  iframe parked on `window` throws, and that must never break the page (it did
  during development; keep the try/catch).
- `nativeCall(method, args, timeout)` posts a request id and resolves on
  `window.__litNative(reqId, json)`; a synchronous string (or promise) return works
  too. `nativeFetchText`, `nativeCookies`, `nativeOpenChallenge`, `nativeInfo`,
  `nativeMethods` wrap it.
- `nativeAvailable()` puts a `{name: "native"}` transport **first** in
  `getTransports()` and first in `sfPostTransports()`; everything else is unchanged,
  so a broken bridge just falls through to the proxies.
  **A 403/challenge from `native` does not condemn the queue** — `hedgedGet`'s
  `blockedNow()` is skipped for that transport (one device attempt says nothing
  about the proxies' networks, and vice versa: that is why both exist). Treating it
  as a plain failure lets the hedge carry on. Keep that exception if you touch the
  blocked logic.
- `solveInWebView(url, title, onRetry)` opens the challenge screen (or the in-app
  site view) and then retries. `wireCaptchaHint` appends a "Solve in a WebView"
  button to **every** failure card when the bridge has `challenge`, and the WTR card
  prefers it over the frame.

### Connection test (More → Connection test)

`runNetTest()` makes the same requests the app makes, one route at a time, and shows
which answered: this build + origin + bridge + version, **how the page is being
displayed**, a browser-style GET, the
native GET, the perchance GET, `POST /api/reader/get` from the device, from the
bridge and through the perchance route (classified by `netClassWtr`:
`reads chapters ✓` / `asks for the security check (count/threshold)` / `blocked by
the site`), and the cookies each side holds. `netReportText()` + Copy report is the
paste-into-a-bug-report form. It is read-only, and it is the instrument to use
before believing any theory about a failing source.

The display block (`Window`, `Screen`, `Browser scale` / `Window width`, `Fix`) was
added in 2.9.2 for the "everything on the phone is tiny and it doesn't fill the
screen" report. It compares `innerWidth` with the device's width in CSS px
(`screen.width`/`height`, orientation-aware) and with `visualViewport.scale`, and
says which of the two things is happening: the browser is drawing a page wider than
the screen (a page zoom, or Chrome's **Desktop site** mode — that tab had the
Desktop-site chip in its address bar), or the frame YueDu was given is narrow
(the perchance editor's preview pane, or a platform pane left narrow by the editor's
saved Split.js sizes — `__hideEditShell()` hides `#a`/`#f` but does **not** reset
`#b`'s inline width, so a pane dragged narrow in edit mode can stay narrow in view
mode). Neither is the app's layout, which is why the rows exist: they turn "it looks
small" into a number.

### In-app site view (`openSiteView`, `#siteviewScreen`)

The way around a source that only serves its own origin (WTR Lab) or only the
user's own connection (NovelLive, LightNovelPub — they refuse the proxy's IP but
serve a normal browser): show the site's own page inside YueDu in a frame.

- `openSiteView(url, title, opts)` fills `#siteviewFrame`, sets the title, unhides
  the `.subScreen`, and writes one line of chrome above the frame. `opts` can add a
  `note` and a `{retryLabel, onRetry}` button — that is how the WTR unlock ends
  ("I passed the check — read it in YueDu" → closes the frame → retries the
  chapter, which now comes from the device). `closeSiteView()` points the frame at
  `about:blank` so the page stops running/playing; the header has reload +
  open-in-browser buttons, and the chrome line has an "open it in your browser"
  link for the case below.
- Wired through `[data-site-view]` in `wireCaptchaHint`, so any failure card can
  offer it. The URL is `lastBlockedUrl` **only when `sourceForURL(lastBlockedUrl)`
  is that same source** (it's a global — it can be stale from an earlier failure
  on a different source), otherwise `sourceBaseURL(src)`.
- Currently offered by: the WTR gated card (`data-wtr-unlock`, which prefers the
  wrapper's challenge WebView and falls back to this frame), the refusal card
  (`err.blocked` — which is its **own** branch in `openChapter`'s catch; before it
  fell into the generic branch and the honest refusal copy inside the
  `captchaBlocked` branch was unreachable, because `captchaBlocked` is false for
  `err.blocked`), and — as an appended "Solve in a WebView" button — every failure
  card when the native bridge has `challenge`.
- The frame is another origin: the app cannot read, restyle or capture it (the
  full-page snapshot tool skips it — that is expected, and the striped area in a
  capture is the tool's placeholder, not the screen).
- Verified framable (no `X-Frame-Options`, no CSP `frame-ancestors` — checked via
  `api.hackertarget.com/httpheaders`, and the frame load event fires in ~0.9s for
  a WTR chapter page). Third-party-cookie behaviour inside the frame is the one
  thing that can't be verified from here; the chrome's browser link covers it.

## Roleplay AI (2.7.6) — the one feature that is not a novel source

`AI_ENABLED` (localStorage `yuedu_ai_enabled`, default **off**) is flipped by
the switch in **Settings hub → Features → Roleplay AI**. `renderSources()` appends
`aiSourceCardHTML()` when it is on: a `.srcDivider` labelled *Not a reading source*
followed by a `.sourceCard.aiCard` with `data-ai="1"`. The Browse click handler
opens `#aiScreen` for that card instead of `enterSourceMode()`; the AI card is
exempted from `applySourceFilter()` (so "hide unavailable" never hides it) and is
deliberately **not** in `SOURCES`, so global search, health checks, migrate and
the library never see it. The divider exists because the user asked for the AI to
be visually separated from the reading sources.

The screen (`#aiScreen`, a `.subScreen`) has two panes: `#aiListView` (the
character list, a *Create a character* form and a *Connection settings* panel)
and `#aiChatView` (header avatar/name/tagline, `#aiMsgs` scroller, `#aiInput`
textarea + send/stop buttons). Characters are `AI_CHARS` in `index.html` (twelve
built-ins, each with a `persona`; the `gm` one has `mode: "gm"` and gets a
Game-Master system prompt instead of the texting one) plus custom ones in
localStorage `yuedu_ai_custom`. Transcripts live in `yuedu_ai_chats`
(`{charId: [{role, text, ts}]}`, trimmed to `AI_STORE_MAX` per character, and
trimmed again harder if localStorage is full). Only the newest
`AI_HISTORY_MAX` messages are sent, so long chats stay cheap.

**Why it works in the packaged app (this is the part to not break):** the
perchance `generateText` plugin cannot run in the standalone — there is no
`main.pjs`, no `root` and no plugin loader. So the AI is reached over plain
HTTPS instead: `aiRequest()` POSTs to the OpenAI-compatible endpoint from
`aiConfig()`, which defaults to `https://text.pollinations.ai/openai`
(`AI_DEFAULT_URL`, model `openai`) — a free, key-less service that answers with
`Access-Control-Allow-Origin: *`, so even a `file://` WebView can call it
directly with no bridge. That service serves one anonymous model, `gpt-oss-20b`,
which is a *reasoning* model; left alone it thinks for 2000+ characters and the
first text can take 10-25s, so the chat system prompt tells it not to deliberate
at length — with that, a reply streams in ~4-8s. **Do not** set
`reasoning_effort: "low"` to speed it up: that truncates the model's own
thinking stream and the visible reply comes back garbled mid-word (measured).

- A user-supplied endpoint (base URL + key + model, stored in `yuedu_ai_cfg`)
  overrides the default. It is offered from a panel inside the screen, so a user
  whose network blocks the free service has an escape hatch.
- `aiRequestWithFallback()` retries a **network** failure through the app's own
  `bridgeFetch` POST (the packaged app's route to the internet) — but only when
  there is no `window.root.superFetch`, only for the default endpoint, and never
  for an HTTP error (`err.httpStatus`), because an HTTP error is a real answer
  and waiting out a 60s bridge call for it just makes the error slow to appear.
- `aiFriendlyError()` turns statuses into plain sentences (404 → check the
  connection settings, 401/403 → check the key, 429 → busy, retry), because the
  raw body is often an HTML error page. The failed bubble gets a *Try again*
  button in the message stream.
- Replies stream over SSE (`data:` lines, `choices[0].delta.content` only — the
  `delta.reasoning` channel is deliberately ignored). An `AbortController` backs
  the stop button, `aiState.seq` invalidates a reply whose character was switched
  mid-flight, and a `.aiTyping` three-dot bubble is shown from the moment Send is
  tapped until the first content chunk.

Nothing here touches `sf()`, the transports or the sources. If you ever need the
AI to use perchance's own models instead, that means importing `ai-text-plugin`
in `main.pjs` **and** adding a bridge message type so the deployed page can call
`root.generateText` for the standalone — it was considered and deliberately not
done (it puts an ad on the generator for logged-out visitors, and the bridge half
cannot be tested until the generator is saved).

## Adding a source — the touch points

**Looking for what to add next?** `src/SOURCES-CANDIDATES.md` is the surveyed
list: sources that answer JSON (their own app interface), WordPress theme
families where one parser buys dozens of sites (Madara, LightNovelWP,
Fictioneer, ReadNovelFull, MTLNovel, HotNovelPub), and individual scrape-only
sites — plus the APK-dig recipe for a site whose app API is the goal.

A source is a handful of small edits across `index.html`, none of them
optional — miss one and the source half-works (a card that opens an empty feed,
a book that can't be opened from the library, a cover that never resolves).
In the order they appear in the file:

1. **`SOURCES`** — the Browse card: `{name, logoUrl, icon (2-4 letter tile),
   color, desc, lang, active:true, status:"Connected"}`. `logoUrl` is a
   Google-favicon URL; add `logoFallback` only if the favicon is unreliable.
2. **`SRC`** — the behaviour, keyed by the exact same name:
   `cover(id)`, `search(q)`, `authorSearch(name)` (only if the site can search
   by author — otherwise `authorSearch` is omitted and the app falls back to
   `search`), `getBook(bookId)` → `{detail, cat:{chapters,total,note?}}`, and
   `getChapter(book, chapterId)` →
   `{name, num, html, locked, nextId, prevId, total}`.
3. **Identity maps** — `ID_PREFIX_SOURCES` (`nc: "NovelCool"`, so a remembered
   book can be re-attributed), `COVER_HOST_SOURCES` (cover host → source), and
   `SRC_ALIASES` if users might type the name another way.
4. **`sourceForURL(url)`** (which source a blocked/target URL belongs to) and
   **`sourceBaseURL(name)`** (the "Open site" / captcha target).
5. **`HEALTH_URLS`** — one URL that answers to a plain headerless request.
   That is what `sfHealth` probes, so an endpoint needing a header can't be used
   here (NovelHi uses its listing API, not its chapter endpoint).
6. **The feed**: a branch in `buildDiscoverJobs(name)` (2-6 listing URLs), a
   label in `feedLabel(name)`, and a parse branch in `fetchBrowsePage(url, name)`
   (`books = XX_parseBooks(html)`; a JSON API just `JSON.parse`s the body).
7. **Ratings**: add to `RATING_ENRICHABLE` + `ratingForBook` **only** if the
   listing pages don't carry a rating the parser can read (NovelHi's API returns
   `rate`, so it needs neither).
8. **`openExternal`** in the book-card menu — the site's own URL for a book id.
9. **`CATALOGS`** (offline sitemap index) **only** for a source with no usable
   GET search. NovelHi's search is GET, so it isn't there.
10. **A header or a special transport** means the bridge needs it too: pass a
    mode through `bridgeFetch(url, {via})` (`req.via` survives the postMessage)
    and add the matching branch to the `__litBridge` listener at the top of
    `index.html`. Remember the deployed bridge page only learns it once the
    generator is saved.
11. **A site whose pages are heavy or walled may still have a small JSON API.**
    Webnovel's own book list (`/go/pcm/search/result`, see "Webnovel (2.7.12)")
    is the same catalogue as its 350 KB search page for 53 KB, and unlike the
    pages it is not challenged from our route. To find one: fetch any page of
    the site, then grep its `_next/static` (or `assets`) script chunks for
    `/go/pcm/`, `/api/`, `ajax` … — the paths the site itself calls are in
    there. A 5-10x cheaper request is usually a bigger win than any amount of
    transport tuning. **The site's own client is the map**: GoodNovel's routes
    (2.7.41) were found by fetching `mdist/app.…js` off its H5 page and grepping
    it for quoted paths — the `/hwyc/…` list, and the axios call sites that say
    which parameters each route wants, are all in that one file. **A WordPress
    site is the easiest case of all**: `GET
    /wp-json/` lists every registered route (no auth), including the site's own
    app interface — Scribble Hub's `/wp-json/fictionapp/v1/…` was found exactly
    this way (2.7.33) — and WordPress's REST layer echoes the request's `Origin`,
    so those routes are readable by a plain `fetch` from *any* origin, a
    `file://` WebView included.

12. **Publication status** (2.7.14, optional) — if the site says whether a novel
    is ongoing or finished, hand it back as `detail.status` from `getBook`
    (and, if the listing cards show it, as `status` on a browse result). The
    raw words are fine: `normStatus` turns them into the one of the four keys.
    If the site never publishes one, do nothing — the reader can set it by
    hand. See "Novel status (2.7.14)".

13. **Decode every string that reaches the screen with `decodeText(x)`** —
    titles, authors, synopses, chapter names, chapter text. Never hand-write a
    `.replace(/&quot;/g, '"')` chain: these sites write their punctuation as
    *numeric* entities (`&#8217;`, `&#8220;`, `&#8221;`), which such a chain
    misses, and several escape their text twice on top of that. See "The fix:
    one decoder, every path (2.7.31)" — that bug shipped because four chains
    each listed a handful of named entities by hand.

14. **Covers from a host nobody uses yet** need two things, and missing either
    leaves every card showing its letter: an entry in `coverURLs` (the direct
    URL, then `https://images.weserv.nl/?url=…`) **and** the host added to the
    `crossOrigin` exception list inside `loadCoverImg`. A picture CDN that sends
    no ACAO header answers a CORS-mode image request with nothing at all —
    measured on `cdn.scribblehub.com` in 2.7.33 — and `cacheCover` can't cache
    what it can't draw to a canvas. See "A cover host that sends no ACAO…" under
    "Things that will bite you".

15. **Read the site's own app interface before scraping its pages.** Where a
    site ships an Android app, the app's endpoints are usually reachable
    unauthenticated with the app's own identity (Novel Cool: `api.novelcool.com`
    with `appId`/`secret`; Scribble Hub: `/wp-json/fictionapp/v1/…`), they
    answer with JSON — the novel, the **whole** chapter list (paged 200 at a
    time, oldest first) and each chapter's text — and they are usually the
    CORS-permissive ones, so they work from the packaged app's `file://` page.
    This is the approach the user asked for in as many words: *"I want you to do
    the same approach. That android own thing. Like used in novel cool"* — the
    site's own interface, never LNReader's plugin source. And when a site has
    **no** such interface, scraping its reader page is the only route; then anchor
    on the site's own content container, not the whole document. And when even
    that is walled — every address challenging every non-browser request, with no
    app interface to fall back on — the answer is to **drop the source**, which is
    what happened to NovelLive / LightNovelPub in 2.7.38, not to keep re-trying it.

16. **A new source is health-checked automatically — nothing to add, but check
    it anyway.** The 2.7.34 sweep discovers its targets from `SOURCES` and its
    route through `buildDiscoverJobs` + `fetchBrowsePage` + `SRC[...].getBook`/
    `getChapter`, so a source that is wired up correctly (items 1, 2 and 6) is
    tested from the moment it appears. Two things to confirm by hand the first
    time: (a) **its first `buildDiscoverJobs` entry must actually carry novels**,
    or the screen will honestly say *"Its front page answered, but no novels were
    on it"* — the sweep tries the first three jobs, so a weak first URL is fine,
    but if all three are landing pages the source will report `empty` forever;
    (b) **a source whose chapter list is empty for a legitimate reason** (a manga
    entry on Novel Cool, say) will report `book`/`empty` when the sweep happens
    to open that novel — this is why the sweep opens up to three novels before
    judging, and why a new source's shelf should be checked to make sure its
    first few entries are ordinary text novels.

Then: bump `APP_VERSION` and prepend an `UPDATES` entry, update the source count
and the source table in `src/DESCRIPTION.md`, rebuild
`src/standalone/index.html`, and verify in the live preview with
`SRC["Name"].search("…")`, `fetchBrowsePage(buildDiscoverJobs("Name")[0], "Name")`,
`SRC["Name"].getBook(id)` and `SRC["Name"].getChapter(book, firstChapterId)`,
plus `sfHealth(healthURL("Name")) === "ok"` — and click through that source's
Browse card, a book and a chapter in the UI, because the parser being right does
not prove the screen is. (`probeSourceHealth("Name")` runs the 2.7.34 sweep on
one source and returns its verdict, which is the fastest end-to-end check there
is.)

## Things that will bite you

- **A cover host that sends no ACAO must be in `loadCoverImg`'s exception list —
  and the same fact is why `cacheCover` cannot cache it.** `loadCoverImg` sets
  `img.crossOrigin = "anonymous"` unless the URL matches one of the hosts listed
  in its exclusion regex; a CORS-mode request to a CDN with no
  `Access-Control-Allow-Origin` is refused outright (measured on
  `cdn.scribblehub.com`: `crossOrigin="anonymous"` → `error`, the same URL without
  it → loads). Two consequences to keep in mind: (a) adding a source whose covers
  come from a new host means the host must join that list *and* get a
  `coverURLs` entry (usually direct URL + `images.weserv.nl`); (b) a non-CORS
  image **taints a canvas**, so `drawImage`+`toDataURL` in `cacheCover` throws —
  it is wrapped in try/catch, so those covers are shown but never cached (this is
  already true of NovelCool, Wuxiaworld, Lib Read, NovelHi and now Scribble Hub).
  A tainted cover also cannot be captured by a screenshot tool, so verify it by
  `naturalWidth > 0` and by fetching the URL, not by a canvas readback.
- **The source-health sweep runs on the real source code, so it can be tripped
  by the globals it wraps.** Two things to remember before touching it: (a)
  `hedgedGet` is **reassigned** once, in the health section, to a wrapper that
  counts in-flight requests (`healthNet`) so the sweep can stay out of the
  reader's way — a later `const hedgedGet = …` or a second wrapper would break
  the chain, and the wrapper must stay below `hedgedGet`'s declaration in the
  same script; (b) `netState` is already taken (the connection-pill code at
  ~3137 declares a *function* of that name), which is why the counter is called
  `healthNet`. Also: the sweep uses `SRC[...]` and `buildDiscoverJobs` directly,
  so a source that works in the UI but is missing from either will report
  `down`/`feed` — and, when testing from the preview, note that `page_eval`'s
  bare-name assignments do **not** reach the page's own functions (they land on
  the scope proxy), so a failure path has to be exercised with a temporary edit
  to the file rather than by monkey-patching globals from an eval. Stub
  properties on objects (`SRC["Name"].getChapter = …`) *do* work.
- **A WordPress `/wp-json/` route is fetchable from a `file://` page.** WordPress's
  `rest_send_cors_headers` *echoes the request's `Origin`*, so the REST layer is
  CORS-open: measured in the live page, a plain `fetch` of
  `.../wp-json/fictionapp/v1/stories/1048265` resolves and its body can be read,
  while a plain fetch of `/series/1048265/` is CORS-blocked. That is the same
  property that makes Novel Cool's `api.novelcool.com` work in the packaged app,
  and it is why a site's own app interface (`/wp-json/<app>/v1/...`) is the first
  thing to look for when a source is scrape-only — see "Scribble Hub: the site's
  own app interface (2.7.33)". When you add one, ask the interface, then keep the
  old HTML route behind a try/catch as the fallback.
- **Not every site has an app interface — and a whole-page fallback is worse
  than a miss.** NovelLive / LightNovelPub *looked* like a site with none, but it
  has one: `api.novellive.org`, found in 2.7.36 by decompiling the official
  Flutter app — see "NovelLive's app API — found, and currently broken" in the
  *Previously — 2.7.36* section (it is broken: 526 Invalid SSL certificate, so
  nothing can use it, its own app included). That source was **removed in
  2.7.38**: an app interface that is down plus a chapter route that challenges
  every non-browser request leaves nothing to read, and a source nobody can read
  is worse than no source. The lesson from the bug that *did* exist there, and
  which 2.7.35 fixed, is about the web route: `NLP_getChapter`'s old
  extractor searched for a `chapter-content` marker the template does not have,
  fell through to `const body = html`, and harvested every `<p>` on the page — so
  every chapter ended with the site's own "Visit and read more novel…" and "Use
  arrow keys…" lines, the header carried the novel's title (from `<title>`), and
  the synopsis was the truncated `og:description`. Anchor on the site's own
  content container (`class="m-read"` → `class="txt"`, cut at the first of
  `class="chapter-end"` / `class="ul-list7"` / `class="footer"`) rather than on
  the whole document; the container is what makes the difference, a bigger noise
  list is not.
- **To find a site's app API: get the APK and read the right file — and try every
  TLD.** Two mistakes made the 2.7.35 conclusion wrong. (a) Only `.com`, `.app`
  and `.net` were probed; the real host was **`.org`** (`api.novellive.org`).
  Probe the whole family before deciding a host doesn't exist. (b) A **Flutter**
  app (look for `assets/flutter_assets/` in the APK) keeps its whole API surface
  in **`lib/<abi>/libapp.so`**, not in `classes.dex` — a dex-only scan of that APK
  shows only Google ads and Firebase and reads exactly like "this app has no
  API". Regex the raw `.so` bytes for `https?://…` and for candidate field names
  (`novel_id`, `chapter_id`, `offset`, `limit`, `token`, `deviceId`, …); the Dart
  AOT snapshot stores them as plain strings. Then check the host actually answers
  (a 526 through Cloudflare means "broken", not "absent"). Full recipe and the
  endpoint list are in "NovelLive's app API — found, and currently broken".
- **An Android WebView has no Web Speech API.** `window.speechSynthesis` and
  `SpeechSynthesisUtterance` do not exist inside the packaged app (MDN
  browser-compat-data: `webview_android: false` for both), so anything built on
  them is dead there — which is why read-aloud's own switch could never be turned
  on until 2.7.32. Read-aloud therefore runs on **three engines** (`tts.engine`:
  `web` → `native` (the `window.LitTts` bridge) → `remote` (an online voice played
  through an `<audio>` element, which is not subject to CORS and so works from a
  `file://` page)). Never write `if (!window.speechSynthesis) return;` again, and
  never make a toggle reset itself because an engine is missing.
- **A media request that fails reports itself twice.** Dead `<audio>` sources fire
  both a media `error` *and* a rejected `play()` promise, and an element that has
  been replaced keeps firing late events. Count failures **per attempt** (the
  per-attempt record in `ttsRemoteLoad`) or one dead address walks two rungs of the
  ladder and the working backup never gets a turn (measured, 2.7.32).
- **StreamElements' TTS endpoint needs an API key now.** The Polly voices behind
  `api.streamelements.com/kappa/v2/speech` answer
  `401 {"message":"No API key was found"}` (checked Sept 2026); the online voice
  uses Google's keyless `translate_tts` (two hosts) and ResponsiveVoice's
  `getvoice.php` instead.
- **WTR Lab titles carry the site's own `%{name|base64}` markup.** Keep the
  readable half with `wtrCleanTitle()`; it is applied on every path that builds a
  title or a chapter name, and `repairWtrTitles()` cleans what is already saved.

- **Entities are decoded by `decodeText`, never by hand.** Any page text that
  reaches the screen goes through `decodeText` — `decodeEntities` is the
  browser's own `<textarea>` parser (it knows every entity, named and numeric),
  and `decodeText` runs it until the text stops changing so twice-escaped text
  (`&amp;#8217;`, `&amp;quot;`) is decoded twice. A hand-written chain of
  `.replace(/&quot;/g, '"')`-style rules misses the numeric entities these sites
  actually use, and that is exactly how NovelFull chapters showed
  `City&#8217;s` until 2.7.31. Text that is *stored* (the 60-chapter
  `yuedu_chapcache_v2` ring, the `yuedu_offline` downloads) is repaired
  in place with `repairChapterHTML` rather than refetched.
- **The viewport tag must not ask for a fixed width.** `index.html` line 2 sets
  `width=device-width, initial-scale=1, ...`. It used to say `width=600`, and that
  is a self-inflicted "the app is tiny on my phone": a browser (or an Android
  WebView with `UseWideViewPort` + `LoadWithOverviewMode`) lays the page out at
  600 CSS px and then *scales the whole thing down* to fit the screen, so every
  pixel of the app is drawn at ~60% and the app stops filling the screen. The app
  is responsive (verified: no horizontal overflow at 320/390/412/600 px, `nav` is
  always 61 px tall, `#app` fills the viewport), so it should always be given the
  device's own width. Note the perchance page *rewrites* the viewport meta of the
  generator iframe to `width=device-width, initial-scale=1` (checked 2.9.2), so on
  a perchance page the tag is defensive only — the WebView build and the
  standalone are where it actually applies.
- **"It looks small on my phone" is a page/browser question, not an app one.** The
  app never scales itself (there is no `transform`/`zoom` on the shell, and
  `document.documentElement.scrollWidth === clientWidth` at every width). Measured
  from a 2.9.1 screenshot (720×1610): the app's own UI was complete and correctly
  proportioned, but it was drawn at ~38% of the screen width with the platform's
  `#121212` showing around it, i.e. the *page* was shrunk. The suspects, in order:
  Chrome's **Desktop site** (the chip is visible in the address bar of the affected
  tab — it was, in the report that started this), a page **zoom** below 100%
  (`visualViewport.scale`), the perchance **editor preview pane**, or a platform
  pane left narrow by the editor's saved Split.js sizes. The Connection test's
  display rows now print all four numbers, so ask for a screenshot of them instead
  of guessing.
- **The welcome screen shows on *every* load — that is deliberate (2.7.36).**
  `#introScreen` is plain markup and the only thing that removes it is the
  Continue tap (`hideIntro()`); there is no "seen" flag any more. Before 2.7.36
  the flag `yuedu_intro_seen` made it a first-run screen, and the reader
  asked for the old behaviour back — *"when [I] reload it goes back to The
  Intro"*. So do **not** re-add a once-per-browser gate: a reload landing on the
  splash is what the reader wants. (Keep the Continue button visible on short
  screens — see 2.7.35; that is the other half of "the intro".)
- **localStorage is a small shared budget (~5MB).** Keys: `pocketnovel_library`,
  `pocketnovel_history`, `pocketnovel_progress`, `pocketnovel_covers` (base64
  cover cache — the only big one), `pocketnovel_updates_cache`,
  `yuedu_chapcache_v2` (offline chapter bodies), `yuedu_seen_version`
  (update-notification dot), `yuedu_announce_seen`,
  `yuedu_pending_captcha` (resume-where-you-were after a browser captcha),
  `yuedu_srchealth_v1` (the 2.7.34 source-health verdicts — tiny, ~2 KB),
  `pocketnovel_*` settings. (`yuedu_intro_seen` existed up to 2.7.35 and is
  gone from 2.7.36 — the welcome screen is no longer gated.)
  Older builds cached up to 140 covers (~4.7MB!), which silently broke *every*
  other save. Covers are now capped by count **and** byte budget
  (`COVER_CACHE_MAX` / `COVER_CACHE_BYTES`) with a one-time load-time trim, and
  all writers go through `lsSet()`, which retries once after dropping the
  (re-downloadable) cover cache if the write fails.
- **`mapLimit(items, n, fn)`** is the concurrency helper (2 in flight for
  source fetches) — fetching 4+ source pages at once gets you rate-limited or
  captcha'd.
- **Captcha/robot pages** must not be treated as content: `isChallengePage()`,
  `captchaBlocked(err)` and `openCaptchaBlock(onRecover)` (shows the Solve
  screen, then continues what you were doing).
- **The platform's stylesheet outranks single-class button rules.** Perchance
  injects `button:not([disabled]) { color: inherit }` (specificity 0,1,1), which
  beats `.captchaBtn` (0,1,0), so a card's button label inherited the *card's*
  colour — pink-on-pink inside the `.reader-error` cards, grey-on-pink in
  `.searchHint` ones. `.captchaBtn` / `.captchaBtn.alt` set `color` and
  `-webkit-text-fill-color` with `!important` for exactly that reason; check
  contrast on any new button that sits in coloured text (a screenshot won't
  reveal it — read `getComputedStyle(btn).color`).
- **Sources are user-visible strings.** A book's `source` may be spelled
  differently than the `SRC` key (`resolveSource()` normalises, then falls back
  to the id prefix / cover host via `sourceFromId()` — keep
  `ID_PREFIX_SOURCES` in sync when adding a source, e.g. `nc-` NovelCool,
  `wl-` WTR Lab, `na-` NovelArrow, `sh-` Scribble Hub, numeric = Webnovel).
- **Generated ids** are `"<2-letter-prefix>-<slug|numeric id>"`; Webnovel books
  are bare numeric strings. Changing an id scheme orphans saved libraries.
- **Renaming the generator orphans user data**: kv/localStorage is keyed by the
  generator's subdomain, and `yuedu_pending_return` / slugs maps are
  per-origin. Don't rename without warning the user.

- **Never put the two-character replacement pattern "dollar-ampersand" in an
  agent edit's replacement text for this file.** Something in the file-editing
  tooling expands it as a replacement pattern: a past edit silently turned
  `NLP_lastPage`'s regex-escape string (`"\\$&"`, i.e. a backslash plus that
  pattern) into a literal `\const SRC = {`, which is the anchor string of the very
  edit sitting next to it in `index.html`. It survived because it only matters
  when a slug contains a regex metacharacter — and slugs are letters and hyphens —
  so nothing visibly broke. The repair (`escSlug` in `NLP_lastPage`) builds the
  escape with `String.fromCharCode(92)` precisely so that pattern appears nowhere;
  keep it that way, and prefer a function replacement (`(c) => "\\" + c`) when an
  edit would otherwise need it. Reported to the platform (report b84b544a).

- **Changelog prose with quotes: count the backslashes after editing `UPDATES`.**
  In 2.7.49 a patch's added line arrived over-escaped and the *shipped* string
  contained four real backslash characters — found by counting char code 92 in
  the live page (`UPDATES[0].items[2]` had 4 backslashes alongside its 4 quotes),
  not by eye and not through the JSON the file tools print, which escapes again.
  Nothing throws: the update log just shows a backslash in front of each quote.
  Repair such a line with `execute_js` by collapsing each run of backslashes in
  front of a quote down to exactly one (a regex replace over that one line),
  rather than by re-typing escapes into another patch.

- **A URL the app builds wrong surfaces as a captcha, not as a 404.** The first
  exercise of `CH_getChapter` (2.7.50) was handed the `{detail, cat}` object that
  `getBook` *returns* rather than a book carrying `bookId`, so the slug came out
  empty and the request went to `chikari.moe/api/novels//chapters/1/read` — a URL
  the app itself had built. `hedgedGet` read the malformed answer as a challenge
  and the reader was shown the captcha screen for a page that does not exist (the
  tell is `lastBlockedUrl` pointing at a double slash). So: every `*_getChapter`
  should validate the id/slug it derives and throw an honest error instead of
  requesting (Chikari's does now), and when testing a new source, build the book
  the way the app does — `{bookId, chapters, total}` — rather than passing
  `getBook`'s return value straight in.
## Updates feed semantics

`updatesCache = {ts, items:{bookId: entry}, seen:{bookId: snapshot}}` in
`pocketnovel_updates_cache`. On *Check for updates* (`refreshUpdates`) each
library novel's catalog is re-fetched; `catalogSnapshot()` takes
`max(total, highest chapter number)`; `readUpTo()` is
`max(chapters marked read in PROGRESS, HISTORY[bookId].num)`. New chapters are
reported when `latest > read`, or when the catalog grew past the last
`seen` snapshot — so a book you're fully caught up with does not get
re-flagged, and a source that still serves a stale/partial catalog cannot hide
chapters. Entries are pruned for novels no longer in the library, and a novel
you have never opened is labelled `Not started` on the summary row instead of a
misleading `+N new` badge. The screen also lists a per-novel outcome (new / up to date /
couldn't be checked) — this transparency is deliberate: "nothing happened" must
never be ambiguous, and failed fetches surface with a reason instead of being
swallowed.

## In-app app-update check

The About screen checks `https://editable.uploads.dev/file/yuedu-console/yuedu-manifest`
for a newer app version. Publish that manifest from the `yuedu-console` generator when releasing. The manifest may
also carry `announceOn: "yes"`, `announceTitle` and `announce` — that text is
shown once as the amber developer-message card (deduped by
`yuedu_announce_seen`), and `notes` (or `note`) supplies the what's-new
list. A newer version also lights the notification dot until the Update log is
opened (`yuedu_seen_version`).

*Superseded by 2.7.29: Novel Cool's own app API hands the app every chapter of
every novel, so which novels the site wraps no longer decides what can be read.
Kept as history — this is still exactly how the site route behaves.*

*Superseded by 2.7.29 (the app's own API reads these novels' chapters directly).
The measurements here still describe the site route, which remains the fallback.*

*Superseded by 2.7.29: the chapters listed here for *My Vampire System* now open
in the reader too, from Novel Cool's own app API. The site route below is kept as
the fallback and as history.*

## 2.9.22 — ZinManga, Toonily, ManhwaTop, MangaPill retired
Retired all four: chapter CDNs require site Referer (ZinManga cdn-1 404s; Toonily data, ManhwaTop c, MangaPill cdn 403) on direct+proxy+spoofed routes. Probed 10 replacements, none readable in browser builds. 8 comic sources remain, re-verified with decoded pixels: MangaDex, WeebCentral, ManhuaPlus, MangaRead, AsuraScans, FlameComics, MangaGeko, MangaKatana. Shelved books from retired sources get the retired reason + Find-on-another-source.

## 2.9.23 — guarded comics back behind readable routes + native APK project
ZinManga/Toonily/ManhwaTop/MangaPill engines, list rows, feeds restored; chapters open only via native bridge or the new outside image loader (More → Advanced → Image loader; script src/image-proxy/worker.js, Cloudflare free). New src/android-app/ wrapper project (WebView + LitNative bridge, Actions cloud build) so the user can build a real APK. Verified: 40 sources/12 manga listed, gate blocks in browser with loader hint, passes with stub bridge (Toonily 47ch/21pp), loader wrap + MangaPill gate-pass (59pp).

## 2.9.23 — guarded comics back behind readable routes + native APK project
ZinManga/Toonily/ManhwaTop/MangaPill engines, list rows, feeds restored; chapters open only via native bridge or the new outside image loader (More → Advanced → Image loader; script src/image-proxy/worker.js, Cloudflare free). New src/android-app/ wrapper project (WebView + LitNative bridge, Actions cloud build) so the user can build a real APK. Verified: 40 sources/12 manga listed, gate blocks in browser with loader hint, passes with stub bridge (Toonily 47ch/21pp), loader wrap + MangaPill gate-pass (59pp).

## 2.9.24 — LikeManga back as fifth gated comic source
New LM_ engine (likemanga.ink): suggest search, series with JSON-paginated chapter lists merged, plain chapter pictures with JWT-overflow decode, lmfeed listing feeds + extend, cover/count fetchers, lm- prefix/aliases/hosts/home/URL-detect/logo/row/health/enrich wiring, gatedComic gate. Measured: suggest+series+chapter pages plain HTML; mgread host 403s server-side (Referer guard); Ragnarok 69ch (0-68, incl. real Chapter 0), Arise 26ch/ordered, ch pages 18pp mgread URLs, feed 36 cards w/ covers. Verified in preview with stub bridge.

## 2.9.25 — guarded covers via native bridge + honest LikeManga counts
loadCoverImg: guarded hosts (mgImgNeedsReferer) with a bridge fetch bytes natively first, blob URL straight onto the card, old proxy rounds only as fallback — fixes LikeManga drawn tiles + Slow Connection spam in-app. LM_cards drops the list-2-chap count (every card said '2 ch'). Verified: feed chapters 0 pre-enrichment, native-first runs and falls back cleanly with failing stub.
