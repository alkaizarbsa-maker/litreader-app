// NOTE: this is a copy of src/android-plugin/LitNative.java (the canonical
// bridge source). If you change one, copy it to the other.
package com.litreader.bridge;

/*
 * LitNative — the JavaScript interface that lets the LitReader HTML make requests
 * from the DEVICE instead of through LitReader's shared servers.
 *
 * Why it exists: most sites LitReader reads are fine with a server asking, but some
 * count requests per internet address (WTR Lab: "unusual reading activity from your
 * IP", 15 requests then a Turnstile check) or bluntly refuse datacenter addresses
 * (NovelLive, LightNovelPub). The user's own phone is not over that limit and passes
 * the check invisibly, so asking from the device is the fix. That is the same trick
 * LNReader uses, and it needs the wrapper (the HTML→APK converter), not the HTML.
 *
 * Two ways to give the app that ability — see src/android-plugin/README.md:
 *   A. ONE LINE, no new files: webView.getSettings().setAllowUniversalAccessFromFileURLs(true)
 *      (plus setAllowFileAccessFromFileURLs(true) on old devices). The page can then
 *      fetch() cross-origin itself, from your connection, with the WebView's cookies.
 *   B. THIS FILE: a real bridge. Needed when you want the app to fetch natively
 *      (no CORS at all, works even if A is off), when you want to read the WebView's
 *      cookies from JS, and when you want the "pass the check in a proper WebView"
 *      flow that hands the page's text/storage/cookies back to LitReader.
 *
 * LitReader detects this automatically (window.LitNative, or any object with
 * fetch+cookies) and uses it FIRST for every request, falling back to the proxies
 * if it errors. Nothing in LitReader has to change when you add it.
 *
 * Wire-up (3 steps, ~15 lines — see the README for the exact snippet):
 *   1. LitNative.attach(this, webView)                    // registers the interface
 *   2. <activity android:name="com.litreader.bridge.LitNative$Challenge" .../> in the manifest
 *   3. CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
 *
 * Contract used by LitReader's client code (src/../index.html, "native bridge"):
 *   fetch(reqId, url, method, headersJson, body)   -> __litNative(reqId, {ok,status,text,url,contentType[,base64]})
 *   cookies(reqId, url)                            -> __litNative(reqId, {ok,cookies})
 *   challenge(reqId, url, title)                   -> __litNative(reqId, {ok,url,title,cookies,text,html,localStorage,sessionStorage})
 *   wtrResolve(reqId, url)                       -> __litNative(reqId, {ok,html}) — the chapter
 *      page loaded invisibly, its checks passing inside it (QuickNovel's
 *      WebViewResolver fallback for WTR Lab); no puzzle is ever shown
 *   info() -> a JSON string (synchronous; describes itself to the page)
 * Every answer is delivered by evaluating window.__litNative(<reqId>, <json>).
 *
 * It also provides window.LitTts — the device's own speech engine, for LitReader's
 * read-aloud (see the Tts class at the bottom of this file). It is not part of the
 * fetch story: Android's WebView has no Web Speech API at all, so without this an
 * APK can only read aloud through LitReader's online voice. With it, read-aloud uses
 * the phone's own voices and needs no connection.
 */

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LitNative {

    public static final String TAG = "LitNative";
    /** The name LitReader looks for first. Any name in its list works. */
    public static final String JS_NAME = "LitNative";
    private static final int MAX_BYTES = 24 * 1024 * 1024;

    private static WebView host;          // the app's WebView, where answers go back
    private static LitNative instance;
    private static String pendingChallengeReqId = null;

    private final Activity activity;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Handler ui = new Handler(Looper.getMainLooper());

    private LitNative(Activity activity) { this.activity = activity; }

    /**
     * Call once, right after you create the app's WebView and before its first
     * page load. Safe to call again (e.g. after a rotation).
     */
    public static void attach(Activity activity, WebView webView) {
        host = webView;
        if (instance == null) instance = new LitNative(activity);
        try {
            webView.addJavascriptInterface(instance, JS_NAME);
        } catch (Throwable t) {
            Log.w(TAG, "could not register " + JS_NAME, t);
        }
        try {
            webView.addJavascriptInterface(new Tts(webView), Tts.JS_NAME);
        } catch (Throwable t) {
            Log.w(TAG, "could not register " + Tts.JS_NAME, t);
        }
    }

    // ---------------------------------------------------------------- the interface

    /** Synchronous: LitReader reads this to show what the wrapper can do. */
    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("name", JS_NAME);
            o.put("version", 1);
            o.put("capabilities", "fetch,cookies,challenge,wtrResolve,tts,orientation,exitFullscreen,biometric");
            return o.toString();
        } catch (Throwable t) {
            return "{\"name\":\"" + JS_NAME + "\",\"version\":1}";
        }
    }

    /** GET/POST anything from the device, with the WebView's cookies attached. */
    @JavascriptInterface
    public void fetch(final String reqId, final String url, final String method,
                      final String headersJson, final String body) {
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    answer(reqId, doFetch(url, method, headersJson, body));
                } catch (Throwable t) {
                    fail(reqId, t.getClass().getSimpleName() + ": " + t.getMessage());
                }
            }
        });
    }

    /** The cookies the app's WebView holds for a URL (e.g. cf_clearance). */
    @JavascriptInterface
    public void cookies(final String reqId, final String url) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    String c = CookieManager.getInstance().getCookie(url);
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    o.put("cookies", c == null ? "" : c);
                    answer(reqId, o.toString());
                } catch (Throwable t) {
                    fail(reqId, String.valueOf(t.getMessage()));
                }
            }
        });
    }

    /* ---------------- silent chapter-page resolver (WTR Lab) ----------------
       QuickNovel reads WTR Lab this way whenever its reader API stays gated
       (see WtrLabProvider.loadHtml): a hidden page loads the chapter URL, the
       site's own checks pass inside it by themselves, and the rendered chapter
       body (div.chapter-body, one div[data-line] per line) is read back out.
       No puzzle is ever shown to the reader. Answers ride the same
       window.__litNative(reqId, json) channel as every other bridge answer:
       {ok:true, html} or {ok:false, error}. */
    @JavascriptInterface
    public void wtrResolve(final String reqId, final String url) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    startWtrResolve(reqId, url == null ? "" : url);
                } catch (Throwable t) {
                    wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
                }
            }
        });
    }

    private void startWtrResolve(final String reqId, final String url) {
        if (url.length() == 0) { wtrAnswer(reqId, false, "", "no url"); return; }
        final WebView web;
        try {
            web = new WebView(activity);
        } catch (Throwable t) { wtrAnswer(reqId, false, "", "no webview"); return; }
        try {
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
            /* Same marker-free UA as the app's own page: a clearance earned
               under one UA may not count under another. */
            String hua = host != null ? host.getSettings().getUserAgentString() : null;
            if (hua != null && hua.length() > 0) s.setUserAgentString(hua);
        } catch (Throwable ignored) {}
        try {
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        } catch (Throwable ignored) {}
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] done = new boolean[1];
        final int[] tries = new int[1];
        final Runnable[] pollRef = new Runnable[1];
        final Runnable poll = new Runnable() {
            @Override public void run() {
                if (done[0]) return;
                /* ~30s of polling, like QuickNovel's WebViewResolver fallback. */
                if (tries[0]++ >= 30) {
                    done[0] = true;
                    try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                    wtrAnswer(reqId, false, "", "the chapter page never rendered its text");
                    return;
                }
                try {
                    web.evaluateJavascript(
                        "(function(){try{var el=document.querySelector('div.chapter-body');"
                        + "var f=el?el.querySelector('div[data-line]'):null;"
                        + "var t=f?((f.innerText||f.textContent||'').trim()):'';"
                        + "return t.length>0?'1':'0';}catch(e){return '0';}})();",
                        new ValueCallback<String>() {
                            @Override public void onReceiveValue(String value) {
                                if (done[0]) return;
                                boolean found = value != null && value.length() >= 3
                                        && value.charAt(0) == '"' && value.charAt(1) == '1';
                                if (!found) { h.postDelayed(pollRef[0], 1000); return; }
                                try {
                                    web.evaluateJavascript(
                                        "(function(){try{var el=document.querySelector('div.chapter-body');"
                                        + "if(!el)return '';return el.innerHTML.slice(0,2000000);}"
                                        + "catch(e){return '';}})();",
                                        new ValueCallback<String>() {
                                            @Override public void onReceiveValue(String html) {
                                                if (done[0]) return;
                                                done[0] = true;
                                                String out = "";
                                                try {
                                                    if (html != null && html.length() > 1 && html.charAt(0) == '"') {
                                                        Object v = new org.json.JSONTokener(html).nextValue();
                                                        if (v != null && !JSONObject.NULL.equals(v)) out = String.valueOf(v);
                                                    }
                                                } catch (Throwable ignored) {}
                                                try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                                                if (out.length() == 0) wtrAnswer(reqId, false, "", "the chapter page came back empty");
                                                else wtrAnswer(reqId, true, out, null);
                                            }
                                        });
                                } catch (Throwable t) {
                                    done[0] = true;
                                    try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                                    wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
                                }
                            }
                        });
                } catch (Throwable t) {
                    h.postDelayed(pollRef[0], 1000);
                }
            }
        };
        pollRef[0] = poll;
        try {
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) { /* the poll decides */ }
            });
            web.loadUrl(url);
        } catch (Throwable t) {
            done[0] = true;
            try { web.destroy(); } catch (Throwable ignored) {}
            wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
            return;
        }
        h.postDelayed(poll, 1500);
    }

    private void wtrAnswer(String reqId, boolean ok, String html, String error) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (ok) o.put("html", html == null ? "" : html);
            else o.put("error", error == null ? "failed" : error);
            answer(reqId, o.toString());
        } catch (Throwable ignored) {}
    }

    /** Open the site in a real WebView so a challenge can be passed there. */
    @JavascriptInterface
    public void challenge(final String reqId, final String url, final String title) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    pendingChallengeReqId = reqId;
                    try { if (activity instanceof com.litreader.app.MainActivity) com.litreader.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
                    Intent i = new Intent(activity, Challenge.class);
                    i.putExtra("url", url);
                    i.putExtra("title", title);
                    activity.startActivity(i);
                } catch (Throwable t) {
                    fail(reqId, "challenge: " + t.getMessage());
                }
            }
        });
    }

    /** Device fingerprint for the entry lock screen: answers {ok:true} or {ok:false,error}.
     *
     * Auto-cancel hardening (the prompt dies instantly with ERROR_CANCELED when
     * the activity is not in front — floating/small window, split-screen, or a
     * tap that lands mid-resume — which used to surface as "tap Unlock and it
     * cancels by itself"):
     *  - the call waits (up to ~2.4s) for the window to actually be focused
     *    before firing, and answers "not-ready" instead of a doomed prompt;
     *  - only one prompt flies at a time (double-tap replaces, never stacks);
     *  - leaving the app dismisses an open prompt cleanly (see MainActivity).
     */
    private static volatile androidx.biometric.BiometricPrompt currentPrompt = null;

    /** Dismiss any prompt we fired that is still showing. Safe anywhere:
        call it from the host activity's onPause so a prompt never outlives
        the foreground (backgrounding mid-prompt otherwise leaves a stuck
        system sheet that cancels the next tap). */
    public static void cancelBiometric() {
        try {
            final androidx.biometric.BiometricPrompt p = currentPrompt;
            currentPrompt = null;
            if (p != null) p.cancelAuthentication();
        } catch (Throwable ignored) {}
    }

    @JavascriptInterface
    public void biometric(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    if (!(activity instanceof androidx.fragment.app.FragmentActivity)) { fail(reqId, "no activity"); return; }
                    final androidx.fragment.app.FragmentActivity fa = (androidx.fragment.app.FragmentActivity) activity;
                    waitForFocusThenAuth(fa, reqId, 0);
                } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
            }
        });
    }

    private void waitForFocusThenAuth(final androidx.fragment.app.FragmentActivity fa, final String reqId, final int tries) {
        boolean ready = false;
        try { ready = !fa.isFinishing() && !fa.isDestroyed() && fa.hasWindowFocus(); } catch (Throwable ignored) {}
        if (!ready) {
            /* Not in front yet (floating window, split-screen, mid-resume):
               never fire — the system would instantly cancel it. */
            if (tries >= 16) { fail(reqId, "not-ready"); return; }
            ui.postDelayed(new Runnable() {
                @Override public void run() { waitForFocusThenAuth(fa, reqId, tries + 1); }
            }, 150);
            return;
        }
        try {
            int ok;
            try {
                ok = androidx.biometric.BiometricManager.from(fa)
                        .canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                                | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            } catch (Throwable t) { fail(reqId, "unavailable"); return; }
            if (ok != androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) { fail(reqId, "not enrolled"); return; }
            cancelBiometric();
            java.util.concurrent.Executor ex = androidx.core.content.ContextCompat.getMainExecutor(fa);
            final androidx.biometric.BiometricPrompt prompt = new androidx.biometric.BiometricPrompt(fa, ex,
                    new androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(androidx.biometric.BiometricPrompt.AuthenticationResult r) {
                            currentPrompt = null;
                            try { activity.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
                            try { if (activity instanceof com.litreader.app.MainActivity) ((com.litreader.app.MainActivity) activity).reapplyOrientationAfterUnlock(); } catch (Throwable ignored) {}
                            try {
                                JSONObject o = new JSONObject();
                                o.put("ok", true);
                                answer(reqId, o.toString());
                            } catch (Throwable ignored) {}
                        }
                        @Override public void onAuthenticationError(int code, CharSequence msg) {
                            currentPrompt = null;
                            if (code == androidx.biometric.BiometricPrompt.ERROR_LOCKOUT) { fail(reqId, "locked out — too many tries, wait 30 seconds"); return; }
                            fail(reqId, code == androidx.biometric.BiometricPrompt.ERROR_USER_CANCELED
                                    || code == androidx.biometric.BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                    || code == androidx.biometric.BiometricPrompt.ERROR_CANCELED ? "cancelled" : String.valueOf(msg));
                        }
                        @Override public void onAuthenticationFailed() { /* stays open for a retry */ }
                    });
            currentPrompt = prompt;
            androidx.biometric.BiometricPrompt.PromptInfo info =
                    new androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                            .setTitle("Unlock LitReader")
                            .setSubtitle("Confirm fingerprint or screen lock to continue")
                            .setDescription("This lock keeps your library private on this device.")
                            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                                    | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                            .build();
            try { prompt.authenticate(info); }
            catch (Throwable t) { currentPrompt = null; fail(reqId, "unavailable"); }
        } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
    }

    @JavascriptInterface
    public void toast(final String msg) {
        ui.post(new Runnable() {
            @Override public void run() { Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    /**
     * Reading stays portrait; the anime watch screen frees rotation (see
     * LR_setLandscapeAllowed in the page). "sensor" follows the phone,
     * "landscape" pins it sideways for fullscreen video, anything else locks
     * portrait again.
     */
    @JavascriptInterface
    public void setOrientation(final String mode) {
        try {
            final Activity a = activity;
            if (a == null) return;
            final int want = "sensor".equalsIgnoreCase(mode)
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    : "landscape".equalsIgnoreCase(mode)
                    ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
            ui.post(new Runnable() {
                @Override public void run() {
                    try { a.setRequestedOrientation(want); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    /* Step out of fullscreen video on the page request (its own back button
       closes the episode without passing through the system back key, which
       used to strand the app on the dead fullscreen view: landscape, frozen).
       Safe anywhere: a no-op when no custom view is showing. */
    @JavascriptInterface
    public void exitFullscreen() {
        try {
            final Activity a = activity;
            if (a == null) return;
            if (a instanceof com.litreader.app.MainActivity) {
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { ((com.litreader.app.MainActivity) a).hideCustomView(); } catch (Throwable ignored) {}
                    }
                });
            }
        } catch (Throwable ignored) {}
    }

    // ---------------------------------------------------------------- the work

    /* Shared cookie jar for the device route (Aniyomi model: one client on the
       WebView's jar). Native requests are stateless unless cookies are kept:
       hosts that hand a session cookie on one page and demand it on the next
       (embed page → play link) fail without it. Cookies earned natively are
       stored per host AND pushed into the WebView jar, and every native
       request sends both — page, bridge and media intercept share one jar. */
    private static final java.util.Map<String, java.util.Map<String, String>> cookieStore =
            new java.util.HashMap<String, java.util.Map<String, String>>();

    private static String hostOf(String url) {
        try {
            String h = new URL(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Throwable t) { return ""; }
    }

    /** Merged "name=value; ..." for a URL: stored native cookies + WebView jar. */
    public static String cookieHeaderFor(String url) {
        StringBuilder sb = new StringBuilder();
        String host = hostOf(url);
        synchronized (cookieStore) {
            java.util.Map<String, String> m = cookieStore.get(host);
            if (m != null) for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(e.getKey()).append("=").append(e.getValue());
            }
        }
        try {
            String jar = CookieManager.getInstance().getCookie(url);
            if (jar != null && jar.length() > 0) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(jar);
            }
        } catch (Throwable ignored) {}
        return sb.toString();
    }

    /** Fold Set-Cookie response headers into the store + WebView jar. */
    public static void storeCookiesFrom(String url, HttpURLConnection c) {
        if (url == null || c == null) return;
        final String u = url;
        final String host = hostOf(url);
        if (host.length() == 0) return;
        java.util.List<String> set = null;
        try {
            java.util.Map<String, java.util.List<String>> hf = c.getHeaderFields();
            if (hf != null) for (java.util.Map.Entry<String, java.util.List<String>> e : hf.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase("Set-Cookie")) { set = e.getValue(); break; }
            }
        } catch (Throwable ignored) {}
        if (set == null || set.isEmpty()) return;
        final java.util.List<String> add = new java.util.ArrayList<String>();
        synchronized (cookieStore) {
            java.util.Map<String, String> m = cookieStore.get(host);
            if (m == null) { m = new java.util.HashMap<String, String>(); cookieStore.put(host, m); }
            for (String s : set) {
                if (s == null) continue;
                int sc = s.indexOf(';');
                String pair = (sc >= 0 ? s.substring(0, sc) : s).trim();
                int eq = pair.indexOf('=');
                if (eq <= 0) continue;
                String name = pair.substring(0, eq).trim(), value = pair.substring(eq + 1).trim();
                if (name.length() == 0) continue;
                m.put(name, value);
                add.add(pair);
            }
        }
        if (add.isEmpty() || host == null) return;
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        for (String pair : add) CookieManager.getInstance().setCookie(u, pair);
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    private String doFetch(String url, String method, String headersJson, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        boolean post = method != null && !"GET".equalsIgnoreCase(method) && !"HEAD".equalsIgnoreCase(method);
        c.setRequestMethod(post ? method.toUpperCase() : "GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("Accept", "*/*");
        String ua = null;
        if (host != null) {
            try { ua = host.getSettings().getUserAgentString(); } catch (Throwable ignored) {}
        }
        c.setRequestProperty("User-Agent", ua != null ? ua : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
        if (headersJson != null && headersJson.length() > 1) {
            JSONObject h = new JSONObject(headersJson);
            for (Iterator<String> it = h.keys(); it.hasNext(); ) {
                String k = it.next();
                /* Let the platform own these; overriding them breaks the request. */
                if (k.equalsIgnoreCase("cookie") || k.equalsIgnoreCase("host")
                        || k.equalsIgnoreCase("content-length") || k.equalsIgnoreCase("connection")) continue;
                c.setRequestProperty(k, h.getString(k));
            }
        }
        /* The shared jar (stored native cookies + WebView's), so a check
           passed anywhere — page, challenge screen, or an earlier native
           request — counts here too. */
        try {
            String cookie = cookieHeaderFor(url);
            if (cookie != null && cookie.length() > 0) c.setRequestProperty("Cookie", cookie);
        } catch (Throwable ignored) {}
        if (post) {
            c.setDoOutput(true);
            byte[] out = (body == null ? "" : body).getBytes(Charset.forName("UTF-8"));
            c.setFixedLengthStreamingMode(out.length);
            OutputStream os = c.getOutputStream();
            os.write(out);
            os.flush();
            os.close();
        }
        int status = c.getResponseCode();
        try { storeCookiesFrom(url, c); } catch (Throwable ignored) {}
        InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
        byte[] raw = new byte[0];
        if (in != null) raw = readBytes(in);
        String contentType = c.getContentType();
        if (contentType == null) contentType = "";
        JSONObject o = new JSONObject();
        o.put("ok", true);
        o.put("status", status);
        o.put("contentType", contentType);
        o.put("url", c.getURL().toString());
        /* HLS video segments (.ts, video/mp2t) and generic octet-streams are
           binary like pictures: decoding them as text would corrupt them, so
           they ride back base64 and the page turns them into bytes (the anime
           player's bridge loader feeds guarded HLS through this with the
           video host as Referer). Playlists stay text. */
        String ctl = contentType.toLowerCase();
        if (ctl.startsWith("image/") || ctl.startsWith("video/") || ctl.startsWith("audio/") || ctl.startsWith("application/octet-stream")) {
            /* Binary: decoding bytes as text would corrupt them, so they ride
               back base64 and the page turns them into a blob (LikeManga's
               hotlink-guarded pages are read this way, with a Referer header
               no WebView request of its own could state). */
            o.put("base64", Base64.encodeToString(raw, Base64.NO_WRAP));
            o.put("text", "");
        } else {
            o.put("text", new String(raw, Charset.forName(charsetOf(contentType))));
        }
        c.disconnect();
        return o.toString();
    }

    private static String charsetOf(String contentType) {
        if (contentType != null) {
            int i = contentType.toLowerCase().indexOf("charset=");
            if (i >= 0) {
                String cs = contentType.substring(i + 8).trim();
                int sc = cs.indexOf(';');
                if (sc > 0) cs = cs.substring(0, sc).trim();
                try { if (Charset.isSupported(cs)) return cs; } catch (Throwable ignored) {}
            }
        }
        return "UTF-8";
    }

    private static byte[] readBytes(InputStream in) throws Exception {
        BufferedInputStream bin = new BufferedInputStream(in);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n, total = 0;
        while ((n = bin.read(buf)) > 0) {
            bos.write(buf, 0, n);
            total += n;
            if (total > MAX_BYTES) break;
        }
        bin.close();
        return bos.toByteArray();
    }

    /** Called by Challenge with the JSON it scraped out of the site's page. */
    static void deliverChallenge(final String json) {
        final String reqId = pendingChallengeReqId;
        pendingChallengeReqId = null;
        if (reqId == null) return;
        evaluate("window.__litNative(" + JSONObject.quote(reqId) + "," + JSONObject.quote(json) + ")", null);
    }

    private void answer(String reqId, String json) {
        evaluate("window.__litNative(" + JSONObject.quote(reqId) + "," + JSONObject.quote(json) + ")", null);
    }

    private void fail(String reqId, String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("error", message == null ? "failed" : message);
            answer(reqId, o.toString());
        } catch (Throwable ignored) {}
    }

    private static void evaluate(final String js, final String[] out) {
        final WebView w = host;
        if (w == null) return;
        w.post(new Runnable() {
            @Override public void run() {
                try { w.evaluateJavascript(js, null); } catch (Throwable t) { Log.w(TAG, "evaluateJavascript failed", t); }
            }
        });
    }

    // ---------------------------------------------------------------- the challenge screen

    /**
     * A plain WebView on the URL that is blocking us, with a Done button. Passing
     * the check here (Turnstile / Cloudflare) is what the site's own page needs, and
     * the cookies it sets go into the shared jar, so LitReader's next request from
     * the device is already through. Done also hands back the page's text, so a
     * chapter can be read straight out of it if the API stays closed.
     */
    public static class Challenge extends Activity {

        private WebView web;
        private TextView titleView;
        private TextView subView;
        private String startUrl = "https://wtr-lab.com/";
        private boolean delivering = false;
        private boolean loadError = false;
        private boolean pageDone = false;
        private boolean passAnnounced = false;
        private long openedAt = 0;
        private final Handler cfPoller = new Handler(Looper.getMainLooper());
        private String cfAtOpen = "";
        private Runnable cfPoll;

        @Override protected void onCreate(android.os.Bundle saved) {
            super.onCreate(saved);
            try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            if (getIntent() != null && getIntent().getStringExtra("url") != null) {
                startUrl = getIntent().getStringExtra("url");
            }
            final String title = getIntent() == null ? null : getIntent().getStringExtra("title");

            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(0xFF0B0B10);

            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
            s.setSupportZoom(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
            /* Same marker-free UA as the main WebView (see MainActivity): the
               "; wv" WebView token loops bot walls forever, and a clearance
               earned under one UA may not count under another. */
            try {
                String hua = host != null ? host.getSettings().getUserAgentString() : null;
                if (hua != null && hua.length() > 0) s.setUserAgentString(hua);
                else s.setUserAgentString("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            } catch (Throwable ignored) {}
            try { String c = CookieManager.getInstance().getCookie(startUrl); cfAtOpen = c == null ? "" : c; } catch (Throwable ignored) {}
            openedAt = android.os.SystemClock.elapsedRealtime();
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) { pageDone = true; checkClearance(); }
                @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                    if (req != null && req.isForMainFrame()) {
                        loadError = true;
                        if (subView != null) {
                            CharSequence d = err != null ? err.getDescription() : null;
                            subView.setText("Couldn't reach the site (" + (d == null ? "connection error" : d) + ") — check the connection, then Cancel and retry.");
                        }
                    }
                }
                @Override public void onReceivedHttpError(WebView v, WebResourceRequest req, WebResourceResponse resp) {
                    if (req != null && req.isForMainFrame() && resp != null && resp.getStatusCode() >= 400 && subView != null) {
                        loadError = true;
                        subView.setText("The site answered " + resp.getStatusCode() + " — if a check is showing above, solve it, then tap Done.");
                    }
                }
            });
            web.setWebChromeClient(new WebChromeClient() {
                @Override public void onProgressChanged(WebView v, int p) {
                    if (loadError || subView == null) return;
                    subView.setText(p < 100 ? "Loading… " + p + "%" : "If the site shows a check above, solve it — then tap Done");
                }
            });
            root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.VERTICAL);
            bar.setBackgroundColor(0xFF101016);
            bar.setPadding(dp(12), dp(10), dp(12), dp(6));

            titleView = new TextView(this);
            titleView.setText(title == null ? "One quick check" : title);
            titleView.setTextColor(0xFFFFFFFF);
            titleView.setTextSize(15);
            titleView.setTypeface(titleView.getTypeface(), android.graphics.Typeface.BOLD);
            titleView.setMaxLines(1);
            titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            bar.addView(titleView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            subView = new TextView(this);
            subView.setText("Loading…");
            subView.setTextColor(0xFF9A9AAC);
            subView.setTextSize(12);
            subView.setMaxLines(2);
            LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            subParams.topMargin = dp(2);
            bar.addView(subView, subParams);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            bar.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button cancel = new Button(this);
            cancel.setText("Cancel");
            cancel.setTextColor(0xFF9A9AAC);
            cancel.setBackgroundColor(0x00000000);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeWithoutCapture(); }
            });
            row.addView(cancel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button done = new Button(this);
            done.setText("Done ✓");
            done.setTextColor(0xFFFFFFFF);
            done.setBackgroundColor(0xFFFF3B7D);
            done.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { captureAndClose(); }
            });
            row.addView(done, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
            root.addView(bar, barParams);
            setContentView(root);
            web.loadUrl(startUrl);
            /* A Cloudflare check usually passes itself inside the page — wait
               for the fresh cf_clearance cookie and close on the spot instead
               of making the user guess when to tap Done. */
            cfPoll = new Runnable() {
                @Override public void run() { checkClearance(); if (!delivering) cfPoller.postDelayed(cfPoll, 1000); }
            };
            cfPoller.postDelayed(cfPoll, 1000);
        }

        @Override public void onBackPressed() { captureAndClose(); }

        /** A clearance that was not there at open means the check just passed. */
        private String cfValue(String cookies) {
            if (cookies == null) return "";
            for (String p : cookies.split(";")) {
                String t = p.trim();
                if (t.startsWith("cf_clearance=")) return t.substring("cf_clearance=".length());
            }
            return "";
        }
        private String currentClearance() {
            String best = "";
            try {
                String a = CookieManager.getInstance().getCookie(startUrl);
                if (cfValue(a).length() > 0) best = cfValue(a);
            } catch (Throwable ignored) {}
            try {
                String cur = web != null ? web.getUrl() : null;
                if (cur != null && !cur.equals(startUrl)) {
                    String b = CookieManager.getInstance().getCookie(cur);
                    if (cfValue(b).length() > 0) best = cfValue(b);
                }
            } catch (Throwable ignored) {}
            return best;
        }
        private void checkClearance() {
            if (delivering) return;
            try {
                /* Never close on a stale cookie: the screen must have been open
                   a while, finished at least one page load, and seen a
                   clearance that was not there at open. Otherwise an old
                   cookie (or a slow jar) slams the screen shut before the
                   user solves anything — the "pushes me back" loop. */
                if (!pageDone) return;
                if (android.os.SystemClock.elapsedRealtime() - openedAt < 8000) return;
                String now = currentClearance();
                if (now.length() == 0 || now.equals(cfValue(cfAtOpen))) return;
                if (!passAnnounced) {
                    passAnnounced = true;
                    if (subView != null) subView.setText("Check passed — returning to the episode…");
                    cfPoller.postDelayed(new Runnable() {
                        @Override public void run() { captureAndClose(); }
                    }, 1500);
                }
            } catch (Throwable ignored) {}
        }

        /** Read the page back to LitReader, then really close the screen. */
        private void captureAndClose() {
            if (delivering) return;
            delivering = true;
            if (web == null) { Challenge.super.finish(); return; }
            /* Never leave the screen stuck open if the page can't be read. */
            titleView.setText("Saving…");
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { if (delivering) { try { Challenge.super.finish(); } catch (Throwable ignored) {} } }
            }, 4000);
            web.evaluateJavascript(
                "(function(){try{return JSON.stringify({url:location.href,title:document.title," +
                "text:(document.body?document.body.innerText:'').slice(0,2000000)," +
                "html:(document.body?document.body.innerHTML:'').slice(0,4000000)," +
                "localStorage:Object.assign({},localStorage),sessionStorage:Object.assign({},sessionStorage)});}catch(e){return '';}})()",
                new android.webkit.ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        String json = value;
                        if (json != null && json.length() > 1 && json.charAt(0) == '"') {
                            try { json = new org.json.JSONTokener(json).nextValue().toString(); } catch (Throwable ignored) {}
                        }
                        try {
                            JSONObject o = (json == null || json.length() == 0) ? new JSONObject() : new JSONObject(json);
                            String ck = CookieManager.getInstance().getCookie(startUrl);
                            o.put("ok", true);
                            o.put("cookies", ck == null ? "" : ck);
                            if (!o.has("url")) o.put("url", startUrl);
                            LitNative.deliverChallenge(o.toString());
                        } catch (Throwable t) {
                            LitNative.deliverChallenge("{\"ok\":true,\"cookies\":\"\"}");
                        }
                        try { Challenge.super.finish(); } catch (Throwable ignored) {}
                    }
                });
        }

        /** Leave without solving: hand back the cookies so far and let the app's
            own retry decide. Never strands the reader — the waiter is answered. */
        private void closeWithoutCapture() {
            if (delivering) return;
            delivering = true;
            try {
                String ck = CookieManager.getInstance().getCookie(startUrl);
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("cookies", ck == null ? "" : ck);
                try {
                    String cur = web != null ? web.getUrl() : null;
                    if (cur != null) o.put("url", cur);
                } catch (Throwable ignored) {}
                LitNative.deliverChallenge(o.toString());
            } catch (Throwable ignored) {}
            try { Challenge.super.finish(); } catch (Throwable ignored) {}
        }

        private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    }

    // ---------------------------------------------------------------- speech (read aloud)

    /**
     * The device's own speech engine, behind window.LitTts.
     *
     * This is what makes read-aloud possible in the packaged app at all. Android's
     * WebView has no Web Speech API — `window.speechSynthesis` simply does not exist
     * there (MDN's browser-compat-data: webview_android false) — so without this
     * LitReader can only speak through its online voice. With it, read-aloud uses the
     * phone's own voices, works offline, and can use any installed language.
     *
     * LitReader speaks one sentence at a time and drives everything from the
     * callbacks, which arrive as `window.__litTts(<id>, <json>)`:
     *
     *   {"event":"start"}                  it began speaking
     *   {"event":"range","start":s,"end":e}  the word being spoken (API 26+)
     *   {"event":"end"}                    the sentence finished
     *   {"event":"error","code":c}         it refused
     *
     * Android has no pause, so LitReader's pause stops the engine and its resume
     * says the sentence again from its start — the same thing it does for a browser
     * engine that ignores pause().
     */
    public static class Tts {

        public static final String JS_NAME = "LitTts";

        private final WebView host;
        private final Handler ui = new Handler(Looper.getMainLooper());
        private TextToSpeech engine;
        private boolean ready = false;
        private String chosenVoice = null;

        /** Everything the page needs to know about what the engine is doing. */
        private final UtteranceProgressListener progress = new UtteranceProgressListener() {
            @Override public void onStart(String id) {
                fire(id, "{\"event\":\"start\"}");
            }
            @Override public void onDone(String id) {
                fire(id, "{\"event\":\"end\"}");
            }
            @Override public void onError(String id) {
                fire(id, "{\"event\":\"error\",\"code\":-1}");
            }
            @Override public void onError(String id, int code) {
                fire(id, "{\"event\":\"error\",\"code\":" + code + "}");
            }
            @Override public void onRangeStart(String id, int start, int end, int frame) {
                fire(id, "{\"event\":\"range\",\"start\":" + start + ",\"end\":" + end + "}");
            }
        };

        public Tts(WebView webView) {
            host = webView;
            try {
                engine = new TextToSpeech(webView.getContext(), new TextToSpeech.OnInitListener() {
                    @Override public void onInit(int status) {
                        ready = status == TextToSpeech.SUCCESS;
                        if (!ready || engine == null) return;
                        /* The listener is installed once the engine is up: the TTS
                           object refuses most of its calls before that. */
                        try { engine.setOnUtteranceProgressListener(progress); } catch (Throwable ignored) {}
                        try { engine.setLanguage(Locale.getDefault()); } catch (Throwable ignored) {}
                    }
                });
            } catch (Throwable t) {
                Log.w(TAG, "no speech engine available", t);
                engine = null;
            }
        }

        /** Whether the engine came up. LitReader asks once before it relies on it. */
        @JavascriptInterface
        public boolean ready() { return ready && engine != null; }

        /**
         * The device's voices, as [{"name":"…","lang":"en-US"}, …]. LitReader shows
         * these in the TTS settings; each language is a group, the phone's own
         * language first, with "System default" as a real choice.
         */
        @JavascriptInterface
        public String voices() {
            try {
                if (engine == null) return "[]";
                java.util.Set<Voice> set = engine.getVoices();
                if (set == null) return "[]";
                JSONArray arr = new JSONArray();
                for (Voice v : set) {
                    if (v == null) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("lang", v.getLocale() == null ? "" : v.getLocale().toLanguageTag());
                    arr.put(o);
                }
                return arr.toString();
            } catch (Throwable t) {
                return "[]";
            }
        }

        /** Say one sentence. `id` comes back with every callback; `rate` is 0.5-2. */
        @JavascriptInterface
        public void speak(final String id, final String text, final float rate, final String voice) {
            final TextToSpeech t = engine;
            if (t == null || text == null || text.length() == 0) {
                fire(id, "{\"event\":\"error\",\"code\":-1}");
                return;
            }
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (voice != null && voice.length() > 0 && !voice.equals(chosenVoice)) {
                            chosenVoice = voice;
                            java.util.Set<Voice> set = t.getVoices();
                            if (set != null) {
                                for (Voice v : set) {
                                    if (v != null && voice.equals(v.getName())) { t.setVoice(v); break; }
                                }
                            }
                        }
                        t.setSpeechRate(rate > 0 ? rate : 1f);
                        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
                    } catch (Throwable e) {
                        fire(id, "{\"event\":\"error\",\"code\":-2}");
                    }
                }
            });
        }

        /** Stop speaking now (pause and stop are the same thing here). */
        @JavascriptInterface
        public void stop() {
            final TextToSpeech t = engine;
            if (t == null) return;
            ui.post(new Runnable() {
                @Override public void run() { try { t.stop(); } catch (Throwable ignored) {} }
            });
        }

        /** Hand one event back to the page. Called from the engine's own thread. */
        private void fire(String id, String json) {
            final WebView w = host;
            if (w == null || id == null) return;
            final String js = "window.__litTts(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")";
            ui.post(new Runnable() {
                @Override public void run() {
                    try { w.evaluateJavascript(js, null); } catch (Throwable t) { Log.w(TAG, "tts callback failed", t); }
                }
            });
        }
    }
}
