package com.litreader.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.litreader.bridge.LitNative;

/**
 * LitReader, packaged: the generator page in a WebView, plus the LitNative
 * bridge. The bridge is raw device HTTP and can state any header (notably the
 * Referer that guarded comic picture hosts demand) — that is what makes
 * Toonily, ZinManga, ManhwaTop and MangaPill chapters read here with zero
 * configuration. It also gives read-aloud the device's own voices and opens
 * bot checks in a real page when a site demands it.
 *
 * Display options are manifest flags so a converter (e.g. ToApp) can set them
 * per build without touching Java: com.litreader.app.URL,
 * com.litreader.app.IMMERSIVE, com.litreader.app.DARK_MODE,
 * com.litreader.app.EDGE_TO_EDGE, com.litreader.app.PULL_REFRESH,
 * com.litreader.app.DESKTOP_SITE. Each defaults to off when its entry is absent.
 */
public class MainActivity extends Activity {

    private WebView web;
    private SwipeRefreshLayout pull;
    private ValueCallback<Uri[]> fileChooser;
    private String appUA = null;
    private boolean immersive;
    private long lastBackPress = 0;
    private Toast backToast;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        immersive = metaBool("com.litreader.app.IMMERSIVE", false);
        boolean edge = metaBool("com.litreader.app.EDGE_TO_EDGE", false);
        boolean dark = metaBool("com.litreader.app.DARK_MODE", false);
        boolean desktop = metaBool("com.litreader.app.DESKTOP_SITE", false);
        boolean refresh = metaBool("com.litreader.app.PULL_REFRESH", false);

        if (edge) applyEdgeToEdge();

        web = new WebView(this);
        web.setFitsSystemWindows(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        /* Honor the page's `width=550` viewport so the layout stays fixed at
           550 CSS px on every device and every smallest-width (dp) setting.
           Without the wide viewport the WebView ignores the width rule and
           lays out at the device width instead — which is why changing the
           smallest width to 400dp reshaped the whole app. Overview mode then
           scales the fixed 550 layout to fit the screen. */
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        } else {
            /* Strip the "; wv" WebView marker bot walls score as a bot. The
               clearance the check screen earns must count for the app's own
               requests, so both sides use the same marker-free UA (Aniyomi
               solves with one consistent UA the same way). */
            try {
                String ua = s.getUserAgentString();
                if (ua != null && ua.contains("; wv")) s.setUserAgentString(ua.replace("; wv", ""));
            } catch (Throwable ignored) {}
        }
        if (dark) applyDark(s);
        try { appUA = s.getUserAgentString(); } catch (Throwable ignored) {}

        if (refresh) {
            pull = new SwipeRefreshLayout(this);
            pull.addView(web, new SwipeRefreshLayout.LayoutParams(
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT));
            pull.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override public void onRefresh() {
                    if (web != null) web.reload();
                    else pull.setRefreshing(false);
                }
            });
            setContentView(pull);
        } else {
            setContentView(web);
        }
        if (immersive) applyImmersive();
        setupInsetBridge();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        LitNative.attach(this, web);

        web.setWebViewClient(new WebViewClient() {
            /* Guarded video files (AnimeGG's /play mp4s answer file requests
               without the site as Referer with nothing playable — the same
               header its own player and the Aniyomi extension send). A <video>
               element on a file:// page sends no Referer at all, so these are
               fetched natively with the site attached and streamed back,
               ranged requests included. Anything else loads untouched. */
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                try {
                    String u = r != null && r.getUrl() != null ? r.getUrl().toString() : "";
                    String referer = refererForMedia(u);
                    if (referer != null) return fetchMediaWithReferer(u, r.getRequestHeaders(), referer);
                } catch (Throwable ignored) {}
                return null;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                enforceFixedViewport(v);
                pushStoredInsets();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (pull != null && p == 100) pull.setRefreshing(false);
            }
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                /* The player's fullscreen button: without this the WebView drops
                   the request and fullscreen silently does nothing. The video
                   takes the whole window and turns landscape by itself — no
                   system auto-rotate needed — and stays there until fullscreen
                   leaves, even if the phone is held upright. */
                try {
                    if (customView != null) {
                        try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                        return;
                    }
                    customView = view;
                    customCb = callback;
                    android.widget.FrameLayout decor =
                            (android.widget.FrameLayout) getWindow().getDecorView();
                    decor.addView(customView, new android.widget.FrameLayout.LayoutParams(
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
                    if (web != null) web.setVisibility(View.GONE);
                    try {
                        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    } catch (Throwable ignored) {}
                } catch (Throwable t) {
                    try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                }
            }
            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    startActivityForResult(i, 1001);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });

        if (saved != null) {
            web.restoreState(saved);
        } else {
            web.loadUrl(appStartUrl());
        }
    }

    /**
     * The layout is fixed at 550 CSS px on every smallest-width (dp) setting:
     * the wide-viewport flags in onCreate honor the page's width=550 viewport
     * and overview mode scales that fixed layout to fit the screen. Two things
     * used to defeat it — maximum-scale=1 in the viewport clamped the
     * fit-to-screen scale to 1x on screens wider than 550dp, and any bundled
     * page that ever ships without the width rule lays out at the window width
     * instead. The first is fixed in the page; this repairs the second at
     * runtime by creating or correcting the viewport meta after every load, so
     * the fixed layout holds no matter what page text ends up in the bundle.
     */
    private void enforceFixedViewport(WebView v) {
        if (v == null) return;
        try {
            v.evaluateJavascript(
                    "(function(){try{var m=document.querySelector('meta[name=viewport]');"
                            + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');"
                            + "(document.head||document.documentElement).appendChild(m);}"
                            + "var c=m.getAttribute('content')||'';"
                            + "if(!/(^|,)\\s*width\\s*=\\s*550(\\s|,|$)/.test(c)){"
                            + "m.setAttribute('content','width=550, user-scalable=no, viewport-fit=cover');}"
                            + "return window.innerWidth+'x'+window.innerHeight;}catch(e){return 'err';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) { /* layout readout; nothing to do */ }
                    });
        } catch (Throwable ignored) {}
    }

    /**
     * System-bar insets for the page (see the --lit-inset-top/bottom rules).
     * The reader footer, header, bottom nav and select bar pad themselves with
     * the CSS safe-area env(), but a file:// WebView reports that as 0 even
     * when the window draws edge-to-edge behind the status/nav bars — so in
     * the app the footer either hid behind the system bars or floated above
     * them with a visible gap, while the desktop preview sat flush. The
     * window insets are the truth here: they are pushed into the page as CSS
     * variables whenever they change and re-pushed after every load (a fresh
     * page starts with none). Device pixels become page CSS px through the
     * fixed 550-wide layout scale (see enforceFixedViewport).
     */
    private int litInsetTopCss = 0, litInsetBottomCss = 0;

    private void setupInsetBridge() {
        if (web == null) return;
        try {
            web.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try { pushInsetsToPage(insets); } catch (Throwable ignored) {}
                    return v.onApplyWindowInsets(insets);
                }
            });
            web.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void pushInsetsToPage(android.view.WindowInsets insets) {
        try {
            android.view.WindowInsets root = null;
            try { root = getWindow().getDecorView().getRootWindowInsets(); } catch (Throwable ignored) {}
            if (root == null) root = insets;
            if (root == null) return;
            int topPx, bottomPx;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets stb = root.getInsets(android.view.WindowInsets.Type.statusBars());
                android.graphics.Insets nvb = root.getInsets(android.view.WindowInsets.Type.navigationBars());
                android.graphics.Insets tap = root.getInsets(android.view.WindowInsets.Type.tappableElement());
                topPx = Math.max(stb.top, tap.top);
                /* Gesture navigation reports no nav bar, only the handle area
                   (tappable element) — the max covers both worlds. */
                bottomPx = Math.max(nvb.bottom, tap.bottom);
            } else {
                topPx = root.getStableInsetTop();
                bottomPx = root.getStableInsetBottom();
            }
            pushInsetsPxToPage(topPx, bottomPx);
        } catch (Throwable ignored) {}
    }

    private void pushInsetsPxToPage(int topPx, int bottomPx) {
        if (web == null) return;
        int viewW = 0;
        try { viewW = web.getWidth(); } catch (Throwable ignored) {}
        if (viewW <= 0) {
            try { viewW = getResources().getDisplayMetrics().widthPixels; } catch (Throwable ignored) {}
        }
        if (viewW <= 0) return;
        double k = 550.0 / (double) viewW;
        litInsetTopCss = (int) Math.round(topPx * k);
        litInsetBottomCss = (int) Math.round(bottomPx * k);
        pushStoredInsets();
    }

    private void pushStoredInsets() {
        if (web == null) return;
        final int t = litInsetTopCss, b = litInsetBottomCss;
        final String js = "(function(){try{document.documentElement.style.setProperty('--lit-inset-top','"
                + t + "px');document.documentElement.style.setProperty('--lit-inset-bottom','"
                + b + "px');return 1;}catch(e){return 0;}})();";
        try { web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void applyEdgeToEdge() {        try {
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams a = w.getAttributes();
                a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(a);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars()
                                    | android.view.WindowInsets.Type.navigationBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyDark(WebSettings s) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(true);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) {}
    }

    private boolean metaBool(String name, boolean def) {
        try {
            android.os.Bundle m = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA).metaData;
            if (m != null && m.containsKey(name)) {
                Object v = m.get(name);
                if (v instanceof Boolean) return (Boolean) v;
                if (v instanceof String) return Boolean.parseBoolean((String) v);
                if (v instanceof Integer) return (Integer) v != 0;
            }
        } catch (Throwable ignored) {}
        return def;
    }

    /**
     * The page to open. Normally the bundled address, but a converter that
     * repackages this APK as a generic template (e.g. ToApp) can set a
     * per-build address without touching Java: patching one manifest entry is
     * all it takes, which is exactly what in-browser APK patchers can do.
     *
     * <meta-data android:name="com.litreader.app.URL"
     *            android:value="https://example.com/app" />
     */
    private String appStartUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                String u = ai.metaData.getString("com.litreader.app.URL");
                if (u != null && (u.startsWith("https://") || u.startsWith("http://")
                        || u.startsWith("file:///"))) return u;
            }
        } catch (Throwable ignored) {}
        return "file:///android_asset/www/index.html";
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && immersive) applyImmersive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (immersive) applyImmersive();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == 1001 && fileChooser != null) {
            ValueCallback<Uri[]> cb = fileChooser;
            fileChooser = null;
            try {
                cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            } catch (Throwable t) {
                try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        /* Fullscreen video first: back leaves fullscreen, it never quits. */
        if (customView != null) {
            hideCustomView();
            return;
        }
        /* Step-by-step back (2.10.2): the page walks its own layers first
           (dialogs, reader, book screen, source feed — see
           window.__litBackPressed), which used to be skipped entirely: with a
           single-page app the WebView has no history to go back to, so every
           press fell through to super and quit the whole app. Only when the
           page reports its root does the press arm a real exit, and a second
           press within two seconds takes it. */
        try {
            web.evaluateJavascript(
                    "(function(){try{return (typeof window.__litBackPressed==='function')"
                            + "?String(window.__litBackPressed()):'';}catch(e){return '';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) {
                            String v = value;
                            if (v != null && v.length() >= 2 && v.charAt(0) == '"'
                                    && v.charAt(v.length() - 1) == '"') {
                                v = v.substring(1, v.length() - 1);
                            }
                            if ("1".equals(v)) {
                                lastBackPress = 0;
                                return;
                            }
                            if (web != null && web.canGoBack()) {
                                web.goBack();
                                return;
                            }
                            long now = System.currentTimeMillis();
                            if (now - lastBackPress < 2000) {
                                if (backToast != null) backToast.cancel();
                                MainActivity.super.onBackPressed();
                            } else {
                                lastBackPress = now;
                                if (backToast != null) backToast.cancel();
                                backToast = Toast.makeText(MainActivity.this,
                                        "Press back again to exit", Toast.LENGTH_SHORT);
                                backToast.show();
                            }
                        }
                    });
        } catch (Throwable ignored) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /**
     * Leave fullscreen video: the view goes away, the page comes back, and the
     * page decides the orientation — the anime watch screen keeps rotation,
     * anything else locks portrait again.
     */
    private void hideCustomView() {
        try {
            if (customView != null) {
                try {
                    android.widget.FrameLayout decor =
                            (android.widget.FrameLayout) getWindow().getDecorView();
                    decor.removeView(customView);
                } catch (Throwable ignored) {}
                customView = null;
            }
            if (web != null) web.setVisibility(View.VISIBLE);
            try { if (customCb != null) customCb.onCustomViewHidden(); } catch (Throwable ignored) {}
            customCb = null;
            restorePageOrientation();
        } catch (Throwable ignored) {}
    }

    private void restorePageOrientation() {
        try {
            if (web == null) return;
            web.evaluateJavascript("(function(){try{return window.LR_landOk===true?'1':'0';}catch(e){return '0';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String v) {
                            try {
                                boolean land = v != null && v.contains("1");
                                setRequestedOrientation(land
                                        ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR
                                        : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                            } catch (Throwable ignored) {}
                        }
                    });
        } catch (Throwable ignored) {}
    }

    /**
     * The Referer a guarded video file demands, or null to load normally.
     * Only those hosts are intercepted; everything else (m3u8 playlists via
     * hls.js, covers, pages) loads exactly as before.
     */
    private String refererForMedia(String url) {
        if (url == null) return null;
        String u = url.toLowerCase();
        if (u.startsWith("https://www.animegg.org/play/") && u.contains(".mp4")) return "https://www.animegg.org/";
        if (u.contains("://vidcache.") && u.contains(".mp4")) return "https://www.animegg.org/";
        return null;
    }

    /**
     * Fetch a media URL natively (phone IP, app UA + WebView cookies, the given
     * Referer) and stream it back to the WebView — full or ranged (206), so
     * seeking keeps working. Runs on the WebView's background thread, so plain
     * blocking IO is correct here. Null on any failure: the WebView then loads
     * the URL itself and the page's own error path answers.
     */
    private WebResourceResponse fetchMediaWithReferer(String url, java.util.Map<String, String> reqHeaders, String referer) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", appUA != null ? appUA : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
            c.setRequestProperty("Referer", referer);
            c.setRequestProperty("Accept", "*/*");
            try {
                String cookie = LitNative.cookieHeaderFor(url);
                if (cookie != null && cookie.length() > 0) c.setRequestProperty("Cookie", cookie);
            } catch (Throwable ignored) {}
            String range = null;
            if (reqHeaders != null) {
                for (java.util.Map.Entry<String, String> e : reqHeaders.entrySet()) {
                    if (e.getKey() != null && e.getKey().equalsIgnoreCase("Range")) { range = e.getValue(); break; }
                }
            }
            if (range != null && range.length() > 0) c.setRequestProperty("Range", range);
            int status = c.getResponseCode();
            try { LitNative.storeCookiesFrom(url, c); } catch (Throwable ignored) {}
            java.io.InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null || status >= 400) { try { c.disconnect(); } catch (Throwable ignored) {} return null; }
            String ct = c.getContentType();
            String mime = "video/mp4";
            if (ct != null) {
                int sc = ct.indexOf(';');
                mime = (sc > 0 ? ct.substring(0, sc) : ct).trim().toLowerCase();
                if (mime.length() == 0) mime = "video/mp4";
            }
            java.util.Map<String, String> respHeaders = new java.util.HashMap<String, String>();
            String[] copy = { "Content-Length", "Content-Range", "Accept-Ranges", "Content-Type" };
            for (String k : copy) {
                try {
                    String hv = c.getHeaderField(k);
                    if (hv != null) respHeaders.put(k, hv);
                } catch (Throwable ignored) {}
            }
            return new WebResourceResponse(mime, null, status, status == 206 ? "Partial Content" : "OK", respHeaders, in);
        } catch (Throwable t) {
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) {} }
            return null;
        }
    }
}
