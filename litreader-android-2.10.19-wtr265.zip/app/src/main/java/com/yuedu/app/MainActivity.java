package com.yuedu.app;

import androidx.fragment.app.FragmentActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.yuedu.bridge.YueNative;

/**
 * YueDu, packaged: the generator page in a WebView, plus the YueNative
 * bridge. The bridge is raw device HTTP and can state any header (notably the
 * Referer that guarded comic picture hosts demand) — that is what makes
 * Toonily, ZinManga, ManhwaTop and MangaPill chapters read here with zero
 * configuration. It also gives read-aloud the device's own voices and opens
 * bot checks in a real page when a site demands it.
 *
 * Display options are manifest flags so a converter (e.g. ToApp) can set them
 * per build without touching Java: com.yuedu.app.URL,
 * com.yuedu.app.IMMERSIVE, com.yuedu.app.DARK_MODE,
 * com.yuedu.app.EDGE_TO_EDGE, com.yuedu.app.PULL_REFRESH,
 * com.yuedu.app.DESKTOP_SITE. Each defaults to off when its entry is absent.
 */
public class MainActivity extends FragmentActivity {

    private WebView web;
    private SwipeRefreshLayout pull;
    private ValueCallback<Uri[]> fileChooser;
    private String appUA = null;
    private boolean immersive;
    private long lastBackPress = 0;
    private Toast backToast;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        /* Fail-closed window: blank the recents card from the very first
           paint. The page boots locked (opaque card), and the flag is only
           cleared on a successful Unlock — so locked content never leaks
           through the task snapshot, while screenshots keep working unlocked.
           Off until the user opts in (first-run choice / Security screen). */
        try { if (com.yuedu.bridge.YueNative.secGrayOn(this)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}

        immersive = metaBool("com.yuedu.app.IMMERSIVE", false);
        boolean edge = metaBool("com.yuedu.app.EDGE_TO_EDGE", false);
        boolean dark = metaBool("com.yuedu.app.DARK_MODE", false);
        boolean desktop = metaBool("com.yuedu.app.DESKTOP_SITE", false);
        boolean refresh = metaBool("com.yuedu.app.PULL_REFRESH", false);

        if (edge) applyEdgeToEdge();

        web = new WebView(this);
        web.setFitsSystemWindows(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        /* Honor the page's `width=510` viewport so the layout stays fixed at
           510 CSS px on every device and every smallest-width (dp) setting.
           Without the wide viewport the WebView ignores the width rule and
           lays out at the device width instead — which is why changing the
           smallest width to 400dp reshaped the whole app. Overview mode then
           scales the fixed 510 layout to fit the screen. */
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        } else {
            /* Strip the "; wv" WebView marker bot walls score as a bot. The
               clearance the check screen earns must count for the app's own
               requests, so both sides use the same marker-free UA (Aniyomi
               solves with one consistent UA the same way). */
            try {
                String ua = s.getUserAgentString();
                if (ua != null && ua.contains("; wv")) s.setUserAgentString(ua.replace("; wv", ""));
            } catch (Throwable ignored) {}
        }
        if (dark) applyDark(s);
        try { appUA = s.getUserAgentString(); } catch (Throwable ignored) {}
        /* First paint already at the 510-fit scale: without this the page
           first lays out at scale 1 (device width — big intro text/buttons)
           and only shrinks to the fixed 510 layout seconds later when
           overview mode kicks in. Percent = portrait dp width mapped onto
           510 CSS px; rotation is covered by overview mode after this. */
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float dpW = dm.widthPixels / dm.density;
            int pct = Math.round(dpW * 100f / 510f);
            if (pct < 10) pct = 10;
            else if (pct > 500) pct = 500;
            web.setInitialScale(pct);
        } catch (Throwable ignored) {}

        if (refresh) {
            pull = new SwipeRefreshLayout(this);
            pull.addView(web, new SwipeRefreshLayout.LayoutParams(
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT));
            pull.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override public void onRefresh() {
                    if (web != null) web.reload();
                    else pull.setRefreshing(false);
                }
            });
            setContentView(pull);
        } else {
            setContentView(web);
        }
        if (immersive) applyImmersive();
        setupInsetBridge();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        YueNative.attach(this, web);

        web.setWebViewClient(new WebViewClient() {
            /* Guarded video files (AnimeGG's /play mp4s answer file requests
               without the site as Referer with nothing playable — the same
               header its own player and the Aniyomi extension send). A <video>
               element on a file:// page sends no Referer at all, so these are
               fetched natively with the site attached and streamed back,
               ranged requests included. Anything else loads untouched. */
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                try {
                    String u = r != null && r.getUrl() != null ? r.getUrl().toString() : "";
                    String referer = refererForMedia(u);
                    if (referer != null) return fetchMediaWithReferer(u, r.getRequestHeaders(), referer);
                } catch (Throwable ignored) {}
                return null;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                pageLoaded = true;
                enforceFixedViewport(v);
                pushStoredInsets();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (pull != null && p == 100) pull.setRefreshing(false);
            }
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                /* The player's fullscreen button: without this the WebView drops
                   the request and fullscreen silently does nothing. The video
                   takes the whole window and follows the stored player choice
                   — portrait first, landscape only when the rotation switch
                   asked for it — so there is no sideways flash that snaps
                   back a frame later. */
                try {
                    if (customView != null) {
                        try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                        return;
                    }
                    customView = view;
                    customCb = callback;
                    android.widget.FrameLayout decor =
                            (android.widget.FrameLayout) getWindow().getDecorView();
                    decor.addView(customView, new android.widget.FrameLayout.LayoutParams(
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
                    if (web != null) web.setVisibility(View.GONE);
                    /* Portrait-first: lastOrientation tracks every page
                       request (portrait is the default), so this lands
                       directly where the player already is. */
                    try {
                        String lo = "portrait";
                        try { lo = String.valueOf(com.yuedu.bridge.YueNative.lastOrientation); } catch (Throwable ignored) {}
                        String l = lo == null ? "" : lo.toLowerCase();
                        int o;
                        if (l.contains("sensorlandscape")) o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                        else if (l.contains("landscape")) o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                        else o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                        setRequestedOrientation(o);
                    } catch (Throwable ignored) {}
                } catch (Throwable t) {
                    try { callback.onCustomViewHidden(); } catch (Throwable ignored) {}
                }
            }
            @Override
            public void onHideCustomView() {
                hideCustomView();
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    suppressNextResumeGate = true;
                    startActivityForResult(i, 1001);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });

        // Single entry lock lives in the page (#bioLock -> YueNative.biometric).
        // No native gate here: gating before load caused a double fingerprint
        // (system prompt over a blank activity, then the page lock again).
        if (saved != null) {
            web.restoreState(saved);
        } else {
            web.loadUrl(appStartUrl());
        }
        watchVolumeKeys();
    }

    /**
     * The layout is fixed at 510 CSS px on every smallest-width (dp) setting:
     * the wide-viewport flags in onCreate honor the page's width=510 viewport
     * and overview mode scales that fixed layout to fit the screen. Two things
     * used to defeat it — maximum-scale=1 in the viewport clamped the
     * fit-to-screen scale to 1x on screens wider than 510dp, and any bundled
     * page that ever ships without the width rule lays out at the window width
     * instead. The first is fixed in the page; this repairs the second at
     * runtime by creating or correcting the viewport meta after every load, so
     * the fixed layout holds no matter what page text ends up in the bundle.
     */
    private void enforceFixedViewport(WebView v) {
        if (v == null) return;
        try {
            v.evaluateJavascript(
                    "(function(){try{var m=document.querySelector('meta[name=viewport]');"
                            + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');"
                            + "(document.head||document.documentElement).appendChild(m);}"
                            + "var c=m.getAttribute('content')||'';"
                            + "if(!/(^|,)\\s*width\\s*=\\s*510(\\s|,|$)/.test(c)){"
                            + "m.setAttribute('content','width=510, user-scalable=no, viewport-fit=cover');}"
                            + "return window.innerWidth+'x'+window.innerHeight;}catch(e){return 'err';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) { /* layout readout; nothing to do */ }
                    });
        } catch (Throwable ignored) {}
    }

    /**
     * System-bar insets for the page (see the --yue-inset-top/bottom rules).
     * The reader footer, header, bottom nav and select bar pad themselves with
     * the CSS safe-area env(), but a file:// WebView reports that as 0 even
     * when the window draws edge-to-edge behind the status/nav bars — so in
     * the app the footer either hid behind the system bars or floated above
     * them with a visible gap, while the desktop preview sat flush. The
     * window insets are the truth here: they are pushed into the page as CSS
     * variables whenever they change and re-pushed after every load (a fresh
     * page starts with none). Device pixels become page CSS px through the
     * fixed 510-wide layout scale (see enforceFixedViewport).
     */
    private int litInsetTopCss = 0, litInsetBottomCss = 0;

    private void setupInsetBridge() {
        if (web == null) return;
        try {
            web.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try { pushInsetsToPage(insets); } catch (Throwable ignored) {}
                    return v.onApplyWindowInsets(insets);
                }
            });
            web.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void pushInsetsToPage(android.view.WindowInsets insets) {
        try {
            android.view.WindowInsets root = null;
            try { root = getWindow().getDecorView().getRootWindowInsets(); } catch (Throwable ignored) {}
            if (root == null) root = insets;
            if (root == null) return;
            int topPx, bottomPx;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets stb = root.getInsets(android.view.WindowInsets.Type.statusBars());
                android.graphics.Insets nvb = root.getInsets(android.view.WindowInsets.Type.navigationBars());
                android.graphics.Insets tap = root.getInsets(android.view.WindowInsets.Type.tappableElement());
                topPx = Math.max(stb.top, tap.top);
                /* Gesture navigation reports no nav bar, only the handle area
                   (tappable element) — the max covers both worlds. */
                bottomPx = Math.max(nvb.bottom, tap.bottom);
            } else {
                topPx = root.getStableInsetTop();
                bottomPx = root.getStableInsetBottom();
            }
            pushInsetsPxToPage(topPx, bottomPx);
        } catch (Throwable ignored) {}
    }

    private void pushInsetsPxToPage(int topPx, int bottomPx) {
        if (web == null) return;
        int viewW = 0;
        try { viewW = web.getWidth(); } catch (Throwable ignored) {}
        if (viewW <= 0) {
            try { viewW = getResources().getDisplayMetrics().widthPixels; } catch (Throwable ignored) {}
        }
        if (viewW <= 0) return;
        double k = 510.0 / (double) viewW;
        litInsetTopCss = (int) Math.round(topPx * k);
        litInsetBottomCss = (int) Math.round(bottomPx * k);
        pushStoredInsets();
    }

    private void pushStoredInsets() {
        if (web == null) return;
        final int t = litInsetTopCss, b = litInsetBottomCss;
        final String js = "(function(){try{document.documentElement.style.setProperty('--yue-inset-top','"
                + t + "px');document.documentElement.style.setProperty('--yue-inset-bottom','"
                + b + "px');return 1;}catch(e){return 0;}})();";
        try { web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void applyEdgeToEdge() {        try {
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams a = w.getAttributes();
                a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(a);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars()
                                    | android.view.WindowInsets.Type.navigationBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyDark(WebSettings s) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(true);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) {}
    }

    private boolean metaBool(String name, boolean def) {
        try {
            android.os.Bundle m = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA).metaData;
            if (m != null && m.containsKey(name)) {
                Object v = m.get(name);
                if (v instanceof Boolean) return (Boolean) v;
                if (v instanceof String) return Boolean.parseBoolean((String) v);
                if (v instanceof Integer) return (Integer) v != 0;
            }
        } catch (Throwable ignored) {}
        return def;
    }

    /**
     * The page to open. Normally the bundled address, but a converter that
     * repackages this APK as a generic template (e.g. ToApp) can set a
     * per-build address without touching Java: patching one manifest entry is
     * all it takes, which is exactly what in-browser APK patchers can do.
     *
     * <meta-data android:name="com.yuedu.app.URL"
     *            android:value="https://example.com/app" />
     */
    private String appStartUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                String u = ai.metaData.getString("com.yuedu.app.URL");
                if (u != null && (u.startsWith("https://") || u.startsWith("http://")
                        || u.startsWith("file:///"))) return u;
            }
        } catch (Throwable ignored) {}
        return "file:///android_asset/www/index.html";
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            if (immersive) applyImmersive();
            /* Focus regained without ever pausing (notification shade peek,
               cancelled gesture): the cover raised on focus loss has nothing
               else to lower it — no onResume follows — so drop it here and
               re-check the session, or the app sits gray and untouchable
               until a full exit, lock and unlock. Real returns
               (wentBackground) never clear here: onResume owns their re-lock
               and the flag stays up until the bridge reports a fresh unlock;
               clearing early is what used to unblank the app while the lock
               card was still on its way in. */
            if (!wentBackground) { try {
                if (web != null && pageLoaded) web.evaluateJavascript(
                        "(function(){try{return sessionStorage.getItem(\"yuedu_bio_ok\")===\"1\"?\"1\":\"0\";}catch(e){return \"0\";}})();",
                        new ValueCallback<String>() {
                            @Override public void onReceiveValue(String v) {
                                try {
                                    /* The evaluate above is async: a backgrounding
                                       that lands between it and this callback must
                                       keep the blank, so never clear once away. */
                                    if (wentBackground) return;
                                    try { hideLockShield(); } catch (Throwable ignored) {}
                                    if (v != null && v.contains("1")) getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
                                } catch (Throwable ignored) {}
                            }
                        });
            } catch (Throwable ignored) {} }
        } else {
            /* Recents/split-screen/floating-window all drop focus BEFORE
               onPause runs (some paths never pause at all), and the system
               can snapshot the task in between — blank immediately so the
               card is gray no matter which exit path was used. Do NOT mark
               wentBackground here: transient focus loss (notification shade,
               cancelled gestures) fires no onPause/onResume pair, and a mark
               set here would never clear — the cover would sit forever until
               a full exit, lock and unlock. onPause/onStop own that mark. */
            try { if (com.yuedu.bridge.YueNative.secGrayOn(this)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            try { if (com.yuedu.bridge.YueNative.secGrayOn(this)) showShield(); } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (immersive) applyImmersive();
        try { if (web != null) web.onResume(); } catch (Throwable ignored) {}
        /* Re-arm the blank before deciding anything: returns that skip the
           gate below (not-backgrounded, page still loading) must never
           leave an unlocked window unblanked behind them. The suppress and
           biometric-success paths clear it explicitly. */
        try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
        /* Opaque cover, first: the page re-lock below is async, and this is
           what grays the return (and any screenshot of it) until the lock
           card has painted. Always lifted on a timer below — never on
           page JS — so a frozen page can't strand it. */
        try { showShield(); } catch (Throwable ignored) {}
        /* In-app detours (bot-check screen, system file picker) pause us on
           purpose — their return skips the gate and just drops the cover. */
        if (suppressNextResumeGate) {
            suppressNextResumeGate = false;
            wentBackground = false;
            try { getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            try { hideLockShield(); } catch (Throwable ignored) {}
            return;
        }
        /* Security fully off: nothing to re-lock or blank — drop any stray
           cover and flag and go straight back in. */
        final boolean grayOn = com.yuedu.bridge.YueNative.secGrayOn(this);
        final boolean lockOn = com.yuedu.bridge.YueNative.secLockOn(this);
        if (!grayOn && !lockOn) {
            wentBackground = false;
            try { getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            try { hideLockShield(); } catch (Throwable ignored) {}
            return;
        }
        /* Re-entry lock: cold start AND every return belong to the page card
           — never fire the system prompt from here. Just re-show the Unlock
           UI (it clears its own session flag); the prompt only ever fires
           from the Unlock button. Skipped on first foreground and while the
           page is still loading. FLAG_SECURE stays up until the bridge
           reports a successful unlock, so the content stays hidden meanwhile. */
        if (!wentBackground || !pageLoaded) { try { hideLockShield(); } catch (Throwable ignored) {} return; }
        if (web == null) { wentBackground = false; try { hideLockShield(); } catch (Throwable ignored) {} return; }
        wentBackground = false;
        try { if (lockOn && web != null) web.evaluateJavascript("(function(){try{if(window.__yueRelock)window.__yueRelock();}catch(e){}})();", null); } catch (Throwable ignored) {}
        /* Lift the cover on a timer so the freshly painted lock card shows;
           then verify the re-lock actually landed — a dropped evaluate used
           to leave the app returned-but-unlocked with no prompt. */
        resumeGen++;
        final int gen = resumeGen;
        try { new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { try { if (gen != resumeGen || wentBackground) return; hideLockShield(); } catch (Throwable ignored) {} }
        }, 450); } catch (Throwable ignored) {}
        if (lockOn) scheduleRelockVerify(gen, 0);
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        /* The bridge's folder picker (pickFolder): its answer goes back to
           the page over __yueNative, same channel as every other call. */
        try {
            if (com.yuedu.bridge.YueNative.handleActivityResult(code, result, data)) return;
        } catch (Throwable ignored) {}
        if (code == 1001 && fileChooser != null) {
            ValueCallback<Uri[]> cb = fileChooser;
            fileChooser = null;
            try {
                cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            } catch (Throwable t) {
                try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
            }
        }
    }

    /* Re-entry state: onPause marks every exit (home, task switch, screen
       off) and blanks the recents card via FLAG_SECURE; onResume re-shows
       the page's Unlock card. FLAG_SECURE stays up until the bridge reports
       a successful unlock, so screenshots still work while unlocked but the
       locked content never leaks. */
    private boolean wentBackground = false;
    private boolean pageLoaded = false;
    /** Set before opening our own sub-screens/pickers so their return skips the re-entry gate. */
    public static boolean suppressNextResumeGate = false;
    /* Opaque re-entry cover (plain black): shown the moment we background so
       the task snapshot, screenshots and the first resumed frame are gray no
       matter which exit path was used. Always hidden again on resume paths
       and bridge answers — never held on page JS. */
    private android.view.View lockShield = null;
    private int resumeGen = 0;

    /** Applied when the page toggles a security pref: gray on blanks
        immediately; gray off unblanks only when no lock can be showing
        (the lock flow owns the flag while its card is up). */
    public void onSecPrefChanged() {
        try {
            final boolean grayOn = com.yuedu.bridge.YueNative.secGrayOn(this);
            final boolean lockOn = com.yuedu.bridge.YueNative.secLockOn(this);
            if (grayOn) {
                try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            } else if (!lockOn) {
                try { getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
                try { hideLockShield(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    /** Show the re-entry cover immediately. Safe to call twice. */
    private void showShield() {
        try {
            if (web == null) return;
            if (lockShield != null && lockShield.getParent() != null) return;
            android.view.View s = new android.view.View(this);
            s.setBackgroundColor(0xFF0B0B10);
            s.setClickable(true);
            s.setFocusable(true);
            android.widget.FrameLayout decor =
                    (android.widget.FrameLayout) getWindow().getDecorView();
            decor.addView(s, new android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
            lockShield = s;
        } catch (Throwable ignored) {}
    }

    /** Hide the re-entry cover. Called from resume paths, timers and the
        bridge's auth answers — never waits on the page. */
    public void hideLockShield() {
        try {
            if (lockShield != null) {
                try { ((android.view.ViewGroup) lockShield.getParent()).removeView(lockShield); } catch (Throwable ignored) {}
                lockShield = null;
            }
        } catch (Throwable ignored) {}
    }

    /* Re-lock verifier: after a real return, the page session flag must read
       unlocked-"0" (relock ran). If it still reads "1" the re-lock evaluate
       was dropped, so fire it again and re-check, up to three rounds. Each
       round is generation-guarded, so a newer backgrounding cancels the old. */
    private void scheduleRelockVerify(final int gen, final int tries) {
        if (tries >= 3) return;
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        if (gen != resumeGen || web == null || !pageLoaded) return;
                        web.evaluateJavascript("(function(){try{return sessionStorage.getItem(\"yuedu_bio_ok\")===\"1\"?\"1\":\"0\";}catch(e){return \"0\";}})();",
                                new android.webkit.ValueCallback<String>() {
                                    @Override public void onReceiveValue(String v) {
                                        try {
                                            if (gen != resumeGen) return;
                                            if (v != null && v.contains("1")) {
                                                try { web.evaluateJavascript("(function(){try{if(window.__yueRelock)window.__yueRelock();}catch(e){}})();", null); } catch (Throwable ignored) {}
                                                scheduleRelockVerify(gen, tries + 1);
                                            }
                                        } catch (Throwable ignored) {}
                                    }
                                });
                    } catch (Throwable ignored) {}
                }
            }, tries == 0 ? 700 : 1400);
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumeGen++;
        /* Security below only runs when the user opted in (first-run choice
           / Security screen): with both off, backgrounding is a plain media
           freeze with no blank, no flag and no re-lock. */
        final boolean sec = com.yuedu.bridge.YueNative.secGrayOn(this) || com.yuedu.bridge.YueNative.secLockOn(this);
        /* Cover first, then re-lock: the cover is instant (the evaluate below
           is async), so the snapshot is gray even on paths that freeze the
           WebView before it runs. */
        try { if (sec) showShield(); } catch (Throwable ignored) {}
        /* Re-lock the page card BEFORE the freeze below: an evaluate queued
           after web.onPause() can be dropped by an already-frozen WebView,
           which is what left the gray lock / missing lock screen on some
           exits — the resume-time call alone never runs on those paths. */
        try { if (sec && web != null) web.evaluateJavascript("(function(){try{if(window.__yueRelock)window.__yueRelock();}catch(e){}})();", null); } catch (Throwable ignored) {}
        /* NOTE: no cancelBiometric() here — the biometric sheet itself
           pauses the activity on many devices, and cancelling on every pause
           murders the prompt the user just opened (Unlock taps that never
           show a prompt, and successes the frozen page never hears about).
           True backgrounding is covered by onStop below. */
        /* Fullscreen video renders in a native view above the WebView, so the
           page lock could never cover it — drop out of fullscreen first. Then
           freeze the page (this also pauses media) and blank the recents card. */
        try { hideCustomView(); } catch (Throwable ignored) {}
        /* The lock screen is portrait: drop to portrait here so the re-entry
           Unlock card is upright even when an episode had pinned landscape
           (the async restore above can be dropped by an old WebView once the
           page freezes, which used to strand the lock in landscape).
           Skipped for in-app detours, which never show the lock. A
           successful Unlock re-pins an open episode through
           reapplyOrientationAfterUnlock. */
        try { if (!suppressNextResumeGate && com.yuedu.bridge.YueNative.secLockOn(this)) setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignored) {}
        try { if (web != null) web.onPause(); } catch (Throwable ignored) {}
        if (sec) {
            wentBackground = true;
            try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
        }
    }

    /* Backup for exit paths that never pause: if stop arrives without a
       pause having marked us away, blank and mark all the same. */
    @Override
    protected void onStop() {
        /* A prompt left open across a real backgrounding cancels itself on
           some devices and poisons the next tap, so never let one outlive
           the app. (Not in onPause: the sheet itself pauses us.) */
        try { com.yuedu.bridge.YueNative.cancelBiometric(); } catch (Throwable ignored) {}
        resumeGen++;
        final boolean secStop = com.yuedu.bridge.YueNative.secGrayOn(this) || com.yuedu.bridge.YueNative.secLockOn(this);
        if (secStop) {
            try { showShield(); } catch (Throwable ignored) {}
            try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            wentBackground = true;
        }
        super.onStop();
    }

    /* Floating / split-screen windows can expose the task without pausing
       us (Game Space mini windows keep the task visible while another app is
       in front), so blank explicitly on those transitions too. Only when the
       user opted into the gray: the pause/stop paths above own the rest. */
    @Override
    public void onMultiWindowModeChanged(boolean isInMultiWindowMode) {
        super.onMultiWindowModeChanged(isInMultiWindowMode);
        try {
            if (isInMultiWindowMode && com.yuedu.bridge.YueNative.secGrayOn(this)) {
                try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
                try { showShield(); } catch (Throwable ignored) {}
                wentBackground = true;
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode);
        try {
            if (isInPictureInPictureMode && com.yuedu.bridge.YueNative.secGrayOn(this)) {
                try { getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
                try { showShield(); } catch (Throwable ignored) {}
                wentBackground = true;
            }
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        /* Fullscreen video first: back leaves fullscreen, it never quits. */
        if (customView != null) {
            hideCustomView();
            return;
        }
        /* Step-by-step back (2.10.2): the page walks its own layers first
           (dialogs, reader, book screen, source feed — see
           window.__yueBackPressed), which used to be skipped entirely: with a
           single-page app the WebView has no history to go back to, so every
           press fell through to super and quit the whole app. Only when the
           page reports its root does the press arm a real exit, and a second
           press within two seconds takes it. */
        try {
            web.evaluateJavascript(
                    "(function(){try{return (typeof window.__yueBackPressed==='function')"
                            + "?String(window.__yueBackPressed()):'';}catch(e){return '';}})();",
                    new ValueCallback<String>() {
                        @Override public void onReceiveValue(String value) {
                            String v = value;
                            if (v != null && v.length() >= 2 && v.charAt(0) == '"'
                                    && v.charAt(v.length() - 1) == '"') {
                                v = v.substring(1, v.length() - 1);
                            }
                            if ("1".equals(v)) {
                                lastBackPress = 0;
                                return;
                            }
                            if (web != null && web.canGoBack()) {
                                web.goBack();
                                return;
                            }
                            long now = System.currentTimeMillis();
                            if (now - lastBackPress < 2000) {
                                if (backToast != null) backToast.cancel();
                                MainActivity.super.onBackPressed();
                            } else {
                                lastBackPress = now;
                                if (backToast != null) backToast.cancel();
                                backToast = Toast.makeText(MainActivity.this,
                                        "Press back again to exit", Toast.LENGTH_SHORT);
                                backToast.show();
                            }
                        }
                    });
        } catch (Throwable ignored) {
            super.onBackPressed();
        }
    }

    /* Volume-key HUD: hardware presses change the music stream outside the
       page, so mirror them into the in-player volume bar while an episode
       is open (other screens keep the system panel). */
    private android.database.ContentObserver volObs = null;
    private int lastVol = -1;

    private void watchVolumeKeys() {
        try {
            if (volObs != null) return;
            volObs = new android.database.ContentObserver(new android.os.Handler(android.os.Looper.getMainLooper())) {
                @Override public void onChange(boolean selfChange) {
                    try {
                        android.media.AudioManager am = (android.media.AudioManager) getSystemService(android.content.Context.AUDIO_SERVICE);
                        if (am == null) return;
                        final int v = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);
                        final int m = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
                        if (v == lastVol) return;
                        lastVol = v;
                        if (web == null) return;
                        web.evaluateJavascript("(function(){try{if(document.querySelector('.anWrap.watching'))window.__yueVolHud&&window.__yueVolHud(" + v + "," + m + ")}catch(e){}})();", null);
                    } catch (Throwable ignored) {}
                }
            };
            getContentResolver().registerContentObserver(android.provider.Settings.System.CONTENT_URI, true, volObs);
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onDestroy() {
        try { if (volObs != null) getContentResolver().unregisterContentObserver(volObs); } catch (Throwable ignored) {}
        volObs = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }

    /**
     * Leave fullscreen video: the view goes away, the page comes back, and
     * the activity drops straight to portrait — no async page round-trip
     * (the frozen page can drop the old orientation question on old
     * WebViews, which stranded the player in landscape). An open episode
     * re-pins itself on Unlock through reapplyOrientationAfterUnlock.
     */
    public void hideCustomView() {
        try {
            if (customView != null) {
                try {
                    android.widget.FrameLayout decor =
                            (android.widget.FrameLayout) getWindow().getDecorView();
                    decor.removeView(customView);
                } catch (Throwable ignored) {}
                customView = null;
            }
            if (web != null) web.setVisibility(View.VISIBLE);
            try { if (customCb != null) customCb.onCustomViewHidden(); } catch (Throwable ignored) {}
            customCb = null;
            try { setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
    }

    /**
     * After a successful Unlock, always settle back to portrait — even when an
     * episode is still open (the backgrounding already exited fullscreen and
     * pinned portrait, so re-pinning landscape here stranded the app sideways
     * on the inline player). Sideways viewing is one fullscreen tap away.
     */
    public void reapplyOrientationAfterUnlock() {
        try {
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } catch (Throwable ignored) {}
    }

    /**
     * The Referer a guarded video file demands, or null to load normally.
     * Only those hosts are intercepted; everything else (covers, pages)
     * loads exactly as before. Anikage's proxy host (og.bakayaro.live) answers
     * "forbidden origin" without the site as Referer, and Eporner's file hosts
     * answer file requests without it with the site's only-here splash clip — Pornhub's file hosts (pornhub.com/phncdn.com, incl. its get_media redirect links) ride the same intercept —
     * progressive files ride this intercept, while HLS playlists/segments/keys
     * ride hls.js with the page's own bridge loader (the platform player sends
     * no Referer at all).
     */
    private String refererForMedia(String url) {
        if (url == null) return null;
        String u = url.toLowerCase();
        if (u.startsWith("https://www.animegg.org/play/") && u.contains(".mp4")) return "https://www.animegg.org/";
        if (u.contains("://vidcache.") && u.contains(".mp4")) return "https://www.animegg.org/";
        if (u.contains("://og.bakayaro.live/")) return "https://anikage.cc/";
        if (u.contains("eporner.com") && (u.contains(".mp4") || u.contains("/hls/") || u.contains(".m3u8") || u.contains(".m4s") || u.contains(".ts?") || u.contains(".ts&") || u.endsWith(".ts"))) return "https://www.eporner.com/";
        if ((u.contains("pornhub.com") || u.contains("phncdn.com")) && (u.contains(".mp4") || u.contains("/hls/") || u.contains(".m3u8") || u.contains(".m4s") || u.contains("/get_media"))) return "https://www.pornhub.com/";
        return null;
    }

    /**
     * Fetch a media URL natively (phone IP, app UA + WebView cookies, the given
     * Referer) and stream it back to the WebView — full or ranged (206), so
     * seeking keeps working. Runs on the WebView's background thread, so plain
     * blocking IO is correct here. Null on any failure: the WebView then loads
     * the URL itself and the page's own error path answers.
     */
    private WebResourceResponse fetchMediaWithReferer(String url, java.util.Map<String, String> reqHeaders, String referer) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", appUA != null ? appUA : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
            c.setRequestProperty("Referer", referer);
            c.setRequestProperty("Accept", "*/*");
            try {
                String cookie = YueNative.cookieHeaderFor(url);
                if (cookie != null && cookie.length() > 0) c.setRequestProperty("Cookie", cookie);
            } catch (Throwable ignored) {}
            String range = null;
            if (reqHeaders != null) {
                for (java.util.Map.Entry<String, String> e : reqHeaders.entrySet()) {
                    if (e.getKey() != null && e.getKey().equalsIgnoreCase("Range")) { range = e.getValue(); break; }
                }
            }
            if (range != null && range.length() > 0) c.setRequestProperty("Range", range);
            int status = c.getResponseCode();
            try { YueNative.storeCookiesFrom(url, c); } catch (Throwable ignored) {}
            java.io.InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null || status >= 400) { try { c.disconnect(); } catch (Throwable ignored) {} return null; }
            String ct = c.getContentType();
            String mime = "video/mp4";
            if (ct != null) {
                int sc = ct.indexOf(';');
                mime = (sc > 0 ? ct.substring(0, sc) : ct).trim().toLowerCase();
                if (mime.length() == 0) mime = "video/mp4";
            }
            java.util.Map<String, String> respHeaders = new java.util.HashMap<String, String>();
            String[] copy = { "Content-Length", "Content-Range", "Accept-Ranges", "Content-Type" };
            for (String k : copy) {
                try {
                    String hv = c.getHeaderField(k);
                    if (hv != null) respHeaders.put(k, hv);
                } catch (Throwable ignored) {}
            }
            return new WebResourceResponse(mime, null, status, status == 206 ? "Partial Content" : "OK", respHeaders, in);
        } catch (Throwable t) {
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) {} }
            return null;
        }
    }
}
