# LitReader Android app

A complete wrapper project: the LitReader generator page in a WebView, plus
the `LitNative` bridge (`src/android-plugin/LitNative.java`, copied here —
if you change one, copy it to the other). The bridge is raw device HTTP and
can state any header, notably the `Referer` that guarded comic picture hosts
(Toonily, ZinManga, ManhwaTop, MangaPill) demand. That is the same trick the
Kotatsu Android app uses, and it is why chapters that stay blank in a browser
build read here with zero configuration. It also gives read-aloud the
device's own voices and opens bot checks in a real page when a site demands
it. No dependencies beyond the Android SDK; `minSdk 26`.

## Build it in the cloud (recommended — nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload **the contents of this folder** (`settings.gradle`, `build.gradle`,
   `app/`, …) to the repository's root, so `settings.gradle` sits at `/`.
3. Move `github-workflows/build-apk.yml` to `.github/workflows/build-apk.yml`
   (GitHub only runs workflows from `.github/workflows/`), and rename
   `gitignore.txt` to `.gitignore`.
4. Open the repository's **Actions** tab → **Build LitReader APK** → the run
   starts by itself (or Run workflow). Wait ~5–10 minutes.
5. Download the `litreader-apk` artifact, copy it to the phone, tap it to
   install (allow “install unknown apps” once). It is debug-signed, which
   installs fine; updates install over it as long as the package name stays
   `com.litreader.app`.

## Build it locally

Android Studio → Open → this folder → let it sync (it will offer to set up
the Gradle wrapper if you have none) → Run. Same APK as above.

## Point it at your own fork

The app opens its bundled copy of LitReader (`app/src/main/assets/www/`,
mirrored from `src/standalone/index.html` — re-copy that file and rebuild
whenever the generator changes). To wrap a different address instead, add
one manifest entry and it wins over the bundle:
`<meta-data android:name="com.litreader.app.URL"
android:value="https://perchance.org/yourfork" />`. A forked generator
keeps working when the original changes, so prefer your own URL.

## Use it as a converter template (e.g. ToApp)

An in-browser APK patcher cannot inject Java code into a prebuilt template —
a JS bridge has to be *compiled in*. This project already is, so it works as
a drop-in template that upgrades every app it stamps out:

1. Build this project once (cloud workflow above) and use the resulting APK
   as the converter's new `template.apk`.
2. Per conversion, the converter only patches what it already patches: the
   package name, the icon, the label — plus one manifest entry for the
   wrapped address:
   `<meta-data android:name="com.litreader.app.URL" android:value="https://…"/>`
   (`MainActivity` reads that first and falls back to `app_url`). Keep the
   existing `LitNative$Challenge` activity entry; the manifest patcher must
   not strip activities.
3. Every produced app then carries the bridge: guarded comic pictures load
   (any page that asks, like LitReader), device voices work for read-aloud,
   and bot checks can open in a real page. Pages that never call it notice
   nothing — the interfaces sit inert.

## Release signing (optional)

Debug builds install and update fine. For a Play-style signed release:
`keytool -genkeypair -keystore litreader.jks -alias litreader -keyalg RSA
-keysize 2048 -validity 10000`, then add the keystore as a GitHub Actions
secret plus `SIGNING_*` variables and a `signingConfigs` block — any standard
“Android sign APK in GitHub Actions” guide applies unchanged.

## Checking the bridge works

In LitReader: **More → Connection test → Run test**. With the bridge in
place the rows say `Native bridge: found` and `The app (native): works`.
Then open any Toonily chapter — its pages load with no further setup.

## Notes

- The app opens its bundled LitReader page, so first launch needs no connection
  (reading sites, AI features and the gallery still do); LitReader's own
  offline chapter cache works as usual.
- `LitNative.java` also registers `LitTts` (device speech) and a `challenge`
  screen for bot checks; both are automatic, see
  `src/android-plugin/README.md`.
