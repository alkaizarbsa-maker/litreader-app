# LitReader Android app

A complete wrapper project: the LitReader generator page in a WebView, plus
the `LitNative` bridge (`src/android-plugin/LitNative.java`, copied here —
if you change one, copy it to the other). The bridge is raw device HTTP and
can state any header, notably the `Referer` that guarded comic picture hosts
(Toonily, ZinManga, ManhwaTop, MangaPill) demand. That is the same trick the
Kotatsu Android app uses, and it is why chapters that stay blank in a browser
build read here with zero configuration. It also gives read-aloud the
device's own voices and opens bot checks in a real page when a site demands
it. No dependencies beyond the Android SDK; `minSdk 26`.

## Build it in the cloud (recommended — nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload **the contents of this folder** (`settings.gradle`, `build.gradle`,
   `app/`, …) to the repository's root, so `settings.gradle` sits at `/`.
3. Move `github-workflows/build-apk.yml` to `.github/workflows/build-apk.yml`
   (GitHub only runs workflows from `.github/workflows/`), and rename
   `gitignore.txt` to `.gitignore`.
4. Open the repository's **Actions** tab → **Build LitReader APK** → the run
   starts by itself (or Run workflow). Wait ~5–10 minutes.
5. Download the `litreader-apk` artifact, copy it to the phone, tap it to
   install (allow “install unknown apps” once). It is debug-signed, which
   installs fine; updates install over it as long as the package name stays
   `com.litreader.app`.

## Build it locally

Android Studio → Open → this folder → let it sync (it will offer to set up
the Gradle wrapper if you have none) → Run. Same APK as above.

## Point it at your own fork

`app/src/main/res/values/strings.xml` → `app_url`. Default is
`https://perchance.org/lrreader`; a forked generator keeps working when the
original changes, so prefer your own URL.

## Release signing (optional)

Debug builds install and update fine. For a Play-style signed release:
`keytool -genkeypair -keystore litreader.jks -alias litreader -keyalg RSA
-keysize 2048 -validity 10000`, then add the keystore as a GitHub Actions
secret plus `SIGNING_*` variables and a `signingConfigs` block — any standard
“Android sign APK in GitHub Actions” guide applies unchanged.

## Checking the bridge works

In LitReader: **More → Connection test → Run test**. With the bridge in
place the rows say `Native bridge: found` and `The app (native): works`.
Then open any Toonily chapter — its pages load with no further setup.

## Notes

- The app needs a connection on first launch (it opens the live generator
  page); LitReader's own offline chapter cache works from there as usual.
- `LitNative.java` also registers `LitTts` (device speech) and a `challenge`
  screen for bot checks; both are automatic, see
  `src/android-plugin/README.md`.
