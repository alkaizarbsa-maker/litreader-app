# LitReader Android app

A complete wrapper project: the LitReader generator page in a WebView, plus
the `LitNative` bridge (`src/android-plugin/LitNative.java`, copied here —
if you change one, copy it to the other). The bridge is raw device HTTP and
can state any header, notably the `Referer` that guarded comic picture hosts
(Toonily, ZinManga, ManhwaTop, MangaPill, LikeManga) demand. That is the same trick the
Kotatsu Android app uses, and it is why chapters that stay blank in a browser
build read here with zero configuration. It also gives read-aloud the
device's own voices and opens bot checks in a real page when a site demands
it. One small AndroidX dependency (swipe-to-refresh); `minSdk 26`.

## Build it in the cloud (recommended — nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload **the contents of this folder** (`settings.gradle`, `build.gradle`,
   `app/`, …) to the repository's root, so `settings.gradle` sits at `/`.
3. Move `github-workflows/build-apk.yml` to `.github/workflows/build-apk.yml`
   (GitHub only runs workflows from `.github/workflows/`), and rename
   `gitignore.txt` to `.gitignore`.
4. Open the repository's **Actions** tab → **Build LitReader APK** → the run
   starts by itself (or Run workflow). Wait ~5–10 minutes.
5. Download the `litreader-apk` artifact, copy it to the phone, tap it to
   install (allow “install unknown apps” once). All builds share one signing
   key (`litreader-debug.p12`, committed in the repo — do not delete it), so
   every new APK installs over the old one as an update: no uninstall, and
   your library, history and settings carry over.

## Updating (new LitReader version, same install)

Never delete the repository — GitHub overwrites files happily, and a fresh
repo is exactly what breaks updates (new repo, new build numbers).

1. In your repo, open `app/src/main/assets/www/index.html`, delete its
   contents, paste in the new standalone file (or use Add file → Upload
   files and overwrite it), and commit. The workflow rebuilds by itself.
2. Download the new `litreader-apk` artifact and tap it on the phone. It
   installs as an update over the existing LitReader — same app, same data.

One reset is still owed if the app on your phone came from anywhere else
(a converter build or an older repo build): those carry a different
signature, so Android refuses with “conflicting package”. Export first
(LitReader → More → Export), uninstall once, install the repo build,
re-import. From that build on, step 2 above just works, forever.

## Build it locally

Android Studio → Open → this folder → let it sync (it will offer to set up
the Gradle wrapper if you have none) → Run. Same APK as above.

## Point it at your own fork

The app opens its bundled copy of LitReader (`app/src/main/assets/www/`,
mirrored from `src/standalone/index.html` — re-copy that file and rebuild
whenever the generator changes). To wrap a different address instead, add
one manifest entry and it wins over the bundle:
`<meta-data android:name="com.litreader.app.URL"
android:value="https://perchance.org/yourfork" />`. A forked generator
keeps working when the original changes, so prefer your own URL.

## Use it as a converter template (e.g. ToApp)

An in-browser APK patcher cannot inject Java code into a prebuilt template —
a JS bridge has to be *compiled in*. This project already is, so it works as
a drop-in template that upgrades every app it stamps out:

1. Build this project once (cloud workflow above) and use the resulting APK
   as the converter's new `template.apk`.
2. Per conversion, the converter only patches what it already patches: the
   package name, the icon, the label — plus `<meta-data>` entries, which is
   exactly what in-browser APK patchers can do. The flags, all optional,
   all default `false` unless set:
   `<meta-data android:name="com.litreader.app.URL" android:value="https://…"/>`
   (the wrapped address; falls back to the bundled LitReader page),
   `com.litreader.app.IMMERSIVE` (sticky fullscreen, hides status+nav),
   `com.litreader.app.DARK_MODE` (force-darkens light web content),
   `com.litreader.app.EDGE_TO_EDGE` (draws behind transparent system bars),
   `com.litreader.app.PULL_REFRESH` (swipe-down reloads the page),
   `com.litreader.app.DESKTOP_SITE` (desktop user-agent). Values accept
   `true`/`false` or `1`/`0`. Keep the existing `LitNative$Challenge`
   activity entry; the manifest patcher must not strip activities.
3. Every produced app then carries the bridge: guarded comic pictures load
   (any page that asks, like LitReader), device voices work for read-aloud,
   and bot checks can open in a real page. Pages that never call it notice
   nothing — the interfaces sit inert.

## Release signing (optional)

Debug builds install and update fine, because every build signs with the
committed `litreader-debug.p12` and carries a higher version number than
the last. For a Play-style signed release:
`keytool -genkeypair -keystore litreader.jks -alias litreader -keyalg RSA
-keysize 2048 -validity 10000`, then add the keystore as a GitHub Actions
secret plus `SIGNING_*` variables and a `signingConfigs` block — any standard
“Android sign APK in GitHub Actions” guide applies unchanged.
(A release-signed app is a different signature from the debug builds, so
switching between them costs one uninstall.)

## Checking the bridge works

In LitReader: **More → Connection test → Run test**. With the bridge in
place the rows say `Native bridge: found` and `The app (native): works`.
Then open any Toonily chapter — its pages load with no further setup.

## Notes

- The app opens its bundled LitReader page, so first launch needs no connection
  (reading sites, AI features and the gallery still do); LitReader's own
  offline chapter cache works as usual.
- `LitNative.java` also registers `LitTts` (device speech) and a `challenge`
  screen for bot checks; both are automatic, see
  `src/android-plugin/README.md`.
