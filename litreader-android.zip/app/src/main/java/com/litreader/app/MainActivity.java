package com.litreader.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.litreader.bridge.LitNative;

/**
 * LitReader, packaged: the generator page in a WebView, plus the LitNative
 * bridge. The bridge is raw device HTTP and can state any header (notably the
 * Referer that guarded comic picture hosts demand) — that is what makes
 * Toonily, ZinManga, ManhwaTop and MangaPill chapters read here with zero
 * configuration. It also gives read-aloud the device's own voices and opens
 * bot checks in a real page when a site demands it.
 *
 * Display options are manifest flags so a converter (e.g. ToApp) can set them
 * per build without touching Java: com.litreader.app.URL,
 * com.litreader.app.IMMERSIVE, com.litreader.app.DARK_MODE,
 * com.litreader.app.EDGE_TO_EDGE, com.litreader.app.PULL_REFRESH,
 * com.litreader.app.DESKTOP_SITE. Every one defaults to off.
 */
public class MainActivity extends Activity {

    private WebView web;
    private SwipeRefreshLayout pull;
    private ValueCallback<Uri[]> fileChooser;
    private boolean immersive;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        immersive = metaBool("com.litreader.app.IMMERSIVE", false);
        boolean edge = metaBool("com.litreader.app.EDGE_TO_EDGE", false);
        boolean dark = metaBool("com.litreader.app.DARK_MODE", false);
        boolean desktop = metaBool("com.litreader.app.DESKTOP_SITE", false);
        boolean refresh = metaBool("com.litreader.app.PULL_REFRESH", false);

        if (edge) applyEdgeToEdge();

        web = new WebView(this);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        }
        if (dark) applyDark(s);

        if (refresh) {
            pull = new SwipeRefreshLayout(this);
            pull.addView(web, new SwipeRefreshLayout.LayoutParams(
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT));
            pull.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override public void onRefresh() {
                    if (web != null) web.reload();
                    else pull.setRefreshing(false);
                }
            });
            setContentView(pull);
        } else {
            setContentView(web);
        }
        if (immersive) applyImmersive();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        LitNative.attach(this, web);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (pull != null && p == 100) pull.setRefreshing(false);
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    startActivityForResult(i, 1001);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });

        if (saved != null) {
            web.restoreState(saved);
        } else {
            web.loadUrl(appStartUrl());
        }
    }

    private void applyEdgeToEdge() {
        try {
            getWindow().setStatusBarColor(0x00000000);
            getWindow().setNavigationBarColor(0x00000000);
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars()
                                    | android.view.WindowInsets.Type.navigationBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyDark(WebSettings s) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(true);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) {}
    }

    private boolean metaBool(String name, boolean def) {
        try {
            android.os.Bundle m = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA).metaData;
            if (m != null && m.containsKey(name)) {
                Object v = m.get(name);
                if (v instanceof Boolean) return (Boolean) v;
                if (v instanceof String) return Boolean.parseBoolean((String) v);
                if (v instanceof Integer) return (Integer) v != 0;
            }
        } catch (Throwable ignored) {}
        return def;
    }

    /**
     * The page to open. Normally the bundled address, but a converter that
     * repackages this APK as a generic template (e.g. ToApp) can set a
     * per-build address without touching Java: patching one manifest entry is
     * all it takes, which is exactly what in-browser APK patchers can do.
     *
     * <meta-data android:name="com.litreader.app.URL"
     *            android:value="https://example.com/app" />
     */
    private String appStartUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                String u = ai.metaData.getString("com.litreader.app.URL");
                if (u != null && (u.startsWith("https://") || u.startsWith("http://")
                        || u.startsWith("file:///"))) return u;
            }
        } catch (Throwable ignored) {}
        return "file:///android_asset/www/standalone_1_.html";
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && immersive) applyImmersive();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == 1001 && fileChooser != null) {
            ValueCallback<Uri[]> cb = fileChooser;
            fileChooser = null;
            try {
                cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            } catch (Throwable t) {
                try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
