package com.litreader.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.litreader.bridge.LitNative;

/**
 * LitReader, packaged: the generator page in a WebView, plus the LitNative
 * bridge. The bridge is raw device HTTP and can state any header (notably the
 * Referer that guarded comic picture hosts demand) — that is what makes
 * Toonily, ZinManga, ManhwaTop and MangaPill chapters read here with zero
 * configuration. It also gives read-aloud the device's own voices and opens
 * bot checks in a real page when a site demands it.
 */
public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileChooser;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        LitNative.attach(this, web);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) {
                    try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    startActivityForResult(i, 1001);
                } catch (Throwable t) {
                    fileChooser = null;
                    try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
                }
                return true;
            }
        });

        if (saved != null) {
            web.restoreState(saved);
        } else {
            web.loadUrl(appStartUrl());
        }
    }

    /**
     * The page to open. Normally the bundled address, but a converter that
     * repackages this APK as a generic template (e.g. ToApp) can set a
     * per-build address without touching Java: patching one manifest entry is
     * all it takes, which is exactly what in-browser APK patchers can do.
     *
     * <meta-data android:name="com.litreader.app.URL"
     *            android:value="https://example.com/app" />
     */
    private String appStartUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                String u = ai.metaData.getString("com.litreader.app.URL");
                if (u != null && (u.startsWith("https://") || u.startsWith("http://")
                        || u.startsWith("file:///"))) return u;
            }
        } catch (Throwable ignored) {}
        return "file:///android_asset/www/index.html";
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == 1001 && fileChooser != null) {
            ValueCallback<Uri[]> cb = fileChooser;
            fileChooser = null;
            try {
                cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            } catch (Throwable t) {
                try { cb.onReceiveValue(null); } catch (Throwable ignored) {}
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
