// NOTE: this is a copy of src/android-plugin/YueNative.java (the canonical
// bridge source). If you change one, copy it to the other.
package com.yuedu.bridge;

/*
 * YueNative — the JavaScript interface that lets the YueDu HTML make requests
 * from the DEVICE instead of through YueDu's shared servers.
 *
 * Why it exists: most sites YueDu reads are fine with a server asking, but some
 * count requests per internet address (WTR Lab: "unusual reading activity from your
 * IP", 15 requests then a Turnstile check) or bluntly refuse datacenter addresses
 * (NovelLive, LightNovelPub). The user's own phone is not over that limit and passes
 * the check invisibly, so asking from the device is the fix. That is the same trick
 * LNReader uses, and it needs the wrapper (the HTML→APK converter), not the HTML.
 *
 * Two ways to give the app that ability — see src/android-plugin/README.md:
 *   A. ONE LINE, no new files: webView.getSettings().setAllowUniversalAccessFromFileURLs(true)
 *      (plus setAllowFileAccessFromFileURLs(true) on old devices). The page can then
 *      fetch() cross-origin itself, from your connection, with the WebView's cookies.
 *   B. THIS FILE: a real bridge. Needed when you want the app to fetch natively
 *      (no CORS at all, works even if A is off), when you want to read the WebView's
 *      cookies from JS, and when you want the "pass the check in a proper WebView"
 *      flow that hands the page's text/storage/cookies back to YueDu.
 *
 * YueDu detects this automatically (window.YueNative, or any object with
 * fetch+cookies) and uses it FIRST for every request, falling back to the proxies
 * if it errors. Nothing in YueDu has to change when you add it.
 *
 * Wire-up (3 steps, ~15 lines — see the README for the exact snippet):
 *   1. YueNative.attach(this, webView)                    // registers the interface
 *   2. <activity android:name="com.yuedu.bridge.YueNative$Challenge" .../> in the manifest
 *   3. CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
 *
 * Contract used by YueDu's client code (src/../index.html, "native bridge"):
 *   fetch(reqId, url, method, headersJson, body)   -> __yueNative(reqId, {ok,status,text,url,contentType,headers[,base64]})
 *   cookies(reqId, url)                            -> __yueNative(reqId, {ok,cookies})
 *   challenge(reqId, url, title)                   -> __yueNative(reqId, {ok,url,title,cookies,text,html,localStorage,sessionStorage})
*   saveFile(reqId, name, mime, base64)             -> __yueNative(reqId, {ok,where} | {ok:false,error}) — fixed YueDu folder
 *   folderProbe(reqId)                               -> __yueNative(reqId, {ok,exists,count,where})
 openFolder(reqId)                                 -> __yueNative(reqId, {ok, where} | {ok:false, error}) — show the YueDu folder
 *   apkProgress(reqId)                               -> __yueNative(reqId, {ok,state,downloaded,total}) — in-app update progress
 *   apkInstall(reqId)                                -> __yueNative(reqId, {ok} | {ok:false,error}) — re-open the update installer — YueDu auto-detect
 *   wtrResolve(reqId, url)                       -> __yueNative(reqId, {ok,html}) — the chapter
 *      page loaded invisibly, its checks passing inside it (QuickNovel's
 *      WebViewResolver fallback for WTR Lab); no puzzle is ever shown
 *   info() -> a JSON string (synchronous; describes itself to the page)
 * Every answer is delivered by evaluating window.__yueNative(<reqId>, <json>).
 *
 * It also provides window.YueTts — the device's own speech engine, for YueDu's
 * read-aloud (see the Tts class at the bottom of this file). It is not part of the
 * fetch story: Android's WebView has no Web Speech API at all, so without this an
 * APK can only read aloud through YueDu's online voice. With it, read-aloud uses
 * the phone's own voices and needs no connection.
 */

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class YueNative {

    public static final String TAG = "YueNative";
    /** The name YueDu looks for first. Any name in its list works. */
    public static final String JS_NAME = "YueNative";
    private static final int MAX_BYTES = 24 * 1024 * 1024;

    private static WebView host;          // the app's WebView, where answers go back
    private static YueNative instance;
    private static String pendingChallengeReqId = null;

    private final Activity activity;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Handler ui = new Handler(Looper.getMainLooper());

    private YueNative(Activity activity) { this.activity = activity; }

    /**
     * Call once, right after you create the app's WebView and before its first
     * page load. Safe to call again (e.g. after a rotation).
     */
    public static void attach(Activity activity, WebView webView) {
        host = webView;
        if (instance == null) instance = new YueNative(activity);
        try {
            webView.addJavascriptInterface(instance, JS_NAME);
        } catch (Throwable t) {
            Log.w(TAG, "could not register " + JS_NAME, t);
        }
        try {
            webView.addJavascriptInterface(new Tts(webView), Tts.JS_NAME);
        } catch (Throwable t) {
            Log.w(TAG, "could not register " + Tts.JS_NAME, t);
        }
    }

    // ---------------------------------------------------------------- the interface

    /** Synchronous: YueDu reads this to show what the wrapper can do. */
    @JavascriptInterface
    public String info() {
        try {
            JSONObject o = new JSONObject();
            o.put("name", JS_NAME);
            o.put("version", 1);
            o.put("capabilities", "fetch,cookies,challenge,wtrResolve,tts,orientation,exitFullscreen,biometric,downloadApk,saveFile,folderProbe,openFolder,pickFolder,apkProgress,apkInstall");
            return o.toString();
        } catch (Throwable t) {
            return "{\"name\":\"" + JS_NAME + "\",\"version\":1}";
        }
    }

    /** Last orientation the page asked for (Nekoyomi-style rotation switch). */
    public static volatile String lastOrientation = "portrait";

    /**
     * Nekoyomi-style rotation switch: the page's player toggles the whole
     * activity between sensor-portrait and sensor-landscape, so sliders,
     * settings, the episode list and counts all turn with the video.
     * Fire-and-forget like the rest of the interface.
     */
    @JavascriptInterface
    public void setOrientation(final String mode) {
        final String m = String.valueOf(mode);
        lastOrientation = m;
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    int o;
                    if ("sensorLandscape".equals(m) || "landscape".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
                    else if ("sensorPortrait".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
                    else if ("lockLandscape".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                    else if ("free".equals(m) || "sensor".equals(m) || "unspecified".equals(m)) o = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
                    else o = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                    activity.setRequestedOrientation(o);
                } catch (Throwable ignored) {}
            }
        });
    }

    /** GET/POST anything from the device, with the WebView's cookies attached. */
    @JavascriptInterface
    public void fetch(final String reqId, final String url, final String method,
                      final String headersJson, final String body) {
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    answer(reqId, doFetch(url, method, headersJson, body));
                } catch (Throwable t) {
                    fail(reqId, t.getClass().getSimpleName() + ": " + t.getMessage());
                }
            }
        });
    }

    /** The cookies the app's WebView holds for a URL (e.g. cf_clearance). */
    @JavascriptInterface
    public void cookies(final String reqId, final String url) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    String c = CookieManager.getInstance().getCookie(url);
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    o.put("cookies", c == null ? "" : c);
                    answer(reqId, o.toString());
                } catch (Throwable t) {
                    fail(reqId, String.valueOf(t.getMessage()));
                }
            }
        });
    }

    /* ---------------- silent chapter-page resolver (WTR Lab) ----------------
       QuickNovel reads WTR Lab this way whenever its reader API stays gated
       (see WtrLabProvider.loadHtml): a hidden page loads the chapter URL, the
       site's own checks pass inside it by themselves, and the rendered chapter
       body (div.chapter-body, one div[data-line] per line) is read back out.
       No puzzle is ever shown to the reader. Answers ride the same
       window.__yueNative(reqId, json) channel as every other bridge answer:
       {ok:true, html} or {ok:false, error}. */
    @JavascriptInterface
    public void wtrResolve(final String reqId, final String url) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    startWtrResolve(reqId, url == null ? "" : url);
                } catch (Throwable t) {
                    wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
                }
            }
        });
    }

    private void startWtrResolve(final String reqId, final String url) {
        if (url.length() == 0) { wtrAnswer(reqId, false, "", "no url"); return; }
        final WebView web;
        try {
            web = new WebView(activity);
        } catch (Throwable t) { wtrAnswer(reqId, false, "", "no webview"); return; }
        try {
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
            /* Same marker-free UA as the app's own page: a clearance earned
               under one UA may not count under another. */
            String hua = host != null ? host.getSettings().getUserAgentString() : null;
            if (hua != null && hua.length() > 0) s.setUserAgentString(hua);
        } catch (Throwable ignored) {}
        try {
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        } catch (Throwable ignored) {}
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] done = new boolean[1];
        final int[] tries = new int[1];
        final Runnable[] pollRef = new Runnable[1];
        final Runnable poll = new Runnable() {
            @Override public void run() {
                if (done[0]) return;
                /* ~30s of polling, like QuickNovel's WebViewResolver fallback. */
                if (tries[0]++ >= 30) {
                    done[0] = true;
                    try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                    wtrAnswer(reqId, false, "", "the chapter page never rendered its text");
                    return;
                }
                try {
                    web.evaluateJavascript(
                        "(function(){try{var el=document.querySelector('div.chapter-body');"
                        + "var f=el?el.querySelector('div[data-line]'):null;"
                        + "var t=f?((f.innerText||f.textContent||'').trim()):'';"
                        + "return t.length>0?'1':'0';}catch(e){return '0';}})();",
                        new ValueCallback<String>() {
                            @Override public void onReceiveValue(String value) {
                                if (done[0]) return;
                                boolean found = value != null && value.length() >= 3
                                        && value.charAt(0) == '"' && value.charAt(1) == '1';
                                if (!found) { h.postDelayed(pollRef[0], 1000); return; }
                                try {
                                    web.evaluateJavascript(
                                        "(function(){try{var el=document.querySelector('div.chapter-body');"
                                        + "if(!el)return '';return el.innerHTML.slice(0,2000000);}"
                                        + "catch(e){return '';}})();",
                                        new ValueCallback<String>() {
                                            @Override public void onReceiveValue(String html) {
                                                if (done[0]) return;
                                                done[0] = true;
                                                String out = "";
                                                try {
                                                    if (html != null && html.length() > 1 && html.charAt(0) == '"') {
                                                        Object v = new org.json.JSONTokener(html).nextValue();
                                                        if (v != null && !JSONObject.NULL.equals(v)) out = String.valueOf(v);
                                                    }
                                                } catch (Throwable ignored) {}
                                                try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                                                if (out.length() == 0) wtrAnswer(reqId, false, "", "the chapter page came back empty");
                                                else wtrAnswer(reqId, true, out, null);
                                            }
                                        });
                                } catch (Throwable t) {
                                    done[0] = true;
                                    try { web.stopLoading(); web.destroy(); } catch (Throwable ignored) {}
                                    wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
                                }
                            }
                        });
                } catch (Throwable t) {
                    h.postDelayed(pollRef[0], 1000);
                }
            }
        };
        pollRef[0] = poll;
        try {
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) { /* the poll decides */ }
            });
            web.loadUrl(url);
        } catch (Throwable t) {
            done[0] = true;
            try { web.destroy(); } catch (Throwable ignored) {}
            wtrAnswer(reqId, false, "", String.valueOf(t.getMessage()));
            return;
        }
        h.postDelayed(poll, 1500);
    }

    private void wtrAnswer(String reqId, boolean ok, String html, String error) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (ok) o.put("html", html == null ? "" : html);
            else o.put("error", error == null ? "failed" : error);
            answer(reqId, o.toString());
        } catch (Throwable ignored) {}
    }

    /** Open the site in a real WebView so a challenge can be passed there. */
    @JavascriptInterface
    public void challenge(final String reqId, final String url, final String title) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    pendingChallengeReqId = reqId;
                    try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
                    Intent i = new Intent(activity, Challenge.class);
                    i.putExtra("url", url);
                    i.putExtra("title", title);
                    activity.startActivity(i);
                } catch (Throwable t) {
                    fail(reqId, "challenge: " + t.getMessage());
                }
            }
        });
    }

    /* In-app update install (the page's Get update button reaches this
       through U_(), which tries YueNative.downloadApk first): the APK rides
       DownloadManager into the app's own Downloads folder, and when the
       download completes the package installer opens on it — no browser,
       no manual file hunt. Answers nothing to the page; the installer UI
       is the feedback. A void bridge call counts as handled for U_(). */
    @JavascriptInterface
    public void downloadApk(final String url) {
        ui.post(new Runnable() {
            @Override public void run() {
                try { startApkDownload(url == null ? "" : url.trim()); } catch (Throwable ignored) {}
            }
        });
    }

    /* Fixed-folder file saving (the page's Storage folder: backups and other
       small files land in the same place). Contract:
         saveFile(reqId, name, mime, base64[, sub]) -> __yueNative(reqId, {ok, where} | {ok:false, error})
       The folder is "YueDu" unless the user picked their own (pickFolder) —
       the page never chooses names, and the user is never asked to type one.
       `sub` is an optional plain subfolder (the page sends "Backups") that is
       created inside the folder. A previous export of the same name is
       replaced instead of piling up copies.
       Default: MediaStore Downloads with RELATIVE_PATH Download/YueDu[/sub]
       (no permission needed, visible in the Files app). Older: the app's own
       external YueDu folder (no permission needed on any API level).
       Base64 keeps the binary exact; keep files small (backups, covers). */
    @JavascriptInterface
    public void saveFile(final String reqId, final String name, final String mime, final String base64) {
        saveFile(reqId, name, mime, base64, null);
    }

    @JavascriptInterface
    public void saveFile(final String reqId, final String name, final String mime, final String base64, final String sub) {
        ui.post(new Runnable() {
            @Override public void run() {
                try { startSaveFile(reqId, name, mime, sub, base64); }
                catch (Throwable t) { fail(reqId, "save: " + t.getMessage()); }
            }
        });
    }

    private void startSaveFile(String reqId, String name, String mime, String sub, String base64) {
        String clean = name == null ? "" : name.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (clean.length() == 0) { fail(reqId, "bad name"); return; }
        byte[] data;
        try { data = android.util.Base64.decode(base64 == null ? "" : base64, android.util.Base64.DEFAULT); }
        catch (Throwable t) { fail(reqId, "bad data"); return; }
        if (data.length == 0) { fail(reqId, "empty file"); return; }
        String mt = mime == null || mime.length() == 0 ? "application/octet-stream" : mime;
        String folder = "";
        try {
            String s = sub == null ? "" : sub.trim().replaceAll("[^A-Za-z0-9 _-]", "");
            if (s.length() > 32) s = s.substring(0, 32);
            folder = s.trim();
        } catch (Throwable ignored) {}
        try {
            String stored = null;
            try { stored = activity.getSharedPreferences("yuedu", 0).getString("treeUri", null); } catch (Throwable ignored) {}
            android.net.Uri tree = customTree();
            if (tree != null) {
                saveToTree(reqId, tree, folder, clean, data, mt);
                return;
            }
            if (stored != null && stored.length() > 0) {
                /* The user assigned a folder but its permission is gone:
                   say so instead of writing somewhere they didn't choose. */
                fail(reqId, "folder permission lost — tap Save folder to reconnect");
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                String relPath = android.os.Environment.DIRECTORY_DOWNLOADS + "/YueDu"
                        + (folder.length() > 0 ? "/" + folder : "");
                try {
                    /* Replace a previous export of the same name (scoped to
                       this exact folder) instead of piling up copies. */
                    android.net.Uri coll = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                    android.database.Cursor q = null;
                    try {
                        q = activity.getContentResolver().query(coll,
                                new String[]{ android.provider.MediaStore.MediaColumns._ID },
                                android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=? AND "
                                        + android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                                new String[]{ clean, relPath + "/" }, null);
                        if (q != null) {
                            while (q.moveToNext()) {
                                try {
                                    long oldId = q.getLong(0);
                                    activity.getContentResolver().delete(
                                            android.content.ContentUris.withAppendedId(coll, oldId), null, null);
                                } catch (Throwable ignored) {}
                            }
                        }
                    } finally { try { if (q != null) q.close(); } catch (Throwable ignored) {} }
                } catch (Throwable ignored) {}
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, clean);
                v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mt);
                v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, relPath);
                android.net.Uri uri = activity.getContentResolver().insert(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) { fail(reqId, "storage unavailable"); return; }
                java.io.OutputStream os = null;
                try {
                    os = activity.getContentResolver().openOutputStream(uri);
                    if (os == null) { fail(reqId, "storage unavailable"); return; }
                    os.write(data);
                    os.flush();
                } finally { try { if (os != null) os.close(); } catch (Throwable ignored) {} }
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("where", "Download/YueDu/" + (folder.length() > 0 ? folder + "/" : "") + clean);
                answer(reqId, o.toString());
            } else {
                java.io.File dir = new java.io.File(activity.getExternalFilesDir(
                        android.os.Environment.DIRECTORY_DOCUMENTS),
                        folder.length() > 0 ? "YueDu/" + folder : "YueDu");
                try { dir.mkdirs(); } catch (Throwable ignored) {}
                java.io.File out = new java.io.File(dir, clean);
                java.io.FileOutputStream fos = null;
                try {
                    fos = new java.io.FileOutputStream(out);
                    fos.write(data);
                    fos.flush();
                } finally { try { if (fos != null) fos.close(); } catch (Throwable ignored) {} }
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("where", (folder.length() > 0 ? "YueDu/" + folder + "/" : "YueDu/") + clean);
                answer(reqId, o.toString());
            }
        } catch (Throwable t) {
            fail(reqId, String.valueOf(t.getMessage()));
        }
    }

    /* Fixed-folder auto-detect (the page's Storage folder): after a reinstall
       or a data wipe the page's own choice is gone, but Download/YueDu (and
       its files) survive — so the page probes here first and silently re-uses
       the folder instead of asking again. Answers
       {ok:true, exists, count, where} over the same __yueNative channel. */
    @JavascriptInterface
    public void folderProbe(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try { startFolderProbe(reqId); }
                catch (Throwable t) { fail(reqId, "probe: " + t.getMessage()); }
            }
        });
    }

    private void startFolderProbe(String reqId) {
        boolean exists = false;
        int count = 0;
        String where = "Download/YueDu";
        try {
            String stored = null;
            try { stored = activity.getSharedPreferences("yuedu", 0).getString("treeUri", null); } catch (Throwable ignored) {}
            android.net.Uri tree = customTree();
            if (tree != null) {
                int kids = 0;
                try {
                    String treeId = android.provider.DocumentsContract.getTreeDocumentId(tree);
                    android.net.Uri kidUri = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, treeId);
                    android.database.Cursor kc = null;
                    try {
                        kc = activity.getContentResolver().query(kidUri,
                                new String[]{ android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID },
                                null, null, null);
                        if (kc != null) kids = kc.getCount();
                    } finally { try { if (kc != null) kc.close(); } catch (Throwable ignored) {} }
                } catch (Throwable ignored) {}
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("exists", true);
                o.put("count", kids);
                o.put("where", treeDisplayName(tree));
                o.put("custom", true);
                answer(reqId, o.toString());
                return;
            }
            if (stored != null && stored.length() > 0) {
                /* Assigned folder's grant is gone: forget it so the page
                   asks again instead of trusting a dead folder. */
                try { activity.getSharedPreferences("yuedu", 0).edit().remove("treeUri").apply(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                android.net.Uri coll = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                String[] proj = new String[]{ android.provider.MediaStore.MediaColumns.DISPLAY_NAME };
                android.database.Cursor c = null;
                try {
                    c = activity.getContentResolver().query(coll, proj,
                            android.provider.MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                            new String[]{ android.os.Environment.DIRECTORY_DOWNLOADS + "/YueDu%" }, null);
                    if (c != null) { count = c.getCount(); exists = count > 0; }
                } catch (Throwable ignored) { exists = false; count = 0; }
                finally { try { if (c != null) c.close(); } catch (Throwable ignored) {} }
            } else {
                java.io.File dir = new java.io.File(activity.getExternalFilesDir(
                        android.os.Environment.DIRECTORY_DOCUMENTS), "YueDu");
                try { exists = dir.exists() && dir.isDirectory(); } catch (Throwable ignored) {}
                try { String[] ls = dir.list(); if (ls != null) count = ls.length; } catch (Throwable ignored) {}
                where = "YueDu";
            }
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("exists", exists);
            o.put("count", count);
            o.put("where", where);
            o.put("custom", false);
            answer(reqId, o.toString());
        } catch (Throwable t) {
            fail(reqId, String.valueOf(t.getMessage()));
        }
    }

    /* Open the YueDu folder in the system's Files app (the page's Storage
    *  folder: after "Set up" the user can SEE where backups land).
    *  Contract:
    *    openFolder(reqId) -> __yueNative(reqId, {ok, where} | {ok:false, error})
    *  Tries the exact Download/YueDu folder first, then Download, then the
    *  system folder picker (works without any OEM Files app), then the
    *  Files app itself — some file managers ignore the folder hint and just
    *  open, which still counts as ok. */
    @JavascriptInterface
    public void openFolder(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try { startOpenFolder(reqId); }
                catch (Throwable t) { fail(reqId, "open: " + t.getMessage()); }
            }
        });
    }

    private void startOpenFolder(String reqId) {
        try {
            android.net.Uri tree = customTree();
            if (tree != null) {
                String disp = treeDisplayName(tree);
                try {
                    String treeId = android.provider.DocumentsContract.getTreeDocumentId(tree);
                    android.net.Uri doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, treeId);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(doc, android.provider.DocumentsContract.Document.MIME_TYPE_DIR);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(i);
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    o.put("where", disp);
                    answer(reqId, o.toString());
                    return;
                } catch (Throwable ignored) {}
                /* System picker rooted at their folder — always available,
                   even with no Files app to view the folder directly. */
                try {
                    Intent t = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    try { t.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, tree); } catch (Throwable ignored) {}
                    t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(t);
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    o.put("where", disp);
                    answer(reqId, o.toString());
                    return;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        String[] docIds = new String[]{
                "primary:" + android.os.Environment.DIRECTORY_DOWNLOADS + "/YueDu",
                "primary:" + android.os.Environment.DIRECTORY_DOWNLOADS,
                "primary:"};
        for (String docId : docIds) {
            try {
                android.net.Uri uri = android.provider.DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents", docId);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(uri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(i);
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("where", "Download/YueDu");
                answer(reqId, o.toString());
                return;
            } catch (Throwable ignored) {}
        }
        /* System folder picker (Storage Access Framework — part of every
           Android, needs no OEM Files app). The initial-uri hint opens it at
           Download/YueDu where honored; either way the user sees and can
           browse their files. Plain startActivity: display only. */
        try {
            Intent t = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            try {
                android.net.Uri init = android.provider.DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents",
                        "primary:" + android.os.Environment.DIRECTORY_DOWNLOADS + "/YueDu");
                t.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, init);
            } catch (Throwable ignored) {}
            t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(t);
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("where", "Download/YueDu");
            answer(reqId, o.toString());
            return;
        } catch (Throwable ignored) {}
        String[] pkgs = new String[]{"com.google.android.documentsui", "com.android.documentsui"};
        for (String pkg : pkgs) {
            try {
                Intent l = activity.getPackageManager().getLaunchIntentForPackage(pkg);
                if (l == null) continue;
                l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(l);
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("where", "Download/YueDu");
                answer(reqId, o.toString());
                return;
            } catch (Throwable ignored) {}
        }
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("error", "no files app found");
            o.put("where", "Download/YueDu");
            answer(reqId, o.toString());
        } catch (Throwable t) { fail(reqId, "no files app found"); }
    }

    /* Let the user assign their own folder (page's "Choose my own folder"):
       opens the system folder picker; the read/write grant is persisted, so
       exports keep landing there across restarts. Contract:
         pickFolder(reqId) -> __yueNative(reqId, {ok, where} | {ok:false, error})
       `where` is the folder's display name. Cancelling answers ok:false with
       error "cancelled" so the page stays put instead of toasting. The host
       activity must route onActivityResult to handleActivityResult
       (MainActivity does). */
    private static final int REQ_PICK_FOLDER = 1002;
    private static String pendingPickFolderReqId = null;

    public static boolean handleActivityResult(int code, int resultCode, Intent data) {
        if (code != REQ_PICK_FOLDER) return false;
        final String reqId = pendingPickFolderReqId;
        pendingPickFolderReqId = null;
        final YueNative self = instance;
        if (reqId == null || self == null) return true;
        try {
            if (resultCode == android.app.Activity.RESULT_OK && data != null && data.getData() != null) {
                android.net.Uri uri = data.getData();
                try {
                    self.activity.getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    self.activity.getSharedPreferences("yuedu", 0).edit().putString("treeUri", uri.toString()).apply();
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    o.put("where", self.treeDisplayName(uri));
                    self.answer(reqId, o.toString());
                } catch (Throwable t) {
                    self.fail(reqId, String.valueOf(t.getMessage()));
                }
            } else {
                try {
                    JSONObject o = new JSONObject();
                    o.put("ok", false);
                    o.put("error", "cancelled");
                    self.answer(reqId, o.toString());
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return true;
    }

    @JavascriptInterface
    public void pickFolder(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    /* No FLAG_ACTIVITY_NEW_TASK here: combined with
                       startActivityForResult it makes many devices (notably
                       MIUI) answer RESULT_CANCELED the instant the picker
                       opens, so the user's choice never arrives. */
                    pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    pendingPickFolderReqId = reqId;
                    activity.startActivityForResult(pick, REQ_PICK_FOLDER);
                } catch (Throwable t) {
                    pendingPickFolderReqId = null;
                    fail(reqId, String.valueOf(t.getMessage()));
                }
            }
        });
    }

    /* The user's own folder, if they picked one and the grant survived
       (grants die on uninstall, data wipe, or manual revoke in Settings). */
    private android.net.Uri customTree() {
        try {
            String s = activity.getSharedPreferences("yuedu", 0).getString("treeUri", null);
            if (s == null || s.length() == 0) return null;
            android.net.Uri u = android.net.Uri.parse(s);
            try {
                for (android.content.UriPermission p : activity.getContentResolver().getPersistedUriPermissions()) {
                    if (u.equals(p.getUri()) && p.isReadPermission() && p.isWritePermission()) return u;
                }
            } catch (Throwable ignored) {}
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    private String treeDisplayName(android.net.Uri tree) {
        try {
            String id = android.provider.DocumentsContract.getTreeDocumentId(tree);
            int s = id.lastIndexOf('/');
            int c = id.lastIndexOf(':');
            int k = s > c ? s : c;
            String n = (k >= 0 ? id.substring(k + 1) : id).trim();
            if (n.length() > 0) return n;
        } catch (Throwable ignored) {}
        return "chosen folder";
    }

    private android.net.Uri treeChild(android.net.Uri tree, String parentDocId, String name) {
        android.database.Cursor c = null;
        try {
            android.net.Uri kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId);
            c = activity.getContentResolver().query(kids,
                    new String[]{ android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME },
                    null, null, null);
            if (c != null) {
                int idCol = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nmCol = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    String nm = null;
                    try { nm = c.getString(nmCol); } catch (Throwable ignored) {}
                    if (nm != null && nm.equals(name)) {
                        String did = null;
                        try { did = c.getString(idCol); } catch (Throwable ignored) {}
                        if (did != null) return android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, did);
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            try { if (c != null) c.close(); } catch (Throwable ignored) {}
        }
        return null;
    }

    /* Write into the user's own folder (plus optional subfolder, created on
       demand). Replaces a same-named file. Always answers exactly once. */
    private void saveToTree(String reqId, android.net.Uri tree, String folder, String clean, byte[] data, String mt) {
        try {
            String parentId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            android.net.Uri parentUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, parentId);
            String whereBase = treeDisplayName(tree);
            if (folder.length() > 0) {
                android.net.Uri sub = treeChild(tree, parentId, folder);
                if (sub == null) {
                    sub = android.provider.DocumentsContract.createDocument(
                            activity.getContentResolver(), parentUri,
                            android.provider.DocumentsContract.Document.MIME_TYPE_DIR, folder);
                }
                if (sub == null) { fail(reqId, "could not create " + folder); return; }
                try { parentId = android.provider.DocumentsContract.getDocumentId(sub); } catch (Throwable ignored) {}
                parentUri = sub;
                whereBase = whereBase + "/" + folder;
            }
            android.net.Uri old = treeChild(tree, parentId, clean);
            if (old != null) {
                try { android.provider.DocumentsContract.deleteDocument(activity.getContentResolver(), old); } catch (Throwable ignored) {}
            }
            android.net.Uri file = android.provider.DocumentsContract.createDocument(
                    activity.getContentResolver(), parentUri, mt, clean);
            if (file == null) { fail(reqId, "storage unavailable"); return; }
            java.io.OutputStream os = null;
            try {
                os = activity.getContentResolver().openOutputStream(file);
                if (os == null) { fail(reqId, "storage unavailable"); return; }
                os.write(data);
                os.flush();
            } finally { try { if (os != null) os.close(); } catch (Throwable ignored) {} }
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("where", whereBase + "/" + clean);
            answer(reqId, o.toString());
        } catch (Throwable t) {
            fail(reqId, String.valueOf(t.getMessage()));
        }
    }

    private void startApkDownload(String url) {
        try {
            if (!(url.startsWith("https://") || url.startsWith("http://"))) return;
            android.app.DownloadManager dm = (android.app.DownloadManager) activity.getSystemService(android.content.Context.DOWNLOAD_SERVICE);
            java.io.File dir = activity.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dm == null || dir == null) { openUrl(url); return; }
            String name = "yuedu-update.apk";
            try {
                String tail = android.net.Uri.parse(url).getLastPathSegment();
                if (tail != null && tail.toLowerCase().endsWith(".apk")) name = tail;
            } catch (Throwable ignored) {}
            android.app.DownloadManager.Request req = new android.app.DownloadManager.Request(android.net.Uri.parse(url));
            req.setTitle("YueDu update");
            req.setDescription("Downloading new version…");
            req.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setMimeType("application/vnd.android.package-archive");
            try { req.setDestinationUri(android.net.Uri.fromFile(new java.io.File(dir, name))); } catch (Throwable t) { openUrl(url); return; }
            long id = dm.enqueue(req);
            try { lastApkId = id; } catch (Throwable ignored) {}
            try { Toast.makeText(activity, "Downloading update…", Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
            watchApkDownload(dm, id, name);
        } catch (Throwable ignored) {}
    }

    private static final java.util.Map<Long, String> apkPending = new java.util.HashMap<Long, String>();
    private static volatile boolean apkReceiverOn = false;

    private static volatile long lastApkId = -1;

    /* In-app update progress (the page's Updates screen): Kotatsu shows a
       progress bar while its DownloadManager fetch runs — the page mirrors
       that by polling this. Answers {ok, state, downloaded, total} where
       state is none|downloading|paused|done|failed. */
    @JavascriptInterface
    public void apkProgress(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    long id = lastApkId;
                    if (id < 0) { o.put("state", "none"); o.put("downloaded", 0); o.put("total", 0); answer(reqId, o.toString()); return; }
                    android.app.DownloadManager dm = (android.app.DownloadManager) activity.getSystemService(android.content.Context.DOWNLOAD_SERVICE);
                    android.database.Cursor q = null;
                    try {
                        q = dm.query(new android.app.DownloadManager.Query().setFilterById(id));
                        if (q != null && q.moveToFirst()) {
                            int st = q.getInt(q.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_STATUS));
                            long got = q.getLong(q.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                            long tot = q.getLong(q.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            String state = "downloading";
                            if (st == android.app.DownloadManager.STATUS_SUCCESSFUL) state = "done";
                            else if (st == android.app.DownloadManager.STATUS_FAILED) state = "failed";
                            else if (st == android.app.DownloadManager.STATUS_PAUSED) state = "paused";
                            o.put("state", state); o.put("downloaded", got); o.put("total", tot);
                        } else { o.put("state", "none"); o.put("downloaded", 0); o.put("total", 0); }
                    } finally { try { if (q != null) q.close(); } catch (Throwable ignored) {} }
                    answer(reqId, o.toString());
                } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
            }
        });
    }

    /* Re-open the update installer for the last downloaded APK (the page's
       Updates screen "Install" button — e.g. the user missed the automatic
       install prompt). Answers {ok} or {ok:false,error}. */
    @JavascriptInterface
    public void apkInstall(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    long id = lastApkId;
                    if (id < 0) { fail(reqId, "nothing downloaded"); return; }
                    android.app.DownloadManager dm = (android.app.DownloadManager) activity.getSystemService(android.content.Context.DOWNLOAD_SERVICE);
                    android.net.Uri uri = dm.getUriForDownloadedFile(id);
                    if (uri == null) { fail(reqId, "not ready"); return; }
                    Intent in = new Intent(Intent.ACTION_INSTALL_PACKAGE);
                    in.setDataAndType(uri, "application/vnd.android.package-archive");
                    in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
                    activity.startActivity(in);
                    JSONObject o = new JSONObject();
                    o.put("ok", true);
                    answer(reqId, o.toString());
                } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
            }
        });
    }

    private void watchApkDownload(final android.app.DownloadManager dm, final long id, final String name) {
        synchronized (apkPending) { apkPending.put(id, name); }
        if (apkReceiverOn) return;
        apkReceiverOn = true;
        try {
            activity.registerReceiver(new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context ctx, Intent intent) {
                    try {
                        long got = intent.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                        String nm;
                        synchronized (apkPending) { nm = apkPending.remove(got); }
                        if (nm == null) return;
                        android.database.Cursor q = null;
                        try {
                            q = dm.query(new android.app.DownloadManager.Query().setFilterById(got));
                            if (q != null && q.moveToFirst()) {
                                int st = q.getInt(q.getColumnIndexOrThrow(android.app.DownloadManager.COLUMN_STATUS));
                                if (st == android.app.DownloadManager.STATUS_SUCCESSFUL) installApkFile(nm);
                            }
                        } finally { try { if (q != null) q.close(); } catch (Throwable ignored) {} }
                    } catch (Throwable ignored) {}
                }
            }, new android.content.IntentFilter(android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        } catch (Throwable ignored) { apkReceiverOn = false; }
    }

    private void installApkFile(String name) {
        try {
            java.io.File dir = activity.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) return;
            java.io.File apk = new java.io.File(dir, name);
            if (!apk.exists()) return;
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", apk);
            Intent in = new Intent(Intent.ACTION_VIEW);
            in.setDataAndType(uri, "application/vnd.android.package-archive");
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
            activity.startActivity(in);
        } catch (Throwable ignored) {}
    }

    private void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(i);
        } catch (Throwable ignored) {}
    }

    /** Device fingerprint for the entry lock screen: answers {ok:true} or {ok:false,error}.
     *
     * Auto-cancel hardening (the prompt dies instantly with ERROR_CANCELED when
     * the activity is not in front — floating/small window, split-screen, or a
     * tap that lands mid-resume — which used to surface as "tap Unlock and it
     * cancels by itself"):
     *  - the call waits (up to ~2.4s) for the window to actually be focused
     *    before firing, and answers "not-ready" instead of a doomed prompt;
     *  - only one prompt flies at a time (double-tap replaces, never stacks);
     *  - leaving the app dismisses an open prompt cleanly (see MainActivity).
     */
    private static volatile androidx.biometric.BiometricPrompt currentPrompt = null;

    /** Dismiss any prompt we fired that is still showing. Safe anywhere:
        call it from the host activity's onStop so a prompt never outlives
        the app (backgrounding mid-prompt otherwise leaves a stuck system
        sheet that cancels the next tap). Never from onPause: the prompt
        sheet itself pauses the activity on many devices, and cancelling
        there kills the prompt the user just opened. */
    public static void cancelBiometric() {
        try {
            final androidx.biometric.BiometricPrompt p = currentPrompt;
            currentPrompt = null;
            if (p != null) p.cancelAuthentication();
        } catch (Throwable ignored) {}
    }

    @JavascriptInterface
    public void biometric(final String reqId) {
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    if (!(activity instanceof androidx.fragment.app.FragmentActivity)) { fail(reqId, "no activity"); return; }
                    final androidx.fragment.app.FragmentActivity fa = (androidx.fragment.app.FragmentActivity) activity;
                    waitForFocusThenAuth(fa, reqId, 0);
                } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
            }
        });
    }

    private void waitForFocusThenAuth(final androidx.fragment.app.FragmentActivity fa, final String reqId, final int tries) {
        boolean ready = false;
        try { ready = !fa.isFinishing() && !fa.isDestroyed() && fa.hasWindowFocus(); } catch (Throwable ignored) {}
        if (!ready) {
            /* Not in front yet (floating window, split-screen, mid-resume):
               never fire — the system would instantly cancel it. */
            if (tries >= 16) { fail(reqId, "not-ready"); return; }
            ui.postDelayed(new Runnable() {
                @Override public void run() { waitForFocusThenAuth(fa, reqId, tries + 1); }
            }, 150);
            return;
        }
        try {
            int ok;
            try {
                ok = androidx.biometric.BiometricManager.from(fa)
                        .canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                                | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            } catch (Throwable t) { fail(reqId, "unavailable"); return; }
            if (ok != androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) { fail(reqId, "not enrolled"); return; }
            cancelBiometric();
            java.util.concurrent.Executor ex = androidx.core.content.ContextCompat.getMainExecutor(fa);
            final androidx.biometric.BiometricPrompt prompt = new androidx.biometric.BiometricPrompt(fa, ex,
                    new androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(androidx.biometric.BiometricPrompt.AuthenticationResult r) {
                            currentPrompt = null;
                            try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = false; } catch (Throwable ignored) {}
                            /* The sheet may have paused us (freezing the
                               WebView): resume it first, or the success
                               answer below is dropped by the frozen page and
                               the lock never lifts. */
                            try { if (host != null) host.onResume(); } catch (Throwable ignored) {}
                            try { activity.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
                            try { if (activity instanceof com.yuedu.app.MainActivity) ((com.yuedu.app.MainActivity) activity).hideLockShield(); } catch (Throwable ignored) {}
                            try { if (activity instanceof com.yuedu.app.MainActivity) ((com.yuedu.app.MainActivity) activity).reapplyOrientationAfterUnlock(); } catch (Throwable ignored) {}
                            try {
                                JSONObject o = new JSONObject();
                                o.put("ok", true);
                                answer(reqId, o.toString());
                            } catch (Throwable ignored) {}
                        }
                        @Override public void onAuthenticationError(int code, CharSequence msg) {
                            currentPrompt = null;
                            try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = false; } catch (Throwable ignored) {}
                            /* Still locked: the page lock card must be visible, so a
                               leftover re-entry shield must come down here too. */
                            try { if (activity instanceof com.yuedu.app.MainActivity) ((com.yuedu.app.MainActivity) activity).hideLockShield(); } catch (Throwable ignored) {}
                            if (code == androidx.biometric.BiometricPrompt.ERROR_LOCKOUT) { fail(reqId, "locked out — too many tries, wait 30 seconds"); return; }
                            fail(reqId, code == androidx.biometric.BiometricPrompt.ERROR_USER_CANCELED
                                    || code == androidx.biometric.BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                    || code == androidx.biometric.BiometricPrompt.ERROR_CANCELED ? "cancelled" : String.valueOf(msg));
                        }
                        @Override public void onAuthenticationFailed() { /* stays open for a retry */ }
                    });
            currentPrompt = prompt;
            androidx.biometric.BiometricPrompt.PromptInfo info =
                    new androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                            .setTitle("Unlock YueDu")
                            .setSubtitle("Confirm fingerprint or screen lock to continue")
                            .setDescription("This lock keeps your library private on this device.")
                            .setAllowedAuthenticators(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
                                    | androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                            .build();
            /* The prompt sheet is an in-app detour: its pause/resume must
               skip the re-entry lock (a success answer lands after resume,
               and re-locking first would revive the lock over it). Cleared
               again in both auth callbacks so a stale flag never skips a
               real gate. */
            try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = true; } catch (Throwable ignored) {}
            try { prompt.authenticate(info); }
            catch (Throwable t) { currentPrompt = null; try { if (activity instanceof com.yuedu.app.MainActivity) com.yuedu.app.MainActivity.suppressNextResumeGate = false; } catch (Throwable ignored) {} fail(reqId, "unavailable"); }
        } catch (Throwable t) { fail(reqId, String.valueOf(t.getMessage())); }
    }

    @JavascriptInterface
    public void toast(final String msg) {
        ui.post(new Runnable() {
            @Override public void run() { Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    /* Screen-lock / screenshot-gray prefs, mirrored from the page's Security
       screen and first-run choice. Both default OFF: nothing blanks or locks
       until the user opts in. MainActivity gates FLAG_SECURE, the shield and
       the re-lock gate on these. */
    @JavascriptInterface
    public void setSecurePref(final String key, final String value) {
        try {
            if (activity == null) return;
            final android.content.SharedPreferences p = activity.getSharedPreferences("yuedu_sec", android.content.Context.MODE_PRIVATE);
            final boolean on = "1".equals(value);
            try { p.edit().putBoolean("lock".equals(key) ? "lock" : "gray", on).apply(); } catch (Throwable ignored) {}
            final Activity a = activity;
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (a instanceof com.yuedu.app.MainActivity) ((com.yuedu.app.MainActivity) a).onSecPrefChanged();
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    public static boolean secLockOn(android.content.Context c) {
        try { return c.getSharedPreferences("yuedu_sec", android.content.Context.MODE_PRIVATE).getBoolean("lock", false); }
        catch (Throwable t) { return false; }
    }

    public static boolean secGrayOn(android.content.Context c) {
        try { return c.getSharedPreferences("yuedu_sec", android.content.Context.MODE_PRIVATE).getBoolean("gray", false); }
        catch (Throwable t) { return false; }
    }

    /* In-player volume HUD + swipe: current music-stream volume as JSON. */
    @JavascriptInterface
    public String getVolume() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) activity.getSystemService(android.content.Context.AUDIO_SERVICE);
            if (am == null) return "{\"v\":0,\"m\":15}";
            return "{\"v\":" + am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) + ",\"m\":" + am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) + "}";
        } catch (Throwable t) { return "{\"v\":0,\"m\":15}"; }
    }

    /* In-player volume swipe: set music-stream volume (0..max). */
    @JavascriptInterface
    public void setVolume(final int v) {
        try {
            android.media.AudioManager am = (android.media.AudioManager) activity.getSystemService(android.content.Context.AUDIO_SERVICE);
            if (am == null) return;
            final int m = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
            final int want = Math.max(0, Math.min(m, v));
            ui.post(new Runnable() {
                @Override public void run() {
                    try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, want, 0); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    /* Step out of fullscreen video on the page request (its own back button
       closes the episode without passing through the system back key, which
       used to strand the app on the dead fullscreen view: landscape, frozen).
       Safe anywhere: a no-op when no custom view is showing. */
    @JavascriptInterface
    public void exitFullscreen() {
        try {
            final Activity a = activity;
            if (a == null) return;
            if (a instanceof com.yuedu.app.MainActivity) {
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { ((com.yuedu.app.MainActivity) a).hideCustomView(); } catch (Throwable ignored) {}
                    }
                });
            }
        } catch (Throwable ignored) {}
    }

    // ---------------------------------------------------------------- the work

    /* Shared cookie jar for the device route (Aniyomi model: one client on the
       WebView's jar). Native requests are stateless unless cookies are kept:
       hosts that hand a session cookie on one page and demand it on the next
       (embed page → play link) fail without it. Cookies earned natively are
       stored per host AND pushed into the WebView jar, and every native
       request sends both — page, bridge and media intercept share one jar. */
    private static final java.util.Map<String, java.util.Map<String, String>> cookieStore =
            new java.util.HashMap<String, java.util.Map<String, String>>();

    private static String hostOf(String url) {
        try {
            String h = new URL(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Throwable t) { return ""; }
    }

    /** Merged "name=value; ..." for a URL: stored native cookies + WebView jar. */
    public static String cookieHeaderFor(String url) {
        StringBuilder sb = new StringBuilder();
        String host = hostOf(url);
        synchronized (cookieStore) {
            java.util.Map<String, String> m = cookieStore.get(host);
            if (m != null) for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(e.getKey()).append("=").append(e.getValue());
            }
        }
        try {
            String jar = CookieManager.getInstance().getCookie(url);
            if (jar != null && jar.length() > 0) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(jar);
            }
        } catch (Throwable ignored) {}
        return sb.toString();
    }

    /** Fold Set-Cookie response headers into the store + WebView jar. */
    public static void storeCookiesFrom(String url, HttpURLConnection c) {
        if (url == null || c == null) return;
        final String u = url;
        final String host = hostOf(url);
        if (host.length() == 0) return;
        java.util.List<String> set = null;
        try {
            java.util.Map<String, java.util.List<String>> hf = c.getHeaderFields();
            if (hf != null) for (java.util.Map.Entry<String, java.util.List<String>> e : hf.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase("Set-Cookie")) { set = e.getValue(); break; }
            }
        } catch (Throwable ignored) {}
        if (set == null || set.isEmpty()) return;
        final java.util.List<String> add = new java.util.ArrayList<String>();
        synchronized (cookieStore) {
            java.util.Map<String, String> m = cookieStore.get(host);
            if (m == null) { m = new java.util.HashMap<String, String>(); cookieStore.put(host, m); }
            for (String s : set) {
                if (s == null) continue;
                int sc = s.indexOf(';');
                String pair = (sc >= 0 ? s.substring(0, sc) : s).trim();
                int eq = pair.indexOf('=');
                if (eq <= 0) continue;
                String name = pair.substring(0, eq).trim(), value = pair.substring(eq + 1).trim();
                if (name.length() == 0) continue;
                m.put(name, value);
                add.add(pair);
            }
        }
        if (add.isEmpty() || host == null) return;
        try {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        for (String pair : add) CookieManager.getInstance().setCookie(u, pair);
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    /** Merge two "a=b; ..." cookie strings by name (explicit wins). Used so a saved/pasted
     *  SAPISID still rides even though the platform owns Cookie, and so challenge captures
     *  from google + youtube jars combine instead of only one domain winning. */
    private static String mergeCookieHeaders(String a, String b) {
        try {
            java.util.LinkedHashMap<String, String> m = new java.util.LinkedHashMap<String, String>();
            String[] parts = new String[]{ a, b };
            for (String part : parts) {
                if (part == null) continue;
                for (String p : part.split(";")) {
                    if (p == null) continue;
                    String t = p.trim();
                    if (t.length() == 0) continue;
                    int eq = t.indexOf('=');
                    if (eq <= 0) continue;
                    String name = t.substring(0, eq).trim();
                    String val = t.substring(eq + 1).trim();
                    if (name.length() == 0) continue;
                    m.put(name, val);
                }
            }
            StringBuilder sb = new StringBuilder();
            for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(e.getKey()).append("=").append(e.getValue());
            }
            return sb.toString();
        } catch (Throwable ignored) {
            if (a != null && a.length() > 0) return a;
            return b == null ? "" : b;
        }
    }

    private String doFetch(String url, String method, String headersJson, String body) throws Exception {
        boolean post = method != null && !"GET".equalsIgnoreCase(method) && !"HEAD".equalsIgnoreCase(method);
        /* One silent retry on a fresh connection: pooled keep-alive sockets to
           HLS edges sometimes die mid-read ("unexpected end of stream") while a
           brand-new connection sails through. Only for GET/HEAD. */
        IOException lastErr = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod(post ? method.toUpperCase() : "GET");
                if (attempt > 0) c.setRequestProperty("Connection", "close");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("Accept", "*/*");
                String ua = null;
                if (host != null) {
                    try { ua = host.getSettings().getUserAgentString(); } catch (Throwable ignored) {}
                }
                c.setRequestProperty("User-Agent", ua != null ? ua : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
                String explicitCookie = null;
                if (headersJson != null && headersJson.length() > 1) {
                    JSONObject h = new JSONObject(headersJson);
                    for (Iterator<String> it = h.keys(); it.hasNext(); ) {
                        String k = it.next();
                        if (k.equalsIgnoreCase("cookie")) { try { explicitCookie = h.getString(k); } catch (Throwable ignored2) {} continue; }
                        /* Let the platform own these; overriding them breaks the request. */
                        if (k.equalsIgnoreCase("host")
                                || k.equalsIgnoreCase("content-length") || k.equalsIgnoreCase("connection")) continue;
                        c.setRequestProperty(k, h.getString(k));
                    }
                }
                /* The shared jar (stored native cookies + WebView's) plus any explicit Cookie
                   the page sent (e.g. a pasted YouTube SAPISID) — the bridge used to drop the
                   explicit value, so pasted sessions never authenticated on-device. */
                try {
                    String cookie = mergeCookieHeaders(cookieHeaderFor(url), explicitCookie);
                    if (cookie != null && cookie.length() > 0) c.setRequestProperty("Cookie", cookie);
                } catch (Throwable ignored) {}
                if (post) {
                    c.setDoOutput(true);
                    byte[] out = (body == null ? "" : body).getBytes(Charset.forName("UTF-8"));
                    c.setFixedLengthStreamingMode(out.length);
                    OutputStream os = c.getOutputStream();
                    os.write(out);
                    os.flush();
                    os.close();
                }
                int status = c.getResponseCode();
                try { storeCookiesFrom(url, c); } catch (Throwable ignored) {}
                /* Manual redirect walk: one picture CDN answers plain-http
                   with a 301 this stack will not follow on its own. Chase up
                   to 5 hops here so the final bytes (and status) come back. */
                String hop = url;
                for (int rhop = 0; rhop < 5 && (status == 301 || status == 302 || status == 303 || status == 307 || status == 308); rhop++) {
                    String loc = null;
                    try { loc = c.getHeaderField("Location"); } catch (Throwable ignored) {}
                    if (loc == null || loc.length() == 0) break;
                    try { c.disconnect(); } catch (Throwable ignored) {}
                    String nhop = null;
                    try { nhop = new URL(new URL(hop), loc).toString(); } catch (Throwable ignored) {}
                    if (nhop == null) break;
                    boolean downgrade = (status == 303) || ((status == 301 || status == 302) && post);
                    HttpURLConnection nc = null;
                    int nst = -1;
                    try {
                        nc = (HttpURLConnection) new URL(nhop).openConnection();
                        nc.setRequestMethod((post && !downgrade) ? method.toUpperCase() : "GET");
                        if (attempt > 0) nc.setRequestProperty("Connection", "close");
                        nc.setConnectTimeout(15000);
                        nc.setReadTimeout(30000);
                        nc.setInstanceFollowRedirects(true);
                        nc.setRequestProperty("Accept", "*/*");
                        nc.setRequestProperty("User-Agent", ua != null ? ua : "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36");
                        String explicitCookie2 = null;
                        if (headersJson != null && headersJson.length() > 1) {
                            JSONObject hh = new JSONObject(headersJson);
                                                        for (Iterator<String> it = hh.keys(); it.hasNext(); ) {
                                String k = it.next();
                                if (k.equalsIgnoreCase("cookie")) { try { explicitCookie2 = hh.getString(k); } catch (Throwable ignored2) {} continue; }
                                if (k.equalsIgnoreCase("host")
                                        || k.equalsIgnoreCase("content-length") || k.equalsIgnoreCase("connection")) continue;
                                nc.setRequestProperty(k, hh.getString(k));
                            }
                        }
                        try {
                            String hcookie = mergeCookieHeaders(cookieHeaderFor(nhop), explicitCookie2);
                            if (hcookie != null && hcookie.length() > 0) nc.setRequestProperty("Cookie", hcookie);
                        } catch (Throwable ignored) {}
                        if (post && !downgrade) {
                            nc.setDoOutput(true);
                            byte[] hout = (body == null ? "" : body).getBytes(Charset.forName("UTF-8"));
                            nc.setFixedLengthStreamingMode(hout.length);
                            OutputStream hos = nc.getOutputStream();
                            hos.write(hout);
                            hos.flush();
                            hos.close();
                        }
                        nst = nc.getResponseCode();
                        try { storeCookiesFrom(nhop, nc); } catch (Throwable ignored) {}
                    } catch (Throwable ignored) {
                        try { if (nc != null) nc.disconnect(); } catch (Throwable ignored2) {}
                        break;
                    }
                    c = nc;
                    hop = nhop;
                    status = nst;
                    if (downgrade) post = false;
                }
                url = hop;
                InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                byte[] raw = new byte[0];
                if (in != null) raw = readBytes(in);
                String contentType = c.getContentType();
                if (contentType == null) contentType = "";
                /* Declared length (when the server states one and the body isn't
                   encoded): a reset connection can end the body early while the
                   status stays 200, and handing a truncated segment to the player
                   kills playback with an append error. The page treats a short
                   read as a failure and retries instead. */
                long expectedLen = -1;
                try {
                    String contentEncoding = c.getHeaderField("Content-Encoding");
                    String contentLength = c.getHeaderField("Content-Length");
                    if ((contentEncoding == null || contentEncoding.trim().length() == 0) && contentLength != null) expectedLen = Long.parseLong(contentLength.trim());
                } catch (Throwable ignored) {}
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("status", status);
                o.put("contentType", contentType);
                o.put("expected", expectedLen);
                o.put("length", raw.length);
                o.put("url", c.getURL().toString());
                try {
                    JSONObject rh = new JSONObject();
                    java.util.Map<String, java.util.List<String>> hmap = c.getHeaderFields();
                    if (hmap != null) for (java.util.Map.Entry<String, java.util.List<String>> hent : hmap.entrySet()) {
                        if (hent.getKey() == null) continue;
                        java.util.List<String> hvals = hent.getValue();
                        if (hvals != null && !hvals.isEmpty()) rh.put(hent.getKey(), hvals.get(hvals.size() - 1));
                    }
                    o.put("headers", rh);
                } catch (Throwable ignored) {}
                /* HLS video segments (.ts, video/mp2t) and generic octet-streams are
                   binary like pictures: decoding them as text would corrupt them, so
                   they ride back base64 and the page turns them into bytes (the anime
                   player's bridge loader feeds guarded HLS through this with the
                   video host as Referer). Playlists stay text. */
                String ctl = contentType.toLowerCase();
                /* Some HLS hosts serve binary init/segment files under a playlist-ish
                   content-type (e.g. an .mp4 init map as application/x-mpegURL), so the
                   extension decides too — otherwise binary rides back as mangled text. */
                String upath = url == null ? "" : url.toLowerCase();
                int qi = upath.indexOf('?');
                if (qi >= 0) upath = upath.substring(0, qi);
                int hi = upath.indexOf('#');
                if (hi >= 0) upath = upath.substring(0, hi);
                boolean mediaExt = upath.endsWith(".mp4") || upath.endsWith(".m4s") || upath.endsWith(".m4a") || upath.endsWith(".m4i") || upath.endsWith(".m4v") || upath.endsWith(".ts") || upath.endsWith(".m2t") || upath.endsWith(".mts") || upath.endsWith(".aac") || upath.endsWith(".ac3") || upath.endsWith(".eac3") || upath.endsWith(".opus") || upath.endsWith(".jpg") || upath.endsWith(".jpeg") || upath.endsWith(".png") || upath.endsWith(".webp");
                /* Subtitle sidecars are always text, even when a host serves them as
                   octet-stream (HentaiHaven s/*.vtt arrive as application/octet-stream).
                   They ride back as UTF-8 text for the playlist/subtitle loader. */
                boolean subExt = upath.endsWith(".vtt") || upath.endsWith(".srt") || upath.endsWith(".ttml") || upath.endsWith(".vttml");
                /* Disguised HLS segments: HentaiHaven serves binary mp4 audio/video
                   pieces as *.html under a playlist content-type (Hanime serves its HLS pieces the same way, as *.html under /v1x/segs/ — no real page ever lives under /segs/)
                   (application/x-mpegURL). Real HTML pages are text/html, never
                   mpegURL — so .html + mpegURL means a binary segment. */
                boolean htmlSeg = (upath.endsWith(".html") || upath.endsWith(".htm")) && (ctl.contains("mpegurl") || upath.contains("/segs/"));
                if (subExt) {
                    o.put("text", new String(raw, Charset.forName(charsetOf(contentType))));
                    try { o.put("base64", Base64.encodeToString(raw, Base64.NO_WRAP)); } catch (Throwable ignored) { o.put("base64", ""); }
                } else if (mediaExt || htmlSeg || ctl.startsWith("image/") || ctl.startsWith("video/") || ctl.startsWith("audio/") || ctl.startsWith("application/octet-stream")) {
                    /* Binary: decoding bytes as text would corrupt them, so they ride
                       back base64 and the page turns them into a blob (LikeManga's
                       hotlink-guarded pages are read this way, with a Referer header
                       no WebView request of its own could state). */
                    o.put("base64", Base64.encodeToString(raw, Base64.NO_WRAP));
                    o.put("text", "");
                } else {
                    o.put("text", new String(raw, Charset.forName(charsetOf(contentType))));
                }
                try { c.disconnect(); } catch (Throwable ignored) {}
                c = null;
                return o.toString();
            } catch (IOException e) {
                lastErr = e;
                if (post) throw e;
            } finally {
                try { if (c != null) c.disconnect(); } catch (Throwable ignored) {}
            }
        }
        throw lastErr;
    }

    private static String charsetOf(String contentType) {
        if (contentType != null) {
            int i = contentType.toLowerCase().indexOf("charset=");
            if (i >= 0) {
                String cs = contentType.substring(i + 8).trim();
                int sc = cs.indexOf(';');
                if (sc > 0) cs = cs.substring(0, sc).trim();
                try { if (Charset.isSupported(cs)) return cs; } catch (Throwable ignored) {}
            }
        }
        return "UTF-8";
    }

    private static byte[] readBytes(InputStream in) throws Exception {
        BufferedInputStream bin = new BufferedInputStream(in);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n, total = 0;
        while ((n = bin.read(buf)) > 0) {
            bos.write(buf, 0, n);
            total += n;
            if (total > MAX_BYTES) break;
        }
        bin.close();
        return bos.toByteArray();
    }

    /** Called by Challenge with the JSON it scraped out of the site's page. */
    static void deliverChallenge(final String json) {
        final String reqId = pendingChallengeReqId;
        pendingChallengeReqId = null;
        if (reqId == null) { try { android.util.Log.w(TAG, "deliverChallenge: no pending request, dropping " + (json == null ? 0 : json.length()) + " chars"); } catch (Throwable ignored) {} return; }
        evaluate("window.__yueNative(" + JSONObject.quote(reqId) + "," + JSONObject.quote(json) + ")", null);
    }

    private void answer(String reqId, String json) {
        evaluate("window.__yueNative(" + JSONObject.quote(reqId) + "," + JSONObject.quote(json) + ")", null);
    }

    private void fail(String reqId, String message) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", false);
            o.put("error", message == null ? "failed" : message);
            answer(reqId, o.toString());
        } catch (Throwable ignored) {}
    }

    private static void evaluate(final String js, final String[] out) {
        final WebView w = host;
        if (w == null) return;
        w.post(new Runnable() {
            @Override public void run() {
                try { w.evaluateJavascript(js, null); } catch (Throwable t) { Log.w(TAG, "evaluateJavascript failed", t); }
            }
        });
    }

    // ---------------------------------------------------------------- the challenge screen

    /**
     * A plain WebView on the URL that is blocking us, with a Done button. Passing
     * the check here (Turnstile / Cloudflare) is what the site's own page needs, and
     * the cookies it sets go into the shared jar, so YueDu's next request from
     * the device is already through. Done also hands back the page's text, so a
     * chapter can be read straight out of it if the API stays closed.
     */
    public static class Challenge extends Activity {

        private WebView web;
        private TextView titleView;
        private TextView subView;
        private String startUrl = "https://wtr-lab.com/";
        private boolean delivering = false;
        private boolean loadError = false;
        private boolean pageDone = false;
        private boolean passAnnounced = false;
        private long openedAt = 0;
        private final Handler cfPoller = new Handler(Looper.getMainLooper());
        private String cfAtOpen = "";
        private Runnable cfPoll;

        @Override protected void onCreate(android.os.Bundle saved) {
            super.onCreate(saved);
            try { if (YueNative.secGrayOn(this) || YueNative.secLockOn(this)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); } catch (Throwable ignored) {}
            if (getIntent() != null && getIntent().getStringExtra("url") != null) {
                startUrl = getIntent().getStringExtra("url");
            }
            final String title = getIntent() == null ? null : getIntent().getStringExtra("title");

            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(0xFF0B0B10);

            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setLoadWithOverviewMode(true);
            s.setUseWideViewPort(true);
            s.setSupportZoom(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
            /* Same marker-free UA as the main WebView (see MainActivity): the
               "; wv" WebView token loops bot walls forever, and a clearance
               earned under one UA may not count under another. */
            try {
                String hua = host != null ? host.getSettings().getUserAgentString() : null;
                if (hua != null && hua.length() > 0) s.setUserAgentString(hua);
                else s.setUserAgentString("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36");
            } catch (Throwable ignored) {}
            try { String c = CookieManager.getInstance().getCookie(startUrl); cfAtOpen = c == null ? "" : c; } catch (Throwable ignored) {}
            openedAt = android.os.SystemClock.elapsedRealtime();
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) { pageDone = true; checkClearance(); }
                @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                    if (req != null && req.isForMainFrame()) {
                        loadError = true;
                        if (subView != null) {
                            CharSequence d = err != null ? err.getDescription() : null;
                            subView.setText("Couldn't reach the site (" + (d == null ? "connection error" : d) + ") — check the connection, then Cancel and retry.");
                        }
                    }
                }
                @Override public void onReceivedHttpError(WebView v, WebResourceRequest req, WebResourceResponse resp) {
                    if (req != null && req.isForMainFrame() && resp != null && resp.getStatusCode() >= 400 && subView != null) {
                        loadError = true;
                        subView.setText("The site answered " + resp.getStatusCode() + " — if a check is showing above, solve it, then tap Done.");
                    }
                }
            });
            web.setWebChromeClient(new WebChromeClient() {
                @Override public void onProgressChanged(WebView v, int p) {
                    if (loadError || subView == null) return;
                    boolean isS2 = false; try { String tt1 = title; isS2 = tt1 != null && tt1.toLowerCase().contains("sign"); } catch (Throwable ignored) {} subView.setText(p < 100 ? (isS2 ? "Loading sign-in… " + p + "%" : "Loading… " + p + "%") : (isS2 ? "Tap Sign in inside this page, finish login, then tap Done" : "If the site shows a check above, solve it — then tap Done"));
                }
            });
            root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.VERTICAL);
            bar.setBackgroundColor(0xFF101016);
            bar.setPadding(dp(12), dp(10), dp(12), dp(6));

            titleView = new TextView(this);
            titleView.setText(title == null ? "One quick check" : title);
            titleView.setTextColor(0xFFFFFFFF);
            titleView.setTextSize(15);
            titleView.setTypeface(titleView.getTypeface(), android.graphics.Typeface.BOLD);
            titleView.setMaxLines(1);
            titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            bar.addView(titleView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            subView = new TextView(this);
            boolean isSignInScreen = false; try { String tt0 = title; isSignInScreen = tt0 != null && tt0.toLowerCase().contains("sign"); } catch (Throwable ignored) {} subView.setText(isSignInScreen ? "Sign in to your Google account inside this screen \u2014 then tap Done" : "Loading…");
            subView.setTextColor(0xFF9A9AAC);
            subView.setTextSize(12);
            subView.setMaxLines(2);
            LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            subParams.topMargin = dp(2);
            bar.addView(subView, subParams);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            bar.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button reload = new Button(this);
            reload.setText("\u21BB");
            reload.setTextColor(0xFF9A9AAC);
            reload.setBackgroundColor(0x00000000);
            reload.setContentDescription("Reload page");
            reload.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { try { if (web != null) web.reload(); } catch (Throwable ignored) {} }
            });
            row.addView(reload, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button cancel = new Button(this);
            cancel.setText("Cancel");
            cancel.setTextColor(0xFF9A9AAC);
            cancel.setBackgroundColor(0x00000000);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { closeWithoutCapture(); }
            });
            row.addView(cancel, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button done = new Button(this);
            done.setText("Done ✓");
            done.setTextColor(0xFFFFFFFF);
            done.setBackgroundColor(0xFFFF3B7D);
            done.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { captureAndClose(); }
            });
            row.addView(done, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
            root.addView(bar, barParams);
            setContentView(root);
            web.loadUrl(startUrl);
            /* A Cloudflare check usually passes itself inside the page — wait
               for the fresh cf_clearance cookie and close on the spot instead
               of making the user guess when to tap Done. */
            cfPoll = new Runnable() {
                @Override public void run() { checkClearance(); if (!delivering) cfPoller.postDelayed(cfPoll, 1000); }
            };
            cfPoller.postDelayed(cfPoll, 1000);
        }

        @Override public void onBackPressed() { captureAndClose(); }

        /** A clearance that was not there at open means the check just passed. */
        private String cfValue(String cookies) {
            if (cookies == null) return "";
            for (String p : cookies.split(";")) {
                String t = p.trim();
                if (t.startsWith("cf_clearance=")) return t.substring("cf_clearance=".length());
            }
            return "";
        }
        private String currentClearance() {
            String best = "";
            try {
                String a = CookieManager.getInstance().getCookie(startUrl);
                if (cfValue(a).length() > 0) best = cfValue(a);
            } catch (Throwable ignored) {}
            try {
                String cur = web != null ? web.getUrl() : null;
                if (cur != null && !cur.equals(startUrl)) {
                    String b = CookieManager.getInstance().getCookie(cur);
                    if (cfValue(b).length() > 0) best = cfValue(b);
                }
            } catch (Throwable ignored) {}
            return best;
        }
        private void checkClearance() {
            if (delivering) return;
            try {
                /* Never close on a stale cookie: the screen must have been open
                   a while, finished at least one page load, and seen a
                   clearance that was not there at open. Otherwise an old
                   cookie (or a slow jar) slams the screen shut before the
                   user solves anything — the "pushes me back" loop. */
                if (!pageDone) return;
                if (android.os.SystemClock.elapsedRealtime() - openedAt < 8000) return;
                String now = currentClearance();
                if (now.length() == 0 || now.equals(cfValue(cfAtOpen))) return;
                if (!passAnnounced) {
                    passAnnounced = true;
                    if (subView != null) subView.setText("Check passed — returning to the episode…");
                    cfPoller.postDelayed(new Runnable() {
                        @Override public void run() { captureAndClose(); }
                    }, 1500);
                }
            } catch (Throwable ignored) {}
        }

        /** All cookies that prove the sign-in: youtube + google jars merged by name.
         *  getCookie(startUrl) alone only returns cookies for ONE domain — Google sets SAPISID
         *  on .google.com while the challenge opens youtube.com, so the old code handed back a
         *  jar with no SAPISID and every Done looked "not signed in" even though the web page
         *  showed the account. */
        private String mergedChallengeCookies() {
            java.util.LinkedHashMap<String, String> m = new java.util.LinkedHashMap<String, String>();
            try {
                String cur = null;
                try { cur = web != null ? web.getUrl() : null; } catch (Throwable ignored) {}
                String[] urls = new String[]{ startUrl, cur, "https://www.youtube.com/", "https://m.youtube.com/", "https://youtube.com/", "https://www.google.com/", "https://accounts.google.com/" };
                for (String u : urls) {
                    if (u == null || u.length() == 0) continue;
                    String ck = null;
                    try { ck = CookieManager.getInstance().getCookie(u); } catch (Throwable ignored) { continue; }
                    if (ck == null || ck.length() == 0) continue;
                    for (String p : ck.split(";")) {
                        if (p == null) continue;
                        String t = p.trim();
                        if (t.length() == 0) continue;
                        int eq = t.indexOf('=');
                        if (eq <= 0) continue;
                        String name = t.substring(0, eq).trim();
                        String val = t.substring(eq + 1).trim();
                        if (name.length() == 0) continue;
                        m.put(name, val);
                    }
                }
            } catch (Throwable ignored) {}
            StringBuilder sb = new StringBuilder();
            try {
                for (java.util.Map.Entry<String, String> e : m.entrySet()) {
                    if (sb.length() > 0) sb.append("; ");
                    sb.append(e.getKey()).append("=").append(e.getValue());
                }
            } catch (Throwable ignored) {}
            return sb.toString();
        }

        /** Cookie NAMES only (never values): safe to show in toasts and debug. */
        private String ckNames(String merged) {
            try {
                java.util.TreeSet<String> names = new java.util.TreeSet<String>();
                if (merged != null) {
                    for (String p : merged.split(";")) {
                        if (p == null) continue;
                        String t = p.trim();
                        int eq = t.indexOf('=');
                        if (eq > 0 && t.substring(0, eq).trim().length() > 0) names.add(t.substring(0, eq).trim());
                    }
                }
                StringBuilder sb = new StringBuilder();
                for (String n : names) { if (sb.length() > 0) sb.append(","); sb.append(n); }
                return sb.toString();
            } catch (Throwable ignored) { return ""; }
        }

        /** Hand the sign-in cookies back to YueDu, then really close the screen.
         *  The answer is deliberately tiny (url + cookies only): the old page
         *  dump (megabytes of logged-in page HTML) could silently kill the
         *  bridge answer, leaving Done looking dead. The only challenge caller
         *  (YouTube sign-in) reads cookies alone. */
        private void captureAndClose() {
            if (delivering) return;
            delivering = true;
            if (web == null) { try { YueNative.deliverChallenge("{\"ok\":true,\"cookies\":\"\",\"ckNames\":\"\"}"); } catch (Throwable ignored) {} try { Challenge.super.finish(); } catch (Throwable ignored) {} return; }
            /* Never leave the screen stuck open. */
            try { titleView.setText("Saving\u2026"); } catch (Throwable ignored) {}
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { if (delivering) { try { Challenge.super.finish(); } catch (Throwable ignored) {} } }
            }, 4000);
            try {
                String ck = mergedChallengeCookies();
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("cookies", ck == null ? "" : ck);
                o.put("ckNames", ckNames(ck));
                try {
                    String cur = web.getUrl();
                    o.put("url", cur != null ? cur : startUrl);
                    String t = web.getTitle();
                    if (t != null) o.put("title", t);
                } catch (Throwable ignored) {}
                YueNative.deliverChallenge(o.toString());
            } catch (Throwable t) {
                try { YueNative.deliverChallenge("{\"ok\":true,\"cookies\":\"\"}"); } catch (Throwable ignored) {}
            }
            try { Challenge.super.finish(); } catch (Throwable ignored) {}
        }

        /** Leave without solving: hand back the cookies so far and let the app's
            own retry decide. Never strands the reader — the waiter is answered. */
        private void closeWithoutCapture() {
            if (delivering) return;
            delivering = true;
            try {
                String ck = mergedChallengeCookies();
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("cookies", ck == null ? "" : ck);
                o.put("ckNames", ckNames(ck));
                try {
                    String cur = web != null ? web.getUrl() : null;
                    if (cur != null) o.put("url", cur);
                } catch (Throwable ignored) {}
                YueNative.deliverChallenge(o.toString());
            } catch (Throwable ignored) {}
            try { Challenge.super.finish(); } catch (Throwable ignored) {}
        }

        private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    }

    // ---------------------------------------------------------------- speech (read aloud)

    /**
     * The device's own speech engine, behind window.YueTts.
     *
     * This is what makes read-aloud possible in the packaged app at all. Android's
     * WebView has no Web Speech API — `window.speechSynthesis` simply does not exist
     * there (MDN's browser-compat-data: webview_android false) — so without this
     * YueDu can only speak through its online voice. With it, read-aloud uses the
     * phone's own voices, works offline, and can use any installed language.
     *
     * YueDu speaks one sentence at a time and drives everything from the
     * callbacks, which arrive as `window.__yueTts(<id>, <json>)`:
     *
     *   {"event":"start"}                  it began speaking
     *   {"event":"range","start":s,"end":e}  the word being spoken (API 26+)
     *   {"event":"end"}                    the sentence finished
     *   {"event":"error","code":c}         it refused
     *
     * Android has no pause, so YueDu's pause stops the engine and its resume
     * says the sentence again from its start — the same thing it does for a browser
     * engine that ignores pause().
     */
    public static class Tts {

        public static final String JS_NAME = "YueTts";

        private final WebView host;
        private final Handler ui = new Handler(Looper.getMainLooper());
        private TextToSpeech engine;
        private boolean ready = false;
        private String chosenVoice = null;

        /** Everything the page needs to know about what the engine is doing. */
        private final UtteranceProgressListener progress = new UtteranceProgressListener() {
            @Override public void onStart(String id) {
                fire(id, "{\"event\":\"start\"}");
            }
            @Override public void onDone(String id) {
                fire(id, "{\"event\":\"end\"}");
            }
            @Override public void onError(String id) {
                fire(id, "{\"event\":\"error\",\"code\":-1}");
            }
            @Override public void onError(String id, int code) {
                fire(id, "{\"event\":\"error\",\"code\":" + code + "}");
            }
            @Override public void onRangeStart(String id, int start, int end, int frame) {
                fire(id, "{\"event\":\"range\",\"start\":" + start + ",\"end\":" + end + "}");
            }
        };

        public Tts(WebView webView) {
            host = webView;
            try {
                engine = new TextToSpeech(webView.getContext(), new TextToSpeech.OnInitListener() {
                    @Override public void onInit(int status) {
                        ready = status == TextToSpeech.SUCCESS;
                        if (!ready || engine == null) return;
                        /* The listener is installed once the engine is up: the TTS
                           object refuses most of its calls before that. */
                        try { engine.setOnUtteranceProgressListener(progress); } catch (Throwable ignored) {}
                        try { engine.setLanguage(Locale.getDefault()); } catch (Throwable ignored) {}
                    }
                });
            } catch (Throwable t) {
                Log.w(TAG, "no speech engine available", t);
                engine = null;
            }
        }

        /** Whether the engine came up. YueDu asks once before it relies on it. */
        @JavascriptInterface
        public boolean ready() { return ready && engine != null; }

        /**
         * The device's voices, as [{"name":"…","lang":"en-US"}, …]. YueDu shows
         * these in the TTS settings; each language is a group, the phone's own
         * language first, with "System default" as a real choice.
         */
        @JavascriptInterface
        public String voices() {
            try {
                if (engine == null) return "[]";
                java.util.Set<Voice> set = engine.getVoices();
                if (set == null) return "[]";
                JSONArray arr = new JSONArray();
                for (Voice v : set) {
                    if (v == null) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", v.getName());
                    o.put("lang", v.getLocale() == null ? "" : v.getLocale().toLanguageTag());
                    arr.put(o);
                }
                return arr.toString();
            } catch (Throwable t) {
                return "[]";
            }
        }

        /** Say one sentence. `id` comes back with every callback; `rate` is 0.5-2. */
        @JavascriptInterface
        public void speak(final String id, final String text, final float rate, final String voice) {
            final TextToSpeech t = engine;
            if (t == null || text == null || text.length() == 0) {
                fire(id, "{\"event\":\"error\",\"code\":-1}");
                return;
            }
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (voice != null && voice.length() > 0 && !voice.equals(chosenVoice)) {
                            chosenVoice = voice;
                            java.util.Set<Voice> set = t.getVoices();
                            if (set != null) {
                                for (Voice v : set) {
                                    if (v != null && voice.equals(v.getName())) { t.setVoice(v); break; }
                                }
                            }
                        }
                        t.setSpeechRate(rate > 0 ? rate : 1f);
                        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
                    } catch (Throwable e) {
                        fire(id, "{\"event\":\"error\",\"code\":-2}");
                    }
                }
            });
        }

        /** Stop speaking now (pause and stop are the same thing here). */
        @JavascriptInterface
        public void stop() {
            final TextToSpeech t = engine;
            if (t == null) return;
            ui.post(new Runnable() {
                @Override public void run() { try { t.stop(); } catch (Throwable ignored) {} }
            });
        }

        /** Hand one event back to the page. Called from the engine's own thread. */
        private void fire(String id, String json) {
            final WebView w = host;
            if (w == null || id == null) return;
            final String js = "window.__yueTts(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")";
            ui.post(new Runnable() {
                @Override public void run() {
                    try { w.evaluateJavascript(js, null); } catch (Throwable t) { Log.w(TAG, "tts callback failed", t); }
                }
            });
        }
    }
}
