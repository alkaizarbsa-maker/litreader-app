# YueDu Android app

A complete wrapper project: the YueDu generator page in a WebView, plus
the `YueNative` bridge (`src/android-plugin/YueNative.java`, copied here —
if you change one, copy it to the other). The bridge is raw device HTTP and
can state any header, notably the `Referer` that guarded comic picture hosts
(Toonily, ManhwaTop, MangaPill, LikeManga) demand. That is the same trick the
Kotatsu Android app uses, and it is why chapters that stay blank in a browser
build read here with zero configuration. It also gives read-aloud the
device's own voices and opens bot checks in a real page when a site demands
it. One small AndroidX dependency (swipe-to-refresh); `minSdk 26`.

## Build it in the cloud (recommended — nothing to install)

1. Create a free GitHub account and a new empty repository.
2. Upload **the contents of this folder** (`settings.gradle`, `build.gradle`,
   `app/`, …) to the repository's root, so `settings.gradle` sits at `/`.
3. Move `github-workflows/build-apk.yml` to `.github/workflows/build-apk.yml`
   (GitHub only runs workflows from `.github/workflows/`), and rename
   `gitignore.txt` to `.gitignore`.
4. Open the repository's **Actions** tab → **Build YueDu APK** → the run
   starts by itself (or Run workflow). Wait ~5–10 minutes.
5. Download the `yuedu-apk` artifact, copy it to the phone, tap it to
   install (allow “install unknown apps” once). All builds share one signing
   key (`yuedu-debug.p12`, committed in the repo — do not delete it), so
   every new APK installs over the old one as an update: no uninstall, and
   your library, history and settings carry over.

## Updating (new YueDu version, same install)

Never delete the repository — GitHub overwrites files happily, and a fresh
repo is exactly what breaks updates (new repo, new build numbers).

1. In your repo, open `app/src/main/assets/www/index.html`, delete its
   contents, paste in the new standalone file (or use Add file → Upload
   files and overwrite it), and commit. The workflow rebuilds by itself.
2. Download the new `yuedu-apk` artifact and tap it on the phone. It
   installs as an update over the existing YueDu — same app, same data.

One reset is still owed if the app on your phone came from anywhere else
(a converter build or an older repo build): those carry a different
signature, so Android refuses with “conflicting package”. Export first
(YueDu → More → Export), uninstall once, install the repo build,
re-import. From that build on, step 2 above just works, forever.

## Build it locally

Android Studio → Open → this folder → let it sync (it will offer to set up
the Gradle wrapper if you have none) → Run. Same APK as above.

## Point it at your own fork

The app opens its bundled copy of YueDu (`app/src/main/assets/www/`,
mirrored from `src/standalone/index.html` — re-copy that file and rebuild
whenever the generator changes). To wrap a different address instead, add
one manifest entry and it wins over the bundle:
`<meta-data android:name="com.yuedu.app.URL"
android:value="https://perchance.org/yourfork" />`. A forked generator
keeps working when the original changes, so prefer your own URL.

## Use it as a converter template (e.g. ToApp)

An in-browser APK patcher cannot inject Java code into a prebuilt template —
a JS bridge has to be *compiled in*. This project already is, so it works as
a drop-in template that upgrades every app it stamps out:

1. Build this project once (cloud workflow above) and use the resulting APK
   as the converter's new `template.apk`.
2. Per conversion, the converter only patches what it already patches: the
   package name, the icon, the label — plus `<meta-data>` entries, which is
   exactly what in-browser APK patchers can do. The flags, all optional,
   all default `false` unless set:
   `<meta-data android:name="com.yuedu.app.URL" android:value="https://…"/>`
   (the wrapped address; falls back to the bundled YueDu page),
   `com.yuedu.app.IMMERSIVE` (sticky fullscreen, hides status+nav),
   `com.yuedu.app.DARK_MODE` (force-darkens light web content),
   `com.yuedu.app.EDGE_TO_EDGE` (draws behind transparent system bars),
   `com.yuedu.app.PULL_REFRESH` (swipe-down reloads the page),
   `com.yuedu.app.DESKTOP_SITE` (desktop user-agent). Values accept
   `true`/`false` or `1`/`0`. Keep the existing `YueNative$Challenge`
   activity entry; the manifest patcher must not strip activities.
3. Every produced app then carries the bridge: guarded comic pictures load
   (any page that asks, like YueDu), device voices work for read-aloud,
   and bot checks can open in a real page. Pages that never call it notice
   nothing — the interfaces sit inert.

## Release signing (optional)

Debug builds install and update fine, because every build signs with the
committed `yuedu-debug.p12` and carries a higher version number than
the last. For a Play-style signed release:
`keytool -genkeypair -keystore yuedu.jks -alias yuedu -keyalg RSA
-keysize 2048 -validity 10000`, then add the keystore as a GitHub Actions
secret plus `SIGNING_*` variables and a `signingConfigs` block — any standard
“Android sign APK in GitHub Actions” guide applies unchanged.
(A release-signed app is a different signature from the debug builds, so
switching between them costs one uninstall.)

## Play Store bundle (.aab)

Google Play does not take APKs — it takes an Android App Bundle. This repo
builds one: move `github-workflows/build-bundle.yml` to
`.github/workflows/` alongside the APK workflow (same move as step 3 above),
then run **Build YueDu Bundle** from the Actions tab. The
`yuedu-bundle` artifact holds `app-release.aab`, signed with the same
committed key, so every rebuild uploads as an update of the last.

Upload it in Play Console (Create app → Production → Create new release →
upload the `.aab`). Play App Signing re-signs for users with Google's own
key, so the committed key's "debug" nature never reaches devices — but it
does become the permanent *upload* key for this app, so keep
`yuedu-debug.p12` in the repo exactly like the APK key. First upload
also asks for the usual listing (icon, screenshots, content-rating
questionnaire, privacy policy URL, app category) — none of that lives in
this repo; it is filled in on the Play Console website.

## Checking the bridge works

In YueDu: **More → Connection test → Run test**. With the bridge in
place the rows say `Native bridge: found` and `The app (native): works`.
Then open any Toonily chapter — its pages load with no further setup.

## Notes

- The app opens its bundled YueDu page, so first launch needs no connection
  (reading sites, AI features and the gallery still do); YueDu's own
  offline chapter cache works as usual.
- `YueNative.java` also registers `YueTts` (device speech) and a `challenge`
  screen for bot checks; both are automatic, see
  `src/android-plugin/README.md`.
- Storage folder: `saveFile(reqId, name, mime, base64)` writes small files
  (backups, save exports) into the fixed `Download/YueDu/` folder
  (MediaStore, no permission needed; app-private `YueDu/` below API 29), and
  `folderProbe(reqId)` answers `{ok, exists, count, where}` so the page can
  auto-reuse the folder after a reinstall or data wipe instead of asking,
  and `openFolder(reqId)` answers `{ok, where}` after showing the folder in
  the Files app, so setup ends on something the user can see.
